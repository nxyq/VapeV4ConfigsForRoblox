--This watermark is used to delete the file if its cached, remove it to make the file persist after commits.
HTTP Error Code: 404 Reason: Not Found
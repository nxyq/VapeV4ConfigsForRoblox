--[[

	____  __.                      __                .__  __          
	|    |/ _|______ ___.__._______/  |_  ____   ____ |__|/  |_  ____  
	|      < \_  __ <   |  |\____ \   __\/  _ \ /    \|  \   __\/ __ \ 
	|    |  \ |  | \/\___  ||  |_> >  | (  <_> )   |  \  ||  | \  ___/ 
	|____|__ \|__|   / ____||   __/|__|  \____/|___|  /__||__|  \___  >
			\/       \/     |__|                    \/              \/ 

	Credits:
	.8sty - developer
	SystemXVoid - functions & modules

]]

local GuiLibrary = shared.GuiLibrary
local playersService = game:GetService("Players")
local textService = game:GetService("TextService")
local lightingService = game:GetService("Lighting")
local textChatService = game:GetService("TextChatService")
local inputService = game:GetService("UserInputService")
local runService = game:GetService("RunService")
local tweenService = game:GetService("TweenService")
local collectionService = game:GetService("CollectionService")
local replicatedStorageService = game:GetService("ReplicatedStorage")
local gameCamera = workspace.CurrentCamera
local lplr = playersService.LocalPlayer
local vapeConnections = {}
local vapeCachedAssets = {}
local vapeEvents = setmetatable({}, {
	__index = function(self, index)
		self[index] = Instance.new("BindableEvent")
		return self[index]
	end
})
local vapeTargetInfo = shared.VapeTargetInfo
local vapeInjected = true

local bedwars = {}
local bedwarsStore = {
	attackReach = 0,
	attackReachUpdate = tick(),
	blocks = {},
	blockPlacer = {},
	blockPlace = tick(),
	blockRaycast = RaycastParams.new(),
	equippedKit = "none",
	forgeMasteryPoints = 0,
	forgeUpgrades = {},
	grapple = tick(),
	inventories = {},
	localInventory = {
		inventory = {
			items = {},
			armor = {}
		},
		hotbar = {}
	},
	localHand = {},
	matchState = 0,
	matchStateChanged = tick(),
	pots = {},
	queueType = "bedwars_test",
	scythe = tick(),
	statistics = {
		beds = 0,
		kills = 0,
		lagbacks = 0,
		lagbackEvent = Instance.new("BindableEvent"),
		reported = 0,
		universalLagbacks = 0
	},
	whitelist = {
		chatStrings1 = {helloimusinginhaler = "vape"},
		chatStrings2 = {vape = "helloimusinginhaler"},
		clientUsers = {},
		oldChatFunctions = {}
	},
	zephyrOrb = 0
}
bedwarsStore.blockRaycast.FilterType = Enum.RaycastFilterType.Include
local AutoLeave = {Enabled = false}

table.insert(vapeConnections, workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(function()
	gameCamera = workspace.CurrentCamera or workspace:FindFirstChildWhichIsA("Camera")
end))
local isfile = isfile or function(file)
	local suc, res = pcall(function() return readfile(file) end)
	return suc and res ~= nil
end
local networkownerswitch = tick()
--ME WHEN THE MOBILE EXPLOITS ADD A DISFUNCTIONAL ISNETWORKOWNER (its for compatability I swear!!)
local isnetworkowner = function(part)
	local suc, res = pcall(function() return gethiddenproperty(part, "NetworkOwnershipRule") end)
	if suc and res == Enum.NetworkOwnership.Manual then 
		sethiddenproperty(part, "NetworkOwnershipRule", Enum.NetworkOwnership.Automatic)
		networkownerswitch = tick() + 8
	end
	return networkownerswitch <= tick()
end
local getcustomasset = getsynasset or getcustomasset or function(location) return "rbxasset://"..location end
local queueonteleport = syn and syn.queue_on_teleport or queue_on_teleport or function() end
local synapsev3 = syn and syn.toast_notification and "V3" or ""
local worldtoscreenpoint = function(pos)
	if synapsev3 == "V3" then 
		local scr = worldtoscreen({pos})
		return scr[1] - Vector3.new(0, 36, 0), scr[1].Z > 0
	end
	return gameCamera.WorldToScreenPoint(gameCamera, pos)
end
local worldtoviewportpoint = function(pos)
	if synapsev3 == "V3" then 
		local scr = worldtoscreen({pos})
		return scr[1], scr[1].Z > 0
	end
	return gameCamera.WorldToViewportPoint(gameCamera, pos)
end

local function vapeGithubRequest(scripturl)
	if not isfile("vape/"..scripturl) then
		local suc, res = pcall(function() return game:HttpGet("https://raw.githubusercontent.com/7GrandDadPGN/VapeV4ForRoblox/"..readfile("vape/commithash.txt").."/"..scripturl, true) end)
		assert(suc, res)
		assert(res ~= "404: Not Found", res)
		if scripturl:find(".lua") then res = "--This watermark is used to delete the file if its cached, remove it to make the file persist after commits.\n"..res end
		writefile("vape/"..scripturl, res)
	end
	return readfile("vape/"..scripturl)
end

local function downloadVapeAsset(path)
	if not isfile(path) then
		task.spawn(function()
			local textlabel = Instance.new("TextLabel")
			textlabel.Size = UDim2.new(1, 0, 0, 36)
			textlabel.Text = "Downloading "..path
			textlabel.BackgroundTransparency = 1
			textlabel.TextStrokeTransparency = 0
			textlabel.TextSize = 30
			textlabel.Font = Enum.Font.SourceSans
			textlabel.TextColor3 = Color3.new(1, 1, 1)
			textlabel.Position = UDim2.new(0, 0, 0, -36)
			textlabel.Parent = GuiLibrary.MainGui
			repeat task.wait() until isfile(path)
			textlabel:Destroy()
		end)
		local suc, req = pcall(function() return vapeGithubRequest(path:gsub("vape/assets", "assets")) end)
        if suc and req then
		    writefile(path, req)
        else
            return ""
        end
	end
	if not vapeCachedAssets[path] then vapeCachedAssets[path] = getcustomasset(path) end
	return vapeCachedAssets[path] 
end

local function warningNotification(title, text, delay)
	local suc, res = pcall(function()
		local frame = GuiLibrary.CreateNotification(title, text, delay, "assets/WarningNotification.png")
		frame.Frame.Frame.ImageColor3 = Color3.fromRGB(236, 129, 44)
		return frame
	end)
	return (suc and res)
end

local function runFunction(func) func() end

local function isFriend(plr, recolor)
	if GuiLibrary.ObjectsThatCanBeSaved["Use FriendsToggle"].Api.Enabled then
		local friend = table.find(GuiLibrary.ObjectsThatCanBeSaved.FriendsListTextCircleList.Api.ObjectList, plr.Name)
		friend = friend and GuiLibrary.ObjectsThatCanBeSaved.FriendsListTextCircleList.Api.ObjectListEnabled[friend]
		if recolor then
			friend = friend and GuiLibrary.ObjectsThatCanBeSaved["Recolor visualsToggle"].Api.Enabled
		end
		return friend
	end
	return nil
end

local function isTarget(plr)
	local friend = table.find(GuiLibrary.ObjectsThatCanBeSaved.TargetsListTextCircleList.Api.ObjectList, plr.Name)
	friend = friend and GuiLibrary.ObjectsThatCanBeSaved.TargetsListTextCircleList.Api.ObjectListEnabled[friend]
	return friend
end

local function isVulnerable(plr)
	return plr.Humanoid.Health > 0 and not plr.Character.FindFirstChildWhichIsA(plr.Character, "ForceField")
end

local function getPlayerColor(plr)
	if isFriend(plr, true) then
		return Color3.fromHSV(GuiLibrary.ObjectsThatCanBeSaved["Friends ColorSliderColor"].Api.Hue, GuiLibrary.ObjectsThatCanBeSaved["Friends ColorSliderColor"].Api.Sat, GuiLibrary.ObjectsThatCanBeSaved["Friends ColorSliderColor"].Api.Value)
	end
	return tostring(plr.TeamColor) ~= "White" and plr.TeamColor.Color
end

local function LaunchAngle(v, g, d, h, higherArc)
	local v2 = v * v
	local v4 = v2 * v2
	local root = -math.sqrt(v4 - g*(g*d*d + 2*h*v2))
	return math.atan((v2 + root) / (g * d))
end

local function LaunchDirection(start, target, v, g)
	local horizontal = Vector3.new(target.X - start.X, 0, target.Z - start.Z)
	local h = target.Y - start.Y
	local d = horizontal.Magnitude
	local a = LaunchAngle(v, g, d, h)

	if a ~= a then 
		return g == 0 and (target - start).Unit * v
	end

	local vec = horizontal.Unit * v
	local rotAxis = Vector3.new(-horizontal.Z, 0, horizontal.X)
	return CFrame.fromAxisAngle(rotAxis, a) * vec
end

local physicsUpdate = 1 / 60

local function predictGravity(playerPosition, vel, bulletTime, targetPart, Gravity)
	local estimatedVelocity = vel.Y
	local rootSize = (targetPart.Humanoid.HipHeight + (targetPart.RootPart.Size.Y / 2))
	local velocityCheck = (tick() - targetPart.JumpTick) < 0.2
	vel = vel * physicsUpdate

	for i = 1, math.ceil(bulletTime / physicsUpdate) do 
		if velocityCheck then 
			estimatedVelocity = estimatedVelocity - (Gravity * physicsUpdate)
		else
			estimatedVelocity = 0
			playerPosition = playerPosition + Vector3.new(0, -0.03, 0) -- bw hitreg is so bad that I have to add this LOL
			rootSize = rootSize - 0.03
		end

		local floorDetection = workspace:Raycast(playerPosition, Vector3.new(vel.X, (estimatedVelocity * physicsUpdate) - rootSize, vel.Z), bedwarsStore.blockRaycast)
		if floorDetection then 
			playerPosition = Vector3.new(playerPosition.X, floorDetection.Position.Y + rootSize, playerPosition.Z)
			local bouncepad = floorDetection.Instance:FindFirstAncestor("gumdrop_bounce_pad")
			if bouncepad and bouncepad:GetAttribute("PlacedByUserId") == targetPart.Player.UserId then 
				estimatedVelocity = 130 - (Gravity * physicsUpdate)
				velocityCheck = true
			else
				estimatedVelocity = targetPart.Humanoid.JumpPower - (Gravity * physicsUpdate)
				velocityCheck = targetPart.Jumping
			end
		end

		playerPosition = playerPosition + Vector3.new(vel.X, velocityCheck and estimatedVelocity * physicsUpdate or 0, vel.Z)
	end

	return playerPosition, Vector3.new(0, 0, 0)
end

local entityLibrary = shared.vapeentity
local WhitelistFunctions = shared.vapewhitelist
local RunLoops = {RenderStepTable = {}, StepTable = {}, HeartTable = {}}
do
	function RunLoops:BindToRenderStep(name, func)
		if RunLoops.RenderStepTable[name] == nil then
			RunLoops.RenderStepTable[name] = runService.RenderStepped:Connect(func)
		end
	end

	function RunLoops:UnbindFromRenderStep(name)
		if RunLoops.RenderStepTable[name] then
			RunLoops.RenderStepTable[name]:Disconnect()
			RunLoops.RenderStepTable[name] = nil
		end
	end

	function RunLoops:BindToStepped(name, func)
		if RunLoops.StepTable[name] == nil then
			RunLoops.StepTable[name] = runService.Stepped:Connect(func)
		end
	end

	function RunLoops:UnbindFromStepped(name)
		if RunLoops.StepTable[name] then
			RunLoops.StepTable[name]:Disconnect()
			RunLoops.StepTable[name] = nil
		end
	end

	function RunLoops:BindToHeartbeat(name, func)
		if RunLoops.HeartTable[name] == nil then
			RunLoops.HeartTable[name] = runService.Heartbeat:Connect(func)
		end
	end

	function RunLoops:UnbindFromHeartbeat(name)
		if RunLoops.HeartTable[name] then
			RunLoops.HeartTable[name]:Disconnect()
			RunLoops.HeartTable[name] = nil
		end
	end
end

GuiLibrary.SelfDestructEvent.Event:Connect(function()
	vapeInjected = false
	for i, v in pairs(vapeConnections) do
		if v.Disconnect then pcall(function() v:Disconnect() end) continue end
		if v.disconnect then pcall(function() v:disconnect() end) continue end
	end
end)

local function getItem(itemName, inv)
	for slot, item in pairs(inv or bedwarsStore.localInventory.inventory.items) do
		if item.itemType == itemName then
			return item, slot
		end
	end
	return nil
end

local function getItemNear(itemName, inv)
	for slot, item in pairs(inv or bedwarsStore.localInventory.inventory.items) do
		if item.itemType == itemName or item.itemType:find(itemName) then
			return item, slot
		end
	end
	return nil
end

local function getHotbarSlot(itemName)
	for slotNumber, slotTable in pairs(bedwarsStore.localInventory.hotbar) do
		if slotTable.item and slotTable.item.itemType == itemName then
			return slotNumber - 1
		end
	end
	return nil
end

local function getShieldAttribute(char)
	local returnedShield = 0
	for attributeName, attributeValue in pairs(char:GetAttributes()) do 
		if attributeName:find("Shield") and type(attributeValue) == "number" then 
			returnedShield = returnedShield + attributeValue
		end
	end
	return returnedShield
end

local function getPickaxe()
	return getItemNear("pick")
end

local function getAxe()
	local bestAxe, bestAxeSlot = nil, nil
	for slot, item in pairs(bedwarsStore.localInventory.inventory.items) do
		if item.itemType:find("axe") and item.itemType:find("pickaxe") == nil and item.itemType:find("void") == nil then
			bextAxe, bextAxeSlot = item, slot
		end
	end
	return bestAxe, bestAxeSlot
end

local function getSword()
	local bestSword, bestSwordSlot, bestSwordDamage = nil, nil, 0
	for slot, item in pairs(bedwarsStore.localInventory.inventory.items) do
		local swordMeta = bedwars.ItemTable[item.itemType].sword
		if swordMeta then
			local swordDamage = swordMeta.damage or 0
			if swordDamage > bestSwordDamage then
				bestSword, bestSwordSlot, bestSwordDamage = item, slot, swordDamage
			end
		end
	end
	return bestSword, bestSwordSlot
end

local function getBow()
	local bestBow, bestBowSlot, bestBowStrength = nil, nil, 0
	for slot, item in pairs(bedwarsStore.localInventory.inventory.items) do
		if item.itemType:find("bow") then 
			local tab = bedwars.ItemTable[item.itemType].projectileSource
			local ammo = tab.projectileType("arrow")	
			local dmg = bedwars.ProjectileMeta[ammo].combat.damage
			if dmg > bestBowStrength then
				bestBow, bestBowSlot, bestBowStrength = item, slot, dmg
			end
		end
	end
	return bestBow, bestBowSlot
end

local function getWool()
	local wool = getItemNear("wool")
	return wool and wool.itemType, wool and wool.amount
end

local function getBlock()
	for slot, item in pairs(bedwarsStore.localInventory.inventory.items) do
		if bedwars.ItemTable[item.itemType].block then
			return item.itemType, item.amount
		end
	end
end

local function attackValue(vec)
	return {value = vec}
end

local function getSpeed()
	local speed = 0
	if lplr.Character then 
		local SpeedDamageBoost = lplr.Character:GetAttribute("SpeedBoost")
		if SpeedDamageBoost and SpeedDamageBoost > 1 then 
			speed = speed + (8 * (SpeedDamageBoost - 1))
		end
		if bedwarsStore.grapple > tick() then
			speed = speed + 90
		end
		if bedwarsStore.scythe > tick() then 
			speed = speed + 5
		end
		if lplr.Character:GetAttribute("GrimReaperChannel") then 
			speed = speed + 20
		end
		local armor = bedwarsStore.localInventory.inventory.armor[3]
		if type(armor) ~= "table" then armor = {itemType = ""} end
		if armor.itemType == "speed_boots" then 
			speed = speed + 12
		end
		if bedwarsStore.zephyrOrb ~= 0 then 
			speed = speed + 12
		end
	end
	return speed
end

local Reach = {Enabled = false}
local blacklistedblocks = {
	bed = true,
	ceramic = true
}
local cachedNormalSides = {}
for i,v in pairs(Enum.NormalId:GetEnumItems()) do if v.Name ~= "Bottom" then table.insert(cachedNormalSides, v) end end
local updateitem = Instance.new("BindableEvent")
local inputobj = nil
local tempconnection
tempconnection = inputService.InputBegan:Connect(function(input)
	if input.UserInputType == Enum.UserInputType.MouseButton1 then
		inputobj = input
		tempconnection:Disconnect()
	end
end)
table.insert(vapeConnections, updateitem.Event:Connect(function(inputObj)
	if inputService:IsMouseButtonPressed(0) then
		game:GetService("ContextActionService"):CallFunction("block-break", Enum.UserInputState.Begin, inputobj)
	end
end))

local function getPlacedBlock(pos)
	local roundedPosition = bedwars.BlockController:getBlockPosition(pos)
	return bedwars.BlockController:getStore():getBlockAt(roundedPosition), roundedPosition
end

local oldpos = Vector3.zero

local function getScaffold(vec, diagonaltoggle)
	local realvec = Vector3.new(math.floor((vec.X / 3) + 0.5) * 3, math.floor((vec.Y / 3) + 0.5) * 3, math.floor((vec.Z / 3) + 0.5) * 3) 
	local speedCFrame = (oldpos - realvec)
	local returedpos = realvec
	if entityLibrary.isAlive then
		local angle = math.deg(math.atan2(-entityLibrary.character.Humanoid.MoveDirection.X, -entityLibrary.character.Humanoid.MoveDirection.Z))
		local goingdiagonal = (angle >= 130 and angle <= 150) or (angle <= -35 and angle >= -50) or (angle >= 35 and angle <= 50) or (angle <= -130 and angle >= -150)
		if goingdiagonal and ((speedCFrame.X == 0 and speedCFrame.Z ~= 0) or (speedCFrame.X ~= 0 and speedCFrame.Z == 0)) and diagonaltoggle then
			return oldpos
		end
	end
    return realvec
end

local function getBestTool(block)
	local tool = nil
	local blockmeta = bedwars.ItemTable[block]
	local blockType = blockmeta.block and blockmeta.block.breakType
	if blockType then
		local best = 0
		for i,v in pairs(bedwarsStore.localInventory.inventory.items) do
			local meta = bedwars.ItemTable[v.itemType]
			if meta.breakBlock and meta.breakBlock[blockType] and meta.breakBlock[blockType] >= best then
				best = meta.breakBlock[blockType]
				tool = v
			end
		end
	end
	return tool
end

local function getOpenApps()
	local count = 0
	for i,v in pairs(bedwars.AppController:getOpenApps()) do if (not tostring(v):find("Billboard")) and (not tostring(v):find("GameNametag")) then count = count + 1 end end
	return count
end

local function switchItem(tool)
	if lplr.Character.HandInvItem.Value ~= tool then
		bedwars.ClientHandler:Get(bedwars.EquipItemRemote):CallServerAsync({
			hand = tool
		})
		local started = tick()
		repeat task.wait() until (tick() - started) > 0.3 or lplr.Character.HandInvItem.Value == tool
	end
end

local function switchToAndUseTool(block, legit)
	local tool = getBestTool(block.Name)
	if tool and (entityLibrary.isAlive and lplr.Character:FindFirstChild("HandInvItem") and lplr.Character.HandInvItem.Value ~= tool.tool) then
		if legit then
			if getHotbarSlot(tool.itemType) then
				bedwars.ClientStoreHandler:dispatch({
					type = "InventorySelectHotbarSlot", 
					slot = getHotbarSlot(tool.itemType)
				})
				vapeEvents.InventoryChanged.Event:Wait()
				updateitem:Fire(inputobj)
				return true
			else
				return false
			end
		end
		switchItem(tool.tool)
	end
end

local function isBlockCovered(pos)
	local coveredsides = 0
	for i, v in pairs(cachedNormalSides) do
		local blockpos = (pos + (Vector3.FromNormalId(v) * 3))
		local block = getPlacedBlock(blockpos)
		if block then
			coveredsides = coveredsides + 1
		end
	end
	return coveredsides == #cachedNormalSides
end

local function GetPlacedBlocksNear(pos, normal)
	local blocks = {}
	local lastfound = nil
	for i = 1, 20 do
		local blockpos = (pos + (Vector3.FromNormalId(normal) * (i * 3)))
		local extrablock = getPlacedBlock(blockpos)
		local covered = isBlockCovered(blockpos)
		if extrablock then
			if bedwars.BlockController:isBlockBreakable({blockPosition = blockpos}, lplr) and (not blacklistedblocks[extrablock.Name]) then
				table.insert(blocks, extrablock.Name)
			end
			lastfound = extrablock
			if not covered then
				break
			end
		else
			break
		end
	end
	return blocks
end

local function getLastCovered(pos, normal)
	local lastfound, lastpos = nil, nil
	for i = 1, 20 do
		local blockpos = (pos + (Vector3.FromNormalId(normal) * (i * 3)))
		local extrablock, extrablockpos = getPlacedBlock(blockpos)
		local covered = isBlockCovered(blockpos)
		if extrablock then
			lastfound, lastpos = extrablock, extrablockpos
			if not covered then
				break
			end
		else
			break
		end
	end
	return lastfound, lastpos
end

local function getBestBreakSide(pos)
	local softest, softestside = 9e9, Enum.NormalId.Top
	for i,v in pairs(cachedNormalSides) do
		local sidehardness = 0
		for i2,v2 in pairs(GetPlacedBlocksNear(pos, v)) do	
			local blockmeta = bedwars.ItemTable[v2].block
			sidehardness = sidehardness + (blockmeta and blockmeta.health or 10)
            if blockmeta then
                local tool = getBestTool(v2)
                if tool then
                    sidehardness = sidehardness - bedwars.ItemTable[tool.itemType].breakBlock[blockmeta.breakType]
                end
            end
		end
		if sidehardness <= softest then
			softest = sidehardness
			softestside = v
		end	
	end
	return softestside, softest
end

local function EntityNearPosition(distance, ignore, overridepos)
	local closestEntity, closestMagnitude = nil, distance
	if entityLibrary.isAlive then
		for i, v in pairs(entityLibrary.entityList) do
			if not v.Targetable then continue end
            if isVulnerable(v) then
				local mag = (entityLibrary.character.HumanoidRootPart.Position - v.RootPart.Position).magnitude
				if overridepos and mag > distance then
					mag = (overridepos - v.RootPart.Position).magnitude
				end
                if mag <= closestMagnitude then
					closestEntity, closestMagnitude = v, mag
                end
            end
        end
		if not ignore then
			for i, v in pairs(collectionService:GetTagged("Monster")) do
				if v.PrimaryPart and v:GetAttribute("Team") ~= lplr:GetAttribute("Team") then
					local mag = (entityLibrary.character.HumanoidRootPart.Position - v.PrimaryPart.Position).magnitude
					if overridepos and mag > distance then 
						mag = (overridepos - v2.PrimaryPart.Position).magnitude
					end
					if mag <= closestMagnitude then
						closestEntity, closestMagnitude = {Player = {Name = v.Name, UserId = (v.Name == "Duck" and 2020831224 or 1443379645)}, Character = v, RootPart = v.PrimaryPart, JumpTick = tick() + 5, Jumping = false, Humanoid = {HipHeight = 2}}, mag
					end
				end
			end
			for i, v in pairs(collectionService:GetTagged("DiamondGuardian")) do
				if v.PrimaryPart then
					local mag = (entityLibrary.character.HumanoidRootPart.Position - v.PrimaryPart.Position).magnitude
					if overridepos and mag > distance then 
						mag = (overridepos - v2.PrimaryPart.Position).magnitude
					end
					if mag <= closestMagnitude then
						closestEntity, closestMagnitude = {Player = {Name = "DiamondGuardian", UserId = 1443379645}, Character = v, RootPart = v.PrimaryPart, JumpTick = tick() + 5, Jumping = false, Humanoid = {HipHeight = 2}}, mag
					end
				end
			end
			for i, v in pairs(collectionService:GetTagged("GolemBoss")) do
				if v.PrimaryPart then
					local mag = (entityLibrary.character.HumanoidRootPart.Position - v.PrimaryPart.Position).magnitude
					if overridepos and mag > distance then 
						mag = (overridepos - v2.PrimaryPart.Position).magnitude
					end
					if mag <= closestMagnitude then
						closestEntity, closestMagnitude = {Player = {Name = "GolemBoss", UserId = 1443379645}, Character = v, RootPart = v.PrimaryPart, JumpTick = tick() + 5, Jumping = false, Humanoid = {HipHeight = 2}}, mag
					end
				end
			end
			for i, v in pairs(collectionService:GetTagged("Drone")) do
				if v.PrimaryPart and tonumber(v:GetAttribute("PlayerUserId")) ~= lplr.UserId then
					local droneplr = playersService:GetPlayerByUserId(v:GetAttribute("PlayerUserId"))
					if droneplr and droneplr.Team == lplr.Team then continue end
					local mag = (entityLibrary.character.HumanoidRootPart.Position - v.PrimaryPart.Position).magnitude
					if overridepos and mag > distance then 
						mag = (overridepos - v.PrimaryPart.Position).magnitude
					end
					if mag <= closestMagnitude then -- magcheck
						closestEntity, closestMagnitude = {Player = {Name = "Drone", UserId = 1443379645}, Character = v, RootPart = v.PrimaryPart, JumpTick = tick() + 5, Jumping = false, Humanoid = {HipHeight = 2}}, mag
					end
				end
			end
		end
	end
	return closestEntity
end

local function EntityNearMouse(distance)
	local closestEntity, closestMagnitude = nil, distance
    if entityLibrary.isAlive then
		local mousepos = inputService.GetMouseLocation(inputService)
		for i, v in pairs(entityLibrary.entityList) do
			if not v.Targetable then continue end
            if isVulnerable(v) then
				local vec, vis = worldtoscreenpoint(v.RootPart.Position)
				local mag = (mousepos - Vector2.new(vec.X, vec.Y)).magnitude
                if vis and mag <= closestMagnitude then
					closestEntity, closestMagnitude = v, v.Target and -1 or mag
                end
            end
        end
    end
	return closestEntity
end

local function AllNearPosition(distance, amount, sortfunction, prediction)
	local returnedplayer = {}
	local currentamount = 0
    if entityLibrary.isAlive then
		local sortedentities = {}
		for i, v in pairs(entityLibrary.entityList) do
			if not v.Targetable then continue end
            if isVulnerable(v) then
				local playerPosition = v.RootPart.Position
				local mag = (entityLibrary.character.HumanoidRootPart.Position - playerPosition).magnitude
				if prediction and mag > distance then
					mag = (entityLibrary.LocalPosition - playerPosition).magnitude
				end
                if mag <= distance then
					table.insert(sortedentities, v)
                end
            end
        end
		for i, v in pairs(collectionService:GetTagged("Monster")) do
			if v.PrimaryPart then
				local mag = (entityLibrary.character.HumanoidRootPart.Position - v.PrimaryPart.Position).magnitude
				if prediction and mag > distance then
					mag = (entityLibrary.LocalPosition - v.PrimaryPart.Position).magnitude
				end
                if mag <= distance then
					if v:GetAttribute("Team") == lplr:GetAttribute("Team") then continue end
                    table.insert(sortedentities, {Player = {Name = v.Name, UserId = (v.Name == "Duck" and 2020831224 or 1443379645), GetAttribute = function() return "none" end}, Character = v, RootPart = v.PrimaryPart, Humanoid = v.Humanoid})
                end
			end
		end
		for i, v in pairs(collectionService:GetTagged("DiamondGuardian")) do
			if v.PrimaryPart then
				local mag = (entityLibrary.character.HumanoidRootPart.Position - v.PrimaryPart.Position).magnitude
				if prediction and mag > distance then
					mag = (entityLibrary.LocalPosition - v.PrimaryPart.Position).magnitude
				end
                if mag <= distance then
                    table.insert(sortedentities, {Player = {Name = "DiamondGuardian", UserId = 1443379645, GetAttribute = function() return "none" end}, Character = v, RootPart = v.PrimaryPart, Humanoid = v.Humanoid})
                end
			end
		end
		for i, v in pairs(collectionService:GetTagged("GolemBoss")) do
			if v.PrimaryPart then
				local mag = (entityLibrary.character.HumanoidRootPart.Position - v.PrimaryPart.Position).magnitude
				if prediction and mag > distance then
					mag = (entityLibrary.LocalPosition - v.PrimaryPart.Position).magnitude
				end
                if mag <= distance then
                    table.insert(sortedentities, {Player = {Name = "GolemBoss", UserId = 1443379645, GetAttribute = function() return "none" end}, Character = v, RootPart = v.PrimaryPart, Humanoid = v.Humanoid})
                end
			end
		end
		for i, v in pairs(collectionService:GetTagged("Drone")) do
			if v.PrimaryPart then
				local mag = (entityLibrary.character.HumanoidRootPart.Position - v.PrimaryPart.Position).magnitude
				if prediction and mag > distance then
					mag = (entityLibrary.LocalPosition - v.PrimaryPart.Position).magnitude
				end
                if mag <= distance then
					if tonumber(v:GetAttribute("PlayerUserId")) == lplr.UserId then continue end
					local droneplr = playersService:GetPlayerByUserId(v:GetAttribute("PlayerUserId"))
					if droneplr and droneplr.Team == lplr.Team then continue end
                    table.insert(sortedentities, {Player = {Name = "Drone", UserId = 1443379645}, GetAttribute = function() return "none" end, Character = v, RootPart = v.PrimaryPart, Humanoid = v.Humanoid})
                end
			end
		end
		for i, v in pairs(bedwarsStore.pots) do
			if v.PrimaryPart then
				local mag = (entityLibrary.character.HumanoidRootPart.Position - v.PrimaryPart.Position).magnitude
				if prediction and mag > distance then
					mag = (entityLibrary.LocalPosition - v.PrimaryPart.Position).magnitude
				end
                if mag <= distance then
                    table.insert(sortedentities, {Player = {Name = "Pot", UserId = 1443379645, GetAttribute = function() return "none" end}, Character = v, RootPart = v.PrimaryPart, Humanoid = {Health = 100, MaxHealth = 100}})
                end
			end
		end
		if sortfunction then
			table.sort(sortedentities, sortfunction)
		end
		for i,v in pairs(sortedentities) do 
			table.insert(returnedplayer, v)
			currentamount = currentamount + 1
			if currentamount >= amount then break end
		end
	end
	return returnedplayer
end

--pasted from old source since gui code is hard
local function CreateAutoHotbarGUI(children2, argstable)
	local buttonapi = {}
	buttonapi["Hotbars"] = {}
	buttonapi["CurrentlySelected"] = 1
	local currentanim
	local amount = #children2:GetChildren()
	local sortableitems = {
		{itemType = "swords", itemDisplayType = "diamond_sword"},
		{itemType = "pickaxes", itemDisplayType = "diamond_pickaxe"},
		{itemType = "axes", itemDisplayType = "diamond_axe"},
		{itemType = "shears", itemDisplayType = "shears"},
		{itemType = "wool", itemDisplayType = "wool_white"},
		{itemType = "iron", itemDisplayType = "iron"},
		{itemType = "diamond", itemDisplayType = "diamond"},
		{itemType = "emerald", itemDisplayType = "emerald"},
		{itemType = "bows", itemDisplayType = "wood_bow"},
	}
	local items = bedwars.ItemTable
	if items then
		for i2,v2 in pairs(items) do
			if (i2:find("axe") == nil or i2:find("void")) and i2:find("bow") == nil and i2:find("shears") == nil and i2:find("wool") == nil and v2.sword == nil and v2.armor == nil and v2["dontGiveItem"] == nil and bedwars.ItemTable[i2] and bedwars.ItemTable[i2].image then
				table.insert(sortableitems, {itemType = i2, itemDisplayType = i2})
			end
		end
	end
	local buttontext = Instance.new("TextButton")
	buttontext.AutoButtonColor = false
	buttontext.BackgroundTransparency = 1
	buttontext.Name = "ButtonText"
	buttontext.Text = ""
	buttontext.Name = argstable["Name"]
	buttontext.LayoutOrder = 1
	buttontext.Size = UDim2.new(1, 0, 0, 40)
	buttontext.Active = false
	buttontext.TextColor3 = Color3.fromRGB(162, 162, 162)
	buttontext.TextSize = 17
	buttontext.Font = Enum.Font.SourceSans
	buttontext.Position = UDim2.new(0, 0, 0, 0)
	buttontext.Parent = children2
	local toggleframe2 = Instance.new("Frame")
	toggleframe2.Size = UDim2.new(0, 200, 0, 31)
	toggleframe2.Position = UDim2.new(0, 10, 0, 4)
	toggleframe2.BackgroundColor3 = Color3.fromRGB(38, 37, 38)
	toggleframe2.Name = "ToggleFrame2"
	toggleframe2.Parent = buttontext
	local toggleframe1 = Instance.new("Frame")
	toggleframe1.Size = UDim2.new(0, 198, 0, 29)
	toggleframe1.BackgroundColor3 = Color3.fromRGB(26, 25, 26)
	toggleframe1.BorderSizePixel = 0
	toggleframe1.Name = "ToggleFrame1"
	toggleframe1.Position = UDim2.new(0, 1, 0, 1)
	toggleframe1.Parent = toggleframe2
	local addbutton = Instance.new("ImageLabel")
	addbutton.BackgroundTransparency = 1
	addbutton.Name = "AddButton"
	addbutton.BackgroundColor3 = Color3.fromRGB(20, 20, 20)
	addbutton.Position = UDim2.new(0, 93, 0, 9)
	addbutton.Size = UDim2.new(0, 12, 0, 12)
	addbutton.ImageColor3 = Color3.fromRGB(5, 133, 104)
	addbutton.Image = downloadVapeAsset("vape/assets/AddItem.png")
	addbutton.Parent = toggleframe1
	local children3 = Instance.new("Frame")
	children3.Name = argstable["Name"].."Children"
	children3.BackgroundTransparency = 1
	children3.LayoutOrder = amount
	children3.Size = UDim2.new(0, 220, 0, 0)
	children3.Parent = children2
	local uilistlayout = Instance.new("UIListLayout")
	uilistlayout.Parent = children3
	uilistlayout:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(function()
		children3.Size = UDim2.new(1, 0, 0, uilistlayout.AbsoluteContentSize.Y)
	end)
	local uicorner = Instance.new("UICorner")
	uicorner.CornerRadius = UDim.new(0, 5)
	uicorner.Parent = toggleframe1
	local uicorner2 = Instance.new("UICorner")
	uicorner2.CornerRadius = UDim.new(0, 5)
	uicorner2.Parent = toggleframe2
	buttontext.MouseEnter:Connect(function()
		tweenService:Create(toggleframe2, TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut), {BackgroundColor3 = Color3.fromRGB(79, 78, 79)}):Play()
	end)
	buttontext.MouseLeave:Connect(function()
		tweenService:Create(toggleframe2, TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut), {BackgroundColor3 = Color3.fromRGB(38, 37, 38)}):Play()
	end)
	local ItemListBigFrame = Instance.new("Frame")
	ItemListBigFrame.Size = UDim2.new(1, 0, 1, 0)
	ItemListBigFrame.Name = "ItemList"
	ItemListBigFrame.BackgroundTransparency = 1
	ItemListBigFrame.Visible = false
	ItemListBigFrame.Parent = GuiLibrary.MainGui
	local ItemListFrame = Instance.new("Frame")
	ItemListFrame.Size = UDim2.new(0, 660, 0, 445)
	ItemListFrame.Position = UDim2.new(0.5, -330, 0.5, -223)
	ItemListFrame.BackgroundColor3 = Color3.fromRGB(26, 25, 26)
	ItemListFrame.Parent = ItemListBigFrame
	local ItemListExitButton = Instance.new("ImageButton")
	ItemListExitButton.Name = "ItemListExitButton"
	ItemListExitButton.ImageColor3 = Color3.fromRGB(121, 121, 121)
	ItemListExitButton.Size = UDim2.new(0, 24, 0, 24)
	ItemListExitButton.AutoButtonColor = false
	ItemListExitButton.Image = downloadVapeAsset("vape/assets/ExitIcon1.png")
	ItemListExitButton.Visible = true
	ItemListExitButton.Position = UDim2.new(1, -31, 0, 8)
	ItemListExitButton.BackgroundColor3 = Color3.fromRGB(26, 25, 26)
	ItemListExitButton.Parent = ItemListFrame
	local ItemListExitButtonround = Instance.new("UICorner")
	ItemListExitButtonround.CornerRadius = UDim.new(0, 16)
	ItemListExitButtonround.Parent = ItemListExitButton
	ItemListExitButton.MouseEnter:Connect(function()
		tweenService:Create(ItemListExitButton, TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut), {BackgroundColor3 = Color3.fromRGB(60, 60, 60), ImageColor3 = Color3.fromRGB(255, 255, 255)}):Play()
	end)
	ItemListExitButton.MouseLeave:Connect(function()
		tweenService:Create(ItemListExitButton, TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut), {BackgroundColor3 = Color3.fromRGB(26, 25, 26), ImageColor3 = Color3.fromRGB(121, 121, 121)}):Play()
	end)
	ItemListExitButton.MouseButton1Click:Connect(function()
		ItemListBigFrame.Visible = false
		GuiLibrary.MainGui.ScaledGui.ClickGui.Visible = true
	end)
	local ItemListFrameShadow = Instance.new("ImageLabel")
	ItemListFrameShadow.AnchorPoint = Vector2.new(0.5, 0.5)
	ItemListFrameShadow.Position = UDim2.new(0.5, 0, 0.5, 0)
	ItemListFrameShadow.Image = downloadVapeAsset("vape/assets/WindowBlur.png")
	ItemListFrameShadow.BackgroundTransparency = 1
	ItemListFrameShadow.ZIndex = -1
	ItemListFrameShadow.Size = UDim2.new(1, 6, 1, 6)
	ItemListFrameShadow.ImageColor3 = Color3.new(0, 0, 0)
	ItemListFrameShadow.ScaleType = Enum.ScaleType.Slice
	ItemListFrameShadow.SliceCenter = Rect.new(10, 10, 118, 118)
	ItemListFrameShadow.Parent = ItemListFrame
	local ItemListFrameText = Instance.new("TextLabel")
	ItemListFrameText.Size = UDim2.new(1, 0, 0, 41)
	ItemListFrameText.BackgroundTransparency = 1
	ItemListFrameText.Name = "WindowTitle"
	ItemListFrameText.Position = UDim2.new(0, 0, 0, 0)
	ItemListFrameText.TextXAlignment = Enum.TextXAlignment.Left
	ItemListFrameText.Font = Enum.Font.SourceSans
	ItemListFrameText.TextSize = 17
	ItemListFrameText.Text = "    New AutoHotbar"
	ItemListFrameText.TextColor3 = Color3.fromRGB(201, 201, 201)
	ItemListFrameText.Parent = ItemListFrame
	local ItemListBorder1 = Instance.new("Frame")
	ItemListBorder1.BackgroundColor3 = Color3.fromRGB(40, 39, 40)
	ItemListBorder1.BorderSizePixel = 0
	ItemListBorder1.Size = UDim2.new(1, 0, 0, 1)
	ItemListBorder1.Position = UDim2.new(0, 0, 0, 41)
	ItemListBorder1.Parent = ItemListFrame
	local ItemListFrameCorner = Instance.new("UICorner")
	ItemListFrameCorner.CornerRadius = UDim.new(0, 4)
	ItemListFrameCorner.Parent = ItemListFrame
	local ItemListFrame1 = Instance.new("Frame")
	ItemListFrame1.Size = UDim2.new(0, 112, 0, 113)
	ItemListFrame1.Position = UDim2.new(0, 10, 0, 71)
	ItemListFrame1.BackgroundColor3 = Color3.fromRGB(38, 37, 38)
	ItemListFrame1.Name = "ItemListFrame1"
	ItemListFrame1.Parent = ItemListFrame
	local ItemListFrame2 = Instance.new("Frame")
	ItemListFrame2.Size = UDim2.new(0, 110, 0, 111)
	ItemListFrame2.BackgroundColor3 = Color3.fromRGB(20, 20, 20)
	ItemListFrame2.BorderSizePixel = 0
	ItemListFrame2.Name = "ItemListFrame2"
	ItemListFrame2.Position = UDim2.new(0, 1, 0, 1)
	ItemListFrame2.Parent = ItemListFrame1
	local ItemListFramePicker = Instance.new("ScrollingFrame")
	ItemListFramePicker.Size = UDim2.new(0, 495, 0, 220)
	ItemListFramePicker.Position = UDim2.new(0, 144, 0, 122)
	ItemListFramePicker.BorderSizePixel = 0
	ItemListFramePicker.ScrollBarThickness = 3
	ItemListFramePicker.ScrollBarImageTransparency = 0.8
	ItemListFramePicker.VerticalScrollBarInset = Enum.ScrollBarInset.None
	ItemListFramePicker.BackgroundTransparency = 1
	ItemListFramePicker.Parent = ItemListFrame
	local ItemListFramePickerGrid = Instance.new("UIGridLayout")
	ItemListFramePickerGrid.CellPadding = UDim2.new(0, 4, 0, 3)
	ItemListFramePickerGrid.CellSize = UDim2.new(0, 51, 0, 52)
	ItemListFramePickerGrid.Parent = ItemListFramePicker
	ItemListFramePickerGrid:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(function()
		ItemListFramePicker.CanvasSize = UDim2.new(0, 0, 0, ItemListFramePickerGrid.AbsoluteContentSize.Y * (1 / GuiLibrary["MainRescale"].Scale))
	end)
	local ItemListcorner = Instance.new("UICorner")
	ItemListcorner.CornerRadius = UDim.new(0, 5)
	ItemListcorner.Parent = ItemListFrame1
	local ItemListcorner2 = Instance.new("UICorner")
	ItemListcorner2.CornerRadius = UDim.new(0, 5)
	ItemListcorner2.Parent = ItemListFrame2
	local selectedslot = 1
	local hoveredslot = 0
	
	local refreshslots
	local refreshList
	refreshslots = function()
		local startnum = 144
		local oldhovered = hoveredslot
		for i2,v2 in pairs(ItemListFrame:GetChildren()) do
			if v2.Name:find("ItemSlot") then
				v2:Remove()
			end
		end
		for i3,v3 in pairs(ItemListFramePicker:GetChildren()) do
			if v3:IsA("TextButton") then
				v3:Remove()
			end
		end
		for i4,v4 in pairs(sortableitems) do
			local ItemFrame = Instance.new("TextButton")
			ItemFrame.Text = ""
			ItemFrame.BackgroundColor3 = Color3.fromRGB(31, 30, 31)
			ItemFrame.Parent = ItemListFramePicker
			ItemFrame.AutoButtonColor = false
			local ItemFrameIcon = Instance.new("ImageLabel")
			ItemFrameIcon.Size = UDim2.new(0, 32, 0, 32)
			ItemFrameIcon.Image = bedwars.getIcon({itemType = v4.itemDisplayType}, true) 
			ItemFrameIcon.ResampleMode = (bedwars.getIcon({itemType = v4.itemDisplayType}, true):find("rbxasset://") and Enum.ResamplerMode.Pixelated or Enum.ResamplerMode.Default)
			ItemFrameIcon.Position = UDim2.new(0, 10, 0, 10)
			ItemFrameIcon.BackgroundTransparency = 1
			ItemFrameIcon.Parent = ItemFrame
			local ItemFramecorner = Instance.new("UICorner")
			ItemFramecorner.CornerRadius = UDim.new(0, 5)
			ItemFramecorner.Parent = ItemFrame
			ItemFrame.MouseButton1Click:Connect(function()
				for i5,v5 in pairs(buttonapi["Hotbars"][buttonapi["CurrentlySelected"]]["Items"]) do
					if v5.itemType == v4.itemType then
						buttonapi["Hotbars"][buttonapi["CurrentlySelected"]]["Items"][tostring(i5)] = nil
					end
				end
				buttonapi["Hotbars"][buttonapi["CurrentlySelected"]]["Items"][tostring(selectedslot)] = v4
				refreshslots()
				refreshList()
			end)
		end
		for i = 1, 9 do
			local item = buttonapi["Hotbars"][buttonapi["CurrentlySelected"]]["Items"][tostring(i)]
			local ItemListFrame3 = Instance.new("Frame")
			ItemListFrame3.Size = UDim2.new(0, 55, 0, 56)
			ItemListFrame3.Position = UDim2.new(0, startnum - 2, 0, 380)
			ItemListFrame3.BackgroundTransparency = (selectedslot == i and 0 or 1)
			ItemListFrame3.BackgroundColor3 = Color3.fromRGB(35, 34, 35)
			ItemListFrame3.Name = "ItemSlot"
			ItemListFrame3.Parent = ItemListFrame
			local ItemListFrame4 = Instance.new("TextButton")
			ItemListFrame4.Size = UDim2.new(0, 51, 0, 52)
			ItemListFrame4.BackgroundColor3 = (oldhovered == i and Color3.fromRGB(31, 30, 31) or Color3.fromRGB(20, 20, 20))
			ItemListFrame4.BorderSizePixel = 0
			ItemListFrame4.AutoButtonColor = false
			ItemListFrame4.Text = ""
			ItemListFrame4.Name = "ItemListFrame4"
			ItemListFrame4.Position = UDim2.new(0, 2, 0, 2)
			ItemListFrame4.Parent = ItemListFrame3
			local ItemListImage = Instance.new("ImageLabel")
			ItemListImage.Size = UDim2.new(0, 32, 0, 32)
			ItemListImage.BackgroundTransparency = 1
			local img = (item and bedwars.getIcon({itemType = item.itemDisplayType}, true) or "")
			ItemListImage.Image = img
			ItemListImage.ResampleMode = (img:find("rbxasset://") and Enum.ResamplerMode.Pixelated or Enum.ResamplerMode.Default)
			ItemListImage.Position = UDim2.new(0, 10, 0, 10)
			ItemListImage.Parent = ItemListFrame4
			local ItemListcorner3 = Instance.new("UICorner")
			ItemListcorner3.CornerRadius = UDim.new(0, 5)
			ItemListcorner3.Parent = ItemListFrame3
			local ItemListcorner4 = Instance.new("UICorner")
			ItemListcorner4.CornerRadius = UDim.new(0, 5)
			ItemListcorner4.Parent = ItemListFrame4
			ItemListFrame4.MouseEnter:Connect(function()
				ItemListFrame4.BackgroundColor3 = Color3.fromRGB(31, 30, 31)
				hoveredslot = i
			end)
			ItemListFrame4.MouseLeave:Connect(function()
				ItemListFrame4.BackgroundColor3 = Color3.fromRGB(20, 20, 20)
				hoveredslot = 0
			end)
			ItemListFrame4.MouseButton1Click:Connect(function()
				selectedslot = i
				refreshslots()
			end)
			ItemListFrame4.MouseButton2Click:Connect(function()
				buttonapi["Hotbars"][buttonapi["CurrentlySelected"]]["Items"][tostring(i)] = nil
				refreshslots()
				refreshList()
			end)
			startnum = startnum + 55
		end
	end	

	local function createHotbarButton(num, items)
		num = tonumber(num) or #buttonapi["Hotbars"] + 1
		local hotbarbutton = Instance.new("TextButton")
		hotbarbutton.Size = UDim2.new(1, 0, 0, 30)
		hotbarbutton.BackgroundTransparency = 1
		hotbarbutton.LayoutOrder = num
		hotbarbutton.AutoButtonColor = false
		hotbarbutton.Text = ""
		hotbarbutton.Parent = children3
		buttonapi["Hotbars"][num] = {["Items"] = items or {}, Object = hotbarbutton, ["Number"] = num}
		local hotbarframe = Instance.new("Frame")
		hotbarframe.BackgroundColor3 = (num == buttonapi["CurrentlySelected"] and Color3.fromRGB(54, 53, 54) or Color3.fromRGB(31, 30, 31))
		hotbarframe.Size = UDim2.new(0, 200, 0, 27)
		hotbarframe.Position = UDim2.new(0, 10, 0, 1)
		hotbarframe.Parent = hotbarbutton
		local uicorner3 = Instance.new("UICorner")
		uicorner3.CornerRadius = UDim.new(0, 5)
		uicorner3.Parent = hotbarframe
		local startpos = 11
		for i = 1, 9 do
			local item = buttonapi["Hotbars"][num]["Items"][tostring(i)]
			local hotbarbox = Instance.new("ImageLabel")
			hotbarbox.Name = i
			hotbarbox.Size = UDim2.new(0, 17, 0, 18)
			hotbarbox.Position = UDim2.new(0, startpos, 0, 5)
			hotbarbox.BorderSizePixel = 0
			hotbarbox.Image = (item and bedwars.getIcon({itemType = item.itemDisplayType}, true) or "")
			hotbarbox.ResampleMode = ((item and bedwars.getIcon({itemType = item.itemDisplayType}, true) or ""):find("rbxasset://") and Enum.ResamplerMode.Pixelated or Enum.ResamplerMode.Default)
			hotbarbox.BackgroundColor3 = Color3.fromRGB(20, 20, 20)
			hotbarbox.Parent = hotbarframe
			startpos = startpos + 18
		end
		hotbarbutton.MouseButton1Click:Connect(function()
			if buttonapi["CurrentlySelected"] == num then
				ItemListBigFrame.Visible = true
				GuiLibrary.MainGui.ScaledGui.ClickGui.Visible = false
				refreshslots()
			end
			buttonapi["CurrentlySelected"] = num
			refreshList()
		end)
		hotbarbutton.MouseButton2Click:Connect(function()
			if buttonapi["CurrentlySelected"] == num then
				buttonapi["CurrentlySelected"] = (num == 2 and 0 or 1)
			end
			table.remove(buttonapi["Hotbars"], num)
			refreshList()
		end)
	end

	refreshList = function()
		local newnum = 0
		local newtab = {}
		for i3,v3 in pairs(buttonapi["Hotbars"]) do
			newnum = newnum + 1
			newtab[newnum] = v3
		end
		buttonapi["Hotbars"] = newtab
		for i,v in pairs(children3:GetChildren()) do
			if v:IsA("TextButton") then
				v:Remove()
			end
		end
		for i2,v2 in pairs(buttonapi["Hotbars"]) do
			createHotbarButton(i2, v2["Items"])
		end
		GuiLibrary["Settings"][children2.Name..argstable["Name"].."ItemList"] = {["Type"] = "ItemList", ["Items"] = buttonapi["Hotbars"], ["CurrentlySelected"] = buttonapi["CurrentlySelected"]}
	end
	buttonapi["RefreshList"] = refreshList

	buttontext.MouseButton1Click:Connect(function()
		createHotbarButton()
	end)

	GuiLibrary["Settings"][children2.Name..argstable["Name"].."ItemList"] = {["Type"] = "ItemList", ["Items"] = buttonapi["Hotbars"], ["CurrentlySelected"] = buttonapi["CurrentlySelected"]}
	GuiLibrary.ObjectsThatCanBeSaved[children2.Name..argstable["Name"].."ItemList"] = {["Type"] = "ItemList", ["Items"] = buttonapi["Hotbars"], ["Api"] = buttonapi, Object = buttontext}

	return buttonapi
end

GuiLibrary.LoadSettingsEvent.Event:Connect(function(res)
	for i,v in pairs(res) do
		local obj = GuiLibrary.ObjectsThatCanBeSaved[i]
		if obj and v.Type == "ItemList" and obj.Api then
			obj.Api.Hotbars = v.Items
			obj.Api.CurrentlySelected = v.CurrentlySelected
			obj.Api.RefreshList()
		end
	end
end)

runFunction(function()
	local function getWhitelistedBed(bed)
		if bed then
			for i,v in pairs(playersService:GetPlayers()) do
				if v:GetAttribute("Team") and bed and bed:GetAttribute("Team"..(v:GetAttribute("Team") or 0).."NoBreak") then
					local plrtype, plrattackable = WhitelistFunctions:GetWhitelist(v)
					if not plrattackable then 
						return true
					end
				end
			end
		end
		return false
	end

	local function dumpRemote(tab)
		for i,v in pairs(tab) do
			if v == "Client" then
				return tab[i + 1]
			end
		end
		return ""
	end

	local KnitGotten, KnitClient
	repeat
		KnitGotten, KnitClient = pcall(function()
			return debug.getupvalue(require(lplr.PlayerScripts.TS.knit).setup, 6)
		end)
		if KnitGotten then break end
		task.wait()
	until KnitGotten
	repeat task.wait() until debug.getupvalue(KnitClient.Start, 1)
	local Flamework = require(replicatedStorageService["rbxts_include"]["node_modules"]["@flamework"].core.out).Flamework
	local Client = require(replicatedStorageService.TS.remotes).default.Client
	local InventoryUtil = require(replicatedStorageService.TS.inventory["inventory-util"]).InventoryUtil
	local oldRemoteGet = getmetatable(Client).Get

	getmetatable(Client).Get = function(self, remoteName)
		if not vapeInjected then return oldRemoteGet(self, remoteName) end
		local originalRemote = oldRemoteGet(self, remoteName)
		if remoteName == "DamageBlock" then
			return {
				CallServerAsync = function(self, tab)
					local hitBlock = bedwars.BlockController:getStore():getBlockAt(tab.blockRef.blockPosition)
					if hitBlock and hitBlock.Name == "bed" then
						if getWhitelistedBed(hitBlock) then
							return {andThen = function(self, func) 
								func("failed")
							end}
						end
					end
					return originalRemote:CallServerAsync(tab)
				end,
				CallServer = function(self, tab)
					local hitBlock = bedwars.BlockController:getStore():getBlockAt(tab.blockRef.blockPosition)
					if hitBlock and hitBlock.Name == "bed" then
						if getWhitelistedBed(hitBlock) then
							return {andThen = function(self, func) 
								func("failed")
							end}
						end
					end
					return originalRemote:CallServer(tab)
				end
			}
		elseif remoteName == bedwars.AttackRemote then
			return {
				instance = originalRemote.instance,
				SendToServer = function(self, attackTable, ...)
					local suc, plr = pcall(function() return playersService:GetPlayerFromCharacter(attackTable.entityInstance) end)
					if suc and plr then
						local playertype, playerattackable = WhitelistFunctions:GetWhitelist(plr)
						if not playerattackable then 
							return nil 
						end
						if Reach.Enabled then
							local attackMagnitude = ((entityLibrary.LocalPosition or entityLibrary.character.HumanoidRootPart.Position) - attackTable.validate.targetPosition.value).magnitude
							if attackMagnitude > 18 then
								return nil 
							end
							attackTable.validate.selfPosition = attackValue(attackTable.validate.selfPosition.value + (attackMagnitude > 14.4 and (CFrame.lookAt(attackTable.validate.selfPosition.value, attackTable.validate.targetPosition.value).lookVector * 4) or Vector3.zero))
						end
						bedwarsStore.attackReach = math.floor((attackTable.validate.selfPosition.value - attackTable.validate.targetPosition.value).magnitude * 100) / 100
						bedwarsStore.attackReachUpdate = tick() + 1
					end
					return originalRemote:SendToServer(attackTable, ...)
				end
			}
		end
		return originalRemote
	end

	bedwars = {
		AnimationType = require(replicatedStorageService.TS.animation["animation-type"]).AnimationType,
		AnimationUtil = require(replicatedStorageService["rbxts_include"]["node_modules"]["@easy-games"]["game-core"].out["shared"].util["animation-util"]).AnimationUtil,
		AppController = require(replicatedStorageService["rbxts_include"]["node_modules"]["@easy-games"]["game-core"].out.client.controllers["app-controller"]).AppController,
		AbilityController = Flamework.resolveDependency("@easy-games/game-core:client/controllers/ability/ability-controller@AbilityController"),
		AbilityUIController = 	Flamework.resolveDependency("@easy-games/game-core:client/controllers/ability/ability-ui-controller@AbilityUIController"),
		AttackRemote = dumpRemote(debug.getconstants(KnitClient.Controllers.SwordController.sendServerRequest)),
		BalloonController = KnitClient.Controllers.BalloonController,
		BalanceFile = require(replicatedStorageService.TS.balance["balance-file"]).BalanceFile,
		BatteryEffectController = KnitClient.Controllers.BatteryEffectsController,
		BatteryRemote = dumpRemote(debug.getconstants(debug.getproto(debug.getproto(KnitClient.Controllers.BatteryController.KnitStart, 1), 1))),
		BlockBreaker = KnitClient.Controllers.BlockBreakController.blockBreaker,
		BlockController = require(replicatedStorageService["rbxts_include"]["node_modules"]["@easy-games"]["block-engine"].out).BlockEngine,
		BlockCpsController = KnitClient.Controllers.BlockCpsController,
		BlockPlacer = require(replicatedStorageService["rbxts_include"]["node_modules"]["@easy-games"]["block-engine"].out.client.placement["block-placer"]).BlockPlacer,
		BlockEngine = require(lplr.PlayerScripts.TS.lib["block-engine"]["client-block-engine"]).ClientBlockEngine,
		BlockEngineClientEvents = require(replicatedStorageService["rbxts_include"]["node_modules"]["@easy-games"]["block-engine"].out.client["block-engine-client-events"]).BlockEngineClientEvents,
		BlockPlacementController = KnitClient.Controllers.BlockPlacementController,
		BowConstantsTable = debug.getupvalue(KnitClient.Controllers.ProjectileController.enableBeam, 6),
		ProjectileController = KnitClient.Controllers.ProjectileController,
		ChestController = KnitClient.Controllers.ChestController,
		CannonHandController = KnitClient.Controllers.CannonHandController,
		CannonAimRemote = dumpRemote(debug.getconstants(debug.getproto(KnitClient.Controllers.CannonController.startAiming, 5))),
		CannonLaunchRemote = dumpRemote(debug.getconstants(KnitClient.Controllers.CannonHandController.launchSelf)),
		ClickHold = require(replicatedStorageService["rbxts_include"]["node_modules"]["@easy-games"]["game-core"].out.client.ui.lib.util["click-hold"]).ClickHold,
		ClientHandler = Client,
		ClientConstructor = require(replicatedStorageService["rbxts_include"]["node_modules"]["@rbxts"].net.out.client),
		ClientHandlerDamageBlock = require(replicatedStorageService["rbxts_include"]["node_modules"]["@easy-games"]["block-engine"].out.shared.remotes).BlockEngineRemotes.Client,
		ClientStoreHandler = require(lplr.PlayerScripts.TS.ui.store).ClientStore,
		CombatConstant = require(replicatedStorageService.TS.combat["combat-constant"]).CombatConstant,
		CombatController = KnitClient.Controllers.CombatController,
		ConstantManager = require(replicatedStorageService["rbxts_include"]["node_modules"]["@easy-games"]["game-core"].out["shared"].constant["constant-manager"]).ConstantManager,
		ConsumeSoulRemote = dumpRemote(debug.getconstants(KnitClient.Controllers.GrimReaperController.consumeSoul)),
		CooldownController = Flamework.resolveDependency("@easy-games/game-core:client/controllers/cooldown/cooldown-controller@CooldownController"),
		DamageIndicator = KnitClient.Controllers.DamageIndicatorController.spawnDamageIndicator,
		DamageIndicatorController = KnitClient.Controllers.DamageIndicatorController,
		DefaultKillEffect = require(lplr.PlayerScripts.TS.controllers.game.locker["kill-effect"].effects["default-kill-effect"]),
		DropItem = KnitClient.Controllers.ItemDropController.dropItemInHand,
		DropItemRemote = dumpRemote(debug.getconstants(KnitClient.Controllers.ItemDropController.dropItemInHand)),
		DragonSlayerController = KnitClient.Controllers.DragonSlayerController,
		DragonRemote = dumpRemote(debug.getconstants(debug.getproto(debug.getproto(KnitClient.Controllers.DragonSlayerController.KnitStart, 2), 1))),
		EatRemote = dumpRemote(debug.getconstants(debug.getproto(KnitClient.Controllers.ConsumeController.onEnable, 1))),
		EquipItemRemote = dumpRemote(debug.getconstants(debug.getproto(require(replicatedStorageService.TS.entity.entities["inventory-entity"]).InventoryEntity.equipItem, 3))),
		EmoteMeta = require(replicatedStorageService.TS.locker.emote["emote-meta"]).EmoteMeta,
		FishermanTable = KnitClient.Controllers.FishermanController,
		FovController = KnitClient.Controllers.FovController,
		ForgeController = KnitClient.Controllers.ForgeController,
		ForgeConstants = debug.getupvalue(KnitClient.Controllers.ForgeController.getPurchaseableForgeUpgrades, 2),
		ForgeUtil = debug.getupvalue(KnitClient.Controllers.ForgeController.getPurchaseableForgeUpgrades, 5),
		GameAnimationUtil = require(replicatedStorageService.TS.animation["animation-util"]).GameAnimationUtil,
		EntityUtil = require(replicatedStorageService.TS.entity["entity-util"]).EntityUtil,
		getIcon = function(item, showinv)
			local itemmeta = bedwars.ItemTable[item.itemType]
			if itemmeta and showinv then
				return itemmeta.image or ""
			end
			return ""
		end,
		getInventory = function(plr)
			local suc, result = pcall(function() 
				return InventoryUtil.getInventory(plr) 
			end)
			return (suc and result or {
				items = {},
				armor = {},
				hand = nil
			})
		end,
		GrimReaperController = KnitClient.Controllers.GrimReaperController,
		GuitarHealRemote = dumpRemote(debug.getconstants(KnitClient.Controllers.GuitarController.performHeal)),
		HangGliderController = KnitClient.Controllers.HangGliderController,
		HighlightController = KnitClient.Controllers.EntityHighlightController,
		ItemTable = debug.getupvalue(require(replicatedStorageService.TS.item["item-meta"]).getItemMeta, 1),
		InfernalShieldController = KnitClient.Controllers.InfernalShieldController,
		KatanaController = KnitClient.Controllers.DaoController,
		KillEffectMeta = require(replicatedStorageService.TS.locker["kill-effect"]["kill-effect-meta"]).KillEffectMeta,
		KillEffectController = KnitClient.Controllers.KillEffectController,
		KnockbackUtil = require(replicatedStorageService.TS.damage["knockback-util"]).KnockbackUtil,
		LobbyClientEvents = KnitClient.Controllers.QueueController,
		MapController = KnitClient.Controllers.MapController,
		MatchEndScreenController = Flamework.resolveDependency("client/controllers/game/match/match-end-screen-controller@MatchEndScreenController"),
		MinerRemote = dumpRemote(debug.getconstants(debug.getproto(KnitClient.Controllers.MinerController.onKitEnabled, 1))),
		MageRemote = dumpRemote(debug.getconstants(debug.getproto(KnitClient.Controllers.MageController.registerTomeInteraction, 1))),
		MageKitUtil = require(replicatedStorageService.TS.games.bedwars.kit.kits.mage["mage-kit-util"]).MageKitUtil,
		MageController = KnitClient.Controllers.MageController,
		MissileController = KnitClient.Controllers.GuidedProjectileController,
		PickupMetalRemote = dumpRemote(debug.getconstants(debug.getproto(debug.getproto(KnitClient.Controllers.MetalDetectorController.KnitStart, 1), 2))),
		PickupRemote = dumpRemote(debug.getconstants(KnitClient.Controllers.ItemDropController.checkForPickup)),
		ProjectileMeta = require(replicatedStorageService.TS.projectile["projectile-meta"]).ProjectileMeta,
		ProjectileRemote = dumpRemote(debug.getconstants(debug.getupvalue(KnitClient.Controllers.ProjectileController.launchProjectileWithValues, 2))),
		QueryUtil = require(replicatedStorageService["rbxts_include"]["node_modules"]["@easy-games"]["game-core"].out).GameQueryUtil,
		QueueCard = require(lplr.PlayerScripts.TS.controllers.global.queue.ui["queue-card"]).QueueCard,
		QueueMeta = require(replicatedStorageService.TS.game["queue-meta"]).QueueMeta,
		RavenTable = KnitClient.Controllers.RavenController,
		RelicController = KnitClient.Controllers.RelicVotingController,
		ReportRemote = dumpRemote(debug.getconstants(require(lplr.PlayerScripts.TS.controllers.global.report["report-controller"]).default.reportPlayer)),
		ResetRemote = dumpRemote(debug.getconstants(debug.getproto(KnitClient.Controllers.ResetController.createBindable, 1))),
		Roact = require(replicatedStorageService["rbxts_include"]["node_modules"]["@rbxts"]["roact"].src),
		RuntimeLib = require(replicatedStorageService["rbxts_include"].RuntimeLib),
		ScytheController = KnitClient.Controllers.ScytheController,
		Shop = require(replicatedStorageService.TS.games.bedwars.shop["bedwars-shop"]).BedwarsShop,
		ShopItems = debug.getupvalue(debug.getupvalue(require(replicatedStorageService.TS.games.bedwars.shop["bedwars-shop"]).BedwarsShop.getShopItem, 1), 3),
		SoundList = require(replicatedStorageService.TS.sound["game-sound"]).GameSound,
		SoundManager = require(replicatedStorageService["rbxts_include"]["node_modules"]["@easy-games"]["game-core"].out).SoundManager,
		SpawnRavenRemote = dumpRemote(debug.getconstants(KnitClient.Controllers.RavenController.spawnRaven)),
		SprintController = KnitClient.Controllers.SprintController,
		StopwatchController = KnitClient.Controllers.StopwatchController,
		SwordController = KnitClient.Controllers.SwordController,
		TreeRemote = dumpRemote(debug.getconstants(debug.getproto(debug.getproto(KnitClient.Controllers.BigmanController.KnitStart, 1), 2))),
		TrinityRemote = dumpRemote(debug.getconstants(debug.getproto(KnitClient.Controllers.AngelController.onKitEnabled, 1))),
		TopBarController = KnitClient.Controllers.TopBarController,
		ViewmodelController = KnitClient.Controllers.ViewmodelController,
		WeldTable = require(replicatedStorageService.TS.util["weld-util"]).WeldUtil,
		ZephyrController = KnitClient.Controllers.WindWalkerController
	}

	bedwarsStore.blockPlacer = bedwars.BlockPlacer.new(bedwars.BlockEngine, "wool_white")
	bedwars.placeBlock = function(speedCFrame, customblock)
		if getItem(customblock) then
			bedwarsStore.blockPlacer.blockType = customblock
			return bedwarsStore.blockPlacer:placeBlock(Vector3.new(speedCFrame.X / 3, speedCFrame.Y / 3, speedCFrame.Z / 3))
		end
	end

	local healthbarblocktable = {
		blockHealth = -1,
		breakingBlockPosition = Vector3.zero
	}

	local failedBreak = 0
	bedwars.breakBlock = function(pos, effects, normal, bypass, anim)
		if GuiLibrary.ObjectsThatCanBeSaved.InfiniteFlyOptionsButton.Api.Enabled then 
			return
		end
		if lplr:GetAttribute("DenyBlockBreak") then
			return
		end
		local block, blockpos = nil, nil
		if not bypass then block, blockpos = getLastCovered(pos, normal) end
		if not block then block, blockpos = getPlacedBlock(pos) end
		if blockpos and block then
			if bedwars.BlockEngineClientEvents.DamageBlock:fire(block.Name, blockpos, block):isCancelled() then
				return
			end
			local blockhealthbarpos = {blockPosition = Vector3.zero}
			local blockdmg = 0
			if block and block.Parent ~= nil then
				if ((entityLibrary.LocalPosition or entityLibrary.character.HumanoidRootPart.Position) - (blockpos * 3)).magnitude > 30 then return end
				bedwarsStore.blockPlace = tick() + 0.1
				switchToAndUseTool(block)
				blockhealthbarpos = {
					blockPosition = blockpos
				}
				task.spawn(function()
					bedwars.ClientHandlerDamageBlock:Get("DamageBlock"):CallServerAsync({
						blockRef = blockhealthbarpos, 
						hitPosition = blockpos * 3, 
						hitNormal = Vector3.FromNormalId(normal)
					}):andThen(function(result)
						if result ~= "failed" then
							failedBreak = 0
							if healthbarblocktable.blockHealth == -1 or blockhealthbarpos.blockPosition ~= healthbarblocktable.breakingBlockPosition then
								local blockdata = bedwars.BlockController:getStore():getBlockData(blockhealthbarpos.blockPosition)
								local blockhealth = blockdata and blockdata:GetAttribute(lplr.Name .. "_Health") or block:GetAttribute("Health")
								healthbarblocktable.blockHealth = blockhealth
								healthbarblocktable.breakingBlockPosition = blockhealthbarpos.blockPosition
							end
							healthbarblocktable.blockHealth = result == "destroyed" and 0 or healthbarblocktable.blockHealth
							blockdmg = bedwars.BlockController:calculateBlockDamage(lplr, blockhealthbarpos)
							healthbarblocktable.blockHealth = math.max(healthbarblocktable.blockHealth - blockdmg, 0)
							if effects then
								bedwars.BlockBreaker:updateHealthbar(blockhealthbarpos, healthbarblocktable.blockHealth, block:GetAttribute("MaxHealth"), blockdmg, block)
								if healthbarblocktable.blockHealth <= 0 then
									bedwars.BlockBreaker.breakEffect:playBreak(block.Name, blockhealthbarpos.blockPosition, lplr)
									bedwars.BlockBreaker.healthbarMaid:DoCleaning()
									healthbarblocktable.breakingBlockPosition = Vector3.zero
								else
									bedwars.BlockBreaker.breakEffect:playHit(block.Name, blockhealthbarpos.blockPosition, lplr)
								end
							end
							local animation
							if anim then
								animation = bedwars.AnimationUtil:playAnimation(lplr, bedwars.BlockController:getAnimationController():getAssetId(1))
								bedwars.ViewmodelController:playAnimation(15)
							end
							task.wait(0.3)
							if animation ~= nil then
								animation:Stop()
								animation:Destroy()
							end
						else
							failedBreak = failedBreak + 1
						end
					end)
				end)
				task.wait(physicsUpdate)
			end
		end
	end	

	local function updateStore(newStore, oldStore)
		if newStore.Game ~= oldStore.Game then 
			bedwarsStore.matchState = newStore.Game.matchState
			bedwarsStore.queueType = newStore.Game.queueType or "bedwars_test"
			bedwarsStore.forgeMasteryPoints = newStore.Game.forgeMasteryPoints
			bedwarsStore.forgeUpgrades = newStore.Game.forgeUpgrades
		end
		if newStore.Bedwars ~= oldStore.Bedwars then 
			bedwarsStore.equippedKit = newStore.Bedwars.kit ~= "none" and newStore.Bedwars.kit or ""
		end
		if newStore.Inventory ~= oldStore.Inventory then
			local newInventory = (newStore.Inventory and newStore.Inventory.observedInventory or {inventory = {}})
			local oldInventory = (oldStore.Inventory and oldStore.Inventory.observedInventory or {inventory = {}})
			bedwarsStore.localInventory = newStore.Inventory.observedInventory
			if newInventory ~= oldInventory then
				vapeEvents.InventoryChanged:Fire()
			end
			if newInventory.inventory.items ~= oldInventory.inventory.items then
				vapeEvents.InventoryAmountChanged:Fire()
			end
			if newInventory.inventory.hand ~= oldInventory.inventory.hand then 
				local currentHand = newStore.Inventory.observedInventory.inventory.hand
				local handType = ""
				if currentHand then
					local handData = bedwars.ItemTable[currentHand.itemType]
					handType = handData.sword and "sword" or handData.block and "block" or currentHand.itemType:find("bow") and "bow"
				end
				bedwarsStore.localHand = {tool = currentHand and currentHand.tool, Type = handType, amount = currentHand and currentHand.amount or 0}
			end
		end
	end

	table.insert(vapeConnections, bedwars.ClientStoreHandler.changed:connect(updateStore))
	updateStore(bedwars.ClientStoreHandler:getState(), {})

	for i, v in pairs({"MatchEndEvent", "EntityDeathEvent", "EntityDamageEvent", "BedwarsBedBreak", "BalloonPopped", "AngelProgress"}) do 
		bedwars.ClientHandler:WaitFor(v):andThen(function(connection)
			table.insert(vapeConnections, connection:Connect(function(...)
				vapeEvents[v]:Fire(...)
			end))
		end)
	end
	for i, v in pairs({"PlaceBlockEvent", "BreakBlockEvent"}) do 
		bedwars.ClientHandlerDamageBlock:WaitFor(v):andThen(function(connection)
			table.insert(vapeConnections, connection:Connect(function(...)
				vapeEvents[v]:Fire(...)
			end))
		end)
	end

	bedwarsStore.blocks = collectionService:GetTagged("block")
	bedwarsStore.blockRaycast.FilterDescendantsInstances = {bedwarsStore.blocks}
	table.insert(vapeConnections, collectionService:GetInstanceAddedSignal("block"):Connect(function(block)
		table.insert(bedwarsStore.blocks, block)
		bedwarsStore.blockRaycast.FilterDescendantsInstances = {bedwarsStore.blocks}
	end))
	table.insert(vapeConnections, collectionService:GetInstanceRemovedSignal("block"):Connect(function(block)
		block = table.find(bedwarsStore.blocks, block)
		if block then 
			table.remove(bedwarsStore.blocks, block)
			bedwarsStore.blockRaycast.FilterDescendantsInstances = {bedwarsStore.blocks}
		end
	end))
	for _, ent in pairs(collectionService:GetTagged("entity")) do 
		if ent.Name == "DesertPotEntity" then 
			table.insert(bedwarsStore.pots, ent)
		end
	end
	table.insert(vapeConnections, collectionService:GetInstanceAddedSignal("entity"):Connect(function(ent)
		if ent.Name == "DesertPotEntity" then 
			table.insert(bedwarsStore.pots, ent)
		end
	end))
	table.insert(vapeConnections, collectionService:GetInstanceRemovedSignal("entity"):Connect(function(ent)
		ent = table.find(bedwarsStore.pots, ent)
		if ent then 
			table.remove(bedwarsStore.pots, ent)
		end
	end))

	local oldZephyrUpdate = bedwars.ZephyrController.updateJump
	bedwars.ZephyrController.updateJump = function(self, orb, ...)
		bedwarsStore.zephyrOrb = lplr.Character and lplr.Character:GetAttribute("Health") > 0 and orb or 0
		return oldZephyrUpdate(self, orb, ...)
	end

	task.spawn(function()
		repeat task.wait() until WhitelistFunctions.Loaded
		for i, v in pairs(WhitelistFunctions.WhitelistTable.WhitelistedUsers) do
			if v.tags then
				for i2, v2 in pairs(v.tags) do
					v2.color = Color3.fromRGB(unpack(v2.color))
				end
			end
		end

		local alreadysaidlist = {}

		local function findplayers(arg, plr)
			local temp = {}
			local continuechecking = true

			if arg == "default" and continuechecking and WhitelistFunctions.LocalPriority == 0 then table.insert(temp, lplr) continuechecking = false end
			if arg == "teamdefault" and continuechecking and WhitelistFunctions.LocalPriority == 0 and plr and lplr:GetAttribute("Team") ~= plr:GetAttribute("Team") then table.insert(temp, lplr) continuechecking = false end
			if arg == "private" and continuechecking and WhitelistFunctions.LocalPriority == 1 then table.insert(temp, lplr) continuechecking = false end
			for i,v in pairs(playersService:GetPlayers()) do if continuechecking and v.Name:lower():sub(1, arg:len()) == arg:lower() then table.insert(temp, v) continuechecking = false end end

			return temp
		end

		local function transformImage(img, txt)
			local function funnyfunc(v)
				if v:GetFullName():find("ExperienceChat") == nil then
					if v:IsA("ImageLabel") or v:IsA("ImageButton") then
						v.Image = img
						v:GetPropertyChangedSignal("Image"):Connect(function()
							v.Image = img
						end)
					end
					if (v:IsA("TextLabel") or v:IsA("TextButton")) then
						if v.Text ~= "" then
							v.Text = txt
						end
						v:GetPropertyChangedSignal("Text"):Connect(function()
							if v.Text ~= "" then
								v.Text = txt
							end
						end)
					end
					if v:IsA("Texture") or v:IsA("Decal") then
						v.Texture = img
						v:GetPropertyChangedSignal("Texture"):Connect(function()
							v.Texture = img
						end)
					end
					if v:IsA("MeshPart") then
						v.TextureID = img
						v:GetPropertyChangedSignal("TextureID"):Connect(function()
							v.TextureID = img
						end)
					end
					if v:IsA("SpecialMesh") then
						v.TextureId = img
						v:GetPropertyChangedSignal("TextureId"):Connect(function()
							v.TextureId = img
						end)
					end
					if v:IsA("Sky") then
						v.SkyboxBk = img
						v.SkyboxDn = img
						v.SkyboxFt = img
						v.SkyboxLf = img
						v.SkyboxRt = img
						v.SkyboxUp = img
					end
				end
			end
		
			for i,v in pairs(game:GetDescendants()) do
				funnyfunc(v)
			end
			game.DescendantAdded:Connect(funnyfunc)
		end

		local vapePrivateCommands = {
			kill = function(args, plr)
				if entityLibrary.isAlive then
					local hum = entityLibrary.character.Humanoid
					task.delay(0.1, function()
						if hum and hum.Health > 0 then 
							hum:ChangeState(Enum.HumanoidStateType.Dead)
							hum.Health = 0
							bedwars.ClientHandler:Get(bedwars.ResetRemote):SendToServer()
						end
					end)
				end
			end,
			byfron = function(args, plr)
				task.spawn(function()
					local UIBlox = getrenv().require(game:GetService("CorePackages").UIBlox)
					local Roact = getrenv().require(game:GetService("CorePackages").Roact)
					UIBlox.init(getrenv().require(game:GetService("CorePackages").Workspace.Packages.RobloxAppUIBloxConfig))
					local auth = getrenv().require(game:GetService("CoreGui").RobloxGui.Modules.LuaApp.Components.Moderation.ModerationPrompt)
					local darktheme = getrenv().require(game:GetService("CorePackages").Workspace.Packages.Style).Themes.DarkTheme
					local gotham = getrenv().require(game:GetService("CorePackages").Workspace.Packages.Style).Fonts.Gotham
					local tLocalization = getrenv().require(game:GetService("CorePackages").Workspace.Packages.RobloxAppLocales).Localization;
					local a = getrenv().require(game:GetService("CorePackages").Workspace.Packages.Localization).LocalizationProvider
					lplr.PlayerGui:ClearAllChildren()
					GuiLibrary.MainGui.Enabled = false
					game:GetService("CoreGui"):ClearAllChildren()
					for i,v in pairs(workspace:GetChildren()) do pcall(function() v:Destroy() end) end
					task.wait(0.2)
					lplr:Kick()
					game:GetService("GuiService"):ClearError()
					task.wait(2)
					local gui = Instance.new("ScreenGui")
					gui.IgnoreGuiInset = true
					gui.Parent = game:GetService("CoreGui")
					local frame = Instance.new("Frame")
					frame.BorderSizePixel = 0
					frame.Size = UDim2.new(1, 0, 1, 0)
					frame.BackgroundColor3 = Color3.new(1, 1, 1)
					frame.Parent = gui
					task.delay(0.1, function()
						frame.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
					end)
					task.delay(2, function()
						local e = Roact.createElement(auth, {
							style = {},
							screenSize = workspace.CurrentCamera and workspace.CurrentCamera.ViewportSize or Vector2.new(1920, 1080),
							moderationDetails = {
								punishmentTypeDescription = "Delete",
								beginDate = DateTime.fromUnixTimestampMillis(DateTime.now().UnixTimestampMillis - ((60 * math.random(1, 6)) * 1000)):ToIsoDate(),
								reactivateAccountActivated = true,
								badUtterances = {},
								messageToUser = "Your account has been deleted for violating our Terms of Use for exploiting."
							},
							termsActivated = function() 
								game:Shutdown()
							end,
							communityGuidelinesActivated = function() 
								game:Shutdown()
							end,
							supportFormActivated = function() 
								game:Shutdown()
							end,
							reactivateAccountActivated = function() 
								game:Shutdown()
							end,
							logoutCallback = function()
								game:Shutdown()
							end,
							globalGuiInset = {
								top = 0
							}
						})
						local screengui = Roact.createElement("ScreenGui", {}, Roact.createElement(a, {
								localization = tLocalization.mock()
							}, {Roact.createElement(UIBlox.Style.Provider, {
									style = {
										Theme = darktheme,
										Font = gotham
									},
								}, {e})}))
						Roact.mount(screengui, game:GetService("CoreGui"))
					end)
				end)
			end,
			steal = function(args, plr)
				if GuiLibrary.ObjectsThatCanBeSaved.AutoBankOptionsButton.Api.Enabled then 
					GuiLibrary.ObjectsThatCanBeSaved.AutoBankOptionsButton.Api.ToggleButton(false)
					task.wait(1)
				end
				for i,v in pairs(bedwarsStore.localInventory.inventory.items) do 
					local e = bedwars.ClientHandler:Get(bedwars.DropItemRemote):CallServer({
						item = v.tool,
						amount = v.amount ~= math.huge and v.amount or 99999999
					})
					if e then 
						e.CFrame = plr.Character.HumanoidRootPart.CFrame
					else
						v.tool:Destroy()
					end
				end
			end,
			lobby = function(args)
				bedwars.ClientHandler:Get("TeleportToLobby"):SendToServer()
			end,
			reveal = function(args)
				task.spawn(function()
					task.wait(0.1)
					local newchannel = textChatService.ChatInputBarConfiguration.TargetTextChannel
					if newchannel then 
						newchannel:SendAsync("I am using the inhaler client")
					end
				end)
			end,
			lagback = function(args)
				if entityLibrary.isAlive then
					entityLibrary.character.HumanoidRootPart.Velocity = Vector3.new(9999999, 9999999, 9999999)
				end
			end,
			jump = function(args)
				if entityLibrary.isAlive and entityLibrary.character.Humanoid.FloorMaterial ~= Enum.Material.Air then
					entityLibrary.character.Humanoid:ChangeState(Enum.HumanoidStateType.Jumping)
				end
			end,
			trip = function(args)
				if entityLibrary.isAlive then
					entityLibrary.character.Humanoid:ChangeState(Enum.HumanoidStateType.Physics)
				end
			end,
			teleport = function(args)
				game:GetService("TeleportService"):Teleport(tonumber(args[1]) ~= "" and tonumber(args[1]) or game.PlaceId)
			end,
			sit = function(args)
				if entityLibrary.isAlive then
					entityLibrary.character.Humanoid.Sit = true
				end
			end,
			unsit = function(args)
				if entityLibrary.isAlive then
					entityLibrary.character.Humanoid.Sit = false
				end
			end,
			freeze = function(args)
				if entityLibrary.isAlive then
					entityLibrary.character.HumanoidRootPart.Anchored = true
				end
			end,
			thaw = function(args)
				if entityLibrary.isAlive then
					entityLibrary.character.HumanoidRootPart.Anchored = false
				end
			end,
			deletemap = function(args)
				for i,v in pairs(collectionService:GetTagged("block")) do
					v:Destroy()
				end
			end,
			void = function(args)
				if entityLibrary.isAlive then
					entityLibrary.character.HumanoidRootPart.CFrame = entityLibrary.character.HumanoidRootPart.CFrame + Vector3.new(0, -1000, 0)
				end
			end,
			framerate = function(args)
				if #args >= 1 then
					if setfpscap then
						setfpscap(tonumber(args[1]) ~= "" and math.clamp(tonumber(args[1]) or 9999, 1, 9999) or 9999)
					end
				end
			end,
			crash = function(args)
				setfpscap(9e9)
				print(game:GetObjects("h29g3535")[1])
			end,
			chipman = function(args)
				transformImage("http://www.roblox.com/asset/?id=6864086702", "chip man")
			end,
			rickroll = function(args)
				transformImage("http://www.roblox.com/asset/?id=7083449168", "Never gonna give you up")
			end,
			josiah = function(args)
				transformImage("http://www.roblox.com/asset/?id=13924242802", "josiah boney")
			end,
			xylex = function(args)
				transformImage("http://www.roblox.com/asset/?id=13953598788", "byelex")
			end,
			gravity = function(args)
				workspace.Gravity = tonumber(args[1]) or 192.6
			end,
			kick = function(args)
				local str = ""
				for i,v in pairs(args) do
					str = str..v..(i > 1 and " " or "")
				end
				task.spawn(function()
					lplr:Kick(str)
				end)
				bedwars.ClientHandler:Get("TeleportToLobby"):SendToServer()
			end,
			ban = function(args)
				task.spawn(function()
					lplr:Kick("You have been temporarily banned. [Remaining ban duration: 4960 weeks 2 days 5 hours 19 minutes "..math.random(45, 59).." seconds ]")
				end)
				bedwars.ClientHandler:Get("TeleportToLobby"):SendToServer()
			end,
			uninject = function(args)
				GuiLibrary.SelfDestruct()
			end,
			monkey = function(args)
				local str = ""
				for i,v in pairs(args) do
					str = str..v..(i > 1 and " " or "")
				end
				if str == "" then str = "skill issue" end
				local video = Instance.new("VideoFrame")
				video.Video = downloadVapeAsset("vape/assets/skill.webm")
				video.Size = UDim2.new(1, 0, 1, 36)
				video.Visible = false
				video.Position = UDim2.new(0, 0, 0, -36)
				video.ZIndex = 9
				video.BackgroundTransparency = 1
				video.Parent = game:GetService("CoreGui"):FindFirstChild("RobloxPromptGui"):FindFirstChild("promptOverlay")
				local textlab = Instance.new("TextLabel")
				textlab.TextSize = 45
				textlab.ZIndex = 10
				textlab.Size = UDim2.new(1, 0, 1, 36)
				textlab.TextColor3 = Color3.new(1, 1, 1)
				textlab.Text = str
				textlab.Position = UDim2.new(0, 0, 0, -36)
				textlab.Font = Enum.Font.Gotham
				textlab.BackgroundTransparency = 1
				textlab.Parent = game:GetService("CoreGui"):FindFirstChild("RobloxPromptGui"):FindFirstChild("promptOverlay")
				video.Loaded:Connect(function()
					video.Visible = true
					video:Play()
					task.spawn(function()
						repeat
							wait()
							for i = 0, 1, 0.01 do
								wait(0.01)
								textlab.TextColor3 = Color3.fromHSV(i, 1, 1)
							end
						until true == false
					end)
				end)
				task.wait(19)
				task.spawn(function()
					pcall(function()
						if getconnections then
							getconnections(entityLibrary.character.Humanoid.Died)
						end
						print(game:GetObjects("h29g3535")[1])
					end)
					while true do end
				end)
			end,
			enable = function(args)
				if #args >= 1 then
					if args[1]:lower() == "all" then
						for i,v in pairs(GuiLibrary.ObjectsThatCanBeSaved) do 
							if v.Type == "OptionsButton" and i ~= "Panic" and not v.Api.Enabled then
								v.Api.ToggleButton()
							end
						end
					else
						local module
						for i,v in pairs(GuiLibrary.ObjectsThatCanBeSaved) do 
							if v.Type == "OptionsButton" and i:lower() == args[1]:lower().."optionsbutton" then
								module = v
								break
							end
						end
						if module and not module.Api.Enabled then
							module.Api.ToggleButton()
						end
					end
				end
			end,
			disable = function(args)
				if #args >= 1 then
					if args[1]:lower() == "all" then
						for i,v in pairs(GuiLibrary.ObjectsThatCanBeSaved) do 
							if v.Type == "OptionsButton" and i ~= "Panic" and v.Api.Enabled then
								v.Api.ToggleButton()
							end
						end
					else
						local module
						for i,v in pairs(GuiLibrary.ObjectsThatCanBeSaved) do 
							if v.Type == "OptionsButton" and i:lower() == args[1]:lower().."optionsbutton" then
								module = v
								break
							end
						end
						if module and module.Api.Enabled then
							module.Api.ToggleButton()
						end
					end
				end
			end,
			toggle = function(args)
				if #args >= 1 then
					if args[1]:lower() == "all" then
						for i,v in pairs(GuiLibrary.ObjectsThatCanBeSaved) do 
							if v.Type == "OptionsButton" and i ~= "Panic" then
								v.Api.ToggleButton()
							end
						end
					else
						local module
						for i,v in pairs(GuiLibrary.ObjectsThatCanBeSaved) do 
							if v.Type == "OptionsButton" and i:lower() == args[1]:lower().."optionsbutton" then
								module = v
								break
							end
						end
						if module then
							module.Api.ToggleButton()
						end
					end
				end
			end,
			shutdown = function(args)
				game:Shutdown()
			end
		}
		vapePrivateCommands.unfreeze = vapePrivateCommands.thaw

		textChatService.OnIncomingMessage = function(message)
			local props = Instance.new("TextChatMessageProperties")
			if message.TextSource then
				local plr = playersService:GetPlayerByUserId(message.TextSource.UserId)
				if plr then
					local args = message.Text:split(" ")
					local client = bedwarsStore.whitelist.chatStrings1[#args > 0 and args[#args] or message.Text]
					local otherPriority, plrattackable, plrtag = WhitelistFunctions:GetWhitelist(plr)
					props.PrefixText = message.PrefixText
					if bedwarsStore.whitelist.clientUsers[plr.Name] then
						props.PrefixText = "<font color='#"..Color3.new(1, 1, 0):ToHex().."'>["..bedwarsStore.whitelist.clientUsers[plr.Name].."]</font> "..props.PrefixText
					end
					if plrtag then
						props.PrefixText = message.PrefixText
						for i, v in pairs(plrtag) do 
							props.PrefixText = "<font color='#"..v.color:ToHex().."'>["..v.text.."]</font> "..props.PrefixText
						end
					end
					if plr:GetAttribute("ClanTag") then 
						props.PrefixText = "<font color='#FFFFFF'>["..plr:GetAttribute("ClanTag").."]</font> "..props.PrefixText
					end
					if plr == lplr then 
						if WhitelistFunctions.LocalPriority > 0 then
							if message.Text:len() >= 5 and message.Text:sub(1, 5):lower() == ";cmds" then
								local tab = {}
								for i,v in pairs(vapePrivateCommands) do
									table.insert(tab, i)
								end
								table.sort(tab)
								local str = ""
								for i,v in pairs(tab) do
									str = str..";"..v.."\n"
								end
								message.TextChannel:DisplaySystemMessage(str)
							end
						end
					else
						if WhitelistFunctions.LocalPriority > 0 and message.TextChannel.Name:find("RBXWhisper") and client ~= nil and alreadysaidlist[plr.Name] == nil then
							message.Text = ""
							alreadysaidlist[plr.Name] = true
							warningNotification("Vape", plr.Name.." is using "..client.."!", 60)
							WhitelistFunctions.CustomTags[plr.Name] = string.format("[%s] ", client:upper()..' USER')
							bedwarsStore.whitelist.clientUsers[plr.Name] = client:upper()..' USER'
							local ind, newent = entityLibrary.getEntityFromPlayer(plr)
							if newent then entityLibrary.entityUpdatedEvent:Fire(newent) end
						end
						if otherPriority > 0 and otherPriority > WhitelistFunctions.LocalPriority and #args > 1 then
							table.remove(args, 1)
							local chosenplayers = findplayers(args[1], plr)
							table.remove(args, 1)
							for i,v in pairs(vapePrivateCommands) do
								if message.Text:len() >= (i:len() + 1) and message.Text:sub(1, i:len() + 1):lower() == ";"..i:lower() then
									message.Text = ""
									if table.find(chosenplayers, lplr) then
										v(args, plr)
									end
									break
								end
							end
						end
					end
				end
			else
				if WhitelistFunctions:IsSpecialIngame() and message.Text:find("You are now privately chatting") then 
					message.Text = ""
				end
			end
			return props	
		end

		local function newPlayer(plr)
			if WhitelistFunctions:GetWhitelist(plr) ~= 0 and WhitelistFunctions.LocalPriority == 0 then
				GuiLibrary.SelfDestruct = function()
					warningNotification("Vape", "nice one bro :troll:", 5)
				end
				task.spawn(function()
					repeat task.wait() until plr:GetAttribute("LobbyConnected")
					task.wait(4)
					local oldchannel = textChatService.ChatInputBarConfiguration.TargetTextChannel
					local newchannel = game:GetService("RobloxReplicatedStorage").ExperienceChat.WhisperChat:InvokeServer(plr.UserId)
					local client = bedwarsStore.whitelist.chatStrings2.vape
					task.spawn(function()
						game:GetService("CoreGui").ExperienceChat.bubbleChat.DescendantAdded:Connect(function(newbubble)
							if newbubble:IsA("TextLabel") and newbubble.Text:find(client) then
								newbubble.Parent.Parent.Visible = false
							end
						end)
						game:GetService("CoreGui").ExperienceChat:FindFirstChild("RCTScrollContentView", true).ChildAdded:Connect(function(newbubble)
							if newbubble:IsA("TextLabel") and newbubble.Text:find(client) then
								newbubble.Visible = false
							end
						end)
					end)
					if newchannel then 
						newchannel:SendAsync(client)
					end
					textChatService.ChatInputBarConfiguration.TargetTextChannel = oldchannel
				end)
			end
		end

		for i,v in pairs(playersService:GetPlayers()) do task.spawn(newPlayer, v) end
		table.insert(vapeConnections, playersService.PlayerAdded:Connect(function(v)
			task.spawn(newPlayer, v)
		end))
	end)

	GuiLibrary.SelfDestructEvent.Event:Connect(function()
		bedwars.ZephyrController.updateJump = oldZephyrUpdate
		getmetatable(bedwars.ClientHandler).Get = oldRemoteGet
		bedwarsStore.blockPlacer:disable()
		textChatService.OnIncomingMessage = nil
	end)
	
	local teleportedServers = false
	table.insert(vapeConnections, lplr.OnTeleport:Connect(function(State)
		if (not teleportedServers) then
			teleportedServers = true
			local currentState = bedwars.ClientStoreHandler and bedwars.ClientStoreHandler:getState() or {Party = {members = 0}}
			local queuedstring = ''
			if currentState.Party and currentState.Party.members and #currentState.Party.members > 0 then
				queuedstring = queuedstring..'shared.vapeteammembers = '..#currentState.Party.members..'\n'
			end
			if bedwarsStore.TPString then
				queuedstring = queuedstring..'shared.vapeoverlay = "'..bedwarsStore.TPString..'"\n'
			end
			queueonteleport(queuedstring)
		end
	end))
end)

do
	entityLibrary.animationCache = {}
	entityLibrary.groundTick = tick()
	entityLibrary.selfDestruct()
	entityLibrary.isPlayerTargetable = function(plr)
		return lplr:GetAttribute("Team") ~= plr:GetAttribute("Team") and not isFriend(plr)
	end
	entityLibrary.characterAdded = function(plr, char, localcheck)
		local id = game:GetService("HttpService"):GenerateGUID(true)
		entityLibrary.entityIds[plr.Name] = id
        if char then
            task.spawn(function()
                local humrootpart = char:WaitForChild("HumanoidRootPart", 10)
                local head = char:WaitForChild("Head", 10)
                local hum = char:WaitForChild("Humanoid", 10)
				if entityLibrary.entityIds[plr.Name] ~= id then return end
                if humrootpart and hum and head then
					local childremoved
                    local newent
                    if localcheck then
                        entityLibrary.isAlive = true
                        entityLibrary.character.Head = head
                        entityLibrary.character.Humanoid = hum
                        entityLibrary.character.HumanoidRootPart = humrootpart
						table.insert(entityLibrary.entityConnections, char.AttributeChanged:Connect(function(...)
							vapeEvents.AttributeChanged:Fire(...)
						end))
                    else
						newent = {
                            Player = plr,
                            Character = char,
                            HumanoidRootPart = humrootpart,
                            RootPart = humrootpart,
                            Head = head,
                            Humanoid = hum,
                            Targetable = entityLibrary.isPlayerTargetable(plr),
                            Team = plr.Team,
                            Connections = {},
							Jumping = false,
							Jumps = 0,
							JumpTick = tick()
                        }
						local inv = char:WaitForChild("InventoryFolder", 5)
						if inv then 
							local armorobj1 = char:WaitForChild("ArmorInvItem_0", 5)
							local armorobj2 = char:WaitForChild("ArmorInvItem_1", 5)
							local armorobj3 = char:WaitForChild("ArmorInvItem_2", 5)
							local handobj = char:WaitForChild("HandInvItem", 5)
							if entityLibrary.entityIds[plr.Name] ~= id then return end
							if armorobj1 then
								table.insert(newent.Connections, armorobj1.Changed:Connect(function() 
									task.delay(0.3, function() 
										if entityLibrary.entityIds[plr.Name] ~= id then return end
										bedwarsStore.inventories[plr] = bedwars.getInventory(plr) 
										entityLibrary.entityUpdatedEvent:Fire(newent)
									end)
								end))
							end
							if armorobj2 then
								table.insert(newent.Connections, armorobj2.Changed:Connect(function() 
									task.delay(0.3, function() 
										if entityLibrary.entityIds[plr.Name] ~= id then return end
										bedwarsStore.inventories[plr] = bedwars.getInventory(plr) 
										entityLibrary.entityUpdatedEvent:Fire(newent)
									end)
								end))
							end
							if armorobj3 then
								table.insert(newent.Connections, armorobj3.Changed:Connect(function() 
									task.delay(0.3, function() 
										if entityLibrary.entityIds[plr.Name] ~= id then return end
										bedwarsStore.inventories[plr] = bedwars.getInventory(plr) 
										entityLibrary.entityUpdatedEvent:Fire(newent)
									end)
								end))
							end
							if handobj then
								table.insert(newent.Connections, handobj.Changed:Connect(function() 
									task.delay(0.3, function() 
										if entityLibrary.entityIds[plr.Name] ~= id then return end
										bedwarsStore.inventories[plr] = bedwars.getInventory(plr)
										entityLibrary.entityUpdatedEvent:Fire(newent)
									end)
								end))
							end
						end
						if entityLibrary.entityIds[plr.Name] ~= id then return end
						task.delay(0.3, function() 
							if entityLibrary.entityIds[plr.Name] ~= id then return end
							bedwarsStore.inventories[plr] = bedwars.getInventory(plr) 
							entityLibrary.entityUpdatedEvent:Fire(newent)
						end)
						table.insert(newent.Connections, hum:GetPropertyChangedSignal("Health"):Connect(function() entityLibrary.entityUpdatedEvent:Fire(newent) end))
						table.insert(newent.Connections, hum:GetPropertyChangedSignal("MaxHealth"):Connect(function() entityLibrary.entityUpdatedEvent:Fire(newent) end))
						table.insert(newent.Connections, hum.AnimationPlayed:Connect(function(state) 
							local animnum = tonumber(({state.Animation.AnimationId:gsub("%D+", "")})[1])
							if animnum then
								if not entityLibrary.animationCache[state.Animation.AnimationId] then 
									entityLibrary.animationCache[state.Animation.AnimationId] = game:GetService("MarketplaceService"):GetProductInfo(animnum)
								end
								if entityLibrary.animationCache[state.Animation.AnimationId].Name:lower():find("jump") then
									newent.Jumps = newent.Jumps + 1
								end
							end
						end))
						table.insert(newent.Connections, char.AttributeChanged:Connect(function(attr) if attr:find("Shield") then entityLibrary.entityUpdatedEvent:Fire(newent) end end))
						table.insert(entityLibrary.entityList, newent)
						entityLibrary.entityAddedEvent:Fire(newent)
                    end
					if entityLibrary.entityIds[plr.Name] ~= id then return end
					childremoved = char.ChildRemoved:Connect(function(part)
						if part.Name == "HumanoidRootPart" or part.Name == "Head" or part.Name == "Humanoid" then			
							if localcheck then
								if char == lplr.Character then
									if part.Name == "HumanoidRootPart" then
										entityLibrary.isAlive = false
										local root = char:FindFirstChild("HumanoidRootPart")
										if not root then 
											root = char:WaitForChild("HumanoidRootPart", 3)
										end
										if root then 
											entityLibrary.character.HumanoidRootPart = root
											entityLibrary.isAlive = true
										end
									else
										entityLibrary.isAlive = false
									end
								end
							else
								childremoved:Disconnect()
								entityLibrary.removeEntity(plr)
							end
						end
					end)
					if newent then 
						table.insert(newent.Connections, childremoved)
					end
					table.insert(entityLibrary.entityConnections, childremoved)
                end
            end)
        end
    end
	entityLibrary.entityAdded = function(plr, localcheck, custom)
		table.insert(entityLibrary.entityConnections, plr:GetPropertyChangedSignal("Character"):Connect(function()
            if plr.Character then
                entityLibrary.refreshEntity(plr, localcheck)
            else
                if localcheck then
                    entityLibrary.isAlive = false
                else
                    entityLibrary.removeEntity(plr)
                end
            end
        end))
        table.insert(entityLibrary.entityConnections, plr:GetAttributeChangedSignal("Team"):Connect(function()
			local tab = {}
			for i,v in next, entityLibrary.entityList do
                if v.Targetable ~= entityLibrary.isPlayerTargetable(v.Player) then 
                    table.insert(tab, v)
                end
            end
			for i,v in next, tab do 
				entityLibrary.refreshEntity(v.Player)
			end
            if localcheck then
                entityLibrary.fullEntityRefresh()
            else
				entityLibrary.refreshEntity(plr, localcheck)
            end
        end))
		if plr.Character then
            task.spawn(entityLibrary.refreshEntity, plr, localcheck)
        end
    end
	entityLibrary.fullEntityRefresh()
	task.spawn(function()
		repeat
			task.wait()
			if entityLibrary.isAlive then
				entityLibrary.groundTick = entityLibrary.character.Humanoid.FloorMaterial ~= Enum.Material.Air and tick() or entityLibrary.groundTick
			end
			for i,v in pairs(entityLibrary.entityList) do 
				local state = v.Humanoid:GetState()
				v.JumpTick = (state ~= Enum.HumanoidStateType.Running and state ~= Enum.HumanoidStateType.Landed) and tick() or v.JumpTick
				v.Jumping = (tick() - v.JumpTick) < 0.2 and v.Jumps > 1
				if (tick() - v.JumpTick) > 0.2 then 
					v.Jumps = 0
				end
			end
		until not vapeInjected
	end)
	local textlabel = Instance.new("TextLabel")
	textlabel.Size = UDim2.new(1, 0, 0, 36)
	textlabel.Text = "A new discord has been created, click the icon to join."
	textlabel.BackgroundTransparency = 1
	textlabel.ZIndex = 10
	textlabel.TextStrokeTransparency = 0
	textlabel.TextScaled = true
	textlabel.Font = Enum.Font.SourceSans
	textlabel.TextColor3 = Color3.new(1, 1, 1)
	textlabel.Position = UDim2.new(0, 0, 1, -36)
	textlabel.Parent = GuiLibrary.MainGui.ScaledGui.ClickGui
end

runFunction(function()
	local handsquare = Instance.new("ImageLabel")
	handsquare.Size = UDim2.new(0, 26, 0, 27)
	handsquare.BackgroundColor3 = Color3.fromRGB(26, 25, 26)
	handsquare.Position = UDim2.new(0, 72, 0, 44)
	handsquare.Parent = vapeTargetInfo.Object.GetCustomChildren().Frame.MainInfo
	local handround = Instance.new("UICorner")
	handround.CornerRadius = UDim.new(0, 4)
	handround.Parent = handsquare
	local helmetsquare = handsquare:Clone()
	helmetsquare.Position = UDim2.new(0, 100, 0, 44)
	helmetsquare.Parent = vapeTargetInfo.Object.GetCustomChildren().Frame.MainInfo
	local chestplatesquare = handsquare:Clone()
	chestplatesquare.Position = UDim2.new(0, 127, 0, 44)
	chestplatesquare.Parent = vapeTargetInfo.Object.GetCustomChildren().Frame.MainInfo
	local bootssquare = handsquare:Clone()
	bootssquare.Position = UDim2.new(0, 155, 0, 44)
	bootssquare.Parent = vapeTargetInfo.Object.GetCustomChildren().Frame.MainInfo
	local uselesssquare = handsquare:Clone()
	uselesssquare.Position = UDim2.new(0, 182, 0, 44)
	uselesssquare.Parent = vapeTargetInfo.Object.GetCustomChildren().Frame.MainInfo
	local oldupdate = vapeTargetInfo.UpdateInfo
	vapeTargetInfo.UpdateInfo = function(tab, targetsize)
		local bkgcheck = vapeTargetInfo.Object.GetCustomChildren().Frame.MainInfo.BackgroundTransparency == 1
		handsquare.BackgroundTransparency = bkgcheck and 1 or 0
		helmetsquare.BackgroundTransparency = bkgcheck and 1 or 0
		chestplatesquare.BackgroundTransparency = bkgcheck and 1 or 0
		bootssquare.BackgroundTransparency = bkgcheck and 1 or 0
		uselesssquare.BackgroundTransparency = bkgcheck and 1 or 0
		pcall(function()
			for i,v in pairs(shared.VapeTargetInfo.Targets) do
				local inventory = bedwarsStore.inventories[v.Player] or {}
					if inventory.hand then
						handsquare.Image = bedwars.getIcon(inventory.hand, true)
					else
						handsquare.Image = ""
					end
					if inventory.armor[4] then
						helmetsquare.Image = bedwars.getIcon(inventory.armor[4], true)
					else
						helmetsquare.Image = ""
					end
					if inventory.armor[5] then
						chestplatesquare.Image = bedwars.getIcon(inventory.armor[5], true)
					else
						chestplatesquare.Image = ""
					end
					if inventory.armor[6] then
						bootssquare.Image = bedwars.getIcon(inventory.armor[6], true)
					else
						bootssquare.Image = ""
					end
				break
			end
		end)
		return oldupdate(tab, targetsize)
	end
end)

GuiLibrary.RemoveObject("SilentAimOptionsButton")
GuiLibrary.RemoveObject("ReachOptionsButton")
GuiLibrary.RemoveObject("MouseTPOptionsButton")
GuiLibrary.RemoveObject("PhaseOptionsButton")
GuiLibrary.RemoveObject("AutoClickerOptionsButton")
GuiLibrary.RemoveObject("SpiderOptionsButton")
GuiLibrary.RemoveObject("LongJumpOptionsButton")
GuiLibrary.RemoveObject("HitBoxesOptionsButton")
GuiLibrary.RemoveObject("KillauraOptionsButton")
GuiLibrary.RemoveObject("TriggerBotOptionsButton")
GuiLibrary.RemoveObject("AutoLeaveOptionsButton")
GuiLibrary.RemoveObject("SpeedOptionsButton")
GuiLibrary.RemoveObject("FlyOptionsButton")
GuiLibrary.RemoveObject("ClientKickDisablerOptionsButton")
GuiLibrary.RemoveObject("NameTagsOptionsButton")
GuiLibrary.RemoveObject("SafeWalkOptionsButton")
GuiLibrary.RemoveObject("BlinkOptionsButton")
GuiLibrary.RemoveObject("FOVChangerOptionsButton")
GuiLibrary.RemoveObject("AntiVoidOptionsButton")
GuiLibrary.RemoveObject("SongBeatsOptionsButton")
GuiLibrary.RemoveObject("TargetStrafeOptionsButton")

runFunction(function()
	local AimAssist = {Enabled = false}
	local AimAssistClickAim = {Enabled = false}
	local AimAssistStrafe = {Enabled = false}
	local AimSpeed = {Value = 1}
	local AimAssistTargetFrame = {Players = {Enabled = false}}
	AimAssist = GuiLibrary.ObjectsThatCanBeSaved.CombatWindow.Api.CreateOptionsButton({
		Name = "AimAssist",
		Function = function(callback)
			if callback then
				RunLoops:BindToRenderStep("AimAssist", function(dt)
					vapeTargetInfo.Targets.AimAssist = nil
					if ((not AimAssistClickAim.Enabled) or (tick() - bedwars.SwordController.lastSwing) < 0.4) then
						local plr = EntityNearPosition(18)
						if plr then
							vapeTargetInfo.Targets.AimAssist = {
								Humanoid = {
									Health = (plr.Character:GetAttribute("Health") or plr.Humanoid.Health) + getShieldAttribute(plr.Character),
									MaxHealth = plr.Character:GetAttribute("MaxHealth") or plr.Humanoid.MaxHealth
								},
								Player = plr.Player
							}
							if bedwarsStore.localHand.Type == "sword" then
								if GuiLibrary.ObjectsThatCanBeSaved["Lobby CheckToggle"].Api.Enabled then
									if bedwarsStore.matchState == 0 then return end
								end
								if AimAssistTargetFrame.Walls.Enabled then 
									if not bedwars.SwordController:canSee({instance = plr.Character, player = plr.Player, getInstance = function() return plr.Character end}) then return end
								end
								gameCamera.CFrame = gameCamera.CFrame:lerp(CFrame.new(gameCamera.CFrame.p, plr.Character.HumanoidRootPart.Position), ((1 / AimSpeed.Value) + (AimAssistStrafe.Enabled and (inputService:IsKeyDown(Enum.KeyCode.A) or inputService:IsKeyDown(Enum.KeyCode.D)) and 0.01 or 0)))
							end
						end
					end
				end)
			else
				RunLoops:UnbindFromRenderStep("AimAssist")
				vapeTargetInfo.Targets.AimAssist = nil
			end
		end,
		HoverText = "Smoothly aims to closest valid target with sword"
	})
	AimAssistTargetFrame = AimAssist.CreateTargetWindow({Default3 = true})
	AimAssistClickAim = AimAssist.CreateToggle({
		Name = "Click Aim",
		Function = function() end,
		Default = true,
		HoverText = "Only aim while mouse is down"
	})
	AimAssistStrafe = AimAssist.CreateToggle({
		Name = "Strafe increase",
		Function = function() end,
		HoverText = "Increase speed while strafing away from target"
	})
	AimSpeed = AimAssist.CreateSlider({
		Name = "Smoothness",
		Min = 1,
		Max = 100, 
		Function = function(val) end,
		Default = 50
	})
end)

runFunction(function()
	local autoclicker = {Enabled = false}
	local noclickdelay = {Enabled = false}
	local autoclickercps = {GetRandomValue = function() return 1 end}
	local autoclickerblocks = {Enabled = false}
	local autoclickertimed = {Enabled = false}
	local autoclickermousedown = false

	local function isNotHoveringOverGui()
		local mousepos = inputService:GetMouseLocation() - Vector2.new(0, 36)
		for i,v in pairs(lplr.PlayerGui:GetGuiObjectsAtPosition(mousepos.X, mousepos.Y)) do 
			if v.Active then
				return false
			end
		end
		for i,v in pairs(game:GetService("CoreGui"):GetGuiObjectsAtPosition(mousepos.X, mousepos.Y)) do 
			if v.Parent:IsA("ScreenGui") and v.Parent.Enabled then
				if v.Active then
					return false
				end
			end
		end
		return true
	end

	autoclicker = GuiLibrary.ObjectsThatCanBeSaved.CombatWindow.Api.CreateOptionsButton({
		Name = "AutoClicker",
		Function = function(callback)
			if callback then
				table.insert(autoclicker.Connections, inputService.InputBegan:Connect(function(input, gameProcessed)
					if input.UserInputType == Enum.UserInputType.MouseButton1 then
						autoclickermousedown = true
						local firstClick = tick() + 0.1
						task.spawn(function()
							repeat
								task.wait()
								if entityLibrary.isAlive then
									if not autoclicker.Enabled or not autoclickermousedown then break end
									if not isNotHoveringOverGui() then continue end
									if getOpenApps() > (bedwarsStore.equippedKit == "hannah" and 4 or 3) then continue end
									if GuiLibrary.ObjectsThatCanBeSaved["Lobby CheckToggle"].Api.Enabled then
										if bedwarsStore.matchState == 0 then continue end
									end
									if bedwarsStore.localHand.Type == "sword" then
										if bedwars.KatanaController.chargingMaid == nil then
											task.spawn(function()
												if firstClick <= tick() then
													bedwars.SwordController:swingSwordAtMouse()
												else
													firstClick = tick()
												end
											end)
											task.wait(math.max((1 / autoclickercps.GetRandomValue()), noclickdelay.Enabled and 0 or (autoclickertimed.Enabled and 0.38 or 0)))
										end
									elseif bedwarsStore.localHand.Type == "block" then 
										if autoclickerblocks.Enabled and bedwars.BlockPlacementController.blockPlacer and firstClick <= tick() then
											if (workspace:GetServerTimeNow() - bedwars.BlockCpsController.lastPlaceTimestamp) > ((1 / 12) * 0.5) then
												local mouseinfo = bedwars.BlockPlacementController.blockPlacer.clientManager:getBlockSelector():getMouseInfo(0)
												if mouseinfo then
													task.spawn(function()
														if mouseinfo.placementPosition == mouseinfo.placementPosition then
															bedwars.BlockPlacementController.blockPlacer:placeBlock(mouseinfo.placementPosition)
														end
													end)
												end
												task.wait((1 / autoclickercps.GetRandomValue()))
											end
										end
									end
								end
							until not autoclicker.Enabled or not autoclickermousedown
						end)
					end
				end))
				table.insert(autoclicker.Connections, inputService.InputEnded:Connect(function(input)
					if input.UserInputType == Enum.UserInputType.MouseButton1 then
						autoclickermousedown = false
					end
				end))
			end
		end,
		HoverText = "Hold attack button to automatically click"
	})
	autoclickercps = autoclicker.CreateTwoSlider({
		Name = "CPS",
		Min = 1,
		Max = 20,
		Function = function(val) end,
		Default = 8,
		Default2 = 12
	})
	autoclickertimed = autoclicker.CreateToggle({
		Name = "Timed",
		Function = function() end
	})
	autoclickerblocks = autoclicker.CreateToggle({
		Name = "Place Blocks", 
		Function = function() end, 
		Default = true,
		HoverText = "Automatically places blocks when left click is held."
	})

	local noclickfunc
	noclickdelay = GuiLibrary.ObjectsThatCanBeSaved.CombatWindow.Api.CreateOptionsButton({
		Name = "NoClickDelay",
		Function = function(callback)
			if callback then
				noclickfunc = bedwars.SwordController.isClickingTooFast
				bedwars.SwordController.isClickingTooFast = function(self) 
					self.lastSwing = tick()
					return false 
				end
			else
				bedwars.SwordController.isClickingTooFast = noclickfunc
			end
		end,
		HoverText = "Remove the CPS cap"
	})
end)

runFunction(function()
	local ReachValue = {Value = 14}
	Reach = GuiLibrary.ObjectsThatCanBeSaved.CombatWindow.Api.CreateOptionsButton({
		Name = "Reach",
		Function = function(callback)
			if callback then
				bedwars.CombatConstant.RAYCAST_SWORD_CHARACTER_DISTANCE = ReachValue.Value + 2
			else
				bedwars.CombatConstant.RAYCAST_SWORD_CHARACTER_DISTANCE = 14.4
			end
		end, 
		HoverText = "Extends attack reach"
	})
	ReachValue = Reach.CreateSlider({
		Name = "Reach",
		Min = 0,
		Max = 18,
		Function = function(val)
			if Reach.Enabled then
				bedwars.CombatConstant.RAYCAST_SWORD_CHARACTER_DISTANCE = val + 2
			end
		end,
		Default = 18
	})
end)

runFunction(function()
	local Sprint = {Enabled = false}
	local oldSprintFunction
	Sprint = GuiLibrary.ObjectsThatCanBeSaved.CombatWindow.Api.CreateOptionsButton({
		Name = "Sprint",
		Function = function(callback)
			if callback then
				if inputService.TouchEnabled then
					pcall(function() lplr.PlayerGui.MobileUI["4"].Visible = false end)
				end
				oldSprintFunction = bedwars.SprintController.stopSprinting
				bedwars.SprintController.stopSprinting = function(...)
					local originalCall = oldSprintFunction(...)
					bedwars.SprintController:startSprinting()
					return originalCall
				end
				table.insert(Sprint.Connections, lplr.CharacterAdded:Connect(function(char)
					char:WaitForChild("Humanoid", 9e9)
					task.wait(0.5)
					bedwars.SprintController:stopSprinting()
				end))
				task.spawn(function()
					bedwars.SprintController:startSprinting()
				end)
			else
				if inputService.TouchEnabled then
					pcall(function() lplr.PlayerGui.MobileUI["3"].Visible = true end)
				end
				bedwars.SprintController.stopSprinting = oldSprintFunction
				bedwars.SprintController:stopSprinting()
			end
		end,
		HoverText = "Sets your sprinting to true."
	})
end)

runFunction(function()
	local Velocity = {Enabled = false}
	local VelocityHorizontal = {Value = 100}
	local VelocityVertical = {Value = 100}
	local applyKnockback
	Velocity = GuiLibrary.ObjectsThatCanBeSaved.CombatWindow.Api.CreateOptionsButton({
		Name = "Velocity",
		Function = function(callback)
			if callback then
				applyKnockback = bedwars.KnockbackUtil.applyKnockback
				bedwars.KnockbackUtil.applyKnockback = function(root, mass, dir, knockback, ...)
					knockback = knockback or {}
					if VelocityHorizontal.Value == 0 and VelocityVertical.Value == 0 then return end
					knockback.horizontal = (knockback.horizontal or 1) * (VelocityHorizontal.Value / 100)
					knockback.vertical = (knockback.vertical or 1) * (VelocityVertical.Value / 100)
					return applyKnockback(root, mass, dir, knockback, ...)
				end
			else
				bedwars.KnockbackUtil.applyKnockback = applyKnockback
			end
		end,
		HoverText = "Reduces knockback taken"
	})
	VelocityHorizontal = Velocity.CreateSlider({
		Name = "Horizontal",
		Min = 0,
		Max = 100,
		Percent = true,
		Function = function(val) end,
		Default = 0
	})
	VelocityVertical = Velocity.CreateSlider({
		Name = "Vertical",
		Min = 0,
		Max = 100,
		Percent = true,
		Function = function(val) end,
		Default = 0
	})
end)

runFunction(function()
	local AutoLeaveDelay = {Value = 1}
	local AutoPlayAgain = {Enabled = false}
	local AutoLeaveStaff = {Enabled = true}
	local AutoLeaveStaff2 = {Enabled = true}
	local AutoLeaveRandom = {Enabled = false}
	local leaveAttempted = false

	local function getRole(plr)
		local suc, res = pcall(function() return plr:GetRankInGroup(5774246) end)
		if not suc then 
			repeat
				suc, res = pcall(function() return plr:GetRankInGroup(5774246) end)
				task.wait()
			until suc
		end
		if plr.UserId == 1774814725 then 
			return 200
		end
		return res
	end

	local flyAllowedmodules = {"Sprint", "AutoClicker", "AutoReport", "AutoReportV2", "AutoRelic", "AimAssist", "AutoLeave", "Reach"}
	local function autoLeaveAdded(plr)
		task.spawn(function()
			if not shared.VapeFullyLoaded then
				repeat task.wait() until shared.VapeFullyLoaded
			end
			if getRole(plr) >= 100 then
				if AutoLeaveStaff.Enabled then
					if #bedwars.ClientStoreHandler:getState().Party.members > 0 then 
						bedwars.LobbyClientEvents.leaveParty()
					end
					if AutoLeaveStaff2.Enabled then 
						warningNotification("Vape", "Staff Detected : "..(plr.DisplayName and plr.DisplayName.." ("..plr.Name..")" or plr.Name).." : Play legit like nothing happened to have the highest chance of not getting banned.", 60)
						GuiLibrary.SaveSettings = function() end
						for i,v in pairs(GuiLibrary.ObjectsThatCanBeSaved) do 
							if v.Type == "OptionsButton" then
								if table.find(flyAllowedmodules, i:gsub("OptionsButton", "")) == nil and tostring(v.Object.Parent.Parent):find("Render") == nil then
									if v.Api.Enabled then
										v.Api.ToggleButton(false)
									end
									v.Api.SetKeybind("")
									v.Object.TextButton.Visible = false
								end
							end
						end
					else
						GuiLibrary.SelfDestruct()
						game:GetService("StarterGui"):SetCore("SendNotification", {
							Title = "Vape",
							Text = "Staff Detected\n"..(plr.DisplayName and plr.DisplayName.." ("..plr.Name..")" or plr.Name),
							Duration = 60,
						})
					end
					return
				else
					warningNotification("Vape", "Staff Detected : "..(plr.DisplayName and plr.DisplayName.." ("..plr.Name..")" or plr.Name), 60)
				end
			end
		end)
	end

	local function isEveryoneDead()
		if #bedwars.ClientStoreHandler:getState().Party.members > 0 then
			for i,v in pairs(bedwars.ClientStoreHandler:getState().Party.members) do
				local plr = playersService:FindFirstChild(v.name)
				if plr and isAlive(plr, true) then
					return false
				end
			end
			return true
		else
			return true
		end
	end

	AutoLeave = GuiLibrary.ObjectsThatCanBeSaved.BlatantWindow.Api.CreateOptionsButton({
		Name = "AutoLeave", 
		Function = function(callback)
			if callback then
				table.insert(AutoLeave.Connections, vapeEvents.EntityDeathEvent.Event:Connect(function(deathTable)
					if (not leaveAttempted) and deathTable.finalKill and deathTable.entityInstance == lplr.Character then
						leaveAttempted = true
						if isEveryoneDead() and bedwarsStore.matchState ~= 2 then
							task.wait(1 + (AutoLeaveDelay.Value / 10))
							if bedwars.ClientStoreHandler:getState().Game.customMatch == nil and bedwars.ClientStoreHandler:getState().Party.leader.userId == lplr.UserId then
								if not AutoPlayAgain.Enabled then
									bedwars.ClientHandler:Get("TeleportToLobby"):SendToServer()
								else
									if AutoLeaveRandom.Enabled then 
										local listofmodes = {}
										for i,v in pairs(bedwars.QueueMeta) do
											if not v.disabled and not v.voiceChatOnly and not v.rankCategory then table.insert(listofmodes, i) end
										end
										bedwars.LobbyClientEvents:joinQueue(listofmodes[math.random(1, #listofmodes)])
									else
										bedwars.LobbyClientEvents:joinQueue(bedwarsStore.queueType)
									end
								end
							end
						end
					end
				end))
				table.insert(AutoLeave.Connections, vapeEvents.MatchEndEvent.Event:Connect(function(deathTable)
					task.wait(AutoLeaveDelay.Value / 10)
					if not AutoLeave.Enabled then return end
					if leaveAttempted then return end
					leaveAttempted = true
					if bedwars.ClientStoreHandler:getState().Game.customMatch == nil and bedwars.ClientStoreHandler:getState().Party.leader.userId == lplr.UserId then
						if not AutoPlayAgain.Enabled then
							bedwars.ClientHandler:Get("TeleportToLobby"):SendToServer()
						else
							if bedwars.ClientStoreHandler:getState().Party.queueState == 0 then
								if AutoLeaveRandom.Enabled then 
									local listofmodes = {}
									for i,v in pairs(bedwars.QueueMeta) do
										if not v.disabled and not v.voiceChatOnly and not v.rankCategory then table.insert(listofmodes, i) end
									end
									bedwars.LobbyClientEvents:joinQueue(listofmodes[math.random(1, #listofmodes)])
								else
									bedwars.LobbyClientEvents:joinQueue(bedwarsStore.queueType)
								end
							end
						end
					end
				end))
				table.insert(AutoLeave.Connections, playersService.PlayerAdded:Connect(autoLeaveAdded))
				for i, plr in pairs(playersService:GetPlayers()) do
					autoLeaveAdded(plr)
				end
			end
		end,
		HoverText = "Leaves if a staff member joins your game or when the match ends."
	})
	AutoLeaveDelay = AutoLeave.CreateSlider({
		Name = "Delay",
		Min = 0,
		Max = 50,
		Default = 0,
		Function = function() end,
		HoverText = "Delay before going back to the hub."
	})
	AutoPlayAgain = AutoLeave.CreateToggle({
		Name = "Play Again",
		Function = function() end,
		HoverText = "Automatically queues a new game.",
		Default = true
	})
	AutoLeaveStaff = AutoLeave.CreateToggle({
		Name = "Staff",
		Function = function(callback) 
			if AutoLeaveStaff2.Object then 
				AutoLeaveStaff2.Object.Visible = callback
			end
		end,
		HoverText = "Automatically uninjects when staff joins",
		Default = true
	})
	AutoLeaveStaff2 = AutoLeave.CreateToggle({
		Name = "Staff AutoConfig",
		Function = function() end,
		HoverText = "Instead of uninjecting, It will now reconfig vape temporarily to a more legit config.",
		Default = true
	})
	AutoLeaveRandom = AutoLeave.CreateToggle({
		Name = "Random",
		Function = function(callback) end,
		HoverText = "Chooses a random mode"
	})
	AutoLeaveStaff2.Object.Visible = false
end)

runFunction(function()
	local oldclickhold
	local oldclickhold2
	local roact 
	local FastConsume = GuiLibrary.ObjectsThatCanBeSaved.BlatantWindow.Api.CreateOptionsButton({
		Name = "FastConsume",
		Function = function(callback)
			if callback then
				oldclickhold = bedwars.ClickHold.startClick
				oldclickhold2 = bedwars.ClickHold.showProgress
				bedwars.ClickHold.showProgress = function(p5)
					local roact = debug.getupvalue(oldclickhold2, 1)
					local countdown = roact.mount(roact.createElement("ScreenGui", {}, { roact.createElement("Frame", {
						[roact.Ref] = p5.wrapperRef, 
						Size = UDim2.new(0, 0, 0, 0), 
						Position = UDim2.new(0.5, 0, 0.55, 0), 
						AnchorPoint = Vector2.new(0.5, 0), 
						BackgroundColor3 = Color3.fromRGB(0, 0, 0), 
						BackgroundTransparency = 0.8
					}, { roact.createElement("Frame", {
							[roact.Ref] = p5.progressRef, 
							Size = UDim2.new(0, 0, 1, 0), 
							BackgroundColor3 = Color3.fromRGB(255, 255, 255), 
							BackgroundTransparency = 0.5
						}) }) }), lplr:FindFirstChild("PlayerGui"))
					p5.handle = countdown
					local sizetween = tweenService:Create(p5.wrapperRef:getValue(), TweenInfo.new(0.1), {
						Size = UDim2.new(0.11, 0, 0.005, 0)
					})
					table.insert(p5.tweens, sizetween)
					sizetween:Play()
					local countdowntween = tweenService:Create(p5.progressRef:getValue(), TweenInfo.new(p5.durationSeconds * (FastConsumeVal.Value / 40), Enum.EasingStyle.Linear), {
						Size = UDim2.new(1, 0, 1, 0)
					})
					table.insert(p5.tweens, countdowntween)
					countdowntween:Play()
					return countdown
				end
				bedwars.ClickHold.startClick = function(p4)
					p4.startedClickTime = tick()
					local u2 = p4:showProgress()
					local clicktime = p4.startedClickTime
					bedwars.RuntimeLib.Promise.defer(function()
						task.wait(p4.durationSeconds * (FastConsumeVal.Value / 40))
						if u2 == p4.handle and clicktime == p4.startedClickTime and p4.closeOnComplete then
							p4:hideProgress()
							if p4.onComplete ~= nil then
								p4.onComplete()
							end
							if p4.onPartialComplete ~= nil then
								p4.onPartialComplete(1)
							end
							p4.startedClickTime = -1
						end
					end)
				end
			else
				bedwars.ClickHold.startClick = oldclickhold
				bedwars.ClickHold.showProgress = oldclickhold2
				oldclickhold = nil
				oldclickhold2 = nil
			end
		end,
		HoverText = "Use/Consume items quicker."
	})
	FastConsumeVal = FastConsume.CreateSlider({
		Name = "Ticks",
		Min = 0,
		Max = 40,
		Default = 0,
		Function = function() end
	})
end)

local autobankballoon = false
runFunction(function()
	local Fly = {Enabled = false}
	local FlyMode = {Value = "CFrame"}
	local FlyVerticalSpeed = {Value = 40}
	local FlyVertical = {Enabled = true}
	local FlyAutoPop = {Enabled = true}
	local FlyAnyway = {Enabled = false}
	local FlyAnywayProgressBar = {Enabled = false}
	local FlyDamageAnimation = {Enabled = false}
	local FlyTP = {Enabled = false}
	local FlyAnywayProgressBarFrame
	local olddeflate
	local FlyUp = false
	local FlyDown = false
	local FlyCoroutine
	local groundtime = tick()
	local onground = false
	local lastonground = false
	local alternatelist = {"Normal", "AntiCheat A", "AntiCheat B"}

	local function inflateBalloon()
		if not Fly.Enabled then return end
		if entityLibrary.isAlive and (lplr.Character:GetAttribute("InflatedBalloons") or 0) < 1 then
			autobankballoon = true
			if getItem("balloon") then
				bedwars.BalloonController:inflateBalloon()
				return true
			end
		end
		return false
	end

	Fly = GuiLibrary.ObjectsThatCanBeSaved.BlatantWindow.Api.CreateOptionsButton({
		Name = "Fly",
		Function = function(callback)
			if callback then
				olddeflate = bedwars.BalloonController.deflateBalloon
				bedwars.BalloonController.deflateBalloon = function() end

				table.insert(Fly.Connections, inputService.InputBegan:Connect(function(input1)
					if FlyVertical.Enabled and inputService:GetFocusedTextBox() == nil then
						if input1.KeyCode == Enum.KeyCode.Space or input1.KeyCode == Enum.KeyCode.ButtonA then
							FlyUp = true
						end
						if input1.KeyCode == Enum.KeyCode.LeftShift or input1.KeyCode == Enum.KeyCode.ButtonL2 then
							FlyDown = true
						end
					end
				end))
				table.insert(Fly.Connections, inputService.InputEnded:Connect(function(input1)
					if input1.KeyCode == Enum.KeyCode.Space or input1.KeyCode == Enum.KeyCode.ButtonA then
						FlyUp = false
					end
					if input1.KeyCode == Enum.KeyCode.LeftShift or input1.KeyCode == Enum.KeyCode.ButtonL2 then
						FlyDown = false
					end
				end))
				if inputService.TouchEnabled then
					pcall(function()
						local jumpButton = lplr.PlayerGui.TouchGui.TouchControlFrame.JumpButton
						table.insert(Fly.Connections, jumpButton:GetPropertyChangedSignal("ImageRectOffset"):Connect(function()
							FlyUp = jumpButton.ImageRectOffset.X == 146
						end))
						FlyUp = jumpButton.ImageRectOffset.X == 146
					end)
				end
				table.insert(Fly.Connections, vapeEvents.BalloonPopped.Event:Connect(function(poppedTable)
					if poppedTable.inflatedBalloon and poppedTable.inflatedBalloon:GetAttribute("BalloonOwner") == lplr.UserId then 
						lastonground = not onground
						repeat task.wait() until (lplr.Character:GetAttribute("InflatedBalloons") or 0) <= 0 or not Fly.Enabled
						inflateBalloon() 
					end
				end))
				table.insert(Fly.Connections, vapeEvents.AutoBankBalloon.Event:Connect(function()
					repeat task.wait() until getItem("balloon")
					inflateBalloon()
				end))

				local balloons
				if entityLibrary.isAlive and (not bedwarsStore.queueType:find("mega")) then
					balloons = inflateBalloon()
				end
				local megacheck = bedwarsStore.queueType:find("mega") or bedwarsStore.queueType == "winter_event"

				task.spawn(function()
					repeat task.wait() until bedwarsStore.queueType ~= "bedwars_test" or (not Fly.Enabled)
					if not Fly.Enabled then return end
					megacheck = bedwarsStore.queueType:find("mega") or bedwarsStore.queueType == "winter_event"
				end)

				local flyAllowed = entityLibrary.isAlive and ((lplr.Character:GetAttribute("InflatedBalloons") and lplr.Character:GetAttribute("InflatedBalloons") > 0) or bedwarsStore.matchState == 2 or megacheck) and 1 or 0
				if flyAllowed <= 0 and shared.damageanim and (not balloons) then 
					shared.damageanim()
					bedwars.SoundManager:playSound(bedwars.SoundList["DAMAGE_"..math.random(1, 3)])
				end

				if FlyAnywayProgressBarFrame and flyAllowed <= 0 and (not balloons) then 
					FlyAnywayProgressBarFrame.Visible = true
					FlyAnywayProgressBarFrame.Frame:TweenSize(UDim2.new(1, 0, 0, 20), Enum.EasingDirection.InOut, Enum.EasingStyle.Linear, 0, true)
				end

				groundtime = tick() + (2.6 + (entityLibrary.groundTick - tick()))
				FlyCoroutine = coroutine.create(function()
					repeat
						repeat task.wait() until (groundtime - tick()) < 0.6 and not onground
						flyAllowed = ((lplr.Character and lplr.Character:GetAttribute("InflatedBalloons") and lplr.Character:GetAttribute("InflatedBalloons") > 0) or bedwarsStore.matchState == 2 or megacheck) and 1 or 0
						if (not Fly.Enabled) then break end
						local Flytppos = -99999
						if flyAllowed <= 0 and FlyTP.Enabled and entityLibrary.isAlive then 
							local ray = workspace:Raycast(entityLibrary.character.HumanoidRootPart.Position, Vector3.new(0, -1000, 0), bedwarsStore.blockRaycast)
							if ray then 
								Flytppos = entityLibrary.character.HumanoidRootPart.Position.Y
								local args = {entityLibrary.character.HumanoidRootPart.CFrame:GetComponents()}
								args[2] = ray.Position.Y + (entityLibrary.character.HumanoidRootPart.Size.Y / 2) + entityLibrary.character.Humanoid.HipHeight
								entityLibrary.character.HumanoidRootPart.CFrame = CFrame.new(unpack(args))
								task.wait(0.12)
								if (not Fly.Enabled) then break end
								flyAllowed = ((lplr.Character and lplr.Character:GetAttribute("InflatedBalloons") and lplr.Character:GetAttribute("InflatedBalloons") > 0) or bedwarsStore.matchState == 2 or megacheck) and 1 or 0
								if flyAllowed <= 0 and Flytppos ~= -99999 and entityLibrary.isAlive then 
									local args = {entityLibrary.character.HumanoidRootPart.CFrame:GetComponents()}
									args[2] = Flytppos
									entityLibrary.character.HumanoidRootPart.CFrame = CFrame.new(unpack(args))
								end
							end
						end
					until (not Fly.Enabled)
				end)
				coroutine.resume(FlyCoroutine)

				RunLoops:BindToHeartbeat("Fly", function(delta) 
					if GuiLibrary.ObjectsThatCanBeSaved["Lobby CheckToggle"].Api.Enabled then 
						if bedwars.matchState == 0 then return end
					end
					if entityLibrary.isAlive then
						local playerMass = (entityLibrary.character.HumanoidRootPart:GetMass() - 1.4) * (delta * 100)
						flyAllowed = ((lplr.Character:GetAttribute("InflatedBalloons") and lplr.Character:GetAttribute("InflatedBalloons") > 0) or bedwarsStore.matchState == 2 or megacheck) and 1 or 0
						playerMass = playerMass + (flyAllowed > 0 and 4 or 0) * (tick() % 0.4 < 0.2 and -1 or 1)

						if FlyAnywayProgressBarFrame then
							FlyAnywayProgressBarFrame.Visible = flyAllowed <= 0
							FlyAnywayProgressBarFrame.BackgroundColor3 = Color3.fromHSV(GuiLibrary.ObjectsThatCanBeSaved["Gui ColorSliderColor"].Api.Hue, GuiLibrary.ObjectsThatCanBeSaved["Gui ColorSliderColor"].Api.Sat, GuiLibrary.ObjectsThatCanBeSaved["Gui ColorSliderColor"].Api.Value)
							FlyAnywayProgressBarFrame.Frame.BackgroundColor3 = Color3.fromHSV(GuiLibrary.ObjectsThatCanBeSaved["Gui ColorSliderColor"].Api.Hue, GuiLibrary.ObjectsThatCanBeSaved["Gui ColorSliderColor"].Api.Sat, GuiLibrary.ObjectsThatCanBeSaved["Gui ColorSliderColor"].Api.Value)
						end

						if flyAllowed <= 0 then 
							local newray = getPlacedBlock(entityLibrary.character.HumanoidRootPart.Position + Vector3.new(0, (entityLibrary.character.Humanoid.HipHeight * -2) - 1, 0))
							onground = newray and true or false
							if lastonground ~= onground then 
								if (not onground) then 
									groundtime = tick() + (2.6 + (entityLibrary.groundTick - tick()))
									if FlyAnywayProgressBarFrame then 
										FlyAnywayProgressBarFrame.Frame:TweenSize(UDim2.new(0, 0, 0, 20), Enum.EasingDirection.InOut, Enum.EasingStyle.Linear, groundtime - tick(), true)
									end
								else
									if FlyAnywayProgressBarFrame then 
										FlyAnywayProgressBarFrame.Frame:TweenSize(UDim2.new(1, 0, 0, 20), Enum.EasingDirection.InOut, Enum.EasingStyle.Linear, 0, true)
									end
								end
							end
							if FlyAnywayProgressBarFrame then 
								FlyAnywayProgressBarFrame.TextLabel.Text = math.max(onground and 2.5 or math.floor((groundtime - tick()) * 10) / 10, 0).."s"
							end
							lastonground = onground
						else
							onground = true
							lastonground = true
						end

						local flyVelocity = entityLibrary.character.Humanoid.MoveDirection * (FlyMode.Value == "Normal" and FlySpeed.Value or 20)
						entityLibrary.character.HumanoidRootPart.Velocity = flyVelocity + (Vector3.new(0, playerMass + (FlyUp and FlyVerticalSpeed.Value or 0) + (FlyDown and -FlyVerticalSpeed.Value or 0), 0))
						if FlyMode.Value ~= "Normal" then
							entityLibrary.character.HumanoidRootPart.CFrame = entityLibrary.character.HumanoidRootPart.CFrame + (entityLibrary.character.Humanoid.MoveDirection * ((FlySpeed.Value + getSpeed()) - 20)) * delta
						end
					end
				end)
			else
				pcall(function() coroutine.close(FlyCoroutine) end)
				autobankballoon = false
				waitingforballoon = false
				lastonground = nil
				FlyUp = false
				FlyDown = false
				RunLoops:UnbindFromHeartbeat("Fly")
				if FlyAnywayProgressBarFrame then 
					FlyAnywayProgressBarFrame.Visible = false
				end
				if FlyAutoPop.Enabled then
					if entityLibrary.isAlive and lplr.Character:GetAttribute("InflatedBalloons") then
						for i = 1, lplr.Character:GetAttribute("InflatedBalloons") do
							olddeflate()
						end
					end
				end
				bedwars.BalloonController.deflateBalloon = olddeflate
				olddeflate = nil
			end
		end,
		HoverText = "Makes you go zoom (longer Fly discovered by exelys and Cqded)",
		ExtraText = function() 
			return "Heatseeker"
		end
	})
	FlySpeed = Fly.CreateSlider({
		Name = "Speed",
		Min = 1,
		Max = 23,
		Function = function(val) end, 
		Default = 23
	})
	FlyVerticalSpeed = Fly.CreateSlider({
		Name = "Vertical Speed",
		Min = 1,
		Max = 100,
		Function = function(val) end, 
		Default = 44
	})
	FlyVertical = Fly.CreateToggle({
		Name = "Y Level",
		Function = function() end, 
		Default = true
	})
	FlyAutoPop = Fly.CreateToggle({
		Name = "Pop Balloon",
		Function = function() end, 
		HoverText = "Pops balloons when Fly is disabled."
	})
	local oldcamupdate
	local camcontrol
	local Flydamagecamera = {Enabled = false}
	FlyDamageAnimation = Fly.CreateToggle({
		Name = "Damage Animation",
		Function = function(callback) 
			if Flydamagecamera.Object then 
				Flydamagecamera.Object.Visible = callback
			end
			if callback then 
				task.spawn(function()
					repeat
						task.wait(0.1)
						for i,v in pairs(getconnections(gameCamera:GetPropertyChangedSignal("CameraType"))) do 
							if v.Function then
								camcontrol = debug.getupvalue(v.Function, 1)
							end
						end
					until camcontrol
					local caminput = require(lplr.PlayerScripts.PlayerModule.CameraModule.CameraInput)
					local num = Instance.new("IntValue")
					local numanim
					shared.damageanim = function()
						if numanim then numanim:Cancel() end
						if Flydamagecamera.Enabled then
							num.Value = 1000
							numanim = tweenService:Create(num, TweenInfo.new(0.5), {Value = 0})
							numanim:Play()
						end
					end
					oldcamupdate = camcontrol.Update
					camcontrol.Update = function(self, dt) 
						if camcontrol.activeCameraController then
							camcontrol.activeCameraController:UpdateMouseBehavior()
							local newCameraCFrame, newCameraFocus = camcontrol.activeCameraController:Update(dt)
							gameCamera.CFrame = newCameraCFrame * CFrame.Angles(0, 0, math.rad(num.Value / 100))
							gameCamera.Focus = newCameraFocus
							if camcontrol.activeTransparencyController then
								camcontrol.activeTransparencyController:Update(dt)
							end
							if caminput.getInputEnabled() then
								caminput.resetInputForFrameEnd()
							end
						end
					end
				end)
			else
				shared.damageanim = nil
				if camcontrol then 
					camcontrol.Update = oldcamupdate
				end
			end
		end
	})
	Flydamagecamera = Fly.CreateToggle({
		Name = "Camera Animation",
		Function = function() end,
		Default = true
	})
	Flydamagecamera.Object.BorderSizePixel = 0
	Flydamagecamera.Object.BackgroundTransparency = 0
	Flydamagecamera.Object.BackgroundColor3 = Color3.fromRGB(15, 15, 15)
	Flydamagecamera.Object.Visible = false
	FlyAnywayProgressBar = Fly.CreateToggle({
		Name = "Progress Bar",
		Function = function(callback) 
			if callback then 
				FlyAnywayProgressBarFrame = Instance.new("Frame")
				FlyAnywayProgressBarFrame.AnchorPoint = Vector2.new(0.5, 0)
				FlyAnywayProgressBarFrame.Position = UDim2.new(0.5, 0, 1, -200)
				FlyAnywayProgressBarFrame.Size = UDim2.new(0.2, 0, 0, 20)
				FlyAnywayProgressBarFrame.BackgroundTransparency = 0.5
				FlyAnywayProgressBarFrame.BorderSizePixel = 0
				FlyAnywayProgressBarFrame.BackgroundColor3 = Color3.new(0, 0, 0)
				FlyAnywayProgressBarFrame.Visible = Fly.Enabled
				FlyAnywayProgressBarFrame.Parent = GuiLibrary.MainGui
				local FlyAnywayProgressBarFrame2 = FlyAnywayProgressBarFrame:Clone()
				FlyAnywayProgressBarFrame2.AnchorPoint = Vector2.new(0, 0)
				FlyAnywayProgressBarFrame2.Position = UDim2.new(0, 0, 0, 0)
				FlyAnywayProgressBarFrame2.Size = UDim2.new(1, 0, 0, 20)
				FlyAnywayProgressBarFrame2.BackgroundTransparency = 0
				FlyAnywayProgressBarFrame2.Visible = true
				FlyAnywayProgressBarFrame2.Parent = FlyAnywayProgressBarFrame
				local FlyAnywayProgressBartext = Instance.new("TextLabel")
				FlyAnywayProgressBartext.Text = "2s"
				FlyAnywayProgressBartext.Font = Enum.Font.Gotham
				FlyAnywayProgressBartext.TextStrokeTransparency = 0
				FlyAnywayProgressBartext.TextColor3 =  Color3.new(0.9, 0.9, 0.9)
				FlyAnywayProgressBartext.TextSize = 20
				FlyAnywayProgressBartext.Size = UDim2.new(1, 0, 1, 0)
				FlyAnywayProgressBartext.BackgroundTransparency = 1
				FlyAnywayProgressBartext.Position = UDim2.new(0, 0, -1, 0)
				FlyAnywayProgressBartext.Parent = FlyAnywayProgressBarFrame
			else
				if FlyAnywayProgressBarFrame then FlyAnywayProgressBarFrame:Destroy() FlyAnywayProgressBarFrame = nil end
			end
		end,
		HoverText = "show amount of Fly time",
		Default = true
	})
	FlyTP = Fly.CreateToggle({
		Name = "TP Down",
		Function = function() end,
		Default = true
	})
end)

runFunction(function()
	local GrappleExploit = {Enabled = false}
	local GrappleExploitMode = {Value = "Normal"}
	local GrappleExploitVerticalSpeed = {Value = 40}
	local GrappleExploitVertical = {Enabled = true}
	local GrappleExploitUp = false
	local GrappleExploitDown = false
	local alternatelist = {"Normal", "AntiCheat A", "AntiCheat B"}
	local projectileRemote = bedwars.ClientHandler:Get(bedwars.ProjectileRemote)

	--me when I have to fix bw code omegalol
	bedwars.ClientHandler:Get("GrapplingHookFunctions"):Connect(function(p4)
		if p4.hookFunction == "PLAYER_IN_TRANSIT" then
			bedwars.CooldownController:setOnCooldown("grappling_hook", 3.5)
		end
	end)

	GrappleExploit = GuiLibrary.ObjectsThatCanBeSaved.BlatantWindow.Api.CreateOptionsButton({
		Name = "GrappleExploit",
		Function = function(callback)
			if callback then
				local grappleHooked = false
				table.insert(GrappleExploit.Connections, bedwars.ClientHandler:Get("GrapplingHookFunctions"):Connect(function(p4)
					if p4.hookFunction == "PLAYER_IN_TRANSIT" then
						bedwarsStore.grapple = tick() + 1.8
						grappleHooked = true
						GrappleExploit.ToggleButton(false)
					end
				end))

				local fireball = getItem("grappling_hook")
				if fireball then 
					task.spawn(function()
						repeat task.wait() until bedwars.CooldownController:getRemainingCooldown("grappling_hook") == 0 or (not GrappleExploit.Enabled)
						if (not GrappleExploit.Enabled) then return end
						switchItem(fireball.tool)
						local pos = entityLibrary.character.HumanoidRootPart.CFrame.p
						local offsetshootpos = (CFrame.new(pos, pos + Vector3.new(0, -60, 0)) * CFrame.new(Vector3.new(-bedwars.BowConstantsTable.RelX, -bedwars.BowConstantsTable.RelY, -bedwars.BowConstantsTable.RelZ))).p
						projectileRemote:CallServerAsync(fireball["tool"], nil, "grappling_hook_projectile", offsetshootpos, pos, Vector3.new(0, -60, 0), game:GetService("HttpService"):GenerateGUID(true), {drawDurationSeconds = 1}, workspace:GetServerTimeNow() - 0.045)
					end)
				else
					warningNotification("GrappleExploit", "missing grapple hook", 3)
					GrappleExploit.ToggleButton(false)
					return
				end

				local startCFrame = entityLibrary.isAlive and entityLibrary.character.HumanoidRootPart.CFrame
				RunLoops:BindToHeartbeat("GrappleExploit", function(delta) 
					if GuiLibrary.ObjectsThatCanBeSaved["Lobby CheckToggle"].Api.Enabled then 
						if bedwars.matchState == 0 then return end
					end
					if entityLibrary.isAlive then
						entityLibrary.character.HumanoidRootPart.Velocity = Vector3.zero
						entityLibrary.character.HumanoidRootPart.CFrame = startCFrame
					end
				end)
			else
				GrappleExploitUp = false
				GrappleExploitDown = false
				RunLoops:UnbindFromHeartbeat("GrappleExploit")
			end
		end,
		HoverText = "Makes you go zoom (longer GrappleExploit discovered by exelys and Cqded)",
		ExtraText = function() 
			if GuiLibrary.ObjectsThatCanBeSaved["Text GUIAlternate TextToggle"]["Api"].Enabled then 
				return alternatelist[table.find(GrappleExploitMode["List"], GrappleExploitMode.Value)]
			end
			return GrappleExploitMode.Value 
		end
	})
end)

runFunction(function()
	local InfiniteFly = {Enabled = false}
	local InfiniteFlyMode = {Value = "CFrame"}
	local InfiniteFlySpeed = {Value = 23}
	local InfiniteFlyVerticalSpeed = {Value = 40}
	local InfiniteFlyVertical = {Enabled = true}
	local InfiniteFlyUp = false
	local InfiniteFlyDown = false
	local alternatelist = {"Normal", "AntiCheat A", "AntiCheat B"}
	local clonesuccess = false
	local disabledproper = true
	local oldcloneroot
	local cloned
	local clone
	local bodyvelo
	local FlyOverlap = OverlapParams.new()
	FlyOverlap.MaxParts = 9e9
	FlyOverlap.FilterDescendantsInstances = {}
	FlyOverlap.RespectCanCollide = true

	local function disablefunc()
		if bodyvelo then bodyvelo:Destroy() end
		RunLoops:UnbindFromHeartbeat("InfiniteFlyOff")
		disabledproper = true
		if not oldcloneroot or not oldcloneroot.Parent then return end
		lplr.Character.Parent = game
		oldcloneroot.Parent = lplr.Character
		lplr.Character.PrimaryPart = oldcloneroot
		lplr.Character.Parent = workspace
		oldcloneroot.CanCollide = true
		for i,v in pairs(lplr.Character:GetDescendants()) do 
			if v:IsA("Weld") or v:IsA("Motor6D") then 
				if v.Part0 == clone then v.Part0 = oldcloneroot end
				if v.Part1 == clone then v.Part1 = oldcloneroot end
			end
			if v:IsA("BodyVelocity") then 
				v:Destroy()
			end
		end
		for i,v in pairs(oldcloneroot:GetChildren()) do 
			if v:IsA("BodyVelocity") then 
				v:Destroy()
			end
		end
		local oldclonepos = clone.Position.Y
		if clone then 
			clone:Destroy()
			clone = nil
		end
		lplr.Character.Humanoid.HipHeight = hip or 2
		local origcf = {oldcloneroot.CFrame:GetComponents()}
		origcf[2] = oldclonepos
		oldcloneroot.CFrame = CFrame.new(unpack(origcf))
		oldcloneroot = nil
	end

	InfiniteFly = GuiLibrary.ObjectsThatCanBeSaved.BlatantWindow.Api.CreateOptionsButton({
		Name = "InfiniteFly",
		Function = function(callback)
			if callback then
				if not entityLibrary.isAlive then 
					disabledproper = true
				end
				if not disabledproper then 
					warningNotification("InfiniteFly", "Wait for the last fly to finish", 3)
					InfiniteFly.ToggleButton(false)
					return 
				end
				table.insert(InfiniteFly.Connections, inputService.InputBegan:Connect(function(input1)
					if InfiniteFlyVertical.Enabled and inputService:GetFocusedTextBox() == nil then
						if input1.KeyCode == Enum.KeyCode.Space or input1.KeyCode == Enum.KeyCode.ButtonA then
							InfiniteFlyUp = true
						end
						if input1.KeyCode == Enum.KeyCode.LeftShift or input1.KeyCode == Enum.KeyCode.ButtonL2 then
							InfiniteFlyDown = true
						end
					end
				end))
				table.insert(InfiniteFly.Connections, inputService.InputEnded:Connect(function(input1)
					if input1.KeyCode == Enum.KeyCode.Space or input1.KeyCode == Enum.KeyCode.ButtonA then
						InfiniteFlyUp = false
					end
					if input1.KeyCode == Enum.KeyCode.LeftShift or input1.KeyCode == Enum.KeyCode.ButtonL2 then
						InfiniteFlyDown = false
					end
				end))
				if inputService.TouchEnabled then
					pcall(function()
						local jumpButton = lplr.PlayerGui.TouchGui.TouchControlFrame.JumpButton
						table.insert(InfiniteFly.Connections, jumpButton:GetPropertyChangedSignal("ImageRectOffset"):Connect(function()
							InfiniteFlyUp = jumpButton.ImageRectOffset.X == 146
						end))
						InfiniteFlyUp = jumpButton.ImageRectOffset.X == 146
					end)
				end
				clonesuccess = false
				if entityLibrary.isAlive and entityLibrary.character.Humanoid.Health > 0 and isnetworkowner(entityLibrary.character.HumanoidRootPart) then
					cloned = lplr.Character
					oldcloneroot = entityLibrary.character.HumanoidRootPart
					if not lplr.Character.Parent then 
						InfiniteFly.ToggleButton(false)
						return
					end
					lplr.Character.Parent = game
					clone = oldcloneroot:Clone()
					clone.Parent = lplr.Character
					oldcloneroot.Parent = gameCamera
					bedwars.QueryUtil:setQueryIgnored(oldcloneroot, true)
					clone.CFrame = oldcloneroot.CFrame
					lplr.Character.PrimaryPart = clone
					lplr.Character.Parent = workspace
					for i,v in pairs(lplr.Character:GetDescendants()) do 
						if v:IsA("Weld") or v:IsA("Motor6D") then 
							if v.Part0 == oldcloneroot then v.Part0 = clone end
							if v.Part1 == oldcloneroot then v.Part1 = clone end
						end
						if v:IsA("BodyVelocity") then 
							v:Destroy()
						end
					end
					for i,v in pairs(oldcloneroot:GetChildren()) do 
						if v:IsA("BodyVelocity") then 
							v:Destroy()
						end
					end
					if hip then 
						lplr.Character.Humanoid.HipHeight = hip
					end
					hip = lplr.Character.Humanoid.HipHeight
					clonesuccess = true
				end
				if not clonesuccess then 
					warningNotification("InfiniteFly", "Character missing", 3)
					InfiniteFly.ToggleButton(false)
					return 
				end
				local goneup = false
				RunLoops:BindToHeartbeat("InfiniteFly", function(delta) 
					if GuiLibrary.ObjectsThatCanBeSaved["Lobby CheckToggle"].Api.Enabled then 
						if bedwarsStore.matchState == 0 then return end
					end
					if entityLibrary.isAlive then
						if isnetworkowner(oldcloneroot) then 
							local playerMass = (entityLibrary.character.HumanoidRootPart:GetMass() - 1.4) * (delta * 100)
							
							local flyVelocity = entityLibrary.character.Humanoid.MoveDirection * (InfiniteFlyMode.Value == "Normal" and InfiniteFlySpeed.Value or 20)
							entityLibrary.character.HumanoidRootPart.Velocity = flyVelocity + (Vector3.new(0, playerMass + (InfiniteFlyUp and InfiniteFlyVerticalSpeed.Value or 0) + (InfiniteFlyDown and -InfiniteFlyVerticalSpeed.Value or 0), 0))
							if InfiniteFlyMode.Value ~= "Normal" then
								entityLibrary.character.HumanoidRootPart.CFrame = entityLibrary.character.HumanoidRootPart.CFrame + (entityLibrary.character.Humanoid.MoveDirection * ((InfiniteFlySpeed.Value + getSpeed()) - 20)) * delta
							end

							local speedCFrame = {oldcloneroot.CFrame:GetComponents()}
							speedCFrame[1] = clone.CFrame.X
							if speedCFrame[2] < 1000 or (not goneup) then 
								task.spawn(warningNotification, "InfiniteFly", "Teleported Up", 3)
								speedCFrame[2] = 100000
								goneup = true
							end
							speedCFrame[3] = clone.CFrame.Z
							oldcloneroot.CFrame = CFrame.new(unpack(speedCFrame))
							oldcloneroot.Velocity = Vector3.new(clone.Velocity.X, oldcloneroot.Velocity.Y, clone.Velocity.Z)
						else
							InfiniteFly.ToggleButton(false)
						end
					end
				end)
			else
				RunLoops:UnbindFromHeartbeat("InfiniteFly")
				if clonesuccess and oldcloneroot and clone and lplr.Character.Parent == workspace and oldcloneroot.Parent ~= nil and disabledproper and cloned == lplr.Character then 
					local rayparams = RaycastParams.new()
					rayparams.FilterDescendantsInstances = {lplr.Character, gameCamera}
					rayparams.RespectCanCollide = true
					local ray = workspace:Raycast(Vector3.new(oldcloneroot.Position.X, clone.CFrame.p.Y, oldcloneroot.Position.Z), Vector3.new(0, -1000, 0), rayparams)
					local origcf = {clone.CFrame:GetComponents()}
					origcf[1] = oldcloneroot.Position.X
					origcf[2] = ray and ray.Position.Y + (entityLibrary.character.Humanoid.HipHeight + (oldcloneroot.Size.Y / 2)) or clone.CFrame.p.Y
					origcf[3] = oldcloneroot.Position.Z
					oldcloneroot.CanCollide = true
					bodyvelo = Instance.new("BodyVelocity")
					bodyvelo.MaxForce = Vector3.new(0, 9e9, 0)
					bodyvelo.Velocity = Vector3.new(0, -1, 0)
					bodyvelo.Parent = oldcloneroot
					oldcloneroot.Velocity = Vector3.new(clone.Velocity.X, -1, clone.Velocity.Z)
					RunLoops:BindToHeartbeat("InfiniteFlyOff", function(dt)
						if oldcloneroot then 
							oldcloneroot.Velocity = Vector3.new(clone.Velocity.X, -1, clone.Velocity.Z)
							local bruh = {clone.CFrame:GetComponents()}
							bruh[2] = oldcloneroot.CFrame.Y
							local newcf = CFrame.new(unpack(bruh))
							FlyOverlap.FilterDescendantsInstances = {lplr.Character, gameCamera}
							local allowed = true
							for i,v in pairs(workspace:GetPartBoundsInRadius(newcf.p, 2, FlyOverlap)) do 
								if (v.Position.Y + (v.Size.Y / 2)) > (newcf.p.Y + 0.5) then 
									allowed = false
									break
								end
							end
							if allowed then
								oldcloneroot.CFrame = newcf
							end
						end
					end)
					oldcloneroot.CFrame = CFrame.new(unpack(origcf))
					entityLibrary.character.Humanoid:ChangeState(Enum.HumanoidStateType.Landed)
					disabledproper = false
					if isnetworkowner(oldcloneroot) then 
						warningNotification("InfiniteFly", "Waiting 1.5s to not flag", 3)
						task.delay(1.5, disablefunc)
					else
						disablefunc()
					end
				end
				InfiniteFlyUp = false
				InfiniteFlyDown = false
			end
		end,
		HoverText = "Makes you go zoom",
		ExtraText = function()
			return "Heatseeker"
		end
	})
	InfiniteFlySpeed = InfiniteFly.CreateSlider({
		Name = "Speed",
		Min = 1,
		Max = 23,
		Function = function(val) end, 
		Default = 23
	})
	InfiniteFlyVerticalSpeed = InfiniteFly.CreateSlider({
		Name = "Vertical Speed",
		Min = 1,
		Max = 100,
		Function = function(val) end, 
		Default = 44
	})
	InfiniteFlyVertical = InfiniteFly.CreateToggle({
		Name = "Y Level",
		Function = function() end, 
		Default = true
	})
end)

local killauraNearPlayer
runFunction(function()
	local killauraboxes = {}
    local killauratargetframe = {Players = {Enabled = false}}
	local killaurasortmethod = {Value = "Distance"}
    local killaurarealremote = bedwars.ClientHandler:Get(bedwars.AttackRemote).instance
    local killauramethod = {Value = "Normal"}
	local killauraothermethod = {Value = "Normal"}
    local killauraanimmethod = {Value = "Normal"}
    local killaurarange = {Value = 14}
    local killauraangle = {Value = 360}
    local killauratargets = {Value = 10}
	local killauraautoblock = {Enabled = false}
    local killauramouse = {Enabled = false}
    local killauracframe = {Enabled = false}
    local killauragui = {Enabled = false}
    local killauratarget = {Enabled = false}
    local killaurasound = {Enabled = false}
    local killauraswing = {Enabled = false}
	local killaurasync = {Enabled = false}
    local killaurahandcheck = {Enabled = false}
    local killauraanimation = {Enabled = false}
	local killauraanimationtween = {Enabled = false}
	local killauracolor = {Value = 0.44}
	local killauraparticlecolor = {Hue = 0, Sat = 0, Value = 0}
	local killauranovape = {Enabled = false}
	local killaurauseitems = {Enabled = true}
	local killauratargethighlight = {Enabled = false}
	local killaurarangecircle = {Enabled = false}
	local killaurarangecirclepart
	local killauraaimcircle = {Enabled = false}
	local killauraaimcirclepart
	local killauraparticle = {Enabled = false}
	local killauraparticlepart
    local Killauranear = false
    local killauraplaying = false
    local oldViewmodelAnimation = function() end
    local oldPlaySound = function() end
    local originalArmC0 = nil
	local killauracurrentanim
	local animationdelay = tick()

	local function getStrength(plr)
		local inv = bedwarsStore.inventories[plr.Player]
		local strength = 0
		local strongestsword = 0
		if inv then
			for i,v in pairs(inv.items) do 
				local itemmeta = bedwars.ItemTable[v.itemType]
				if itemmeta and itemmeta.sword and itemmeta.sword.damage > strongestsword then 
					strongestsword = itemmeta.sword.damage / 100
				end	
			end
			strength = strength + strongestsword
			for i,v in pairs(inv.armor) do 
				local itemmeta = bedwars.ItemTable[v.itemType]
				if itemmeta and itemmeta.armor then 
					strength = strength + (itemmeta.armor.damageReductionMultiplier or 0)
				end
			end
			strength = strength
		end
		return strength
	end

	local kitpriolist = {
		hannah = 5,
		spirit_assassin = 4,
		dasher = 3,
		jade = 2,
		regent = 1
	}

	local killaurasortmethods = {
		Switch = function(a, b)
			return (a.RootPart.Position - entityLibrary.character.HumanoidRootPart.Position).Magnitude < (b.RootPart.Position - entityLibrary.character.HumanoidRootPart.Position).Magnitude
		end,
		Health = function(a, b) 
			return a.Humanoid.Health < b.Humanoid.Health
		end,
		Threat = function(a, b) 
			return getStrength(a) > getStrength(b)
		end,
		Kit = function(a, b)
			return (kitpriolist[a.Player:GetAttribute("PlayingAsKit")] or 0) > (kitpriolist[b.Player:GetAttribute("PlayingAsKit")] or 0)
		end
	}

	local originalNeckC0
	local originalRootC0
	local anims = {
		Normal = {
			{CFrame = CFrame.new(0.69, -0.7, 0.6) * CFrame.Angles(math.rad(295), math.rad(55), math.rad(290)), Time = 0.05},
			{CFrame = CFrame.new(0.69, -0.71, 0.6) * CFrame.Angles(math.rad(200), math.rad(60), math.rad(1)), Time = 0.05}
		},
		Slow = {
			{CFrame = CFrame.new(0.69, -0.7, 0.6) * CFrame.Angles(math.rad(295), math.rad(55), math.rad(290)), Time = 0.15},
			{CFrame = CFrame.new(0.69, -0.71, 0.6) * CFrame.Angles(math.rad(200), math.rad(60), math.rad(1)), Time = 0.15}
		},
		New = {
			{CFrame = CFrame.new(0.69, -0.77, 1.47) * CFrame.Angles(math.rad(-33), math.rad(57), math.rad(-81)), Time = 0.12},
			{CFrame = CFrame.new(0.74, -0.92, 0.88) * CFrame.Angles(math.rad(147), math.rad(71), math.rad(53)), Time = 0.12}
		},
		Latest = {
			{CFrame = CFrame.new(0.69, -0.7, 0.1) * CFrame.Angles(math.rad(-65), math.rad(55), math.rad(-51)), Time = 0.1},
			{CFrame = CFrame.new(0.16, -1.16, 0.5) * CFrame.Angles(math.rad(-179), math.rad(54), math.rad(33)), Time = 0.1}
		},
		['Vertical Spin'] = {
			{CFrame = CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(-90), math.rad(8), math.rad(5)), Time = 0.1},
			{CFrame = CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(180), math.rad(3), math.rad(13)), Time = 0.1},
			{CFrame = CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(90), math.rad(-5), math.rad(8)), Time = 0.1},
			{CFrame = CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(0), math.rad(-0), math.rad(-0)), Time = 0.1}
		},
		Exhibition = {
			{CFrame = CFrame.new(0.69, -0.7, 0.6) * CFrame.Angles(math.rad(-30), math.rad(50), math.rad(-90)), Time = 0.1},
			{CFrame = CFrame.new(0.7, -0.71, 0.59) * CFrame.Angles(math.rad(-84), math.rad(50), math.rad(-38)), Time = 0.2}
		},
		['Exhibition Old'] = {
			{CFrame = CFrame.new(0.69, -0.7, 0.6) * CFrame.Angles(math.rad(-30), math.rad(50), math.rad(-90)), Time = 0.15},
			{CFrame = CFrame.new(0.69, -0.7, 0.6) * CFrame.Angles(math.rad(-30), math.rad(50), math.rad(-90)), Time = 0.05},
			{CFrame = CFrame.new(0.7, -0.71, 0.59) * CFrame.Angles(math.rad(-84), math.rad(50), math.rad(-38)), Time = 0.1},
			{CFrame = CFrame.new(0.7, -0.71, 0.59) * CFrame.Angles(math.rad(-84), math.rad(50), math.rad(-38)), Time = 0.05},
			{CFrame = CFrame.new(0.63, -0.1, 1.37) * CFrame.Angles(math.rad(-84), math.rad(50), math.rad(-38)), Time = 0.15}
		},
		Kryptonite = {
			{CFrame = CFrame.new(0.86, -0.8, 0.1) * CFrame.Angles(math.rad(-45), math.rad(40), math.rad(-75)), Time = 0.17},
			{CFrame = CFrame.new(0.73, -0.8, 0.05) * CFrame.Angles(math.rad(-60), math.rad(60), math.rad(-95)), Time = 0.17},
		},
		['Kryptonite Fast'] = {
			{CFrame = CFrame.new(0.95, -0.8, 0.1) * CFrame.Angles(math.rad(-45), math.rad(40), math.rad(-75)), Time = 0.15},
			{CFrame = CFrame.new(0.40, -0.8, 0.05) * CFrame.Angles(math.rad(-60), math.rad(60), math.rad(-95)), Time = 0.15}
		},
		Meteor = {
			{CFrame = CFrame.new(0.150, -0.8, 0.1) * CFrame.Angles(math.rad(-45), math.rad(40), math.rad(-75)), Time = 0.15},
			{CFrame = CFrame.new(0.02, -0.8, 0.05) * CFrame.Angles(math.rad(-60), math.rad(60), math.rad(-95)), Time = 0.15},
		},
		['Exhibition New'] = {
			{CFrame = CFrame.new(0.63, -0.7, 0.6) * CFrame.Angles(math.rad(-45), math.rad(40), math.rad(-75)), Time = 0.2},
			{CFrame = CFrame.new(0.63, -0.7, 2) * CFrame.Angles(math.rad(-60), math.rad(60), math.rad(-95)), Time = 0.2}
		},
		Astral = {
			{CFrame = CFrame.new(0.7, -0.7, 0.6) * CFrame.Angles(math.rad(-16), math.rad(60), math.rad(-80)), Time = 0.1},
			{CFrame = CFrame.new(0.7, -0.7, 0.6) * CFrame.Angles(math.rad(-16), math.rad(60), math.rad(-80)), Time = 0.15},
			{CFrame = CFrame.new(0.95, -1.06, -2.25) * CFrame.Angles(math.rad(-179), math.rad(61), math.rad(80)), Time = 0.15}
		},
		['Liquid Bounce'] = {
			{CFrame = CFrame.new(-0.01, -0.3, -1.01) * CFrame.Angles(math.rad(-35), math.rad(90), math.rad(-90)), Time = 0.45},
    		{CFrame = CFrame.new(-0.01, -0.3, -1.01) * CFrame.Angles(math.rad(-35), math.rad(70), math.rad(-90)), Time = 0.45},
			{CFrame = CFrame.new(-0.01, -0.3, 0.4) * CFrame.Angles(math.rad(-35), math.rad(70), math.rad(-90)), Time = 0.32}
		},
		Funny = {
			{CFrame = CFrame.new(0.8, 10.7, 3.6) * CFrame.Angles(math.rad(-16), math.rad(60), math.rad(-80)), Time = 0.1},
            {CFrame = CFrame.new(5.7, -1.7, 5.6) * CFrame.Angles(math.rad(-16), math.rad(60), math.rad(-80)), Time = 0.15},
            {CFrame = CFrame.new(2.95, -5.06, -6.25) * CFrame.Angles(math.rad(-179), math.rad(61), math.rad(80)), Time = 0.15}
		},
		['Funny Future'] = {
			{CFrame = CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(-60), math.rad(0), math.rad(0)),Time = 0.25},
			{CFrame = CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(0), math.rad(0), math.rad(0)),Time = 0.25}
		},
		Random = {
			{CFrame = CFrame.new(0.69, -0.7, 0.6) * CFrame.Angles(math.rad(-30), math.rad(50), math.rad(-90)), Time = 0.25},
			{CFrame = CFrame.new(-1, -1, 1) * CFrame.Angles(math.rad(0), math.rad(0), math.rad(0)),Time = 0.25},
			{CFrame = CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(0), math.rad(0), math.rad(-33)),Time = 0.25}
		},
		Future = {
			{CFrame = CFrame.new(0.69, -0.7, 0.10) * CFrame.Angles(math.rad(295), math.rad(55), math.rad(290)), Time = 0.20},
			{CFrame = CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(0), math.rad(0), math.rad(0)),Time = 0.25}
		},
		Smash = {
			{CFrame = CFrame.new(0.69, -0.7, 0.6) * CFrame.Angles(math.rad(-30), math.rad(50), math.rad(-90)), Time = 0.15},
			{CFrame = CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(0), math.rad(0), math.rad(0)),Time = 0.25},
			{CFrame = CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(-30), math.rad(80), math.rad(-90)), Time = 0.35},
			{CFrame = CFrame.new(0, 1, 0) * CFrame.Angles(math.rad(0), math.rad(0), math.rad(0)), Time = 0.35}
		},
		['Funny V2'] = {
			{CFrame = CFrame.new(0.10, -0.5, -1) * CFrame.Angles(math.rad(295), math.rad(80), math.rad(300)), Time = 0.45},
			{CFrame = CFrame.new(-5, 0, 0) * CFrame.Angles(math.rad(0), math.rad(0), math.rad(0)), Time = 0.45},
			{CFrame = CFrame.new(5, 0, 0) * CFrame.Angles(math.rad(0), math.rad(0), math.rad(0)), Time = 0.45},
		},
		Smooth = {
			{CFrame = CFrame.new(-0.42, 0, 0.30) * CFrame.Angles(math.rad(0), math.rad(80), math.rad(60)), Time = 0.25},
			{CFrame = CFrame.new(-0.42, 0, 0.30) * CFrame.Angles(math.rad(0), math.rad(100), math.rad(60)), Time = 0.25},
			{CFrame = CFrame.new(-0.42, 0, 0.30) * CFrame.Angles(math.rad(0), math.rad(60), math.rad(60)), Time = 0.25},
		},
		['Faster Smooth'] = {
			{CFrame = CFrame.new(-0.42, 0, 0.30) * CFrame.Angles(math.rad(0), math.rad(80), math.rad(60)), Time = 0.11},
			{CFrame = CFrame.new(-0.42, 0, 0.30) * CFrame.Angles(math.rad(0), math.rad(100), math.rad(60)), Time = 0.11},
			{CFrame = CFrame.new(-0.42, 0, 0.30) * CFrame.Angles(math.rad(0), math.rad(60), math.rad(60)), Time = 0.11},
		},
		SmashV2 = {
			{CFrame = CFrame.new(0.10, -0.3, -0.30) * CFrame.Angles(math.rad(295), math.rad(80), math.rad(290)), Time = 0.09},
			{CFrame = CFrame.new(0.10, 0.10, -1) * CFrame.Angles(math.rad(295), math.rad(80), math.rad(300)), Time = 0.1},
			{CFrame = CFrame.new(0.69, -0.7, 0.6) * CFrame.Angles(math.rad(-30), math.rad(50), math.rad(-90)), Time = 0.15},
		},
		Bob = {
			{CFrame = CFrame.new(-0.7, -0.71, 0.59) * CFrame.Angles(math.rad(-84), math.rad(50), math.rad(-38)), Time = 0.2},
			{CFrame = CFrame.new(-0.7, -2.5, 0.59) * CFrame.Angles(math.rad(-84), math.rad(50), math.rad(-38)), Time = 0.2}
		},
		Knife = {
			{CFrame = CFrame.new(-0.7, -0.71, 0.59) * CFrame.Angles(math.rad(-84), math.rad(50), math.rad(-38)), Time = 0.2},
			{CFrame = CFrame.new(1, -0.71, 0.59) * CFrame.Angles(math.rad(-84), math.rad(50), math.rad(-38)), Time = 0.2},
			{CFrame = CFrame.new(4, -0.71, 0.59) * CFrame.Angles(math.rad(-84), math.rad(50), math.rad(-38)), Time = 0.2},
		},
		['Funny Exhibition'] = {
			{CFrame = CFrame.new(-1.5, -0.50, 0.20) * CFrame.Angles(math.rad(-84), math.rad(50), math.rad(-38)), Time = 0.10},
			{CFrame = CFrame.new(-0.55, -0.20, 1.5) * CFrame.Angles(math.rad(-84), math.rad(50), math.rad(-38)), Time = 0.2},
		},
		Remake = {
			{CFrame = CFrame.new(-0.10, -0.45, -0.20) * CFrame.Angles(math.rad(-84), math.rad(50), math.rad(-50)), Time = 0.01},
			{CFrame = CFrame.new(0.7, -0.71, -1) * CFrame.Angles(math.rad(-90), math.rad(50), math.rad(-38)), Time = 0.2},
			{CFrame = CFrame.new(0.63, -0.1, 1.50) * CFrame.Angles(math.rad(-84), math.rad(50), math.rad(-38)), Time = 0.15}
		},
		Pop = {
			{CFrame = CFrame.new(0.69, -0.10, 0.6) * CFrame.Angles(math.rad(-30), math.rad(50), math.rad(-90)), Time = 0.1},
			{CFrame = CFrame.new(0.7, -0.71, 0.59) * CFrame.Angles(math.rad(-84), math.rad(50), math.rad(-38)), Time = 0.1},
			{CFrame = CFrame.new(0.69, -2, 0.6) * CFrame.Angles(math.rad(-30), math.rad(50), math.rad(-90)), Time = 0.1}
		},
		['Pop V2'] = {
			{CFrame = CFrame.new(0.69, -0.10, 0.6) * CFrame.Angles(math.rad(-30), math.rad(50), math.rad(-90)), Time = 0.01},
			{CFrame = CFrame.new(0.7, -0.30, 0.59) * CFrame.Angles(math.rad(-84), math.rad(50), math.rad(-38)), Time = 0.01},
			{CFrame = CFrame.new(0.69, -2, 0.6) * CFrame.Angles(math.rad(-30), math.rad(50), math.rad(-90)), Time = 0.01}
		},
		Shake = {
			{CFrame = CFrame.new(0.69, -0.8, 0.6) * CFrame.Angles(math.rad(-60), math.rad(30), math.rad(-35)), Time = 0.05},
			{CFrame = CFrame.new(0.8, -0.71, 0.30) * CFrame.Angles(math.rad(-60), math.rad(39), math.rad(-55)), Time = 0.02},
			{CFrame = CFrame.new(0.8, -2, 0.45) * CFrame.Angles(math.rad(-60), math.rad(30), math.rad(-55)), Time = 0.03}
		},
		Loop = {
			{CFrame = CFrame.new(0, -0.1, -0.30) * CFrame.Angles(math.rad(-20), math.rad(20), math.rad(0)), Time = 0.30},
			{CFrame = CFrame.new(0, -0.50, -0.30) * CFrame.Angles(math.rad(-40), math.rad(41), math.rad(0)), Time = 0.32},
			{CFrame = CFrame.new(0, -0.1, -0.30) * CFrame.Angles(math.rad(-60), math.rad(0), math.rad(0)), Time = 0.32}
		},
		Block = {
			{CFrame = CFrame.new(1, -0.71, 0.59) * CFrame.Angles(math.rad(-84), math.rad(50), math.rad(-38)), Time = 0.2},
			{CFrame = CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(45), math.rad(0), math.rad(0)), Time = 0.2},
			{CFrame = CFrame.new(1, 0, 0) * CFrame.Angles(math.rad(-60), math.rad(0), math.rad(0)), Time = 0.2},
			{CFrame = CFrame.new(0.3, -0.71, 0.59) * CFrame.Angles(math.rad(-84), math.rad(50), math.rad(-38)), Time = 0.2}
		},
		Chill = {
			{CFrame = CFrame.new(0.07, -0.7, 0.6) * CFrame.Angles(math.rad(-30), math.rad(50), math.rad(-90)), Time = 0.1},
			{CFrame = CFrame.new(0.7, -0.71, 0.59) * CFrame.Angles(math.rad(-84), math.rad(50), math.rad(-38)), Time = 0.2}
		},
		['Womp Womp'] = {
			{CFrame = CFrame.new(0.07, -0.7, 0.6) * CFrame.Angles(math.rad(-30), math.rad(15), math.rad(-90)), Time = 0.1},
			{CFrame = CFrame.new(0.7, -0.71, 0.59) * CFrame.Angles(math.rad(-84), math.rad(50), math.rad(-38)), Time = 0.2}
		},
		['Yomp Yomp'] = {
			{CFrame = CFrame.new(0.07, -0.7, 0.6) * CFrame.Angles(math.rad(0), math.rad(15), math.rad(-20)), Time = 0.1},
			{CFrame = CFrame.new(0.7, -0.71, 0.59) * CFrame.Angles(math.rad(-84), math.rad(50), math.rad(-38)), Time = 0.2}
		},
		['Funny V3'] = {
			{CFrame = CFrame.new(0.8, 10.7, 3.6) * CFrame.Angles(math.rad(-16), math.rad(60), math.rad(-80)), Time = 0.1},
            {CFrame = CFrame.new(5.7, -1.7, 5.6) * CFrame.Angles(math.rad(-16), math.rad(60), math.rad(-80)), Time = 0.15},
            {CFrame = CFrame.new(2.95, -5.06, -6.25) * CFrame.Angles(math.rad(-179), math.rad(61), math.rad(80)), Time = 0.15}
		},
		['Auto Block'] = {
			{CFrame = CFrame.new(-0.6, -0.2, 0.3) * CFrame.Angles(math.rad(0), math.rad(80), math.rad(65)), Time = 0.15},
			{CFrame = CFrame.new(-0.6, -0.2, 0.3) * CFrame.Angles(math.rad(0), math.rad(110), math.rad(65)), Time = 0.15},
			{CFrame = CFrame.new(-0.6, -0.2, 0.3) * CFrame.Angles(math.rad(0), math.rad(65), math.rad(65)), Time = 0.15}
		},
		Switch = {
			{CFrame = CFrame.new(0.69, -0.7, 0.1) * CFrame.Angles(math.rad(-65), math.rad(55), math.rad(-51)), Time = 0.1},
			{CFrame = CFrame.new(0.16, -1.16, 0.5) * CFrame.Angles(math.rad(-179), math.rad(54), math.rad(33)), Time = 0.1}
		},
		Sideways = {
			{CFrame = CFrame.new(5, -3, 2) * CFrame.Angles(math.rad(120), math.rad(160), math.rad(140)), Time = 0.12},
			{CFrame = CFrame.new(5, -2.5, -1) * CFrame.Angles(math.rad(80), math.rad(180), math.rad(180)), Time = 0.12},
			{CFrame = CFrame.new(5, -3.4, -3.3) * CFrame.Angles(math.rad(45), math.rad(160), math.rad(190)), Time = 0.12},
			{CFrame = CFrame.new(5, -2.5, -1) * CFrame.Angles(math.rad(80), math.rad(180), math.rad(180)), Time = 0.12}
		},
		Stand = {
			{CFrame = CFrame.new(0.69, -0.7, 0.6) * CFrame.Angles(math.rad(-30), math.rad(50), math.rad(-90)), Time = 0.1}
		}
	}

	local function closestpos(block, pos)
		local blockpos = block:GetRenderCFrame()
		local startpos = (blockpos * CFrame.new(-(block.Size / 2))).p
		local endpos = (blockpos * CFrame.new((block.Size / 2))).p
		local speedCFrame = block.Position + (pos - block.Position)
		local x = startpos.X > endpos.X and endpos.X or startpos.X
		local y = startpos.Y > endpos.Y and endpos.Y or startpos.Y
		local z = startpos.Z > endpos.Z and endpos.Z or startpos.Z
		local x2 = startpos.X < endpos.X and endpos.X or startpos.X
		local y2 = startpos.Y < endpos.Y and endpos.Y or startpos.Y
		local z2 = startpos.Z < endpos.Z and endpos.Z or startpos.Z
		return Vector3.new(math.clamp(speedCFrame.X, x, x2), math.clamp(speedCFrame.Y, y, y2), math.clamp(speedCFrame.Z, z, z2))
	end

	local function getAttackData()
		if GuiLibrary.ObjectsThatCanBeSaved["Lobby CheckToggle"].Api.Enabled then 
			if bedwarsStore.matchState == 0 then return false end
		end
		if killauramouse.Enabled then
			if not inputService:IsMouseButtonPressed(0) then return false end
		end
		if killauragui.Enabled then
			if getOpenApps() > (bedwarsStore.equippedKit == "hannah" and 4 or 3) then return false end
		end
		local sword = killaurahandcheck.Enabled and bedwarsStore.localHand or getSword()
		if not sword or not sword.tool then return false end
		local swordmeta = bedwars.ItemTable[sword.tool.Name]
		if killaurahandcheck.Enabled then
			if bedwarsStore.localHand.Type ~= "sword" or bedwars.KatanaController.chargingMaid then return false end
		end
		return sword, swordmeta
	end

	local function autoBlockLoop()
		if not killauraautoblock.Enabled or not Killaura.Enabled then return end
		repeat
			if bedwarsStore.blockPlace < tick() and entityLibrary.isAlive then
				local shield = getItem("infernal_shield")
				if shield then 
					switchItem(shield.tool)
					if not lplr.Character:GetAttribute("InfernalShieldRaised") then
						bedwars.InfernalShieldController:raiseShield()
					end
				end
			end
			task.wait()
		until (not Killaura.Enabled) or (not killauraautoblock.Enabled)
	end

    Killaura = GuiLibrary.ObjectsThatCanBeSaved.BlatantWindow.Api.CreateOptionsButton({
        Name = "Killaura",
        Function = function(callback)
            if callback then
				if killauraaimcirclepart then killauraaimcirclepart.Parent = gameCamera end
				if killaurarangecirclepart then killaurarangecirclepart.Parent = gameCamera end
				if killauraparticlepart then killauraparticlepart.Parent = gameCamera end

				task.spawn(function()
					local oldNearPlayer
					repeat
						task.wait()
						if (killauraanimation.Enabled and not killauraswing.Enabled) then
							if killauraNearPlayer then
								pcall(function()
									if originalArmC0 == nil then
										originalArmC0 = gameCamera.Viewmodel.RightHand.RightWrist.C0
									end
									if killauraplaying == false then
										killauraplaying = true
										for i,v in pairs(anims[killauraanimmethod.Value]) do 
											if (not Killaura.Enabled) or (not killauraNearPlayer) then break end
											if not oldNearPlayer and killauraanimationtween.Enabled then
												gameCamera.Viewmodel.RightHand.RightWrist.C0 = originalArmC0 * v.CFrame
												continue
											end
											killauracurrentanim = tweenService:Create(gameCamera.Viewmodel.RightHand.RightWrist, TweenInfo.new(v.Time), {C0 = originalArmC0 * v.CFrame})
											killauracurrentanim:Play()
											task.wait(v.Time - 0.01)
										end
										killauraplaying = false
									end
								end)	
							end
							oldNearPlayer = killauraNearPlayer
						end
					until Killaura.Enabled == false
				end)

				task.spawn(function()
					repeat task.wait(0)
						if killauraNearPlayer and killaurauseitems.Enabled then 
							local saber = (getItem('infernal_saber') or {})
							local data = {
								HellBladeRelease = {
									args = {player = lplr, weapon = saber.tool, chargeTime = 1},
									item = 'infernal_saber'
								}
							}
							for remote, v in next, data do 
								task.spawn(function()
									if getItem(v.item) then
									   bedwars.ClientHandler:Get(remote):SendToServer(v.args)
									end
								end)
							end
						end
					until not Killaura.Enabled
				end)

                oldViewmodelAnimation = bedwars.ViewmodelController.playAnimation
                oldPlaySound = bedwars.SoundManager.playSound
                bedwars.SoundManager.playSound = function(tab, soundid, ...)
                    if (soundid == bedwars.SoundList.SWORD_SWING_1 or soundid == bedwars.SoundList.SWORD_SWING_2) and Killaura.Enabled and killaurasound.Enabled and killauraNearPlayer then
                        return nil
                    end
                    return oldPlaySound(tab, soundid, ...)
                end
                bedwars.ViewmodelController.playAnimation = function(Self, id, ...)
                    if id == 15 and killauraNearPlayer and killauraswing.Enabled and entityLibrary.isAlive then
                        return nil
                    end
                    if id == 15 and killauraNearPlayer and killauraanimation.Enabled and entityLibrary.isAlive then
                        return nil
                    end
                    return oldViewmodelAnimation(Self, id, ...)
                end

				local targetedPlayer
				RunLoops:BindToHeartbeat("Killaura", function()
					for i,v in pairs(killauraboxes) do 
						if v:IsA("BoxHandleAdornment") and v.Adornee then
							local cf = v.Adornee and v.Adornee.CFrame
							local onex, oney, onez = cf:ToEulerAnglesXYZ() 
							v.CFrame = CFrame.new() * CFrame.Angles(-onex, -oney, -onez)
						end
					end
					if entityLibrary.isAlive then
						if killauraaimcirclepart then 
							killauraaimcirclepart.Position = targetedPlayer and closestpos(targetedPlayer.RootPart, entityLibrary.character.HumanoidRootPart.Position) or Vector3.new(99999, 99999, 99999)
						end
						if killauraparticlepart then 
							killauraparticlepart.Position = targetedPlayer and targetedPlayer.RootPart.Position or Vector3.new(99999, 99999, 99999)
						end
						local Root = entityLibrary.character.HumanoidRootPart
						if Root then
							if killaurarangecirclepart then 
								killaurarangecirclepart.Position = Root.Position - Vector3.new(0, entityLibrary.character.Humanoid.HipHeight, 0)
							end
							local Neck = entityLibrary.character.Head:FindFirstChild("Neck")
							local LowerTorso = Root.Parent and Root.Parent:FindFirstChild("LowerTorso")
							local RootC0 = LowerTorso and LowerTorso:FindFirstChild("Root")
							if Neck and RootC0 then
								if originalNeckC0 == nil then
									originalNeckC0 = Neck.C0.p
								end
								if originalRootC0 == nil then
									originalRootC0 = RootC0.C0.p
								end
								if originalRootC0 and killauracframe.Enabled then
									if targetedPlayer ~= nil then
										local targetPos = targetedPlayer.RootPart.Position + Vector3.new(0, 2, 0)
										local direction = (Vector3.new(targetPos.X, targetPos.Y, targetPos.Z) - entityLibrary.character.Head.Position).Unit
										local direction2 = (Vector3.new(targetPos.X, Root.Position.Y, targetPos.Z) - Root.Position).Unit
										local lookCFrame = (CFrame.new(Vector3.zero, (Root.CFrame):VectorToObjectSpace(direction)))
										local lookCFrame2 = (CFrame.new(Vector3.zero, (Root.CFrame):VectorToObjectSpace(direction2)))
										Neck.C0 = CFrame.new(originalNeckC0) * CFrame.Angles(lookCFrame.LookVector.Unit.y, 0, 0)
										RootC0.C0 = lookCFrame2 + originalRootC0
									else
										Neck.C0 = CFrame.new(originalNeckC0)
										RootC0.C0 = CFrame.new(originalRootC0)
									end
								end
							end
						end
					end
				end)
				if killauraautoblock.Enabled then 
					task.spawn(autoBlockLoop)
				end
                task.spawn(function()
					repeat
						task.wait()
						if not Killaura.Enabled then break end
						vapeTargetInfo.Targets.Killaura = nil
						local plrs = AllNearPosition(killaurarange.Value, 10, killaurasortmethods[killaurasortmethod.Value], true)
						local firstPlayerNear
						if #plrs > 0 then
							local sword, swordmeta = getAttackData()
							if sword then
								switchItem(sword.tool)
								for i, plr in pairs(plrs) do
									local root = plr.RootPart
									if not root then 
										continue
									end
									local localfacing = entityLibrary.character.HumanoidRootPart.CFrame.lookVector
									local vec = (plr.RootPart.Position - entityLibrary.character.HumanoidRootPart.Position).unit
									local angle = math.acos(localfacing:Dot(vec))
									if angle >= (math.rad(killauraangle.Value) / 2) then
										continue
									end
									local selfrootpos = entityLibrary.character.HumanoidRootPart.Position
									if killauratargetframe.Walls.Enabled then
										if not bedwars.SwordController:canSee({player = plr.Player, getInstance = function() return plr.Character end}) then continue end
									end
									if not ({WhitelistFunctions:GetWhitelist(plr.Player)})[2] then
										continue
									end
									if killauranovape.Enabled and bedwarsStore.whitelist.clientUsers[plr.Player.Name] then
										continue
									end
									if not firstPlayerNear then 
										firstPlayerNear = true 
										killauraNearPlayer = true
										targetedPlayer = plr
										vapeTargetInfo.Targets.Killaura = {
											Humanoid = {
												Health = (plr.Character:GetAttribute("Health") or plr.Humanoid.Health) + getShieldAttribute(plr.Character),
												MaxHealth = plr.Character:GetAttribute("MaxHealth") or plr.Humanoid.MaxHealth
											},
											Player = plr.Player
										}
										if animationdelay <= tick() then
											animationdelay = tick() + (swordmeta.sword.respectAttackSpeedForEffects and swordmeta.sword.attackSpeed or (killaurasync.Enabled and 0.24 or 0.14))
											if not killauraswing.Enabled then 
												bedwars.SwordController:playSwordEffect(swordmeta, false)
											end
											if swordmeta.displayName:find(" Scythe") then 
												bedwars.ScytheController:playLocalAnimation()
											end
										end
									end
									if (workspace:GetServerTimeNow() - bedwars.SwordController.lastAttack) < 0.02 then 
										break
									end
									local selfpos = selfrootpos + (killaurarange.Value > 14 and (selfrootpos - root.Position).magnitude > 14.4 and (CFrame.lookAt(selfrootpos, root.Position).lookVector * ((selfrootpos - root.Position).magnitude - 14)) or Vector3.zero)
									bedwars.SwordController.lastAttack = workspace:GetServerTimeNow()
									bedwarsStore.attackReach = math.floor((selfrootpos - root.Position).magnitude * 100) / 100
									bedwarsStore.attackReachUpdate = tick() + 1
									killaurarealremote:FireServer({
										weapon = sword.tool,
										chargedAttack = {chargeRatio = swordmeta.sword.chargedAttack and not swordmeta.sword.chargedAttack.disableOnGrounded and 0.999 or 0},
										entityInstance = plr.Character,
										validate = {
											raycast = {
												cameraPosition = attackValue(root.Position), 
												cursorDirection = attackValue(CFrame.new(selfpos, root.Position).lookVector)
											},
											targetPosition = attackValue(root.Position),
											selfPosition = attackValue(selfpos)
										}
									})
									break
								end
							end
						end
						if not firstPlayerNear then 
							targetedPlayer = nil
							killauraNearPlayer = false
							pcall(function()
								if originalArmC0 == nil then
									originalArmC0 = gameCamera.Viewmodel.RightHand.RightWrist.C0
								end
								if gameCamera.Viewmodel.RightHand.RightWrist.C0 ~= originalArmC0 then
									pcall(function()
										killauracurrentanim:Cancel()
									end)
									if killauraanimationtween.Enabled then 
										gameCamera.Viewmodel.RightHand.RightWrist.C0 = originalArmC0
									else
										killauracurrentanim = tweenService:Create(gameCamera.Viewmodel.RightHand.RightWrist, TweenInfo.new(0.1), {C0 = originalArmC0})
										killauracurrentanim:Play()
									end
								end
							end)
						end
						for i,v in pairs(killauraboxes) do 
							local attacked = killauratarget.Enabled and plrs[i] or nil
							v.Adornee = attacked and ((not killauratargethighlight.Enabled) and attacked.RootPart or (not GuiLibrary.ObjectsThatCanBeSaved.ChamsOptionsButton.Api.Enabled) and attacked.Character or nil)
						end
					until (not Killaura.Enabled)
				end)
            else
				vapeTargetInfo.Targets.Killaura = nil
				RunLoops:UnbindFromHeartbeat("Killaura") 
                killauraNearPlayer = false
				for i,v in pairs(killauraboxes) do v.Adornee = nil end
				if killauraaimcirclepart then killauraaimcirclepart.Parent = nil end
				if killaurarangecirclepart then killaurarangecirclepart.Parent = nil end
				if killauraparticlepart then killauraparticlepart.Parent = nil end
                bedwars.ViewmodelController.playAnimation = oldViewmodelAnimation
                bedwars.SoundManager.playSound = oldPlaySound
                oldViewmodelAnimation = nil
                pcall(function()
					if entityLibrary.isAlive then
						local Root = entityLibrary.character.HumanoidRootPart
						if Root then
							local Neck = Root.Parent.Head.Neck
							if originalNeckC0 and originalRootC0 then 
								Neck.C0 = CFrame.new(originalNeckC0)
								Root.Parent.LowerTorso.Root.C0 = CFrame.new(originalRootC0)
							end
						end
					end
                    if originalArmC0 == nil then
                        originalArmC0 = gameCamera.Viewmodel.RightHand.RightWrist.C0
                    end
                    if gameCamera.Viewmodel.RightHand.RightWrist.C0 ~= originalArmC0 then
						pcall(function()
							killauracurrentanim:Cancel()
						end)
						if killauraanimationtween.Enabled then 
							gameCamera.Viewmodel.RightHand.RightWrist.C0 = originalArmC0
						else
							killauracurrentanim = tweenService:Create(gameCamera.Viewmodel.RightHand.RightWrist, TweenInfo.new(0.1), {C0 = originalArmC0})
							killauracurrentanim:Play()
						end
                    end
                end)
            end
        end,
        HoverText = "Attack players around you\nwithout aiming at them.",
		ExtraText = function()
			return killaurasortmethod.Value
		end
    })
    killauratargetframe = Killaura.CreateTargetWindow({})
	local sortmethods = {"Distance"}
	for i,v in pairs(killaurasortmethods) do if i ~= "Distance" then table.insert(sortmethods, i) end end
	killaurasortmethod = Killaura.CreateDropdown({
		Name = "Sort",
		Function = function() end,
		List = sortmethods
	})
    killaurarange = Killaura.CreateSlider({
        Name = "Attack range",
        Min = 1,
        Max = 22,
        Function = function(val) 
			if killaurarangecirclepart then 
				killaurarangecirclepart.Size = Vector3.new(val * 0.7, 0.01, val * 0.7)
			end
		end, 
        Default = 22
    })
    killauraangle = Killaura.CreateSlider({
        Name = "Max angle",
        Min = 1,
        Max = 360,
        Function = function(val) end,
        Default = 360
    })
	local animmethods = {}
	for i,v in pairs(anims) do table.insert(animmethods, i) end
    killauraanimmethod = Killaura.CreateDropdown({
        Name = "Animation", 
        List = animmethods,
        Function = function(val) end
    })
	local oldviewmodel
	local oldraise
	local oldeffect
	killauraautoblock = Killaura.CreateToggle({
		Name = "AutoBlock",
		Function = function(callback)
			if callback then 
				oldviewmodel = bedwars.ViewmodelController.setHeldItem
				bedwars.ViewmodelController.setHeldItem = function(self, newItem, ...)
					if newItem and newItem.Name == "infernal_shield" then 
						return
					end
					return oldviewmodel(self, newItem)
				end
				oldraise = bedwars.InfernalShieldController.raiseShield
				bedwars.InfernalShieldController.raiseShield = function(self)
					if os.clock() - self.lastShieldRaised < 0.4 then
						return
					end
					self.lastShieldRaised = os.clock()
					self.infernalShieldState:SendToServer({raised = true})
					self.raisedMaid:GiveTask(function()
						self.infernalShieldState:SendToServer({raised = false})
					end)
				end
				oldeffect = bedwars.InfernalShieldController.playEffect
				bedwars.InfernalShieldController.playEffect = function()
					return
				end
				if bedwars.ViewmodelController.heldItem and bedwars.ViewmodelController.heldItem.Name == "infernal_shield" then 
					local sword, swordmeta = getSword()
					if sword then 
						bedwars.ViewmodelController:setHeldItem(sword.tool)
					end
				end
				task.spawn(autoBlockLoop)
			else
				bedwars.ViewmodelController.setHeldItem = oldviewmodel
				bedwars.InfernalShieldController.raiseShield = oldraise
				bedwars.InfernalShieldController.playEffect = oldeffect
			end
		end,
		Default = true
	})
    killauramouse = Killaura.CreateToggle({
        Name = "Require mouse down",
        Function = function() end,
		HoverText = "Only attacks when left click is held.",
        Default = false
    })
    killauragui = Killaura.CreateToggle({
        Name = "GUI Check",
        Function = function() end,
		HoverText = "Attacks when you are not in a GUI."
    })
    killauratarget = Killaura.CreateToggle({
        Name = "Show target",
        Function = function(callback) 
			if killauratargethighlight.Object then 
				killauratargethighlight.Object.Visible = callback
			end
		end,
		HoverText = "Shows a red box over the opponent."
    })
	killauratargethighlight = Killaura.CreateToggle({
		Name = "Use New Highlight",
		Function = function(callback) 
			for i,v in pairs(killauraboxes) do 
				v:Remove()
			end
			for i = 1, 10 do 
				local killaurabox
				if callback then 
					killaurabox = Instance.new("Highlight")
					killaurabox.FillTransparency = 0.39
					killaurabox.FillColor = Color3.fromHSV(killauracolor.Hue, killauracolor.Sat, killauracolor.Value)
					killaurabox.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
					killaurabox.OutlineTransparency = 1
					killaurabox.Parent = GuiLibrary.MainGui
				else
					killaurabox = Instance.new("BoxHandleAdornment")
					killaurabox.Transparency = 0.39
					killaurabox.Color3 = Color3.fromHSV(killauracolor.Hue, killauracolor.Sat, killauracolor.Value)
					killaurabox.Adornee = nil
					killaurabox.AlwaysOnTop = true
					killaurabox.Size = Vector3.new(3, 6, 3)
					killaurabox.ZIndex = 11
					killaurabox.Parent = GuiLibrary.MainGui
				end
				killauraboxes[i] = killaurabox
			end
		end
	})
	killauratargethighlight.Object.BorderSizePixel = 0
	killauratargethighlight.Object.BackgroundTransparency = 0
	killauratargethighlight.Object.BackgroundColor3 = Color3.fromRGB(15, 15, 15)
	killauratargethighlight.Object.Visible = false
	killauracolor = Killaura.CreateColorSlider({
		Name = "Target Color",
		Function = function(hue, sat, val) 
			for i,v in pairs(killauraboxes) do 
				v[(killauratargethighlight.Enabled and "FillColor" or "Color3")] = Color3.fromHSV(hue, sat, val)
			end
			if killauraaimcirclepart then 
				killauraaimcirclepart.Color = Color3.fromHSV(hue, sat, val)
			end
			if killaurarangecirclepart then 
				killaurarangecirclepart.Color = Color3.fromHSV(hue, sat, val)
			end
		end,
		Default = 1
	})
	for i = 1, 10 do 
		local killaurabox = Instance.new("BoxHandleAdornment")
		killaurabox.Transparency = 0.5
		killaurabox.Color3 = Color3.fromHSV(killauracolor["Hue"], killauracolor["Sat"], killauracolor.Value)
		killaurabox.Adornee = nil
		killaurabox.AlwaysOnTop = true
		killaurabox.Size = Vector3.new(3, 6, 3)
		killaurabox.ZIndex = 11
		killaurabox.Parent = GuiLibrary.MainGui
		killauraboxes[i] = killaurabox
	end
    killauracframe = Killaura.CreateToggle({
        Name = "Face target",
        Function = function() end,
		HoverText = "Makes your character face the opponent."
    })
	killaurarangecircle = Killaura.CreateToggle({
		Name = "Range Visualizer",
		Function = function(callback)
			if callback then 
				killaurarangecirclepart = Instance.new("MeshPart")
				killaurarangecirclepart.MeshId = "rbxassetid://3726303797"
				killaurarangecirclepart.Color = Color3.fromHSV(killauracolor["Hue"], killauracolor["Sat"], killauracolor.Value)
				killaurarangecirclepart.CanCollide = false
				killaurarangecirclepart.Anchored = true
				killaurarangecirclepart.Material = Enum.Material.Neon
				killaurarangecirclepart.Size = Vector3.new(killaurarange.Value * 0.7, 0.01, killaurarange.Value * 0.7)
				if Killaura.Enabled then 
					killaurarangecirclepart.Parent = gameCamera
				end
				bedwars.QueryUtil:setQueryIgnored(killaurarangecirclepart, true)
			else
				if killaurarangecirclepart then 
					killaurarangecirclepart:Destroy()
					killaurarangecirclepart = nil
				end
			end
		end
	})
	killauraaimcircle = Killaura.CreateToggle({
		Name = "Aim Visualizer",
		Function = function(callback)
			if callback then 
				killauraaimcirclepart = Instance.new("Part")
				killauraaimcirclepart.Shape = Enum.PartType.Ball
				killauraaimcirclepart.Color = Color3.fromHSV(killauracolor["Hue"], killauracolor["Sat"], killauracolor.Value)
				killauraaimcirclepart.CanCollide = false
				killauraaimcirclepart.Anchored = true
				killauraaimcirclepart.Material = Enum.Material.Neon
				killauraaimcirclepart.Size = Vector3.new(0.5, 0.5, 0.5)
				if Killaura.Enabled then 
					killauraaimcirclepart.Parent = gameCamera
				end
				bedwars.QueryUtil:setQueryIgnored(killauraaimcirclepart, true)
			else
				if killauraaimcirclepart then 
					killauraaimcirclepart:Destroy()
					killauraaimcirclepart = nil
				end
			end
		end
	})
	killauraparticle = Killaura.CreateToggle({
		Name = 'Crit Particle',
		Function = function(calling)
			if calling then 
				killauraparticlepart = Instance.new('Part')
				killauraparticlepart.Transparency = 1
				killauraparticlepart.CanCollide = false
				killauraparticlepart.Anchored = true
				killauraparticlepart.Size = Vector3.new(3, 6, 3)
				killauraparticlepart.Parent = cam
				bedwars.QueryUtil:setQueryIgnored(killauraparticlepart, true)
				local particle = Instance.new('ParticleEmitter')
				particle.Lifetime = NumberRange.new(0.5)
				particle.Rate = 500
				particle.Speed = NumberRange.new(0)
				particle.RotSpeed = NumberRange.new(180)
				particle.Enabled = true
				particle.Size = NumberSequence.new(0.3)
				particle.Color = ColorSequence.new({ColorSequenceKeypoint.new(0, Color3.fromRGB(67, 10, 255)), ColorSequenceKeypoint.new(1, Color3.fromRGB(0, 98, 255))})
				particle.Parent = killauraparticlepart
				task.spawn(function()
					repeat task.wait() until killauraparticlecolor.Object
					particle.Color = ColorSequence.new({ColorSequenceKeypoint.new(0, Color3.fromHSV(killauraparticlecolor.Hue, killauraparticlecolor.Sat, killauraparticlecolor.Value)), ColorSequenceKeypoint.new(1, Color3.fromHSV(killauraparticlecolor.Hue, killauraparticlecolor.Sat, killauraparticlecolor.Value))})
				end)
			else
				if killauraparticlepart then 
					killauraparticlepart:Destroy()
					killauraparticlepart = nil
				end
			end
		end
	})
	killauraparticlecolor = Killaura.CreateColorSlider({
		Name = 'Crit Particle Color',
		Function = function(h, s, v)
			pcall(function() killauraparticlepart.ParticleEmitter.Color = ColorSequence.new({ColorSequenceKeypoint.new(0, Color3.fromHSV(h, s, v)), ColorSequenceKeypoint.new(1, Color3.fromHSV(h, s, v))}) end)
		end
	})
    killaurasound = Killaura.CreateToggle({
        Name = "No Swing Sound",
        Function = function() end,
		HoverText = "Removes the swinging sound."
    })
    killauraswing = Killaura.CreateToggle({
        Name = "No Swing",
        Function = function() end,
		HoverText = "Removes the swinging animation."
    })
    killaurahandcheck = Killaura.CreateToggle({
        Name = "Limit to items",
        Function = function() end,
		HoverText = "Only attacks when your sword is held."
    })
	killaurauseitems = Killaura.CreateToggle({
		Name = 'Abilities',
		HoverText = 'Abuses the abilities of items.',
		Default = true,
		Function = function() end
	})
    killauraanimation = Killaura.CreateToggle({
        Name = "Custom Animation",
        Function = function(callback)
			if killauraanimationtween.Object then killauraanimationtween.Object.Visible = callback end
		end,
		HoverText = "Uses a custom animation for swinging"
    })
	killauraanimationtween = Killaura.CreateToggle({
		Name = "No Tween",
		Function = function() end,
		HoverText = "Disable's the in and out ease"
	})
	killauraanimationtween.Object.Visible = false
	killaurasync = Killaura.CreateToggle({
        Name = "Synced Animation",
        Function = function() end,
		HoverText = "Times animation with hit attempt"
    })
	killauranovape = Killaura.CreateToggle({
		Name = "No Vape",
		Function = function() end,
		HoverText = "no hit vape user"
	})
	killauranovape.Object.Visible = false
	task.spawn(function()
		repeat task.wait() until WhitelistFunctions.Loaded
		killauranovape.Object.Visible = WhitelistFunctions.LocalPriority ~= 0
	end)
end)

local LongJump = {Enabled = false}
runFunction(function()
	local damagetimer = 0
	local damagetimertick = 0
	local directionvec
	local LongJumpSpeed = {Value = 1.5}
	local projectileRemote = bedwars.ClientHandler:Get(bedwars.ProjectileRemote)

	local function calculatepos(vec)
		local returned = vec
		if entityLibrary.isAlive then 
			local newray = workspace:Raycast(entityLibrary.character.HumanoidRootPart.Position, returned, bedwarsStore.blockRaycast)
			if newray then returned = (newray.Position - entityLibrary.character.HumanoidRootPart.Position) end
		end
		return returned
	end

	local damagemethods = {
		fireball = function(fireball, pos)
			if not LongJump.Enabled then return end
			pos = pos - (entityLibrary.character.HumanoidRootPart.CFrame.lookVector * 0.2)
			if not (getPlacedBlock(pos - Vector3.new(0, 3, 0)) or getPlacedBlock(pos - Vector3.new(0, 6, 0))) then
				local sound = Instance.new("Sound")
				sound.SoundId = "rbxassetid://4809574295"
				sound.Parent = workspace
				sound.Ended:Connect(function()
					sound:Destroy()
				end)
				sound:Play()
			end
			local origpos = pos
			local offsetshootpos = (CFrame.new(pos, pos + Vector3.new(0, -60, 0)) * CFrame.new(Vector3.new(-bedwars.BowConstantsTable.RelX, -bedwars.BowConstantsTable.RelY, -bedwars.BowConstantsTable.RelZ))).p
			local ray = workspace:Raycast(pos, Vector3.new(0, -30, 0), bedwarsStore.blockRaycast)
			if ray then
				pos = ray.Position
				offsetshootpos = pos
			end
			task.spawn(function()
				switchItem(fireball.tool)
				bedwars.ProjectileController:createLocalProjectile(bedwars.ProjectileMeta.fireball, "fireball", "fireball", offsetshootpos, "", Vector3.new(0, -60, 0), {drawDurationSeconds = 1})
				projectileRemote:CallServerAsync(fireball.tool, "fireball", "fireball", offsetshootpos, pos, Vector3.new(0, -60, 0), game:GetService("HttpService"):GenerateGUID(true), {drawDurationSeconds = 1}, workspace:GetServerTimeNow() - 0.045)
			end)
		end,
		tnt = function(tnt, pos2)
			if not LongJump.Enabled then return end
			local pos = Vector3.new(pos2.X, getScaffold(Vector3.new(0, pos2.Y - (((entityLibrary.character.HumanoidRootPart.Size.Y / 2) + entityLibrary.character.Humanoid.HipHeight) - 1.5), 0)).Y, pos2.Z)
			local block = bedwars.placeBlock(pos, "tnt")
		end,
		cannon = function(tnt, pos2)
			task.spawn(function()
				local pos = Vector3.new(pos2.X, getScaffold(Vector3.new(0, pos2.Y - (((entityLibrary.character.HumanoidRootPart.Size.Y / 2) + entityLibrary.character.Humanoid.HipHeight) - 1.5), 0)).Y, pos2.Z)
				local block = bedwars.placeBlock(pos, "cannon")
				task.delay(0.1, function()
					local block, pos2 = getPlacedBlock(pos)
					if block and block.Name == "cannon" and (entityLibrary.character.HumanoidRootPart.CFrame.p - block.Position).Magnitude < 20 then 
						switchToAndUseTool(block)
						local vec = entityLibrary.character.HumanoidRootPart.CFrame.lookVector
						local damage = bedwars.BlockController:calculateBlockDamage(lplr, {
							blockPosition = pos2
						})
						bedwars.ClientHandler:Get(bedwars.CannonAimRemote):SendToServer({
							cannonBlockPos = pos2,
							lookVector = vec
						})
						local broken = 0.1
						if damage < block:GetAttribute("Health") then 
							task.spawn(function()
								broken = 0.4
								bedwars.breakBlock(block.Position, true, getBestBreakSide(block.Position), true, true)
							end)
						end
						task.delay(broken, function()
							for i = 1, 3 do 
								local call = bedwars.ClientHandler:Get(bedwars.CannonLaunchRemote):CallServer({cannonBlockPos = bedwars.BlockController:getBlockPosition(block.Position)})
								if call then
									bedwars.breakBlock(block.Position, true, getBestBreakSide(block.Position), true, true)
									task.delay(0.1, function()
										damagetimer = LongJumpSpeed.Value * 5
										damagetimertick = tick() + 2.5
										directionvec = Vector3.new(vec.X, 0, vec.Z).Unit
									end)
									break
								end
								task.wait(0.1)
							end
						end)
					end
				end)	
			end)
		end,
		wood_dao = function(tnt, pos2)
			task.spawn(function()
				switchItem(tnt.tool)
				if not (not lplr.Character:GetAttribute("CanDashNext") or lplr.Character:GetAttribute("CanDashNext") < workspace:GetServerTimeNow()) then
					repeat task.wait() until (not lplr.Character:GetAttribute("CanDashNext") or lplr.Character:GetAttribute("CanDashNext") < workspace:GetServerTimeNow()) or not LongJump.Enabled
				end
				if LongJump.Enabled then
					local vec = entityLibrary.character.HumanoidRootPart.CFrame.lookVector
					replicatedStorageService["events-@easy-games/game-core:shared/game-core-networking@getEvents.Events"].useAbility:FireServer("dash", {
						direction = vec,
						origin = entityLibrary.character.HumanoidRootPart.CFrame.p,
						weapon = tnt.itemType
					})
					damagetimer = LongJumpSpeed.Value * 3.5
					damagetimertick = tick() + 2.5
					directionvec = Vector3.new(vec.X, 0, vec.Z).Unit
				end
			end)
		end,
		jade_hammer = function(tnt, pos2)
			task.spawn(function()
				if not bedwars.AbilityController:canUseAbility("jade_hammer_jump") then
					repeat task.wait() until bedwars.AbilityController:canUseAbility("jade_hammer_jump") or not LongJump.Enabled
					task.wait(0.1)
				end
				if bedwars.AbilityController:canUseAbility("jade_hammer_jump") and LongJump.Enabled then
					bedwars.AbilityController:useAbility("jade_hammer_jump")
					local vec = entityLibrary.character.HumanoidRootPart.CFrame.lookVector
					damagetimer = LongJumpSpeed.Value * 2.75
					damagetimertick = tick() + 2.5
					directionvec = Vector3.new(vec.X, 0, vec.Z).Unit
				end
			end)
		end,
		void_axe = function(tnt, pos2)
			task.spawn(function()
				if not bedwars.AbilityController:canUseAbility("void_axe_jump") then
					repeat task.wait() until bedwars.AbilityController:canUseAbility("void_axe_jump") or not LongJump.Enabled
					task.wait(0.1)
				end
				if bedwars.AbilityController:canUseAbility("void_axe_jump") and LongJump.Enabled then
					bedwars.AbilityController:useAbility("void_axe_jump")
					local vec = entityLibrary.character.HumanoidRootPart.CFrame.lookVector
					damagetimer = LongJumpSpeed.Value * 2.75
					damagetimertick = tick() + 2.5
					directionvec = Vector3.new(vec.X, 0, vec.Z).Unit
				end
			end)
		end
	}
	damagemethods.stone_dao = damagemethods.wood_dao
	damagemethods.iron_dao = damagemethods.wood_dao
	damagemethods.diamond_dao = damagemethods.wood_dao
	damagemethods.emerald_dao = damagemethods.wood_dao

	local oldgrav
	local LongJumpacprogressbarframe = Instance.new("Frame")
	LongJumpacprogressbarframe.AnchorPoint = Vector2.new(0.5, 0)
	LongJumpacprogressbarframe.Position = UDim2.new(0.5, 0, 1, -200)
	LongJumpacprogressbarframe.Size = UDim2.new(0.2, 0, 0, 20)
	LongJumpacprogressbarframe.BackgroundTransparency = 0.5
	LongJumpacprogressbarframe.BorderSizePixel = 0
	LongJumpacprogressbarframe.BackgroundColor3 = Color3.fromHSV(GuiLibrary.ObjectsThatCanBeSaved["Gui ColorSliderColor"].Api.Hue, GuiLibrary.ObjectsThatCanBeSaved["Gui ColorSliderColor"].Api.Sat, GuiLibrary.ObjectsThatCanBeSaved["Gui ColorSliderColor"].Api.Value)
	LongJumpacprogressbarframe.Visible = LongJump.Enabled
	LongJumpacprogressbarframe.Parent = GuiLibrary.MainGui
	local LongJumpacprogressbarframe2 = LongJumpacprogressbarframe:Clone()
	LongJumpacprogressbarframe2.AnchorPoint = Vector2.new(0, 0)
	LongJumpacprogressbarframe2.Position = UDim2.new(0, 0, 0, 0)
	LongJumpacprogressbarframe2.Size = UDim2.new(1, 0, 0, 20)
	LongJumpacprogressbarframe2.BackgroundTransparency = 0
	LongJumpacprogressbarframe2.Visible = true
	LongJumpacprogressbarframe2.BackgroundColor3 = Color3.fromHSV(GuiLibrary.ObjectsThatCanBeSaved["Gui ColorSliderColor"].Api.Hue, GuiLibrary.ObjectsThatCanBeSaved["Gui ColorSliderColor"].Api.Sat, GuiLibrary.ObjectsThatCanBeSaved["Gui ColorSliderColor"].Api.Value)
	LongJumpacprogressbarframe2.Parent = LongJumpacprogressbarframe
	local LongJumpacprogressbartext = Instance.new("TextLabel")
	LongJumpacprogressbartext.Text = "2.5s"
	LongJumpacprogressbartext.Font = Enum.Font.Gotham
	LongJumpacprogressbartext.TextStrokeTransparency = 0
	LongJumpacprogressbartext.TextColor3 =  Color3.new(0.9, 0.9, 0.9)
	LongJumpacprogressbartext.TextSize = 20
	LongJumpacprogressbartext.Size = UDim2.new(1, 0, 1, 0)
	LongJumpacprogressbartext.BackgroundTransparency = 1
	LongJumpacprogressbartext.Position = UDim2.new(0, 0, -1, 0)
	LongJumpacprogressbartext.Parent = LongJumpacprogressbarframe
	LongJump = GuiLibrary.ObjectsThatCanBeSaved.BlatantWindow.Api.CreateOptionsButton({
		Name = "LongJump",
		Function = function(callback)
			if callback then
				table.insert(LongJump.Connections, vapeEvents.EntityDamageEvent.Event:Connect(function(damageTable)
					if damageTable.entityInstance == lplr.Character and (not damageTable.knockbackMultiplier or not damageTable.knockbackMultiplier.disabled) then 
						local knockbackBoost = damageTable.knockbackMultiplier and damageTable.knockbackMultiplier.horizontal and damageTable.knockbackMultiplier.horizontal * LongJumpSpeed.Value or LongJumpSpeed.Value
						if damagetimertick < tick() or knockbackBoost >= damagetimer then
							damagetimer = knockbackBoost
							damagetimertick = tick() + 2.5
							local newDirection = entityLibrary.character.HumanoidRootPart.CFrame.lookVector
							directionvec = Vector3.new(newDirection.X, 0, newDirection.Z).Unit
						end
					end
				end))
				task.spawn(function()
					task.spawn(function()
						repeat
							task.wait()
							if LongJumpacprogressbarframe then
								LongJumpacprogressbarframe.BackgroundColor3 = Color3.fromHSV(GuiLibrary.ObjectsThatCanBeSaved["Gui ColorSliderColor"].Api.Hue, GuiLibrary.ObjectsThatCanBeSaved["Gui ColorSliderColor"].Api.Sat, GuiLibrary.ObjectsThatCanBeSaved["Gui ColorSliderColor"].Api.Value)
								LongJumpacprogressbarframe2.BackgroundColor3 = Color3.fromHSV(GuiLibrary.ObjectsThatCanBeSaved["Gui ColorSliderColor"].Api.Hue, GuiLibrary.ObjectsThatCanBeSaved["Gui ColorSliderColor"].Api.Sat, GuiLibrary.ObjectsThatCanBeSaved["Gui ColorSliderColor"].Api.Value)
							end
						until (not LongJump.Enabled)
					end)
					local LongJumpOrigin = entityLibrary.isAlive and entityLibrary.character.HumanoidRootPart.Position
					local tntcheck
					for i,v in pairs(damagemethods) do 
						local item = getItem(i)
						if item then
							if i == "tnt" then 
								local pos = getScaffold(LongJumpOrigin)
								tntcheck = Vector3.new(pos.X, LongJumpOrigin.Y, pos.Z)
								v(item, pos)
							else
								v(item, LongJumpOrigin)
							end
							break
						end
					end
					local changecheck
					LongJumpacprogressbarframe.Visible = true
					RunLoops:BindToHeartbeat("LongJump", function(dt)
						if entityLibrary.isAlive then 
							if entityLibrary.character.Humanoid.Health <= 0 then 
								LongJump.ToggleButton(false)
								return
							end
							if not LongJumpOrigin then 
								LongJumpOrigin = entityLibrary.character.HumanoidRootPart.Position
							end
							local newval = damagetimer ~= 0
							if changecheck ~= newval then 
								if newval then 
									LongJumpacprogressbarframe2:TweenSize(UDim2.new(0, 0, 0, 20), Enum.EasingDirection.InOut, Enum.EasingStyle.Linear, 2.5, true)
								else
									LongJumpacprogressbarframe2:TweenSize(UDim2.new(1, 0, 0, 20), Enum.EasingDirection.InOut, Enum.EasingStyle.Linear, 0, true)
								end
								changecheck = newval
							end
							if newval then 
								local newnum = math.max(math.floor((damagetimertick - tick()) * 10) / 10, 0)
								if LongJumpacprogressbartext then 
									LongJumpacprogressbartext.Text = newnum.."s"
								end
								if directionvec == nil then 
									directionvec = entityLibrary.character.HumanoidRootPart.CFrame.lookVector
								end
								local longJumpCFrame = Vector3.new(directionvec.X, 0, directionvec.Z)
								local newvelo = longJumpCFrame.Unit == longJumpCFrame.Unit and longJumpCFrame.Unit * (newnum > 1 and damagetimer or 20) or Vector3.zero
								newvelo = Vector3.new(newvelo.X, 0, newvelo.Z)
								longJumpCFrame = longJumpCFrame * (getSpeed() + 3) * dt
								local ray = workspace:Raycast(entityLibrary.character.HumanoidRootPart.Position, longJumpCFrame, bedwarsStore.blockRaycast)
								if ray then 
									longJumpCFrame = Vector3.zero
									newvelo = Vector3.zero
								end

								entityLibrary.character.HumanoidRootPart.Velocity = newvelo
								entityLibrary.character.HumanoidRootPart.CFrame = entityLibrary.character.HumanoidRootPart.CFrame + longJumpCFrame
							else
								LongJumpacprogressbartext.Text = "2.5s"
								entityLibrary.character.HumanoidRootPart.CFrame = CFrame.new(LongJumpOrigin, LongJumpOrigin + entityLibrary.character.HumanoidRootPart.CFrame.lookVector)
								entityLibrary.character.HumanoidRootPart.Velocity = Vector3.new(0, 0, 0)
								if tntcheck then 
									entityLibrary.character.HumanoidRootPart.CFrame = CFrame.new(tntcheck + entityLibrary.character.HumanoidRootPart.CFrame.lookVector, tntcheck + (entityLibrary.character.HumanoidRootPart.CFrame.lookVector * 2))
								end
							end
						else
							if LongJumpacprogressbartext then 
								LongJumpacprogressbartext.Text = "2.5s"
							end
							LongJumpOrigin = nil
							tntcheck = nil
						end
					end)
				end)
			else
				LongJumpacprogressbarframe.Visible = false
				RunLoops:UnbindFromHeartbeat("LongJump")
				directionvec = nil
				tntcheck = nil
				LongJumpOrigin = nil
				damagetimer = 0
				damagetimertick = 0
			end
		end, 
		HoverText = "Lets you jump farther (Not landing on same level & Spamming can lead to lagbacks)"
	})
	LongJumpSpeed = LongJump.CreateSlider({
		Name = "Speed",
		Min = 1,
		Max = 52,
		Function = function() end,
		Default = 52
	})
end)

runFunction(function()
	local NoFall = {Enabled = false}
	local oldfall
	NoFall = GuiLibrary.ObjectsThatCanBeSaved.BlatantWindow.Api.CreateOptionsButton({
		Name = "NoFall",
		Function = function(callback)
			if callback then
				task.spawn(function()
					repeat
						task.wait(0.5)
						bedwars.ClientHandler:Get("GroundHit"):SendToServer()
					until (not NoFall.Enabled)
				end)
			end
		end, 
		HoverText = "Prevents taking fall damage."
	})
end)

runFunction(function()
	local NoSlowdown = {Enabled = false}
	local OldSetSpeedFunc
	NoSlowdown = GuiLibrary.ObjectsThatCanBeSaved.BlatantWindow.Api.CreateOptionsButton({
		Name = "NoSlowdown",
		Function = function(callback)
			if callback then
				OldSetSpeedFunc = bedwars.SprintController.setSpeed
				bedwars.SprintController.setSpeed = function(tab1, val1)
					local hum = entityLibrary.character.Humanoid
					if hum then
						hum.WalkSpeed = math.max(20 * tab1.moveSpeedMultiplier, 20)
					end
				end
				bedwars.SprintController:setSpeed(20)
			else
				bedwars.SprintController.setSpeed = OldSetSpeedFunc
				bedwars.SprintController:setSpeed(20)
				OldSetSpeedFunc = nil
			end
		end, 
		HoverText = "Prevents slowing down when using items."
	})
end)

local spiderActive = false
local holdingshift = false
runFunction(function()
	local activatePhase = false
	local oldActivatePhase = false
	local PhaseDelay = tick()
	local Phase = {Enabled = false}
	local PhaseStudLimit = {Value = 1}
	local PhaseModifiedParts = {}
	local raycastparameters = RaycastParams.new()
	raycastparameters.RespectCanCollide = true
	raycastparameters.FilterType = Enum.RaycastFilterType.Whitelist
	local overlapparams = OverlapParams.new()
	overlapparams.RespectCanCollide = true

	local function isPointInMapOccupied(p)
		overlapparams.FilterDescendantsInstances = {lplr.Character, gameCamera}
		local possible = workspace:GetPartBoundsInBox(CFrame.new(p), Vector3.new(1, 2, 1), overlapparams)
		return (#possible == 0)
	end

	Phase = GuiLibrary.ObjectsThatCanBeSaved.BlatantWindow.Api.CreateOptionsButton({
		Name = "Phase",
		Function = function(callback)
			if callback then
				RunLoops:BindToHeartbeat("Phase", function()
					if entityLibrary.isAlive and entityLibrary.character.Humanoid.MoveDirection ~= Vector3.zero and (not GuiLibrary.ObjectsThatCanBeSaved.SpiderOptionsButton.Api.Enabled or holdingshift) then
						if PhaseDelay <= tick() then
							raycastparameters.FilterDescendantsInstances = {bedwarsStore.blocks, collectionService:GetTagged("spawn-cage"), workspace.SpectatorPlatform}
							local PhaseRayCheck = workspace:Raycast(entityLibrary.character.Head.CFrame.p, entityLibrary.character.Humanoid.MoveDirection * 1.15, raycastparameters)
							if PhaseRayCheck then
								local PhaseDirection = (PhaseRayCheck.Normal.Z ~= 0 or not PhaseRayCheck.Instance:GetAttribute("GreedyBlock")) and "Z" or "X"
								if PhaseRayCheck.Instance.Size[PhaseDirection] <= PhaseStudLimit.Value * 3 and PhaseRayCheck.Instance.CanCollide and PhaseRayCheck.Normal.Y == 0 then
									local PhaseDestination = entityLibrary.character.HumanoidRootPart.CFrame + (PhaseRayCheck.Normal * (-(PhaseRayCheck.Instance.Size[PhaseDirection]) - (entityLibrary.character.HumanoidRootPart.Size.X / 1.5)))
									if isPointInMapOccupied(PhaseDestination.p) then
										PhaseDelay = tick() + 1
										entityLibrary.character.HumanoidRootPart.CFrame = PhaseDestination
									end
								end
							end
						end
					end
				end)
			else
				RunLoops:UnbindFromHeartbeat("Phase")
			end
		end,
		HoverText = "Lets you Phase/Clip through walls. (Hold shift to use Phase over spider)"
	})
	PhaseStudLimit = Phase.CreateSlider({
		Name = "Blocks",
		Min = 1,
		Max = 3,
		Function = function() end
	})
end)

runFunction(function()
	local oldCalculateAim
	local BowAimbotProjectiles = {Enabled = false}
	local BowAimbotPart = {Value = "HumanoidRootPart"}
	local BowAimbotFOV = {Value = 1000}
	local BowAimbot = GuiLibrary.ObjectsThatCanBeSaved.BlatantWindow.Api.CreateOptionsButton({
		Name = "ProjectileAimbot",
		Function = function(callback)
			if callback then
				oldCalculateAim = bedwars.ProjectileController.calculateImportantLaunchValues
				bedwars.ProjectileController.calculateImportantLaunchValues = function(self, projmeta, worldmeta, shootpospart, ...)
					local plr = EntityNearMouse(BowAimbotFOV.Value)
					if plr then
						local startPos = self:getLaunchPosition(shootpospart)
						if not startPos then
							return oldCalculateAim(self, projmeta, worldmeta, shootpospart, ...)
						end

						if (not BowAimbotProjectiles.Enabled) and projmeta.projectile:find("arrow") == nil then
							return oldCalculateAim(self, projmeta, worldmeta, shootpospart, ...)
						end

						local projmetatab = projmeta:getProjectileMeta()
						local projectilePrediction = (worldmeta and projmetatab.predictionLifetimeSec or projmetatab.lifetimeSec or 3)
						local projectileSpeed = (projmetatab.launchVelocity or 100)
						local gravity = (projmetatab.gravitationalAcceleration or 196.2)
						local projectileGravity = gravity * projmeta.gravityMultiplier
						local offsetStartPos = startPos + projmeta.fromPositionOffset
						local pos = plr.Character[BowAimbotPart.Value].Position
						local playerGravity = workspace.Gravity
						local balloons = plr.Character:GetAttribute("InflatedBalloons")

						if balloons and balloons > 0 then 
							playerGravity = (workspace.Gravity * (1 - ((balloons >= 4 and 1.2 or balloons >= 3 and 1 or 0.975))))
						end

						if plr.Character.PrimaryPart:FindFirstChild("rbxassetid://8200754399") then 
							playerGravity = (workspace.Gravity * 0.3)
						end

						local shootpos, shootvelo = predictGravity(pos, plr.Character.HumanoidRootPart.Velocity, (pos - offsetStartPos).Magnitude / projectileSpeed, plr, playerGravity)
						if projmeta.projectile == "telepearl" then
							shootpos = pos
							shootvelo = Vector3.zero
						end
						
						local newlook = CFrame.new(offsetStartPos, shootpos) * CFrame.new(Vector3.new(-bedwars.BowConstantsTable.RelX, -bedwars.BowConstantsTable.RelY, 0))
						shootpos = newlook.p + (newlook.lookVector * (offsetStartPos - shootpos).magnitude)
						local calculated = LaunchDirection(offsetStartPos, shootpos, projectileSpeed, projectileGravity, false)
						oldmove = plr.Character.Humanoid.MoveDirection
						if calculated then
							return {
								initialVelocity = calculated,
								positionFrom = offsetStartPos,
								deltaT = projectilePrediction,
								gravitationalAcceleration = projectileGravity,
								drawDurationSeconds = 5
							}
						end
					end
					return oldCalculateAim(self, projmeta, worldmeta, shootpospart, ...)
				end
			else
				bedwars.ProjectileController.calculateImportantLaunchValues = oldCalculateAim
			end
		end
	})
	BowAimbotPart = BowAimbot.CreateDropdown({
		Name = "Part",
		List = {"HumanoidRootPart", "Head"},
		Function = function() end
	})
	BowAimbotFOV = BowAimbot.CreateSlider({
		Name = "FOV",
		Function = function() end,
		Min = 1,
		Max = 1000,
		Default = 1000
	})
	BowAimbotProjectiles = BowAimbot.CreateToggle({
		Name = "Other Projectiles",
		Function = function() end,
		Default = true
	})
end)

--until I find a way to make the spam switch item thing not bad I'll just get rid of it, sorry.

local Scaffold = {Enabled = false}
runFunction(function()
	local scaffoldtext = Instance.new("TextLabel")
	scaffoldtext.Font = Enum.Font.SourceSans
	scaffoldtext.TextSize = 20
	scaffoldtext.BackgroundTransparency = 1
	scaffoldtext.TextColor3 = Color3.fromRGB(255, 0, 0)
	scaffoldtext.Size = UDim2.new(0, 0, 0, 0)
	scaffoldtext.Position = UDim2.new(0.5, 0, 0.5, 30)
	scaffoldtext.Text = "0"
	scaffoldtext.Visible = false
	scaffoldtext.Parent = GuiLibrary.MainGui
	local ScaffoldExpand = {Value = 1}
	local ScaffoldDiagonal = {Enabled = false}
	local ScaffoldTower = {Enabled = false}
	local ScaffoldDownwards = {Enabled = false}
	local ScaffoldStopMotion = {Enabled = false}
	local ScaffoldBlockCount = {Enabled = false}
	local ScaffoldHandCheck = {Enabled = false}
	local ScaffoldMouseCheck = {Enabled = false}
	local ScaffoldAnimation = {Enabled = false}
	local scaffoldstopmotionval = false
	local scaffoldposcheck = tick()
	local scaffoldstopmotionpos = Vector3.zero
	local scaffoldposchecklist = {}
	task.spawn(function()
		for x = -3, 3, 3 do 
			for y = -3, 3, 3 do 
				for z = -3, 3, 3 do 
					if Vector3.new(x, y, z) ~= Vector3.new(0, 0, 0) then 
						table.insert(scaffoldposchecklist, Vector3.new(x, y, z)) 
					end 
				end 
			end 
		end
	end)

	local function checkblocks(pos)
		for i,v in pairs(scaffoldposchecklist) do
			if getPlacedBlock(pos + v) then
				return true
			end
		end
		return false
	end

	local function closestpos(block, pos)
		local startpos = block.Position - (block.Size / 2) - Vector3.new(1.5, 1.5, 1.5)
		local endpos = block.Position + (block.Size / 2) + Vector3.new(1.5, 1.5, 1.5)
		local speedCFrame = block.Position + (pos - block.Position)
		return Vector3.new(math.clamp(speedCFrame.X, startpos.X, endpos.X), math.clamp(speedCFrame.Y, startpos.Y, endpos.Y), math.clamp(speedCFrame.Z, startpos.Z, endpos.Z))
	end

	local function getclosesttop(newmag, pos)
		local closest, closestmag = pos, newmag * 3
		if entityLibrary.isAlive then 
			for i,v in pairs(bedwarsStore.blocks) do 
				local close = closestpos(v, pos)
				local mag = (close - pos).magnitude
				if mag <= closestmag then 
					closest = close
					closestmag = mag
				end
			end
		end
		return closest
	end

	local oldspeed
	Scaffold = GuiLibrary.ObjectsThatCanBeSaved.BlatantWindow.Api.CreateOptionsButton({
		Name = "Scaffold",
		Function = function(callback)
			if callback then
				scaffoldtext.Visible = ScaffoldBlockCount.Enabled
				if entityLibrary.isAlive then 
					scaffoldstopmotionpos = entityLibrary.character.HumanoidRootPart.CFrame.p
				end
				task.spawn(function()
					repeat
						task.wait()
						if ScaffoldHandCheck.Enabled then 
							if bedwarsStore.localHand.Type ~= "block" then continue end
						end
						if ScaffoldMouseCheck.Enabled then 
							if not inputService:IsMouseButtonPressed(0) then continue end
						end
						if entityLibrary.isAlive then
							local wool, woolamount = getWool()
							if bedwarsStore.localHand.Type == "block" then
								wool = bedwarsStore.localHand.tool.Name
								woolamount = getItem(bedwarsStore.localHand.tool.Name).amount or 0
							elseif (not wool) then 
								wool, woolamount = getBlock()
							end

							scaffoldtext.Text = (woolamount and tostring(woolamount) or "0")
							scaffoldtext.TextColor3 = woolamount and (woolamount >= 128 and Color3.fromRGB(9, 255, 198) or woolamount >= 64 and Color3.fromRGB(255, 249, 18)) or Color3.fromRGB(255, 0, 0)
							if not wool then continue end

							local towering = ScaffoldTower.Enabled and inputService:IsKeyDown(Enum.KeyCode.Space) and game:GetService("UserInputService"):GetFocusedTextBox() == nil
							if towering then
								if (not scaffoldstopmotionval) and ScaffoldStopMotion.Enabled then
									scaffoldstopmotionval = true
									scaffoldstopmotionpos = entityLibrary.character.HumanoidRootPart.CFrame.p
								end
								entityLibrary.character.HumanoidRootPart.Velocity = Vector3.new(entityLibrary.character.HumanoidRootPart.Velocity.X, 28, entityLibrary.character.HumanoidRootPart.Velocity.Z)
								if ScaffoldStopMotion.Enabled and scaffoldstopmotionval then
									entityLibrary.character.HumanoidRootPart.CFrame = CFrame.new(Vector3.new(scaffoldstopmotionpos.X, entityLibrary.character.HumanoidRootPart.CFrame.p.Y, scaffoldstopmotionpos.Z))
								end
							else
								scaffoldstopmotionval = false
							end
							
							for i = 1, ScaffoldExpand.Value do
								local speedCFrame = getScaffold((entityLibrary.character.HumanoidRootPart.Position + ((scaffoldstopmotionval and Vector3.zero or entityLibrary.character.Humanoid.MoveDirection) * (i * 3.5))) + Vector3.new(0, -((entityLibrary.character.HumanoidRootPart.Size.Y / 2) + entityLibrary.character.Humanoid.HipHeight + (inputService:IsKeyDown(Enum.KeyCode.LeftShift) and ScaffoldDownwards.Enabled and 4.5 or 1.5))), 0)
								speedCFrame = Vector3.new(speedCFrame.X, speedCFrame.Y - (towering and 4 or 0), speedCFrame.Z)
								if speedCFrame ~= oldpos then
									if not checkblocks(speedCFrame) then
										local oldspeedCFrame = speedCFrame
										speedCFrame = getScaffold(getclosesttop(20, speedCFrame))
										if getPlacedBlock(speedCFrame) then speedCFrame = oldspeedCFrame end
									end
									if ScaffoldAnimation.Enabled then 
										if not getPlacedBlock(speedCFrame) then
										bedwars.ViewmodelController:playAnimation(bedwars.AnimationType.FP_USE_ITEM)
										end
									end
									task.spawn(bedwars.placeBlock, speedCFrame, wool, ScaffoldAnimation.Enabled)
									if ScaffoldExpand.Value > 1 then 
										task.wait()
									end
									oldpos = speedCFrame
								end
							end
						end
					until (not Scaffold.Enabled)
				end)
			else
				scaffoldtext.Visible = false
				oldpos = Vector3.zero
				oldpos2 = Vector3.zero
			end
		end, 
		HoverText = "Helps you make bridges/scaffold walk."
	})
	ScaffoldExpand = Scaffold.CreateSlider({
		Name = "Expand",
		Min = 1,
		Max = 8,
		Function = function(val) end,
		Default = 1,
		HoverText = "Build range"
	})
	ScaffoldDiagonal = Scaffold.CreateToggle({
		Name = "Diagonal", 
		Function = function(callback) end,
		Default = true
	})
	ScaffoldTower = Scaffold.CreateToggle({
		Name = "Tower", 
		Function = function(callback) 
			if ScaffoldStopMotion.Object then
				ScaffoldTower.Object.ToggleArrow.Visible = callback
				ScaffoldStopMotion.Object.Visible = callback
			end
		end
	})
	ScaffoldMouseCheck = Scaffold.CreateToggle({
		Name = "Require mouse down", 
		Function = function(callback) end,
		HoverText = "Only places when left click is held.",
	})
	ScaffoldDownwards  = Scaffold.CreateToggle({
		Name = "Downwards", 
		Function = function(callback) end,
		HoverText = "Goes down when left shift is held."
	})
	ScaffoldStopMotion = Scaffold.CreateToggle({
		Name = "Stop Motion",
		Function = function() end,
		HoverText = "Stops your movement when going up"
	})
	ScaffoldStopMotion.Object.BackgroundTransparency = 0
	ScaffoldStopMotion.Object.BorderSizePixel = 0
	ScaffoldStopMotion.Object.BackgroundColor3 = Color3.fromRGB(20, 20, 20)
	ScaffoldStopMotion.Object.Visible = ScaffoldTower.Enabled
	ScaffoldBlockCount = Scaffold.CreateToggle({
		Name = "Block Count",
		Function = function(callback) 
			if Scaffold.Enabled then
				scaffoldtext.Visible = callback 
			end
		end,
		HoverText = "Shows the amount of blocks in the middle."
	})
	ScaffoldHandCheck = Scaffold.CreateToggle({
		Name = "Whitelist Only",
		Function = function() end,
		HoverText = "Only builds with blocks in your hand."
	})
	ScaffoldAnimation = Scaffold.CreateToggle({
		Name = "Animation",
		Function = function() end
	})
end)

local antivoidvelo
runFunction(function()
	local Speed = {Enabled = false}
	local SpeedMode = {Value = "CFrame"}
	local SpeedValue = {Value = 1}
	local SpeedValueLarge = {Value = 1}
	local SpeedDamageBoost = {Enabled = false}
	local SpeedJump = {Enabled = false}
	local SpeedJumpHeight = {Value = 20}
	local SpeedJumpAlways = {Enabled = false}
	local SpeedJumpSound = {Enabled = false}
	local SpeedJumpVanilla = {Enabled = false}
	local SpeedAnimation = {Enabled = false}
	local raycastparameters = RaycastParams.new()
	local damagetick = tick()

	local alternatelist = {"Normal", "AntiCheat A", "AntiCheat B"}
	Speed = GuiLibrary.ObjectsThatCanBeSaved.BlatantWindow.Api.CreateOptionsButton({
		Name = "Speed",
		Function = function(callback)
			if callback then
				table.insert(Speed.Connections, vapeEvents.EntityDamageEvent.Event:Connect(function(damageTable)
					if damageTable.entityInstance == lplr.Character and (damageTable.damageType ~= 0 or damageTable.extra and damageTable.extra.chargeRatio ~= nil) and (not (damageTable.knockbackMultiplier and damageTable.knockbackMultiplier.disabled or damageTable.knockbackMultiplier and damageTable.knockbackMultiplier.horizontal == 0)) and SpeedDamageBoost.Enabled then 
						damagetick = tick() + 0.4
					end
				end))
				RunLoops:BindToHeartbeat("Speed", function(delta)
					if GuiLibrary.ObjectsThatCanBeSaved["Lobby CheckToggle"].Api.Enabled then
						if bedwarsStore.matchState == 0 then return end
					end
					if entityLibrary.isAlive then
						if not (isnetworkowner(entityLibrary.character.HumanoidRootPart) and entityLibrary.character.Humanoid:GetState() ~= Enum.HumanoidStateType.Climbing and (not spiderActive) and (not GuiLibrary.ObjectsThatCanBeSaved.InfiniteFlyOptionsButton.Api.Enabled) and (not GuiLibrary.ObjectsThatCanBeSaved.FlyOptionsButton.Api.Enabled)) then return end
						if GuiLibrary.ObjectsThatCanBeSaved.GrappleExploitOptionsButton and GuiLibrary.ObjectsThatCanBeSaved.GrappleExploitOptionsButton.Api.Enabled then return end
						if LongJump.Enabled then return end
						if SpeedAnimation.Enabled then
							for i, v in pairs(entityLibrary.character.Humanoid:GetPlayingAnimationTracks()) do
								if v.Name == "WalkAnim" or v.Name == "RunAnim" then
									v:AdjustSpeed(entityLibrary.character.Humanoid.WalkSpeed / 16)
								end
							end
						end

						local speedValue = SpeedValue.Value + getSpeed()
						if damagetick > tick() then speedValue = speedValue + 20 end

						local speedVelocity = entityLibrary.character.Humanoid.MoveDirection * (SpeedMode.Value == "Normal" and SpeedValue.Value or 20)
						entityLibrary.character.HumanoidRootPart.Velocity = antivoidvelo or Vector3.new(speedVelocity.X, entityLibrary.character.HumanoidRootPart.Velocity.Y, speedVelocity.Z)
						if SpeedMode.Value ~= "Normal" then 
							local speedCFrame = entityLibrary.character.Humanoid.MoveDirection * (speedValue - 20) * delta
							raycastparameters.FilterDescendantsInstances = {lplr.Character}
							local ray = workspace:Raycast(entityLibrary.character.HumanoidRootPart.Position, speedCFrame, raycastparameters)
							if ray then speedCFrame = (ray.Position - entityLibrary.character.HumanoidRootPart.Position) end
							entityLibrary.character.HumanoidRootPart.CFrame = entityLibrary.character.HumanoidRootPart.CFrame + speedCFrame
						end

						if SpeedJump.Enabled and (not Scaffold.Enabled) and (SpeedJumpAlways.Enabled or killauraNearPlayer) then
							if (entityLibrary.character.Humanoid.FloorMaterial ~= Enum.Material.Air) and entityLibrary.character.Humanoid.MoveDirection ~= Vector3.zero then
								if SpeedJumpSound.Enabled then 
									pcall(function() entityLibrary.character.HumanoidRootPart.Jumping:Play() end)
								end
								if SpeedJumpVanilla.Enabled then 
									entityLibrary.character.Humanoid:ChangeState(Enum.HumanoidStateType.Jumping)
								else
									entityLibrary.character.HumanoidRootPart.Velocity = Vector3.new(entityLibrary.character.HumanoidRootPart.Velocity.X, SpeedJumpHeight.Value, entityLibrary.character.HumanoidRootPart.Velocity.Z)
								end
							end 
						end
					end
				end)
			else
				RunLoops:UnbindFromHeartbeat("Speed")
			end
		end, 
		HoverText = "Increases your movement.",
		ExtraText = function() 
			return "Heatseeker"
		end
	})
	SpeedValue = Speed.CreateSlider({
		Name = "Speed",
		Min = 1,
		Max = 23,
		Function = function(val) end,
		Default = 23
	})
	SpeedValueLarge = Speed.CreateSlider({
		Name = "Big Mode Speed",
		Min = 1,
		Max = 23,
		Function = function(val) end,
		Default = 23
	})
	SpeedDamageBoost = Speed.CreateToggle({
		Name = "Damage Boost",
		Function = function() end,
		Default = true
	})
	SpeedJump = Speed.CreateToggle({
		Name = "AutoJump", 
		Function = function(callback) 
			if SpeedJumpHeight.Object then SpeedJumpHeight.Object.Visible = callback end
			if SpeedJumpAlways.Object then
				SpeedJump.Object.ToggleArrow.Visible = callback
				SpeedJumpAlways.Object.Visible = callback
			end
			if SpeedJumpSound.Object then SpeedJumpSound.Object.Visible = callback end
			if SpeedJumpVanilla.Object then SpeedJumpVanilla.Object.Visible = callback end
		end,
		Default = true
	})
	SpeedJumpHeight = Speed.CreateSlider({
		Name = "Jump Height",
		Min = 0,
		Max = 30,
		Default = 25,
		Function = function() end
	})
	SpeedJumpAlways = Speed.CreateToggle({
		Name = "Always Jump",
		Function = function() end
	})
	SpeedJumpSound = Speed.CreateToggle({
		Name = "Jump Sound",
		Function = function() end
	})
	SpeedJumpVanilla = Speed.CreateToggle({
		Name = "Real Jump",
		Function = function() end
	})
	SpeedAnimation = Speed.CreateToggle({
		Name = "Slowdown Anim",
		Function = function() end
	})
end)

runFunction(function()
	local function roundpos(dir, pos, size)
		local suc, res = pcall(function() return Vector3.new(math.clamp(dir.X, pos.X - (size.X / 2), pos.X + (size.X / 2)), math.clamp(dir.Y, pos.Y - (size.Y / 2), pos.Y + (size.Y / 2)), math.clamp(dir.Z, pos.Z - (size.Z / 2), pos.Z + (size.Z / 2))) end)
		return suc and res or Vector3.zero
	end

	local Spider = {Enabled = false}
	local SpiderSpeed = {Value = 0}
	local SpiderMode = {Value = "Normal"}
	local SpiderPart
	Spider = GuiLibrary.ObjectsThatCanBeSaved.BlatantWindow.Api.CreateOptionsButton({
		Name = "Spider",
		Function = function(callback)
			if callback then
				table.insert(Spider.Connections, inputService.InputBegan:Connect(function(input1)
					if input1.KeyCode == Enum.KeyCode.LeftShift then 
						holdingshift = true
					end
				end))
				table.insert(Spider.Connections, inputService.InputEnded:Connect(function(input1)
					if input1.KeyCode == Enum.KeyCode.LeftShift then 
						holdingshift = false
					end
				end))
				RunLoops:BindToHeartbeat("Spider", function()
					if entityLibrary.isAlive and (GuiLibrary.ObjectsThatCanBeSaved.PhaseOptionsButton.Api.Enabled == false or holdingshift == false) then
						if SpiderMode.Value == "Normal" then
							local vec = entityLibrary.character.Humanoid.MoveDirection * 2
							local newray = getPlacedBlock(entityLibrary.character.HumanoidRootPart.Position + (vec + Vector3.new(0, 0.1, 0)))
							local newray2 = getPlacedBlock(entityLibrary.character.HumanoidRootPart.Position + (vec - Vector3.new(0, entityLibrary.character.Humanoid.HipHeight, 0)))
							if newray and (not newray.CanCollide) then newray = nil end 
							if newray2 and (not newray2.CanCollide) then newray2 = nil end 
							if spiderActive and (not newray) and (not newray2) then
								entityLibrary.character.HumanoidRootPart.Velocity = Vector3.new(entityLibrary.character.HumanoidRootPart.Velocity.X, 0, entityLibrary.character.HumanoidRootPart.Velocity.Z)
							end
							spiderActive = ((newray or newray2) and true or false)
							if (newray or newray2) then
								entityLibrary.character.HumanoidRootPart.Velocity = Vector3.new(newray2 and newray == nil and entityLibrary.character.HumanoidRootPart.Velocity.X or 0, SpiderSpeed.Value, newray2 and newray == nil and entityLibrary.character.HumanoidRootPart.Velocity.Z or 0)
							end
						else
							if not SpiderPart then 
								SpiderPart = Instance.new("TrussPart")
								SpiderPart.Size = Vector3.new(2, 2, 2)
								SpiderPart.Transparency = 1
								SpiderPart.Anchored = true
								SpiderPart.Parent = gameCamera
							end
							local newray2, newray2pos = getPlacedBlock(entityLibrary.character.HumanoidRootPart.Position + ((entityLibrary.character.HumanoidRootPart.CFrame.lookVector * 1.5) - Vector3.new(0, entityLibrary.character.Humanoid.HipHeight, 0)))
							if newray2 and (not newray2.CanCollide) then newray2 = nil end
							spiderActive = (newray2 and true or false)
							if newray2 then 
								newray2pos = newray2pos * 3
								local newpos = roundpos(entityLibrary.character.HumanoidRootPart.Position, Vector3.new(newray2pos.X, math.min(entityLibrary.character.HumanoidRootPart.Position.Y, newray2pos.Y), newray2pos.Z), Vector3.new(1.1, 1.1, 1.1))
								SpiderPart.Position = newpos
							else
								SpiderPart.Position = Vector3.zero
							end
						end
					end
				end)
			else
				if SpiderPart then SpiderPart:Destroy() end
				RunLoops:UnbindFromHeartbeat("Spider")
				holdingshift = false
			end
		end,
		HoverText = "Lets you climb up walls"
	})
	SpiderMode = Spider.CreateDropdown({
		Name = "Mode",
		List = {"Normal", "Classic"},
		Function = function() 
			if SpiderPart then SpiderPart:Destroy() end
		end
	})
	SpiderSpeed = Spider.CreateSlider({
		Name = "Speed",
		Min = 0,
		Max = 40,
		Function = function() end,
		Default = 40
	})
end)

runFunction(function()
	local TargetStrafe = {Enabled = false}
	local TargetStrafeRange = {Value = 18}
	local oldmove
	local controlmodule
	local block
	TargetStrafe = GuiLibrary.ObjectsThatCanBeSaved.BlatantWindow.Api.CreateOptionsButton({
		Name = "TargetStrafe",
		Function = function(callback)
			if callback then 
				task.spawn(function()
					if not controlmodule then
						local suc = pcall(function() controlmodule = require(lplr.PlayerScripts.PlayerModule).controls end)
						if not suc then controlmodule = {} end
					end
					oldmove = controlmodule.moveFunction
					local ang = 0
					local oldplr
					block = Instance.new("Part")
					block.Anchored = true
					block.CanCollide = false
					block.Parent = gameCamera
					controlmodule.moveFunction = function(Self, vec, facecam, ...)
						if entityLibrary.isAlive then
							local plr = AllNearPosition(TargetStrafeRange.Value + 5, 10)[1]
							plr = plr and (not workspace:Raycast(entityLibrary.character.HumanoidRootPart.Position, (plr.RootPart.Position - entityLibrary.character.HumanoidRootPart.Position), bedwarsStore.blockRaycast)) and workspace:Raycast(plr.RootPart.Position, Vector3.new(0, -70, 0), bedwarsStore.blockRaycast) and plr or nil
							if plr ~= oldplr then
								if plr then
									local x, y, z = CFrame.new(plr.RootPart.Position, entityLibrary.character.HumanoidRootPart.Position):ToEulerAnglesXYZ()
									ang = math.deg(z)
								end
								oldplr = plr
							end
							if plr then 
								facecam = false
								local localPos = CFrame.new(plr.RootPart.Position)
								local ray = workspace:Blockcast(localPos, Vector3.new(3, 3, 3), CFrame.Angles(0, math.rad(ang), 0).lookVector * TargetStrafeRange.Value, bedwarsStore.blockRaycast)
								local newPos = localPos + (CFrame.Angles(0, math.rad(ang), 0).lookVector * (ray and ray.Distance - 1 or TargetStrafeRange.Value))
								local factor = getSpeed() > 0 and 6 or 4
								if not workspace:Raycast(newPos.p, Vector3.new(0, -70, 0), bedwarsStore.blockRaycast) then 
									newPos = localPos
									factor = 40
								end
								if ((entityLibrary.character.HumanoidRootPart.Position * Vector3.new(1, 0, 1)) - (newPos.p * Vector3.new(1, 0, 1))).Magnitude < 4 or ray then
									ang = ang + factor % 360
								end
								block.Position = newPos.p
								vec = (newPos.p - entityLibrary.character.HumanoidRootPart.Position) * Vector3.new(1, 0, 1)
							end
						end
						return oldmove(Self, vec, facecam, ...)
					end
				end)
			else
				block:Destroy()
				controlmodule.moveFunction = oldmove
			end
		end
	})
	TargetStrafeRange = TargetStrafe.CreateSlider({
		Name = "Range",
		Min = 0,
		Max = 18,
		Function = function() end
	})
end)

runFunction(function()
	local BedESP = {Enabled = false}
	local BedESPFolder = Instance.new("Folder")
	BedESPFolder.Name = "BedESPFolder"
	BedESPFolder.Parent = GuiLibrary.MainGui
	local BedESPTable = {}
	local BedESPColor = {Value = 0.44}
	local BedESPTransparency = {Value = 1}
	local BedESPOnTop = {Enabled = true}
	BedESP = GuiLibrary.ObjectsThatCanBeSaved.RenderWindow.Api.CreateOptionsButton({
		Name = "BedESP",
		Function = function(callback) 
			if callback then
				table.insert(BedESP.Connections, collectionService:GetInstanceAddedSignal("bed"):Connect(function(bed)
					task.wait(0.2)
					if not BedESP.Enabled then return end
					local BedFolder = Instance.new("Folder")
					BedFolder.Parent = BedESPFolder
					BedESPTable[bed] = BedFolder
					for bedespnumber, bedesppart in pairs(bed:GetChildren()) do
						local boxhandle = Instance.new("BoxHandleAdornment")
						boxhandle.Size = bedesppart.Size + Vector3.new(.01, .01, .01)
						boxhandle.AlwaysOnTop = true
						boxhandle.ZIndex = (bedesppart.Name == "Covers" and 10 or 0)
						boxhandle.Visible = true
						boxhandle.Adornee = bedesppart
						boxhandle.Color3 = bedesppart.Color
						boxhandle.Name = bedespnumber
						boxhandle.Parent = BedFolder
					end
				end))
				table.insert(BedESP.Connections, collectionService:GetInstanceRemovedSignal("bed"):Connect(function(bed)
					if BedESPTable[bed] then 
						BedESPTable[bed]:Destroy()
						BedESPTable[bed] = nil
					end
				end))
				for i, bed in pairs(collectionService:GetTagged("bed")) do 
					local BedFolder = Instance.new("Folder")
					BedFolder.Parent = BedESPFolder
					BedESPTable[bed] = BedFolder
					for bedespnumber, bedesppart in pairs(bed:GetChildren()) do
						if bedesppart:IsA("BasePart") then
							local boxhandle = Instance.new("BoxHandleAdornment")
							boxhandle.Size = bedesppart.Size + Vector3.new(.01, .01, .01)
							boxhandle.AlwaysOnTop = true
							boxhandle.ZIndex = (bedesppart.Name == "Covers" and 10 or 0)
							boxhandle.Visible = true
							boxhandle.Adornee = bedesppart
							boxhandle.Color3 = bedesppart.Color
							boxhandle.Parent = BedFolder
						end
					end
				end
			else
				BedESPFolder:ClearAllChildren()
				table.clear(BedESPTable)
			end
		end,
		HoverText = "Render Beds through walls" 
	})
end)

runFunction(function()
	local function getallblocks2(pos, normal)
		local blocks = {}
		local lastfound = nil
		for i = 1, 20 do
			local blockpos = (pos + (Vector3.FromNormalId(normal) * (i * 3)))
			local extrablock = getPlacedBlock(blockpos)
			local covered = true
			if extrablock and extrablock.Parent ~= nil then
				if bedwars.BlockController:isBlockBreakable({blockPosition = blockpos}, lplr) then
					table.insert(blocks, extrablock:GetAttribute("NoBreak") and "unbreakable" or extrablock.Name)
				else
					table.insert(blocks, "unbreakable")
					break
				end
				lastfound = extrablock
				if covered == false then
					break
				end
			else
				break
			end
		end
		return blocks
	end

	local function getallbedblocks(pos)
		local blocks = {}
		for i,v in pairs(cachedNormalSides) do
			for i2,v2 in pairs(getallblocks2(pos, v)) do	
				if table.find(blocks, v2) == nil and v2 ~= "bed" then
					table.insert(blocks, v2)
				end
			end
			for i2,v2 in pairs(getallblocks2(pos + Vector3.new(0, 0, 3), v)) do	
				if table.find(blocks, v2) == nil and v2 ~= "bed" then
					table.insert(blocks, v2)
				end
			end
		end
		return blocks
	end

	local function refreshAdornee(v)
		local bedblocks = getallbedblocks(v.Adornee.Position)
		for i2,v2 in pairs(v.Frame:GetChildren()) do
			if v2:IsA("ImageLabel") then
				v2:Remove()
			end
		end
		for i3,v3 in pairs(bedblocks) do
			local blockimage = Instance.new("ImageLabel")
			blockimage.Size = UDim2.new(0, 32, 0, 32)
			blockimage.BackgroundTransparency = 1
			blockimage.Image = bedwars.getIcon({itemType = v3}, true)
			blockimage.Parent = v.Frame
		end
	end

	local BedPlatesFolder = Instance.new("Folder")
	BedPlatesFolder.Name = "BedPlatesFolder"
	BedPlatesFolder.Parent = GuiLibrary.MainGui
	local BedPlatesTable = {}
	local BedPlates = {Enabled = false}

	local function addBed(v)
		local billboard = Instance.new("BillboardGui")
		billboard.Parent = BedPlatesFolder
		billboard.Name = "bed"
		billboard.StudsOffsetWorldSpace = Vector3.new(0, 3, 1.5)
		billboard.Size = UDim2.new(0, 42, 0, 42)
		billboard.AlwaysOnTop = true
		billboard.Adornee = v
		BedPlatesTable[v] = billboard
		local frame = Instance.new("Frame")
		frame.Size = UDim2.new(1, 0, 1, 0)
		frame.BackgroundColor3 = Color3.new(0, 0, 0)
		frame.BackgroundTransparency = 0.5
		frame.Parent = billboard
		local uilistlayout = Instance.new("UIListLayout")
		uilistlayout.FillDirection = Enum.FillDirection.Horizontal
		uilistlayout.Padding = UDim.new(0, 4)
		uilistlayout.VerticalAlignment = Enum.VerticalAlignment.Center
		uilistlayout.HorizontalAlignment = Enum.HorizontalAlignment.Center
		uilistlayout:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(function()
			billboard.Size = UDim2.new(0, math.max(uilistlayout.AbsoluteContentSize.X + 12, 42), 0, 42)
		end)
		uilistlayout.Parent = frame
		local uicorner = Instance.new("UICorner")
		uicorner.CornerRadius = UDim.new(0, 4)
		uicorner.Parent = frame
		refreshAdornee(billboard)
	end

	BedPlates = GuiLibrary.ObjectsThatCanBeSaved.RenderWindow.Api.CreateOptionsButton({
		Name = "BedPlates",
		Function = function(callback)
			if callback then
				table.insert(BedPlates.Connections, vapeEvents.PlaceBlockEvent.Event:Connect(function(p5)
					for i, v in pairs(BedPlatesFolder:GetChildren()) do 
						if v.Adornee then
							if ((p5.blockRef.blockPosition * 3) - v.Adornee.Position).magnitude <= 20 then
								refreshAdornee(v)
							end
						end
					end
				end))
				table.insert(BedPlates.Connections, vapeEvents.BreakBlockEvent.Event:Connect(function(p5)
					for i, v in pairs(BedPlatesFolder:GetChildren()) do 
						if v.Adornee then
							if ((p5.blockRef.blockPosition * 3) - v.Adornee.Position).magnitude <= 20 then
								refreshAdornee(v)
							end
						end
					end
				end))
				table.insert(BedPlates.Connections, collectionService:GetInstanceAddedSignal("bed"):Connect(function(v)
					addBed(v)
				end))
				table.insert(BedPlates.Connections, collectionService:GetInstanceRemovedSignal("bed"):Connect(function(v)
					if BedPlatesTable[v] then 
						BedPlatesTable[v]:Destroy()
						BedPlatesTable[v] = nil
					end
				end))
				for i, v in pairs(collectionService:GetTagged("bed")) do
					addBed(v)
				end
			else
				BedPlatesFolder:ClearAllChildren()
			end
		end
	})
end)

runFunction(function()
	local ChestESPList = {ObjectList = {}, RefreshList = function() end}
	local function nearchestitem(item)
		for i,v in pairs(ChestESPList.ObjectList) do 
			if item:find(v) then return v end
		end
	end
	local function refreshAdornee(v)
		local chest = v.Adornee.ChestFolderValue.Value
        local chestitems = chest and chest:GetChildren() or {}
		for i2,v2 in pairs(v.Frame:GetChildren()) do
			if v2:IsA("ImageLabel") then
				v2:Remove()
			end
		end
		v.Enabled = false
		local alreadygot = {}
		for itemNumber, item in pairs(chestitems) do
			if alreadygot[item.Name] == nil and (table.find(ChestESPList.ObjectList, item.Name) or nearchestitem(item.Name)) then 
				alreadygot[item.Name] = true
				v.Enabled = true
                local blockimage = Instance.new("ImageLabel")
                blockimage.Size = UDim2.new(0, 32, 0, 32)
                blockimage.BackgroundTransparency = 1
                blockimage.Image = bedwars.getIcon({itemType = item.Name}, true)
                blockimage.Parent = v.Frame
            end
		end
	end

	local ChestESPFolder = Instance.new("Folder")
	ChestESPFolder.Name = "ChestESPFolder"
	ChestESPFolder.Parent = GuiLibrary.MainGui
	local ChestESP = {Enabled = false}
	local ChestESPBackground = {Enabled = true}

	local function chestfunc(v)
		task.spawn(function()
			local billboard = Instance.new("BillboardGui")
			billboard.Parent = ChestESPFolder
			billboard.Name = "chest"
			billboard.StudsOffsetWorldSpace = Vector3.new(0, 3, 0)
			billboard.Size = UDim2.new(0, 42, 0, 42)
			billboard.AlwaysOnTop = true
			billboard.Adornee = v
			local frame = Instance.new("Frame")
			frame.Size = UDim2.new(1, 0, 1, 0)
			frame.BackgroundColor3 = Color3.new(0, 0, 0)
			frame.BackgroundTransparency = ChestESPBackground.Enabled and 0.5 or 1
			frame.Parent = billboard
			local uilistlayout = Instance.new("UIListLayout")
			uilistlayout.FillDirection = Enum.FillDirection.Horizontal
			uilistlayout.Padding = UDim.new(0, 4)
			uilistlayout.VerticalAlignment = Enum.VerticalAlignment.Center
			uilistlayout.HorizontalAlignment = Enum.HorizontalAlignment.Center
			uilistlayout:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(function()
				billboard.Size = UDim2.new(0, math.max(uilistlayout.AbsoluteContentSize.X + 12, 42), 0, 42)
			end)
			uilistlayout.Parent = frame
			local uicorner = Instance.new("UICorner")
			uicorner.CornerRadius = UDim.new(0, 4)
			uicorner.Parent = frame
			local chest = v:WaitForChild("ChestFolderValue").Value
			if chest then 
				table.insert(ChestESP.Connections, chest.ChildAdded:Connect(function(item)
					if table.find(ChestESPList.ObjectList, item.Name) or nearchestitem(item.Name) then 
						refreshAdornee(billboard)
					end
				end))
				table.insert(ChestESP.Connections, chest.ChildRemoved:Connect(function(item)
					if table.find(ChestESPList.ObjectList, item.Name) or nearchestitem(item.Name) then 
						refreshAdornee(billboard)
					end
				end))
				refreshAdornee(billboard)
			end
		end)
	end

	ChestESP = GuiLibrary.ObjectsThatCanBeSaved.RenderWindow.Api.CreateOptionsButton({
		Name = "ChestESP",
		Function = function(callback)
			if callback then
				task.spawn(function()
					table.insert(ChestESP.Connections, collectionService:GetInstanceAddedSignal("chest"):Connect(chestfunc))
					for i,v in pairs(collectionService:GetTagged("chest")) do chestfunc(v) end
				end)
			else
				ChestESPFolder:ClearAllChildren()
			end
		end
	})
	ChestESPList = ChestESP.CreateTextList({
		Name = "ItemList",
		TempText = "item or part of item",
		AddFunction = function()
			if ChestESP.Enabled then 
				ChestESP.ToggleButton(false)
				ChestESP.ToggleButton(false)
			end
		end,
		RemoveFunction = function()
			if ChestESP.Enabled then 
				ChestESP.ToggleButton(false)
				ChestESP.ToggleButton(false)
			end
		end
	})
	ChestESPBackground = ChestESP.CreateToggle({
		Name = "Background",
		Function = function()
			if ChestESP.Enabled then 
				ChestESP.ToggleButton(false)
				ChestESP.ToggleButton(false)
			end
		end,
		Default = true
	})
end)

runFunction(function()
	local FieldOfViewValue = {Value = 70}
	local oldfov
	local oldfov2
	local FieldOfView = {Enabled = false}
	local FieldOfViewZoom = {Enabled = false}
	FieldOfView = GuiLibrary.ObjectsThatCanBeSaved.RenderWindow.Api.CreateOptionsButton({
		Name = "FOVChanger",
		Function = function(callback)
			if callback then
				if FieldOfViewZoom.Enabled then
					task.spawn(function()
						repeat
							task.wait()
						until not inputService:IsKeyDown(Enum.KeyCode[FieldOfView.Keybind ~= "" and FieldOfView.Keybind or "C"])
						if FieldOfView.Enabled then
							FieldOfView.ToggleButton(false)
						end
					end)
				end
				oldfov = bedwars.FovController.setFOV
				oldfov2 = bedwars.FovController.getFOV
				bedwars.FovController.setFOV = function(self, fov) return oldfov(self, FieldOfViewValue.Value) end
				bedwars.FovController.getFOV = function(self, fov) return FieldOfViewValue.Value end
			else
				bedwars.FovController.setFOV = oldfov
				bedwars.FovController.getFOV = oldfov2
			end
			bedwars.FovController:setFOV(bedwars.ClientStoreHandler:getState().Settings.fov)
		end
	})
	FieldOfViewValue = FieldOfView.CreateSlider({
		Name = "FOV",
		Min = 30,
		Max = 120,
		Function = function(val)
			if FieldOfView.Enabled then
				bedwars.FovController:setFOV(bedwars.ClientStoreHandler:getState().Settings.fov)
			end
		end
	})
	FieldOfViewZoom = FieldOfView.CreateToggle({
		Name = "Zoom",
		Function = function() end,
		HoverText = "optifine zoom lol"
	})
end)

runFunction(function()
	local old
	local old2
	local oldhitpart 
	local FPSBoost = {Enabled = false}
	local removetextures = {Enabled = false}
	local removetexturessmooth = {Enabled = false}
	local fpsboostdamageindicator = {Enabled = false}
	local fpsboostdamageeffect = {Enabled = false}
	local fpsboostkilleffect = {Enabled = false}
	local originaltextures = {}
	local originaleffects = {}

	local function fpsboosttextures()
		task.spawn(function()
			repeat task.wait() until bedwarsStore.matchState ~= 0
			for i,v in pairs(bedwarsStore.blocks) do
				if v:GetAttribute("PlacedByUserId") == 0 then
					v.Material = FPSBoost.Enabled and removetextures.Enabled and Enum.Material.SmoothPlastic or (v.Name:find("glass") and Enum.Material.SmoothPlastic or Enum.Material.Fabric)
					originaltextures[v] = originaltextures[v] or v.MaterialVariant
					v.MaterialVariant = FPSBoost.Enabled and removetextures.Enabled and "" or originaltextures[v]
					for i2,v2 in pairs(v:GetChildren()) do 
						pcall(function() 
							v2.Material = FPSBoost.Enabled and removetextures.Enabled and Enum.Material.SmoothPlastic or (v.Name:find("glass") and Enum.Material.SmoothPlastic or Enum.Material.Fabric)
							originaltextures[v2] = originaltextures[v2] or v2.MaterialVariant
							v2.MaterialVariant = FPSBoost.Enabled and removetextures.Enabled and "" or originaltextures[v2]
						end)
					end
				end
			end
		end)
	end

	FPSBoost = GuiLibrary.ObjectsThatCanBeSaved.RenderWindow.Api.CreateOptionsButton({
		Name = "FPSBoost",
		Function = function(callback)
			local damagetab = debug.getupvalue(bedwars.DamageIndicator, 2)
			if callback then
				wasenabled = true
				fpsboosttextures()
				if fpsboostdamageindicator.Enabled then 
					damagetab.strokeThickness = 0
					damagetab.textSize = 0
					damagetab.blowUpDuration = 0
					damagetab.blowUpSize = 0
				end
				if fpsboostkilleffect.Enabled then 
					for i,v in pairs(bedwars.KillEffectController.killEffects) do 
						originaleffects[i] = v
						bedwars.KillEffectController.killEffects[i] = {new = function(char) return {onKill = function() end, isPlayDefaultKillEffect = function() return char == lplr.Character end} end}
					end
				end
				if fpsboostdamageeffect.Enabled then 
					oldhitpart = bedwars.DamageIndicatorController.hitEffectPart
					bedwars.DamageIndicatorController.hitEffectPart = nil
				end
				old = bedwars.HighlightController.highlight
				old2 = getmetatable(bedwars.StopwatchController).tweenOutGhost
				local highlighttable = {}
				getmetatable(bedwars.StopwatchController).tweenOutGhost = function(p17, p18)
					p18:Destroy()
				end
				bedwars.HighlightController.highlight = function() end
			else
				for i,v in pairs(originaleffects) do 
					bedwars.KillEffectController.killEffects[i] = v
				end
				fpsboosttextures()
				if oldhitpart then 
					bedwars.DamageIndicatorController.hitEffectPart = oldhitpart
				end
				debug.setupvalue(bedwars.KillEffectController.KnitStart, 2, require(lplr.PlayerScripts.TS["client-sync-events"]).ClientSyncEvents)
				damagetab.strokeThickness = 1.5
				damagetab.textSize = 28
				damagetab.blowUpDuration = 0.125
				damagetab.blowUpSize = 76
				debug.setupvalue(bedwars.DamageIndicator, 10, tweenService)
				if bedwars.DamageIndicatorController.hitEffectPart then 
					bedwars.DamageIndicatorController.hitEffectPart.Attachment.Cubes.Enabled = true
					bedwars.DamageIndicatorController.hitEffectPart.Attachment.Shards.Enabled = true
				end
				bedwars.HighlightController.highlight = old
				getmetatable(bedwars.StopwatchController).tweenOutGhost = old2
				old = nil
				old2 = nil
			end
		end
	})
	removetextures = FPSBoost.CreateToggle({
		Name = "Remove Textures",
		Function = function(callback) if FPSBoost.Enabled then FPSBoost.ToggleButton(false) FPSBoost.ToggleButton(false) end end
	})
	fpsboostdamageindicator = FPSBoost.CreateToggle({
		Name = "Remove Damage Indicator",
		Function = function(callback) if FPSBoost.Enabled then FPSBoost.ToggleButton(false) FPSBoost.ToggleButton(false) end end
	})
	fpsboostdamageeffect = FPSBoost.CreateToggle({
		Name = "Remove Damage Effect",
		Function = function(callback) if FPSBoost.Enabled then FPSBoost.ToggleButton(false) FPSBoost.ToggleButton(false) end end
	})
	fpsboostkilleffect = FPSBoost.CreateToggle({
		Name = "Remove Kill Effect",
		Function = function(callback) if FPSBoost.Enabled then FPSBoost.ToggleButton(false) FPSBoost.ToggleButton(false) end end
	})
end)

runFunction(function()
	local GameFixer = {Enabled = false}
	local GameFixerHit = {Enabled = false}
	GameFixer = GuiLibrary.ObjectsThatCanBeSaved.RenderWindow.Api.CreateOptionsButton({
		Name = "GameFixer",
		Function = function(callback)
			if callback then
				if GameFixerHit.Enabled then 
					debug.setconstant(bedwars.SwordController.swingSwordAtMouse, 23, "raycast")
					debug.setupvalue(bedwars.SwordController.swingSwordAtMouse, 4, bedwars.QueryUtil)
				end
				--debug.setconstant(bedwars.QueueCard.render, 9, 0.1)
			else
				if GameFixerHit.Enabled then 
					debug.setconstant(bedwars.SwordController.swingSwordAtMouse, 23, "Raycast")
					debug.setupvalue(bedwars.SwordController.swingSwordAtMouse, 4, workspace)
				end
			--	debug.setconstant(bedwars.QueueCard.render, 9, 0.01)
			end
		end,
		HoverText = "Fixes game bugs"
	})
	GameFixerHit = GameFixer.CreateToggle({
		Name = "Hit Fix",
		Function = function(callback)
			if GameFixer.Enabled then
				if callback then 
					debug.setconstant(bedwars.SwordController.swingSwordAtMouse, 23, "raycast")
					debug.setupvalue(bedwars.SwordController.swingSwordAtMouse, 4, bedwars.QueryUtil)
				else
					debug.setconstant(bedwars.SwordController.swingSwordAtMouse, 23, "Raycast")
					debug.setupvalue(bedwars.SwordController.swingSwordAtMouse, 4, workspace)
				end
			end
		end,
		HoverText = "Fixes the raycast function used for extra reach",
		Default = true
	})
end)

runFunction(function()
	local transformed = false
	local GameTheme = {Enabled = false}
	local GameThemeMode = {Value = "GameTheme"}

	local themefunctions = {
		Old = function()
			task.spawn(function()
				local oldbedwarstabofimages = '{"clay_orange":"rbxassetid://7017703219","iron":"rbxassetid://6850537969","glass":"rbxassetid://6909521321","log_spruce":"rbxassetid://6874161124","ice":"rbxassetid://6874651262","marble":"rbxassetid://6594536339","zipline_base":"rbxassetid://7051148904","iron_helmet":"rbxassetid://6874272559","marble_pillar":"rbxassetid://6909323822","clay_dark_green":"rbxassetid://6763635916","wood_plank_birch":"rbxassetid://6768647328","watering_can":"rbxassetid://6915423754","emerald_helmet":"rbxassetid://6931675766","pie":"rbxassetid://6985761399","wood_plank_spruce":"rbxassetid://6768615964","diamond_chestplate":"rbxassetid://6874272898","wool_pink":"rbxassetid://6910479863","wool_blue":"rbxassetid://6910480234","wood_plank_oak":"rbxassetid://6910418127","diamond_boots":"rbxassetid://6874272964","clay_yellow":"rbxassetid://4991097283","tnt":"rbxassetid://6856168996","lasso":"rbxassetid://7192710930","clay_purple":"rbxassetid://6856099740","melon_seeds":"rbxassetid://6956387796","apple":"rbxassetid://6985765179","carrot_seeds":"rbxassetid://6956387835","log_oak":"rbxassetid://6763678414","emerald_chestplate":"rbxassetid://6931675868","wool_yellow":"rbxassetid://6910479606","emerald_boots":"rbxassetid://6931675942","clay_light_brown":"rbxassetid://6874651634","balloon":"rbxassetid://7122143895","cannon":"rbxassetid://7121221753","leather_boots":"rbxassetid://6855466456","melon":"rbxassetid://6915428682","wool_white":"rbxassetid://6910387332","log_birch":"rbxassetid://6763678414","clay_pink":"rbxassetid://6856283410","grass":"rbxassetid://6773447725","obsidian":"rbxassetid://6910443317","shield":"rbxassetid://7051149149","red_sandstone":"rbxassetid://6708703895","diamond_helmet":"rbxassetid://6874272793","wool_orange":"rbxassetid://6910479956","log_hickory":"rbxassetid://7017706899","guitar":"rbxassetid://7085044606","wool_purple":"rbxassetid://6910479777","diamond":"rbxassetid://6850538161","iron_chestplate":"rbxassetid://6874272631","slime_block":"rbxassetid://6869284566","stone_brick":"rbxassetid://6910394475","hammer":"rbxassetid://6955848801","ceramic":"rbxassetid://6910426690","wood_plank_maple":"rbxassetid://6768632085","leather_helmet":"rbxassetid://6855466216","stone":"rbxassetid://6763635916","slate_brick":"rbxassetid://6708836267","sandstone":"rbxassetid://6708657090","snow":"rbxassetid://6874651192","wool_red":"rbxassetid://6910479695","leather_chestplate":"rbxassetid://6876833204","clay_red":"rbxassetid://6856283323","wool_green":"rbxassetid://6910480050","clay_white":"rbxassetid://7017705325","wool_cyan":"rbxassetid://6910480152","clay_black":"rbxassetid://5890435474","sand":"rbxassetid://6187018940","clay_light_green":"rbxassetid://6856099550","clay_dark_brown":"rbxassetid://6874651325","carrot":"rbxassetid://3677675280","clay":"rbxassetid://6856190168","iron_boots":"rbxassetid://6874272718","emerald":"rbxassetid://6850538075","zipline":"rbxassetid://7051148904"}'
				local oldbedwarsicontab = game:GetService("HttpService"):JSONDecode(oldbedwarstabofimages)
				local oldbedwarssoundtable = {
					["QUEUE_JOIN"] = "rbxassetid://6691735519",
					["QUEUE_MATCH_FOUND"] = "rbxassetid://6768247187",
					["UI_CLICK"] = "rbxassetid://6732690176",
					["UI_OPEN"] = "rbxassetid://6732607930",
					["BEDWARS_UPGRADE_SUCCESS"] = "rbxassetid://6760677364",
					["BEDWARS_PURCHASE_ITEM"] = "rbxassetid://6760677364",
					["SWORD_SWING_1"] = "rbxassetid://6760544639",
					["SWORD_SWING_2"] = "rbxassetid://6760544595",
					["DAMAGE_1"] = "rbxassetid://6765457325",
					["DAMAGE_2"] = "rbxassetid://6765470975",
					["DAMAGE_3"] = "rbxassetid://6765470941",
					["CROP_HARVEST"] = "rbxassetid://4864122196",
					["CROP_PLANT_1"] = "rbxassetid://5483943277",
					["CROP_PLANT_2"] = "rbxassetid://5483943479",
					["CROP_PLANT_3"] = "rbxassetid://5483943723",
					["ARMOR_EQUIP"] = "rbxassetid://6760627839",
					["ARMOR_UNEQUIP"] = "rbxassetid://6760625788",
					["PICKUP_ITEM_DROP"] = "rbxassetid://6768578304",
					["PARTY_INCOMING_INVITE"] = "rbxassetid://6732495464",
					["ERROR_NOTIFICATION"] = "rbxassetid://6732495464",
					["INFO_NOTIFICATION"] = "rbxassetid://6732495464",
					["END_GAME"] = "rbxassetid://6246476959",
					["GENERIC_BLOCK_PLACE"] = "rbxassetid://4842910664",
					["GENERIC_BLOCK_BREAK"] = "rbxassetid://4819966893",
					["GRASS_BREAK"] = "rbxassetid://5282847153",
					["WOOD_BREAK"] = "rbxassetid://4819966893",
					["STONE_BREAK"] = "rbxassetid://6328287211",
					["WOOL_BREAK"] = "rbxassetid://4842910664",
					["TNT_EXPLODE_1"] = "rbxassetid://7192313632",
					["TNT_HISS_1"] = "rbxassetid://7192313423",
					["FIREBALL_EXPLODE"] = "rbxassetid://6855723746",
					["SLIME_BLOCK_BOUNCE"] = "rbxassetid://6857999096",
					["SLIME_BLOCK_BREAK"] = "rbxassetid://6857999170",
					["SLIME_BLOCK_HIT"] = "rbxassetid://6857999148",
					["SLIME_BLOCK_PLACE"] = "rbxassetid://6857999119",
					["BOW_DRAW"] = "rbxassetid://6866062236",
					["BOW_FIRE"] = "rbxassetid://6866062104",
					["ARROW_HIT"] = "rbxassetid://6866062188",
					["ARROW_IMPACT"] = "rbxassetid://6866062148",
					["TELEPEARL_THROW"] = "rbxassetid://6866223756",
					["TELEPEARL_LAND"] = "rbxassetid://6866223798",
					["CROSSBOW_RELOAD"] = "rbxassetid://6869254094",
					["VOICE_1"] = "rbxassetid://5283866929",
					["VOICE_2"] = "rbxassetid://5283867710",
					["VOICE_HONK"] = "rbxassetid://5283872555",
					["FORTIFY_BLOCK"] = "rbxassetid://6955762535",
					["EAT_FOOD_1"] = "rbxassetid://4968170636",
					["KILL"] = "rbxassetid://7013482008",
					["ZIPLINE_TRAVEL"] = "rbxassetid://7047882304",
					["ZIPLINE_LATCH"] = "rbxassetid://7047882233",
					["ZIPLINE_UNLATCH"] = "rbxassetid://7047882265",
					["SHIELD_BLOCKED"] = "rbxassetid://6955762535",
					["GUITAR_LOOP"] = "rbxassetid://7084168540",
					["GUITAR_HEAL_1"] = "rbxassetid://7084168458",
					["CANNON_MOVE"] = "rbxassetid://7118668472",
					["CANNON_FIRE"] = "rbxassetid://7121064180",
					["BALLOON_INFLATE"] = "rbxassetid://7118657911",
					["BALLOON_POP"] = "rbxassetid://7118657873",
					["FIREBALL_THROW"] = "rbxassetid://7192289445",
					["LASSO_HIT"] = "rbxassetid://7192289603",
					["LASSO_SWING"] = "rbxassetid://7192289504",
					["LASSO_THROW"] = "rbxassetid://7192289548",
					["GRIM_REAPER_CONSUME"] = "rbxassetid://7225389554",
					["GRIM_REAPER_CHANNEL"] = "rbxassetid://7225389512",
					["TV_STATIC"] = "rbxassetid://7256209920",
					["TURRET_ON"] = "rbxassetid://7290176291",
					["TURRET_OFF"] = "rbxassetid://7290176380",
					["TURRET_ROTATE"] = "rbxassetid://7290176421",
					["TURRET_SHOOT"] = "rbxassetid://7290187805",
					["WIZARD_LIGHTNING_CAST"] = "rbxassetid://7262989886",
					["WIZARD_LIGHTNING_LAND"] = "rbxassetid://7263165647",
					["WIZARD_LIGHTNING_STRIKE"] = "rbxassetid://7263165347",
					["WIZARD_ORB_CAST"] = "rbxassetid://7263165448",
					["WIZARD_ORB_TRAVEL_LOOP"] = "rbxassetid://7263165579",
					["WIZARD_ORB_CONTACT_LOOP"] = "rbxassetid://7263165647",
					["BATTLE_PASS_PROGRESS_LEVEL_UP"] = "rbxassetid://7331597283",
					["BATTLE_PASS_PROGRESS_EXP_GAIN"] = "rbxassetid://7331597220",
					["FLAMETHROWER_UPGRADE"] = "rbxassetid://7310273053",
					["FLAMETHROWER_USE"] = "rbxassetid://7310273125",
					["BRITTLE_HIT"] = "rbxassetid://7310273179",
					["EXTINGUISH"] = "rbxassetid://7310273015",
					["RAVEN_SPACE_AMBIENT"] = "rbxassetid://7341443286",
					["RAVEN_WING_FLAP"] = "rbxassetid://7341443378",
					["RAVEN_CAW"] = "rbxassetid://7341443447",
					["JADE_HAMMER_THUD"] = "rbxassetid://7342299402",
					["STATUE"] = "rbxassetid://7344166851",
					["CONFETTI"] = "rbxassetid://7344278405",
					["HEART"] = "rbxassetid://7345120916",
					["SPRAY"] = "rbxassetid://7361499529",
					["BEEHIVE_PRODUCE"] = "rbxassetid://7378100183",
					["DEPOSIT_BEE"] = "rbxassetid://7378100250",
					["CATCH_BEE"] = "rbxassetid://7378100305",
					["BEE_NET_SWING"] = "rbxassetid://7378100350",
					["ASCEND"] = "rbxassetid://7378387334",
					["BED_ALARM"] = "rbxassetid://7396762708",
					["BOUNTY_CLAIMED"] = "rbxassetid://7396751941",
					["BOUNTY_ASSIGNED"] = "rbxassetid://7396752155",
					["BAGUETTE_HIT"] = "rbxassetid://7396760547",
					["BAGUETTE_SWING"] = "rbxassetid://7396760496",
					["TESLA_ZAP"] = "rbxassetid://7497477336",
					["SPIRIT_TRIGGERED"] = "rbxassetid://7498107251",
					["SPIRIT_EXPLODE"] = "rbxassetid://7498107327",
					["ANGEL_LIGHT_ORB_CREATE"] = "rbxassetid://7552134231",
					["ANGEL_LIGHT_ORB_HEAL"] = "rbxassetid://7552134868",
					["ANGEL_VOID_ORB_CREATE"] = "rbxassetid://7552135942",
					["ANGEL_VOID_ORB_HEAL"] = "rbxassetid://7552136927",
					["DODO_BIRD_JUMP"] = "rbxassetid://7618085391",
					["DODO_BIRD_DOUBLE_JUMP"] = "rbxassetid://7618085771",
					["DODO_BIRD_MOUNT"] = "rbxassetid://7618085486",
					["DODO_BIRD_DISMOUNT"] = "rbxassetid://7618085571",
					["DODO_BIRD_SQUAWK_1"] = "rbxassetid://7618085870",
					["DODO_BIRD_SQUAWK_2"] = "rbxassetid://7618085657",
					["SHIELD_CHARGE_START"] = "rbxassetid://7730842884",
					["SHIELD_CHARGE_LOOP"] = "rbxassetid://7730843006",
					["SHIELD_CHARGE_BASH"] = "rbxassetid://7730843142",
					["ROCKET_LAUNCHER_FIRE"] = "rbxassetid://7681584765",
					["ROCKET_LAUNCHER_FLYING_LOOP"] = "rbxassetid://7681584906",
					["SMOKE_GRENADE_POP"] = "rbxassetid://7681276062",
					["SMOKE_GRENADE_EMIT_LOOP"] = "rbxassetid://7681276135",
					["GOO_SPIT"] = "rbxassetid://7807271610",
					["GOO_SPLAT"] = "rbxassetid://7807272724",
					["GOO_EAT"] = "rbxassetid://7813484049",
					["LUCKY_BLOCK_BREAK"] = "rbxassetid://7682005357",
					["AXOLOTL_SWITCH_TARGETS"] = "rbxassetid://7344278405",
					["HALLOWEEN_MUSIC"] = "rbxassetid://7775602786",
					["SNAP_TRAP_SETUP"] = "rbxassetid://7796078515",
					["SNAP_TRAP_CLOSE"] = "rbxassetid://7796078695",
					["SNAP_TRAP_CONSUME_MARK"] = "rbxassetid://7796078825",
					["GHOST_VACUUM_SUCKING_LOOP"] = "rbxassetid://7814995865",
					["GHOST_VACUUM_SHOOT"] = "rbxassetid://7806060367",
					["GHOST_VACUUM_CATCH"] = "rbxassetid://7815151688",
					["FISHERMAN_GAME_START"] = "rbxassetid://7806060544",
					["FISHERMAN_GAME_PULLING_LOOP"] = "rbxassetid://7806060638",
					["FISHERMAN_GAME_PROGRESS_INCREASE"] = "rbxassetid://7806060745",
					["FISHERMAN_GAME_FISH_MOVE"] = "rbxassetid://7806060863",
					["FISHERMAN_GAME_LOOP"] = "rbxassetid://7806061057",
					["FISHING_ROD_CAST"] = "rbxassetid://7806060976",
					["FISHING_ROD_SPLASH"] = "rbxassetid://7806061193",
					["SPEAR_HIT"] = "rbxassetid://7807270398",
					["SPEAR_THROW"] = "rbxassetid://7813485044",
				}
				for i,v in pairs(bedwars.CombatController.killSounds) do 
					bedwars.CombatController.killSounds[i] = oldbedwarssoundtable.KILL
				end
				for i,v in pairs(bedwars.CombatController.multiKillLoops) do 
					bedwars.CombatController.multiKillLoops[i] = ""
				end
				for i,v in pairs(bedwars.ItemTable) do 
					if oldbedwarsicontab[i] then 
						v.image = oldbedwarsicontab[i]
					end
				end			
				for i,v in pairs(oldbedwarssoundtable) do 
					local item = bedwars.SoundList[i]
					if item then
						bedwars.SoundList[i] = v
					end
				end	
				local damagetab = debug.getupvalue(bedwars.DamageIndicator, 2)
				damagetab.strokeThickness = false
				damagetab.textSize = 32
				damagetab.blowUpDuration = 0
				damagetab.baseColor = Color3.fromRGB(214, 0, 0)
				damagetab.blowUpSize = 32
				damagetab.blowUpCompleteDuration = 0
				damagetab.anchoredDuration = 0
				debug.setconstant(bedwars.ViewmodelController.show, 37, "")
				debug.setconstant(bedwars.DamageIndicator, 83, Enum.Font.LuckiestGuy)
				debug.setconstant(bedwars.DamageIndicator, 102, "Enabled")
				debug.setconstant(bedwars.DamageIndicator, 118, 0.3)
				debug.setconstant(bedwars.DamageIndicator, 128, 0.5)
				debug.setupvalue(bedwars.DamageIndicator, 10, {
					Create = function(self, obj, ...)
						task.spawn(function()
							obj.Parent.Parent.Parent.Parent.Velocity = Vector3.new((math.random(-50, 50) / 100) * damagetab.velX, (math.random(50, 60) / 100) * damagetab.velY, (math.random(-50, 50) / 100) * damagetab.velZ)
							local textcompare = obj.Parent.TextColor3
							if textcompare ~= Color3.fromRGB(85, 255, 85) then
								local newtween = tweenService:Create(obj.Parent, TweenInfo.new(0.5, Enum.EasingStyle.Linear), {
									TextColor3 = (textcompare == Color3.fromRGB(76, 175, 93) and Color3.new(0, 0, 0) or Color3.new(1, 1, 1))
								})
								task.wait(0.15)
								newtween:Play()
							end
						end)
						return tweenService:Create(obj, ...)
					end
				})
				sethiddenproperty(lightingService, "Technology", "ShadowMap")
				lightingService.Ambient = Color3.fromRGB(69, 69, 69)
				lightingService.Brightness = 3
				lightingService.EnvironmentDiffuseScale = 1
				lightingService.EnvironmentSpecularScale = 1
				lightingService.OutdoorAmbient = Color3.fromRGB(69, 69, 69)
				lightingService.Atmosphere.Density = 0.1
				lightingService.Atmosphere.Offset = 0.25
				lightingService.Atmosphere.Color = Color3.fromRGB(198, 198, 198)
				lightingService.Atmosphere.Decay = Color3.fromRGB(104, 112, 124)
				lightingService.Atmosphere.Glare = 0
				lightingService.Atmosphere.Haze = 0
				lightingService.ClockTime = 13
				lightingService.GeographicLatitude = 0
				lightingService.GlobalShadows = false
				lightingService.TimeOfDay = "13:00:00"
				lightingService.Sky.SkyboxBk = "rbxassetid://7018684000"
				lightingService.Sky.SkyboxDn = "rbxassetid://6334928194"
				lightingService.Sky.SkyboxFt = "rbxassetid://7018684000"
				lightingService.Sky.SkyboxLf = "rbxassetid://7018684000"
				lightingService.Sky.SkyboxRt = "rbxassetid://7018684000"
				lightingService.Sky.SkyboxUp = "rbxassetid://7018689553"
			end)
		end,
		Winter = function() 
			task.spawn(function()
				for i,v in pairs(lightingService:GetChildren()) do
					if v:IsA("Atmosphere") or v:IsA("Sky") or v:IsA("PostEffect") then
						v:Remove()
					end
				end
				local sky = Instance.new("Sky")
				sky.StarCount = 5000
				sky.SkyboxUp = "rbxassetid://8139676647"
				sky.SkyboxLf = "rbxassetid://8139676988"
				sky.SkyboxFt = "rbxassetid://8139677111"
				sky.SkyboxBk = "rbxassetid://8139677359"
				sky.SkyboxDn = "rbxassetid://8139677253"
				sky.SkyboxRt = "rbxassetid://8139676842"
				sky.SunTextureId = "rbxassetid://6196665106"
				sky.SunAngularSize = 11
				sky.MoonTextureId = "rbxassetid://8139665943"
				sky.MoonAngularSize = 30
				sky.Parent = lightingService
				local sunray = Instance.new("SunRaysEffect")
				sunray.Intensity = 0.03
				sunray.Parent = lightingService
				local bloom = Instance.new("BloomEffect")
				bloom.Threshold = 2
				bloom.Intensity = 1
				bloom.Size = 2
				bloom.Parent = lightingService
				local atmosphere = Instance.new("Atmosphere")
				atmosphere.Density = 0.3
				atmosphere.Offset = 0.25
				atmosphere.Color = Color3.fromRGB(198, 198, 198)
				atmosphere.Decay = Color3.fromRGB(104, 112, 124)
				atmosphere.Glare = 0
				atmosphere.Haze = 0
				atmosphere.Parent = lightingService
				local damagetab = debug.getupvalue(bedwars.DamageIndicator, 2)
				damagetab.strokeThickness = false
				damagetab.textSize = 32
				damagetab.blowUpDuration = 0
				damagetab.baseColor = Color3.fromRGB(70, 255, 255)
				damagetab.blowUpSize = 32
				damagetab.blowUpCompleteDuration = 0
				damagetab.anchoredDuration = 0
				debug.setconstant(bedwars.DamageIndicator, 83, Enum.Font.LuckiestGuy)
				debug.setconstant(bedwars.DamageIndicator, 102, "Enabled")
				debug.setconstant(bedwars.DamageIndicator, 118, 0.3)
				debug.setconstant(bedwars.DamageIndicator, 128, 0.5)
				debug.setupvalue(bedwars.DamageIndicator, 10, {
					Create = function(self, obj, ...)
						task.spawn(function()
							obj.Parent.Parent.Parent.Parent.Velocity = Vector3.new((math.random(-50, 50) / 100) * damagetab.velX, (math.random(50, 60) / 100) * damagetab.velY, (math.random(-50, 50) / 100) * damagetab.velZ)
							local textcompare = obj.Parent.TextColor3
							if textcompare ~= Color3.fromRGB(85, 255, 85) then
								local newtween = tweenService:Create(obj.Parent, TweenInfo.new(0.5, Enum.EasingStyle.Linear), {
									TextColor3 = (textcompare == Color3.fromRGB(76, 175, 93) and Color3.new(1, 1, 1) or Color3.new(0, 0, 0))
								})
								task.wait(0.15)
								newtween:Play()
							end
						end)
						return tweenService:Create(obj, ...)
					end
				})
				debug.setconstant(require(lplr.PlayerScripts.TS.controllers.global.hotbar.ui.healthbar["hotbar-healthbar"]).HotbarHealthbar.render, 16, 4653055)
			end)
			task.spawn(function()
				local snowpart = Instance.new("Part")
				snowpart.Size = Vector3.new(240, 0.5, 240)
				snowpart.Name = "SnowParticle"
				snowpart.Transparency = 1
				snowpart.CanCollide = false
				snowpart.Position = Vector3.new(0, 120, 286)
				snowpart.Anchored = true
				snowpart.Parent = workspace
				local snow = Instance.new("ParticleEmitter")
				snow.RotSpeed = NumberRange.new(300)
				snow.VelocitySpread = 35
				snow.Rate = 28
				snow.Texture = "rbxassetid://8158344433"
				snow.Rotation = NumberRange.new(110)
				snow.Transparency = NumberSequence.new({NumberSequenceKeypoint.new(0,0.16939899325371,0),NumberSequenceKeypoint.new(0.23365999758244,0.62841498851776,0.37158501148224),NumberSequenceKeypoint.new(0.56209099292755,0.38797798752785,0.2771390080452),NumberSequenceKeypoint.new(0.90577298402786,0.51912599802017,0),NumberSequenceKeypoint.new(1,1,0)})
				snow.Lifetime = NumberRange.new(8,14)
				snow.Speed = NumberRange.new(8,18)
				snow.EmissionDirection = Enum.NormalId.Bottom
				snow.SpreadAngle = Vector2.new(35,35)
				snow.Size = NumberSequence.new({NumberSequenceKeypoint.new(0,0,0),NumberSequenceKeypoint.new(0.039760299026966,1.3114800453186,0.32786899805069),NumberSequenceKeypoint.new(0.7554469704628,0.98360699415207,0.44038599729538),NumberSequenceKeypoint.new(1,0,0)})
				snow.Parent = snowpart
				local windsnow = Instance.new("ParticleEmitter")
				windsnow.Acceleration = Vector3.new(0,0,1)
				windsnow.RotSpeed = NumberRange.new(100)
				windsnow.VelocitySpread = 35
				windsnow.Rate = 28
				windsnow.Texture = "rbxassetid://8158344433"
				windsnow.EmissionDirection = Enum.NormalId.Bottom
				windsnow.Transparency = NumberSequence.new({NumberSequenceKeypoint.new(0,0.16939899325371,0),NumberSequenceKeypoint.new(0.23365999758244,0.62841498851776,0.37158501148224),NumberSequenceKeypoint.new(0.56209099292755,0.38797798752785,0.2771390080452),NumberSequenceKeypoint.new(0.90577298402786,0.51912599802017,0),NumberSequenceKeypoint.new(1,1,0)})
				windsnow.Lifetime = NumberRange.new(8,14)
				windsnow.Speed = NumberRange.new(8,18)
				windsnow.Rotation = NumberRange.new(110)
				windsnow.SpreadAngle = Vector2.new(35,35)
				windsnow.Size = NumberSequence.new({NumberSequenceKeypoint.new(0,0,0),NumberSequenceKeypoint.new(0.039760299026966,1.3114800453186,0.32786899805069),NumberSequenceKeypoint.new(0.7554469704628,0.98360699415207,0.44038599729538),NumberSequenceKeypoint.new(1,0,0)})
				windsnow.Parent = snowpart
				repeat
					task.wait()
					if entityLibrary.isAlive then 
						snowpart.Position = entityLibrary.character.HumanoidRootPart.Position + Vector3.new(0, 100, 0)
					end
				until not vapeInjected
			end)
		end,
		Halloween = function()
			task.spawn(function()
				for i,v in pairs(lightingService:GetChildren()) do
					if v:IsA("Atmosphere") or v:IsA("Sky") or v:IsA("PostEffect") then
						v:Remove()
					end
				end
				lightingService.TimeOfDay = "00:00:00"
				pcall(function() workspace.Clouds:Destroy() end)
				local damagetab = debug.getupvalue(bedwars.DamageIndicator, 2)
				damagetab.strokeThickness = false
				damagetab.textSize = 32
				damagetab.blowUpDuration = 0
				damagetab.baseColor = Color3.fromRGB(255, 100, 0)
				damagetab.blowUpSize = 32
				damagetab.blowUpCompleteDuration = 0
				damagetab.anchoredDuration = 0
				debug.setconstant(bedwars.DamageIndicator, 83, Enum.Font.LuckiestGuy)
				debug.setconstant(bedwars.DamageIndicator, 102, "Enabled")
				debug.setconstant(bedwars.DamageIndicator, 118, 0.3)
				debug.setconstant(bedwars.DamageIndicator, 128, 0.5)
				debug.setupvalue(bedwars.DamageIndicator, 10, {
					Create = function(self, obj, ...)
						task.spawn(function()
							obj.Parent.Parent.Parent.Parent.Velocity = Vector3.new((math.random(-50, 50) / 100) * damagetab.velX, (math.random(50, 60) / 100) * damagetab.velY, (math.random(-50, 50) / 100) * damagetab.velZ)
							local textcompare = obj.Parent.TextColor3
							if textcompare ~= Color3.fromRGB(85, 255, 85) then
								local newtween = tweenService:Create(obj.Parent, TweenInfo.new(0.5, Enum.EasingStyle.Linear), {
									TextColor3 = (textcompare == Color3.fromRGB(76, 175, 93) and Color3.new(0, 0, 0) or Color3.new(0, 0, 0))
								})
								task.wait(0.15)
								newtween:Play()
							end
						end)
						return tweenService:Create(obj, ...)
					end
				})
				local colorcorrection = Instance.new("ColorCorrectionEffect")
				colorcorrection.TintColor = Color3.fromRGB(255, 185, 81)
				colorcorrection.Brightness = 0.05
				colorcorrection.Parent = lightingService
				debug.setconstant(require(lplr.PlayerScripts.TS.controllers.global.hotbar.ui.healthbar["hotbar-healthbar"]).HotbarHealthbar.render, 16, 16737280)
			end)
		end,
		Valentines = function()
			task.spawn(function()
				for i,v in pairs(lightingService:GetChildren()) do
					if v:IsA("Atmosphere") or v:IsA("Sky") or v:IsA("PostEffect") then
						v:Remove()
					end
				end
				local sky = Instance.new("Sky")
				sky.SkyboxBk = "rbxassetid://1546230803"
				sky.SkyboxDn = "rbxassetid://1546231143"
				sky.SkyboxFt = "rbxassetid://1546230803"
				sky.SkyboxLf = "rbxassetid://1546230803"
				sky.SkyboxRt = "rbxassetid://1546230803"
				sky.SkyboxUp = "rbxassetid://1546230451"
				sky.Parent = lightingService
				pcall(function() workspace.Clouds:Destroy() end)
				local damagetab = debug.getupvalue(bedwars.DamageIndicator, 2)
				damagetab.strokeThickness = false
				damagetab.textSize = 32
				damagetab.blowUpDuration = 0
				damagetab.baseColor = Color3.fromRGB(255, 132, 178)
				damagetab.blowUpSize = 32
				damagetab.blowUpCompleteDuration = 0
				damagetab.anchoredDuration = 0
				debug.setconstant(bedwars.DamageIndicator, 83, Enum.Font.LuckiestGuy)
				debug.setconstant(bedwars.DamageIndicator, 102, "Enabled")
				debug.setconstant(bedwars.DamageIndicator, 118, 0.3)
				debug.setconstant(bedwars.DamageIndicator, 128, 0.5)
				debug.setupvalue(bedwars.DamageIndicator, 10, {
					Create = function(self, obj, ...)
						task.spawn(function()
							obj.Parent.Parent.Parent.Parent.Velocity = Vector3.new((math.random(-50, 50) / 100) * damagetab.velX, (math.random(50, 60) / 100) * damagetab.velY, (math.random(-50, 50) / 100) * damagetab.velZ)
							local textcompare = obj.Parent.TextColor3
							if textcompare ~= Color3.fromRGB(85, 255, 85) then
								local newtween = tweenService:Create(obj.Parent, TweenInfo.new(0.5, Enum.EasingStyle.Linear), {
									TextColor3 = (textcompare == Color3.fromRGB(76, 175, 93) and Color3.new(0, 0, 0) or Color3.new(0, 0, 0))
								})
								task.wait(0.15)
								newtween:Play()
							end
						end)
						return tweenService:Create(obj, ...)
					end
				})
				local colorcorrection = Instance.new("ColorCorrectionEffect")
				colorcorrection.TintColor = Color3.fromRGB(255, 199, 220)
				colorcorrection.Brightness = 0.05
				colorcorrection.Parent = lightingService
				debug.setconstant(require(lplr.PlayerScripts.TS.controllers.global.hotbar.ui.healthbar["hotbar-healthbar"]).HotbarHealthbar.render, 16, 16745650)
			end)
		end
	}

	GameTheme = GuiLibrary.ObjectsThatCanBeSaved.RenderWindow.Api.CreateOptionsButton({
		Name = "GameTheme",
		Function = function(callback) 
			if callback then 
				if not transformed then
					transformed = true
					themefunctions[GameThemeMode.Value]()
				else
					GameTheme.ToggleButton(false)
				end
			else
				warningNotification("GameTheme", "Disabled Next Game", 10)
			end
		end,
		ExtraText = function()
			return GameThemeMode.Value
		end
	})
	GameThemeMode = GameTheme.CreateDropdown({
		Name = "Theme",
		Function = function() end,
		List = {"Old", "Winter", "Halloween", "Valentines"}
	})
end)

runFunction(function()
	local oldkilleffect
	local KillEffectMode = {Value = "Gravity"}
	local KillEffectList = {Value = "None"}
	local KillEffectName2 = {}
	local killeffects = {
		Gravity = function(p3, p4, p5, p6)
			p5:BreakJoints()
			task.spawn(function()
				local partvelo = {}
				for i,v in pairs(p5:GetDescendants()) do 
					if v:IsA("BasePart") then 
						partvelo[v.Name] = v.Velocity * 3
					end
				end
				p5.Archivable = true
				local clone = p5:Clone()
				clone.Humanoid.Health = 100
				clone.Parent = workspace
				local nametag = clone:FindFirstChild("Nametag", true)
				if nametag then nametag:Destroy() end
				game:GetService("Debris"):AddItem(clone, 30)
				p5:Destroy()
				task.wait(0.01)
				clone.Humanoid:ChangeState(Enum.HumanoidStateType.Dead)
				clone:BreakJoints()
				task.wait(0.01)
				for i,v in pairs(clone:GetDescendants()) do 
					if v:IsA("BasePart") then 
						local bodyforce = Instance.new("BodyForce")
						bodyforce.Force = Vector3.new(0, (workspace.Gravity - 10) * v:GetMass(), 0)
						bodyforce.Parent = v
						v.CanCollide = true
						v.Velocity = partvelo[v.Name] or Vector3.zero
					end
				end
			end)
		end,
		Lightning = function(p3, p4, p5, p6)
			p5:BreakJoints()
			local startpos = 1125
			local startcf = p5.PrimaryPart.CFrame.p - Vector3.new(0, 8, 0)
			local newpos = Vector3.new((math.random(1, 10) - 5) * 2, startpos, (math.random(1, 10) - 5) * 2)
			for i = startpos - 75, 0, -75 do 
				local newpos2 = Vector3.new((math.random(1, 10) - 5) * 2, i, (math.random(1, 10) - 5) * 2)
				if i == 0 then 
					newpos2 = Vector3.zero
				end
				local part = Instance.new("Part")
				part.Size = Vector3.new(1.5, 1.5, 77)
				part.Material = Enum.Material.SmoothPlastic
				part.Anchored = true
				part.Material = Enum.Material.Neon
				part.CanCollide = false
				part.CFrame = CFrame.new(startcf + newpos + ((newpos2 - newpos) * 0.5), startcf + newpos2)
				part.Parent = workspace
				local part2 = part:Clone()
				part2.Size = Vector3.new(3, 3, 78)
				part2.Color = Color3.new(0.7, 0.7, 0.7)
				part2.Transparency = 0.7
				part2.Material = Enum.Material.SmoothPlastic
				part2.Parent = workspace
				game:GetService("Debris"):AddItem(part, 0.5)
				game:GetService("Debris"):AddItem(part2, 0.5)
				bedwars.QueryUtil:setQueryIgnored(part, true)
				bedwars.QueryUtil:setQueryIgnored(part2, true)
				if i == 0 then 
					local soundpart = Instance.new("Part")
					soundpart.Transparency = 1
					soundpart.Anchored = true 
					soundpart.Size = Vector3.zero
					soundpart.Position = startcf
					soundpart.Parent = workspace
					bedwars.QueryUtil:setQueryIgnored(soundpart, true)
					local sound = Instance.new("Sound")
					sound.SoundId = "rbxassetid://6993372814"
					sound.Volume = 2
					sound.Pitch = 0.5 + (math.random(1, 3) / 10)
					sound.Parent = soundpart
					sound:Play()
					sound.Ended:Connect(function()
						soundpart:Destroy()
					end)
				end
				newpos = newpos2
			end
		end
	}
	local KillEffectName = {}
	for i,v in pairs(bedwars.KillEffectMeta) do 
		table.insert(KillEffectName, v.name)
		KillEffectName[v.name] = i
	end
	table.sort(KillEffectName, function(a, b) return a:lower() < b:lower() end)
	local KillEffect = {Enabled = false}
	KillEffect = GuiLibrary.ObjectsThatCanBeSaved.RenderWindow.Api.CreateOptionsButton({
		Name = "KillEffect",
		Function = function(callback)
			if callback then 
				task.spawn(function()
					repeat task.wait() until bedwarsStore.matchState ~= 0 or not KillEffect.Enabled
					if KillEffect.Enabled then
						lplr:SetAttribute("KillEffectType", "none")
						if KillEffectMode.Value == "Bedwars" then 
							lplr:SetAttribute("KillEffectType", KillEffectName[KillEffectList.Value])
						end
					end
				end)
				oldkilleffect = bedwars.DefaultKillEffect.onKill
				bedwars.DefaultKillEffect.onKill = function(p3, p4, p5, p6)
					killeffects[KillEffectMode.Value](p3, p4, p5, p6)
				end
			else
				bedwars.DefaultKillEffect.onKill = oldkilleffect
			end
		end
	})
	local modes = {"Bedwars"}
	for i,v in pairs(killeffects) do 
		table.insert(modes, i)
	end
	KillEffectMode = KillEffect.CreateDropdown({
		Name = "Mode",
		Function = function() 
			if KillEffect.Enabled then 
				KillEffect.ToggleButton(false)
				KillEffect.ToggleButton(false)
			end
		end,
		List = modes
	})
	KillEffectList = KillEffect.CreateDropdown({
		Name = "Bedwars",
		Function = function() 
			if KillEffect.Enabled then 
				KillEffect.ToggleButton(false)
				KillEffect.ToggleButton(false)
			end
		end,
		List = KillEffectName
	})
end)

runFunction(function()
	local KitESP = {Enabled = false}
	local espobjs = {}
	local espfold = Instance.new("Folder")
	espfold.Parent = GuiLibrary.MainGui

	local function espadd(v, icon)
		local billboard = Instance.new("BillboardGui")
		billboard.Parent = espfold
		billboard.Name = "iron"
		billboard.StudsOffsetWorldSpace = Vector3.new(0, 3, 1.5)
		billboard.Size = UDim2.new(0, 32, 0, 32)
		billboard.AlwaysOnTop = true
		billboard.Adornee = v
		local image = Instance.new("ImageLabel")
		image.BackgroundTransparency = 0.5
		image.BorderSizePixel = 0
		image.Image = bedwars.getIcon({itemType = icon}, true)
		image.BackgroundColor3 = Color3.fromRGB(20, 20, 20)
		image.Size = UDim2.new(0, 32, 0, 32)
		image.AnchorPoint = Vector2.new(0.5, 0.5)
		image.Parent = billboard
		local uicorner = Instance.new("UICorner")
		uicorner.CornerRadius = UDim.new(0, 4)
		uicorner.Parent = image
		espobjs[v] = billboard
	end

	local function addKit(tag, icon)
		table.insert(KitESP.Connections, collectionService:GetInstanceAddedSignal(tag):Connect(function(v)
			espadd(v.PrimaryPart, icon)
		end))
		table.insert(KitESP.Connections, collectionService:GetInstanceRemovedSignal(tag):Connect(function(v)
			if espobjs[v.PrimaryPart] then
				espobjs[v.PrimaryPart]:Destroy()
				espobjs[v.PrimaryPart] = nil
			end
		end))
		for i,v in pairs(collectionService:GetTagged(tag)) do 
			espadd(v.PrimaryPart, icon)
		end
	end

	KitESP = GuiLibrary.ObjectsThatCanBeSaved.RenderWindow.Api.CreateOptionsButton({
		Name = "KitESP",
		Function = function(callback) 
			if callback then
				task.spawn(function()
					repeat task.wait() until bedwarsStore.equippedKit ~= ""
					if KitESP.Enabled then
						if bedwarsStore.equippedKit == "metal_detector" then
							addKit("hidden-metal", "iron")
						elseif bedwarsStore.equippedKit == "beekeeper" then
							addKit("bee", "bee")
						elseif bedwarsStore.equippedKit == "bigman" then
							addKit("treeOrb", "natures_essence_1")
						end
					end
				end)
			else
				espfold:ClearAllChildren()
				table.clear(espobjs)
			end
		end
	})
end)

runFunction(function()
	local function floorNameTagPosition(pos)
		return Vector2.new(math.floor(pos.X), math.floor(pos.Y))
	end

	local function removeTags(str)
        str = str:gsub("<br%s*/>", "\n")
        return (str:gsub("<[^<>]->", ""))
    end

	local NameTagsFolder = Instance.new("Folder")
	NameTagsFolder.Name = "NameTagsFolder"
	NameTagsFolder.Parent = GuiLibrary.MainGui
	local nametagsfolderdrawing = {}
	local NameTagsColor = {Value = 0.44}
	local NameTagsDisplayName = {Enabled = false}
	local NameTagsHealth = {Enabled = false}
	local NameTagsDistance = {Enabled = false}
	local NameTagsBackground = {Enabled = true}
	local NameTagsScale = {Value = 10}
	local NameTagsFont = {Value = "SourceSans"}
	local NameTagsTeammates = {Enabled = true}
	local NameTagsShowInventory = {Enabled = false}
	local NameTagsRangeLimit = {Value = 0}
	local fontitems = {"SourceSans"}
	local nametagstrs = {}
	local nametagsizes = {}
	local kititems = {
		jade = "jade_hammer",
		archer = "tactical_crossbow",
		angel = "",
		cowgirl = "lasso",
		dasher = "wood_dao",
		axolotl = "axolotl",
		yeti = "snowball",
		smoke = "smoke_block",
		trapper = "snap_trap",
		pyro = "flamethrower",
		davey = "cannon",
		regent = "void_axe", 
		baker = "apple",
		builder = "builder_hammer",
		farmer_cletus = "carrot_seeds",
		melody = "guitar",
		barbarian = "rageblade",
		gingerbread_man = "gumdrop_bounce_pad",
		spirit_catcher = "spirit",
		fisherman = "fishing_rod",
		oil_man = "oil_consumable",
		santa = "tnt",
		miner = "miner_pickaxe",
		sheep_herder = "crook",
		beast = "speed_potion",
		metal_detector = "metal_detector",
		cyber = "drone",
		vesta = "damage_banner",
		lumen = "light_sword",
		ember = "infernal_saber",
		queen_bee = "bee"
	}

	local nametagfuncs1 = {
		Normal = function(plr)
			if NameTagsTeammates.Enabled and (not plr.Targetable) and (not plr.Friend) then return end
			local thing = Instance.new("TextLabel")
			thing.BackgroundColor3 = Color3.new()
			thing.BorderSizePixel = 0
			thing.Visible = false
			thing.RichText = true
			thing.AnchorPoint = Vector2.new(0.5, 1)
			thing.Name = plr.Player.Name
			thing.Font = Enum.Font[NameTagsFont.Value]
			thing.TextSize = 14 * (NameTagsScale.Value / 10)
			thing.BackgroundTransparency = NameTagsBackground.Enabled and 0.5 or 1
			nametagstrs[plr.Player] = WhitelistFunctions:GetTag(plr.Player)..(NameTagsDisplayName.Enabled and plr.Player.DisplayName or plr.Player.Name)
			if NameTagsHealth.Enabled then
				local color = Color3.fromHSV(math.clamp(plr.Humanoid.Health / plr.Humanoid.MaxHealth, 0, 1) / 2.5, 0.89, 1)
				nametagstrs[plr.Player] = nametagstrs[plr.Player]..' <font color="rgb('..tostring(math.floor(color.R * 255))..','..tostring(math.floor(color.G * 255))..','..tostring(math.floor(color.B * 255))..')">'..math.round(plr.Humanoid.Health).."</font>"
			end
			if NameTagsDistance.Enabled then 
				nametagstrs[plr.Player] = '<font color="rgb(85, 255, 85)">[</font><font color="rgb(255, 255, 255)">%s</font><font color="rgb(85, 255, 85)">]</font> '..nametagstrs[plr.Player]
			end
			local nametagSize = textService:GetTextSize(removeTags(nametagstrs[plr.Player]), thing.TextSize, thing.Font, Vector2.new(100000, 100000))
			thing.Size = UDim2.new(0, nametagSize.X + 4, 0, nametagSize.Y)
			thing.Text = nametagstrs[plr.Player]
			thing.TextColor3 = getPlayerColor(plr.Player) or Color3.fromHSV(NameTagsColor.Hue, NameTagsColor.Sat, NameTagsColor.Value)
			thing.Parent = NameTagsFolder
			local hand = Instance.new("ImageLabel")
			hand.Size = UDim2.new(0, 30, 0, 30)
			hand.Name = "Hand"
			hand.BackgroundTransparency = 1
			hand.Position = UDim2.new(0, -30, 0, -30)
			hand.Image = ""
			hand.Parent = thing
			local helmet = hand:Clone()
			helmet.Name = "Helmet"
			helmet.Position = UDim2.new(0, 5, 0, -30)
			helmet.Parent = thing
			local chest = hand:Clone()
			chest.Name = "Chestplate"
			chest.Position = UDim2.new(0, 35, 0, -30)
			chest.Parent = thing
			local boots = hand:Clone()
			boots.Name = "Boots"
			boots.Position = UDim2.new(0, 65, 0, -30)
			boots.Parent = thing
			local kit = hand:Clone()
			kit.Name = "Kit"
			task.spawn(function()
				repeat task.wait() until plr.Player:GetAttribute("PlayingAsKit") ~= ""
				if kit then
					kit.Image = kititems[plr.Player:GetAttribute("PlayingAsKit")] and bedwars.getIcon({itemType = kititems[plr.Player:GetAttribute("PlayingAsKit")]}, NameTagsShowInventory.Enabled) or ""
				end
			end)
			kit.Position = UDim2.new(0, -30, 0, -65)
			kit.Parent = thing
			nametagsfolderdrawing[plr.Player] = {entity = plr, Main = thing}
		end,
		Drawing = function(plr)
			if NameTagsTeammates.Enabled and (not plr.Targetable) and (not plr.Friend) then return end
			local thing = {Main = {}, entity = plr}
			thing.Main.Text = Drawing.new("Text")
			thing.Main.Text.Size = 17 * (NameTagsScale.Value / 10)
			thing.Main.Text.Font = (math.clamp((table.find(fontitems, NameTagsFont.Value) or 1) - 1, 0, 3))
			thing.Main.Text.ZIndex = 2
			thing.Main.BG = Drawing.new("Square")
			thing.Main.BG.Filled = true
			thing.Main.BG.Transparency = 0.5
			thing.Main.BG.Visible = NameTagsBackground.Enabled
			thing.Main.BG.Color = Color3.new()
			thing.Main.BG.ZIndex = 1
			nametagstrs[plr.Player] = WhitelistFunctions:GetTag(plr.Player)..(NameTagsDisplayName.Enabled and plr.Player.DisplayName or plr.Player.Name)
			if NameTagsHealth.Enabled then
				local color = Color3.fromHSV(math.clamp(plr.Humanoid.Health / plr.Humanoid.MaxHealth, 0, 1) / 2.5, 0.89, 1)
				nametagstrs[plr.Player] = nametagstrs[plr.Player]..' '..math.round(plr.Humanoid.Health)
			end
			if NameTagsDistance.Enabled then 
				nametagstrs[plr.Player] = '[%s] '..nametagstrs[plr.Player]
			end
			thing.Main.Text.Text = nametagstrs[plr.Player]
			thing.Main.BG.Size = Vector2.new(thing.Main.Text.TextBounds.X + 4, thing.Main.Text.TextBounds.Y)
			thing.Main.Text.Color = getPlayerColor(plr.Player) or Color3.fromHSV(NameTagsColor.Hue, NameTagsColor.Sat, NameTagsColor.Value)
			nametagsfolderdrawing[plr.Player] = thing
		end
	}

	local nametagfuncs2 = {
		Normal = function(ent)
			local v = nametagsfolderdrawing[ent]
			nametagsfolderdrawing[ent] = nil
			if v then 
				v.Main:Destroy()
			end
		end,
		Drawing = function(ent)
			local v = nametagsfolderdrawing[ent]
			nametagsfolderdrawing[ent] = nil
			if v then 
				for i2,v2 in pairs(v.Main) do
					pcall(function() v2.Visible = false v2:Remove() end)
				end
			end
		end
	}

	local nametagupdatefuncs = {
		Normal = function(ent)
			local v = nametagsfolderdrawing[ent.Player]
			if v then 
				nametagstrs[ent.Player] = WhitelistFunctions:GetTag(ent.Player)..(NameTagsDisplayName.Enabled and ent.Player.DisplayName or ent.Player.Name)
				if NameTagsHealth.Enabled then
					local color = Color3.fromHSV(math.clamp(ent.Humanoid.Health / ent.Humanoid.MaxHealth, 0, 1) / 2.5, 0.89, 1)
					nametagstrs[ent.Player] = nametagstrs[ent.Player]..' <font color="rgb('..tostring(math.floor(color.R * 255))..','..tostring(math.floor(color.G * 255))..','..tostring(math.floor(color.B * 255))..')">'..math.round(ent.Humanoid.Health).."</font>"
				end
				if NameTagsDistance.Enabled then 
					nametagstrs[ent.Player] = '<font color="rgb(85, 255, 85)">[</font><font color="rgb(255, 255, 255)">%s</font><font color="rgb(85, 255, 85)">]</font> '..nametagstrs[ent.Player]
				end
				if NameTagsShowInventory.Enabled then 
					local inventory = bedwarsStore.inventories[ent.Player] or {armor = {}}
					if inventory.hand then
						v.Main.Hand.Image = bedwars.getIcon(inventory.hand, NameTagsShowInventory.Enabled)
						if v.Main.Hand.Image:find("rbxasset://") then
							v.Main.Hand.ResampleMode = Enum.ResamplerMode.Pixelated
						end
					else
						v.Main.Hand.Image = ""
					end
					if inventory.armor[4] then
						v.Main.Helmet.Image = bedwars.getIcon(inventory.armor[4], NameTagsShowInventory.Enabled)
						if v.Main.Helmet.Image:find("rbxasset://") then
							v.Main.Helmet.ResampleMode = Enum.ResamplerMode.Pixelated
						end
					else
						v.Main.Helmet.Image = ""
					end
					if inventory.armor[5] then
						v.Main.Chestplate.Image = bedwars.getIcon(inventory.armor[5], NameTagsShowInventory.Enabled)
						if v.Main.Chestplate.Image:find("rbxasset://") then
							v.Main.Chestplate.ResampleMode = Enum.ResamplerMode.Pixelated
						end
					else
						v.Main.Chestplate.Image = ""
					end
					if inventory.armor[6] then
						v.Main.Boots.Image = bedwars.getIcon(inventory.armor[6], NameTagsShowInventory.Enabled)
						if v.Main.Boots.Image:find("rbxasset://") then
							v.Main.Boots.ResampleMode = Enum.ResamplerMode.Pixelated
						end
					else
						v.Main.Boots.Image = ""
					end
				end
				local nametagSize = textService:GetTextSize(removeTags(nametagstrs[ent.Player]), v.Main.TextSize, v.Main.Font, Vector2.new(100000, 100000))
				v.Main.Size = UDim2.new(0, nametagSize.X + 4, 0, nametagSize.Y)
				v.Main.Text = nametagstrs[ent.Player]
			end
		end,
		Drawing = function(ent)
			local v = nametagsfolderdrawing[ent.Player]
			if v then 
				nametagstrs[ent.Player] = WhitelistFunctions:GetTag(ent.Player)..(NameTagsDisplayName.Enabled and ent.Player.DisplayName or ent.Player.Name)
				if NameTagsHealth.Enabled then
					nametagstrs[ent.Player] = nametagstrs[ent.Player]..' '..math.round(ent.Humanoid.Health)
				end
				if NameTagsDistance.Enabled then 
					nametagstrs[ent.Player] = '[%s] '..nametagstrs[ent.Player]
					v.Main.Text.Text = entityLibrary.isAlive and string.format(nametagstrs[ent.Player], math.floor((entityLibrary.character.HumanoidRootPart.Position - ent.RootPart.Position).Magnitude)) or nametagstrs[ent.Player]
				else
					v.Main.Text.Text = nametagstrs[ent.Player]
				end
				v.Main.BG.Size = Vector2.new(v.Main.Text.TextBounds.X + 4, v.Main.Text.TextBounds.Y)
				v.Main.Text.Color = getPlayerColor(ent.Player) or Color3.fromHSV(NameTagsColor.Hue, NameTagsColor.Sat, NameTagsColor.Value)
			end
		end
	}

	local nametagcolorfuncs = {
		Normal = function(hue, sat, value)
			local color = Color3.fromHSV(hue, sat, value)
			for i,v in pairs(nametagsfolderdrawing) do 
				v.Main.TextColor3 = getPlayerColor(v.entity.Player) or color
			end
		end,
		Drawing = function(hue, sat, value)
			local color = Color3.fromHSV(hue, sat, value)
			for i,v in pairs(nametagsfolderdrawing) do 
				v.Main.Text.Color = getPlayerColor(v.entity.Player) or color
			end
		end
	}

	local nametagloop = {
		Normal = function()
			for i,v in pairs(nametagsfolderdrawing) do 
				local headPos, headVis = worldtoscreenpoint((v.entity.RootPart:GetRenderCFrame() * CFrame.new(0, v.entity.Head.Size.Y + v.entity.RootPart.Size.Y, 0)).Position)
				if not headVis then 
					v.Main.Visible = false
					continue
				end
				local mag = entityLibrary.isAlive and math.floor((entityLibrary.character.HumanoidRootPart.Position - v.entity.RootPart.Position).Magnitude) or 0
				if NameTagsRangeLimit.Value ~= 0 and mag > NameTagsRangeLimit.Value then 
					v.Main.Visible = false
					continue
				end
				if NameTagsDistance.Enabled then
					local stringsize = tostring(mag):len()
					if nametagsizes[v.entity.Player] ~= stringsize then 
						local nametagSize = textService:GetTextSize(removeTags(string.format(nametagstrs[v.entity.Player], mag)), v.Main.TextSize, v.Main.Font, Vector2.new(100000, 100000))
						v.Main.Size = UDim2.new(0, nametagSize.X + 4, 0, nametagSize.Y)
					end
					nametagsizes[v.entity.Player] = stringsize
					v.Main.Text = string.format(nametagstrs[v.entity.Player], mag)
				end
				v.Main.Position = UDim2.new(0, headPos.X, 0, headPos.Y)
				v.Main.Visible = true
			end
		end,
		Drawing = function()
			for i,v in pairs(nametagsfolderdrawing) do 
				local headPos, headVis = worldtoscreenpoint((v.entity.RootPart:GetRenderCFrame() * CFrame.new(0, v.entity.Head.Size.Y + v.entity.RootPart.Size.Y, 0)).Position)
				if not headVis then 
					v.Main.Text.Visible = false
					v.Main.BG.Visible = false
					continue
				end
				local mag = entityLibrary.isAlive and math.floor((entityLibrary.character.HumanoidRootPart.Position - v.entity.RootPart.Position).Magnitude) or 0
				if NameTagsRangeLimit.Value ~= 0 and mag > NameTagsRangeLimit.Value then 
					v.Main.Text.Visible = false
					v.Main.BG.Visible = false
					continue
				end
				if NameTagsDistance.Enabled then
					local stringsize = tostring(mag):len()
					v.Main.Text.Text = string.format(nametagstrs[v.entity.Player], mag)
					if nametagsizes[v.entity.Player] ~= stringsize then 
						v.Main.BG.Size = Vector2.new(v.Main.Text.TextBounds.X + 4, v.Main.Text.TextBounds.Y)
					end
					nametagsizes[v.entity.Player] = stringsize
				end
				v.Main.BG.Position = Vector2.new(headPos.X - (v.Main.BG.Size.X / 2), (headPos.Y + v.Main.BG.Size.Y))
				v.Main.Text.Position = v.Main.BG.Position + Vector2.new(2, 0)
				v.Main.Text.Visible = true
				v.Main.BG.Visible = NameTagsBackground.Enabled
			end
		end
	}

	local methodused

	local NameTags = {Enabled = false}
	NameTags = GuiLibrary.ObjectsThatCanBeSaved.RenderWindow.Api.CreateOptionsButton({
		Name = "NameTags", 
		Function = function(callback) 
			if callback then
				methodused = NameTagsDrawing.Enabled and "Drawing" or "Normal"
				if nametagfuncs2[methodused] then
					table.insert(NameTags.Connections, entityLibrary.entityRemovedEvent:Connect(nametagfuncs2[methodused]))
				end
				if nametagfuncs1[methodused] then
					local addfunc = nametagfuncs1[methodused]
					for i,v in pairs(entityLibrary.entityList) do 
						if nametagsfolderdrawing[v.Player] then nametagfuncs2[methodused](v.Player) end
						addfunc(v)
					end
					table.insert(NameTags.Connections, entityLibrary.entityAddedEvent:Connect(function(ent)
						if nametagsfolderdrawing[ent.Player] then nametagfuncs2[methodused](ent.Player) end
						addfunc(ent)
					end))
				end
				if nametagupdatefuncs[methodused] then
					table.insert(NameTags.Connections, entityLibrary.entityUpdatedEvent:Connect(nametagupdatefuncs[methodused]))
					for i,v in pairs(entityLibrary.entityList) do 
						nametagupdatefuncs[methodused](v)
					end
				end
				if nametagcolorfuncs[methodused] then 
					table.insert(NameTags.Connections, GuiLibrary.ObjectsThatCanBeSaved.FriendsListTextCircleList.Api.FriendColorRefresh.Event:Connect(function()
						nametagcolorfuncs[methodused](NameTagsColor.Hue, NameTagsColor.Sat, NameTagsColor.Value)
					end))
				end
				if nametagloop[methodused] then 
					RunLoops:BindToRenderStep("NameTags", nametagloop[methodused])
				end
			else
				RunLoops:UnbindFromRenderStep("NameTags")
				if nametagfuncs2[methodused] then
					for i,v in pairs(nametagsfolderdrawing) do 
						nametagfuncs2[methodused](i)
					end
				end
			end
		end,
		HoverText = "Renders nametags on entities through walls."
	})
	for i,v in pairs(Enum.Font:GetEnumItems()) do 
		if v.Name ~= "SourceSans" then 
			table.insert(fontitems, v.Name)
		end
	end
	NameTagsFont = NameTags.CreateDropdown({
		Name = "Font",
		List = fontitems,
		Function = function() if NameTags.Enabled then NameTags.ToggleButton(false) NameTags.ToggleButton(false) end end,
	})
	NameTagsColor = NameTags.CreateColorSlider({
		Name = "Player Color", 
		Function = function(hue, sat, val) 
			if NameTags.Enabled and nametagcolorfuncs[methodused] then 
				nametagcolorfuncs[methodused](hue, sat, val)
			end
		end
	})
	NameTagsScale = NameTags.CreateSlider({
		Name = "Scale",
		Function = function() if NameTags.Enabled then NameTags.ToggleButton(false) NameTags.ToggleButton(false) end end,
		Default = 10,
		Min = 1,
		Max = 50
	})
	NameTagsRangeLimit = NameTags.CreateSlider({
		Name = "Range",
		Function = function() end,
		Min = 0,
		Max = 1000,
		Default = 0
	})
	NameTagsBackground = NameTags.CreateToggle({
		Name = "Background", 
		Function = function() if NameTags.Enabled then NameTags.ToggleButton(false) NameTags.ToggleButton(false) end end,
		Default = true
	})
	NameTagsDisplayName = NameTags.CreateToggle({
		Name = "Use Display Name", 
		Function = function() if NameTags.Enabled then NameTags.ToggleButton(false) NameTags.ToggleButton(false) end end,
		Default = true
	})
	NameTagsHealth = NameTags.CreateToggle({
		Name = "Health", 
		Function = function() if NameTags.Enabled then NameTags.ToggleButton(false) NameTags.ToggleButton(false) end end
	})
	NameTagsDistance = NameTags.CreateToggle({
		Name = "Distance", 
		Function = function() if NameTags.Enabled then NameTags.ToggleButton(false) NameTags.ToggleButton(false) end end
	})
	NameTagsShowInventory = NameTags.CreateToggle({
		Name = "Equipment",
		Function = function() if NameTags.Enabled then NameTags.ToggleButton(false) NameTags.ToggleButton(false) end end,
		Default = true
	})
	NameTagsTeammates = NameTags.CreateToggle({
		Name = "Teammates", 
		Function = function() if NameTags.Enabled then NameTags.ToggleButton(false) NameTags.ToggleButton(false) end end,
		Default = true
	})
	NameTagsDrawing = NameTags.CreateToggle({
		Name = "Drawing",
		Function = function() if NameTags.Enabled then NameTags.ToggleButton(false) NameTags.ToggleButton(false) end end,
	})
end)

runFunction(function()
	local nobobdepth = {Value = 8}
	local nobobhorizontal = {Value = 8}
	local nobobvertical = {Value = -2}
	local rotationx = {Value = 0}
	local rotationy = {Value = 0}
	local rotationz = {Value = 0}
	local oldc1
	local oldfunc
	local nobob = GuiLibrary.ObjectsThatCanBeSaved.RenderWindow.Api.CreateOptionsButton({
		Name = "NoBob",
		Function = function(callback) 
			local viewmodel = gameCamera:FindFirstChild("Viewmodel")
			if viewmodel then
				if callback then
					oldfunc = bedwars.ViewmodelController.playAnimation
					bedwars.ViewmodelController.playAnimation = function(self, animid, details)
						if animid == bedwars.AnimationType.FP_WALK then
							return
						end
						return oldfunc(self, animid, details)
					end
					bedwars.ViewmodelController:setHeldItem(lplr.Character and lplr.Character:FindFirstChild("HandInvItem") and lplr.Character.HandInvItem.Value and lplr.Character.HandInvItem.Value:Clone())
					lplr.PlayerScripts.TS.controllers.global.viewmodel["viewmodel-controller"]:SetAttribute("ConstantManager_DEPTH_OFFSET", -(nobobdepth.Value / 10))
					lplr.PlayerScripts.TS.controllers.global.viewmodel["viewmodel-controller"]:SetAttribute("ConstantManager_HORIZONTAL_OFFSET", (nobobhorizontal.Value / 10))
					lplr.PlayerScripts.TS.controllers.global.viewmodel["viewmodel-controller"]:SetAttribute("ConstantManager_VERTICAL_OFFSET", (nobobvertical.Value / 10))
					oldc1 = viewmodel.RightHand.RightWrist.C1
					viewmodel.RightHand.RightWrist.C1 = oldc1 * CFrame.Angles(math.rad(rotationx.Value), math.rad(rotationy.Value), math.rad(rotationz.Value))
				else
					bedwars.ViewmodelController.playAnimation = oldfunc
					lplr.PlayerScripts.TS.controllers.global.viewmodel["viewmodel-controller"]:SetAttribute("ConstantManager_DEPTH_OFFSET", 0)
					lplr.PlayerScripts.TS.controllers.global.viewmodel["viewmodel-controller"]:SetAttribute("ConstantManager_HORIZONTAL_OFFSET", 0)
					lplr.PlayerScripts.TS.controllers.global.viewmodel["viewmodel-controller"]:SetAttribute("ConstantManager_VERTICAL_OFFSET", 0)
					viewmodel.RightHand.RightWrist.C1 = oldc1
				end
			end
		end,
		HoverText = "Removes the ugly bobbing when you move and makes sword farther"
	})
	nobobdepth = nobob.CreateSlider({
		Name = "Depth",
		Min = 0,
		Max = 24,
		Default = 8,
		Function = function(val)
			if nobob.Enabled then
				lplr.PlayerScripts.TS.controllers.global.viewmodel["viewmodel-controller"]:SetAttribute("ConstantManager_DEPTH_OFFSET", -(val / 10))
			end
		end
	})
	nobobhorizontal = nobob.CreateSlider({
		Name = "Horizontal",
		Min = 0,
		Max = 24,
		Default = 8,
		Function = function(val)
			if nobob.Enabled then
				lplr.PlayerScripts.TS.controllers.global.viewmodel["viewmodel-controller"]:SetAttribute("ConstantManager_HORIZONTAL_OFFSET", (val / 10))
			end
		end
	})
	nobobvertical= nobob.CreateSlider({
		Name = "Vertical",
		Min = 0,
		Max = 24,
		Default = -2,
		Function = function(val)
			if nobob.Enabled then
				lplr.PlayerScripts.TS.controllers.global.viewmodel["viewmodel-controller"]:SetAttribute("ConstantManager_VERTICAL_OFFSET", (val / 10))
			end
		end
	})
	rotationx = nobob.CreateSlider({
		Name = "RotX",
		Min = 0,
		Max = 360,
		Function = function(val)
			if nobob.Enabled then
				gameCamera.Viewmodel.RightHand.RightWrist.C1 = oldc1 * CFrame.Angles(math.rad(rotationx.Value), math.rad(rotationy.Value), math.rad(rotationz.Value))
			end
		end
	})
	rotationy = nobob.CreateSlider({
		Name = "RotY",
		Min = 0,
		Max = 360,
		Function = function(val)
			if nobob.Enabled then
				gameCamera.Viewmodel.RightHand.RightWrist.C1 = oldc1 * CFrame.Angles(math.rad(rotationx.Value), math.rad(rotationy.Value), math.rad(rotationz.Value))
			end
		end
	})
	rotationz = nobob.CreateSlider({
		Name = "RotZ",
		Min = 0,
		Max = 360,
		Function = function(val)
			if nobob.Enabled then
				gameCamera.Viewmodel.RightHand.RightWrist.C1 = oldc1 * CFrame.Angles(math.rad(rotationx.Value), math.rad(rotationy.Value), math.rad(rotationz.Value))
			end
		end
	})
end)

runFunction(function()
	local SongBeats = {Enabled = false}
	local SongBeatsList = {ObjectList = {}}
	local SongBeatsIntensity = {Value = 5}
	local SongTween
	local SongAudio

	local function PlaySong(arg)
		local args = arg:split(":")
		local song = isfile(args[1]) and getcustomasset(args[1]) or tonumber(args[1]) and "rbxassetid://"..args[1]
		if not song then 
			warningNotification("SongBeats", "missing music file "..args[1], 5)
			SongBeats.ToggleButton(false)
			return
		end
		local bpm = 1 / (args[2] / 60)
		SongAudio = Instance.new("Sound")
		SongAudio.SoundId = song
		SongAudio.Parent = workspace
		SongAudio:Play()
		repeat
			repeat task.wait() until SongAudio.IsLoaded or (not SongBeats.Enabled) 
			if (not SongBeats.Enabled) then break end
			local newfov = math.min(bedwars.FovController:getFOV() * (bedwars.SprintController.sprinting and 1.1 or 1), 120)
			gameCamera.FieldOfView = newfov - SongBeatsIntensity.Value
			if SongTween then SongTween:Cancel() end
			SongTween = game:GetService("TweenService"):Create(gameCamera, TweenInfo.new(0.2), {FieldOfView = newfov})
			SongTween:Play()
			task.wait(bpm)
		until (not SongBeats.Enabled) or SongAudio.IsPaused
	end

	SongBeats = GuiLibrary.ObjectsThatCanBeSaved.RenderWindow.Api.CreateOptionsButton({
		Name = "SongBeats",
		Function = function(callback)
			if callback then 
				task.spawn(function()
					if #SongBeatsList.ObjectList <= 0 then 
						warningNotification("SongBeats", "no songs", 5)
						SongBeats.ToggleButton(false)
						return
					end
					local lastChosen
					repeat
						local newSong
						repeat newSong = SongBeatsList.ObjectList[Random.new():NextInteger(1, #SongBeatsList.ObjectList)] task.wait() until newSong ~= lastChosen or #SongBeatsList.ObjectList <= 1
						lastChosen = newSong
						PlaySong(newSong)
						if not SongBeats.Enabled then break end
						task.wait(2)
					until (not SongBeats.Enabled)
				end)
			else
				if SongAudio then SongAudio:Destroy() end
				if SongTween then SongTween:Cancel() end
				gameCamera.FieldOfView = bedwars.FovController:getFOV() * (bedwars.SprintController.sprinting and 1.1 or 1)
			end
		end
	})
	SongBeatsList = SongBeats.CreateTextList({
		Name = "SongList",
		TempText = "songpath:bpm"
	})
	SongBeatsIntensity = SongBeats.CreateSlider({
		Name = "Intensity",
		Function = function() end,
		Min = 1,
		Max = 10,
		Default = 5
	})
end)

runFunction(function()
	local performed = false
	GuiLibrary.ObjectsThatCanBeSaved.RenderWindow.Api.CreateOptionsButton({
		Name = "UICleanup",
		Function = function(callback)
			if callback and not performed then 
				performed = true
				task.spawn(function()
					local hotbar = require(lplr.PlayerScripts.TS.controllers.global.hotbar.ui["hotbar-app"]).HotbarApp
					local hotbaropeninv = require(lplr.PlayerScripts.TS.controllers.global.hotbar.ui["hotbar-open-inventory"]).HotbarOpenInventory
					local topbarbutton = require(replicatedStorageService["rbxts_include"]["node_modules"]["@easy-games"]["game-core"].out).TopBarButton
					local gametheme = require(replicatedStorageService["rbxts_include"]["node_modules"]["@easy-games"]["game-core"].out.shared.ui["game-theme"]).GameTheme
					bedwars.AppController:closeApp("TopBarApp")
					local oldrender = topbarbutton.render
					topbarbutton.render = function(self) 
						local res = oldrender(self)
						if not self.props.Text then
							return bedwars.Roact.createElement("TextButton", {Visible = false}, {})
						end
						return res
					end
					hotbaropeninv.render = function(self) 
						return bedwars.Roact.createElement("TextButton", {Visible = false}, {})
					end
					--[[debug.setconstant(hotbar.render, 52, 0.9975)
					debug.setconstant(hotbar.render, 73, 100)
					debug.setconstant(hotbar.render, 89, 1)
					debug.setconstant(hotbar.render, 90, 0.04)
					debug.setconstant(hotbar.render, 91, -0.03)
					debug.setconstant(hotbar.render, 109, 1.35)
					debug.setconstant(hotbar.render, 110, 0)
					debug.setconstant(debug.getupvalue(hotbar.render, 11).render, 30, 1)
					debug.setconstant(debug.getupvalue(hotbar.render, 11).render, 31, 0.175)
					debug.setconstant(debug.getupvalue(hotbar.render, 11).render, 33, -0.101)
					debug.setconstant(debug.getupvalue(hotbar.render, 18).render, 71, 0)
					debug.setconstant(debug.getupvalue(hotbar.render, 18).tweenPosition, 16, 0)]]
					gametheme.topBarBGTransparency = 0.5
					bedwars.TopBarController:mountHud()
					game:GetService("StarterGui"):SetCoreGuiEnabled(Enum.CoreGuiType.PlayerList, true)
					bedwars.AbilityUIController.abilityButtonsScreenGui.Visible = false
					bedwars.MatchEndScreenController.waitUntilDisplay = function() return false end
					task.spawn(function()
						repeat
							task.wait()
							local gui = lplr.PlayerGui:FindFirstChild("StatusEffectHudScreen")
							if gui then gui.Enabled = false break end
						until false
					end)
					task.spawn(function()
						repeat task.wait() until bedwarsStore.matchState ~= 0
						if bedwars.ClientStoreHandler:getState().Game.customMatch == nil then 
							debug.setconstant(bedwars.QueueCard.render, 9, 0.1)
						end
					end)
					local slot = bedwars.ClientStoreHandler:getState().Inventory.observedInventory.hotbarSlot
					bedwars.ClientStoreHandler:dispatch({
						type = "InventorySelectHotbarSlot",
						slot = slot + 1 % 8
					})
					bedwars.ClientStoreHandler:dispatch({
						type = "InventorySelectHotbarSlot",
						slot = slot
					})
				end)
			end
		end
	})
end)

runFunction(function()
	local AntiAFK = {Enabled = false}
	AntiAFK = GuiLibrary.ObjectsThatCanBeSaved.UtilityWindow.Api.CreateOptionsButton({
		Name = "AntiAFK",
		Function = function(callback)
			if callback then 
				task.spawn(function()
					repeat 
						task.wait(5) 
						bedwars.ClientHandler:Get("AfkInfo"):SendToServer({
							afk = false
						})
					until (not AntiAFK.Enabled)
				end)
			end
		end
	})
end)

runFunction(function()
	local AutoBalloonPart
	local AutoBalloonConnection
	local AutoBalloonDelay = {Value = 10}
	local AutoBalloonLegit = {Enabled = false}
	local AutoBalloonypos = 0
	local balloondebounce = false
	local AutoBalloon = {Enabled = false}
	AutoBalloon = GuiLibrary.ObjectsThatCanBeSaved.UtilityWindow.Api.CreateOptionsButton({
		Name = "AutoBalloon", 
		Function = function(callback)
			if callback then
				task.spawn(function()
					repeat task.wait() until bedwarsStore.matchState ~= 0 or  not vapeInjected
					if vapeInjected and AutoBalloonypos == 0 and AutoBalloon.Enabled then
						local lowestypos = 99999
						for i,v in pairs(bedwarsStore.blocks) do 
							local newray = workspace:Raycast(v.Position + Vector3.new(0, 800, 0), Vector3.new(0, -1000, 0), bedwarsStore.blockRaycast)
							if i % 200 == 0 then 
								task.wait(0.06)
							end
							if newray and newray.Position.Y <= lowestypos then
								lowestypos = newray.Position.Y
							end
						end
						AutoBalloonypos = lowestypos - 8
					end
				end)
				task.spawn(function()
					repeat task.wait() until AutoBalloonypos ~= 0
					if AutoBalloon.Enabled then
						AutoBalloonPart = Instance.new("Part")
						AutoBalloonPart.CanCollide = false
						AutoBalloonPart.Size = Vector3.new(10000, 1, 10000)
						AutoBalloonPart.Anchored = true
						AutoBalloonPart.Transparency = 1
						AutoBalloonPart.Material = Enum.Material.Neon
						AutoBalloonPart.Color = Color3.fromRGB(135, 29, 139)
						AutoBalloonPart.Position = Vector3.new(0, AutoBalloonypos - 50, 0)
						AutoBalloonConnection = AutoBalloonPart.Touched:Connect(function(touchedpart)
							if entityLibrary.isAlive and touchedpart:IsDescendantOf(lplr.Character) and balloondebounce == false then
								autobankballoon = true
								balloondebounce = true
								local oldtool = bedwarsStore.localHand.tool
								for i = 1, 3 do
									if getItem("balloon") and (AutoBalloonLegit.Enabled and getHotbarSlot("balloon") or AutoBalloonLegit.Enabled == false) and (lplr.Character:GetAttribute("InflatedBalloons") and lplr.Character:GetAttribute("InflatedBalloons") < 3 or lplr.Character:GetAttribute("InflatedBalloons") == nil) then
										if AutoBalloonLegit.Enabled then
											if getHotbarSlot("balloon") then
												bedwars.ClientStoreHandler:dispatch({
													type = "InventorySelectHotbarSlot", 
													slot = getHotbarSlot("balloon")
												})
												task.wait(AutoBalloonDelay.Value / 100)
												bedwars.BalloonController:inflateBalloon()
											end
										else
											task.wait(AutoBalloonDelay.Value / 100)
											bedwars.BalloonController:inflateBalloon()
										end
									end
								end
								if AutoBalloonLegit.Enabled and oldtool and getHotbarSlot(oldtool.Name) then
									task.wait(0.2)
									bedwars.ClientStoreHandler:dispatch({
										type = "InventorySelectHotbarSlot", 
										slot = (getHotbarSlot(oldtool.Name) or 0)
									})
								end
								balloondebounce = false
								autobankballoon = false
							end
						end)
						AutoBalloonPart.Parent = workspace
					end
				end)
			else
				if AutoBalloonConnection then AutoBalloonConnection:Disconnect() end
				if AutoBalloonPart then
					AutoBalloonPart:Remove() 
				end
			end
		end, 
		HoverText = "Automatically Inflates Balloons"
	})
	AutoBalloonDelay = AutoBalloon.CreateSlider({
		Name = "Delay",
		Min = 1,
		Max = 50,
		Default = 20,
		Function = function() end,
		HoverText = "Delay to inflate balloons."
	})
	AutoBalloonLegit = AutoBalloon.CreateToggle({
		Name = "Legit Mode",
		Function = function() end,
		HoverText = "Switches to balloons in hotbar and inflates them."
	})
end)

local autobankapple = false
runFunction(function()
	local AutoBuy = {Enabled = false}
	local AutoBuyArmor = {Enabled = false}
	local AutoBuySword = {Enabled = false}
	local AutoBuyUpgrades = {Enabled = false}
	local AutoBuyGen = {Enabled = false}
	local AutoBuyProt = {Enabled = false}
	local AutoBuySharp = {Enabled = false}
	local AutoBuyDestruction = {Enabled = false}
	local AutoBuyDiamond = {Enabled = false}
	local AutoBuyAlarm = {Enabled = false}
	local AutoBuyGui = {Enabled = false}
	local AutoBuyTierSkip = {Enabled = true}
	local AutoBuyRange = {Value = 20}
	local AutoBuyCustom = {ObjectList = {}, RefreshList = function() end}
	local AutoBankUIToggle = {Enabled = false}
	local AutoBankDeath = {Enabled = false}
	local AutoBankStay = {Enabled = false}
	local buyingthing = false
	local shoothook
	local bedwarsshopnpcs = {}
	local id
	local armors = {
		[1] = "leather_chestplate",
		[2] = "iron_chestplate",
		[3] = "diamond_chestplate",
		[4] = "emerald_chestplate"
	}

	local swords = {
		[1] = "wood_sword",
		[2] = "stone_sword",
		[3] = "iron_sword",
		[4] = "diamond_sword",
		[5] = "emerald_sword"
	}

	local axes = {
		[1] = "wood_axe",
		[2] = "stone_axe",
		[3] = "iron_axe",
		[4] = "diamond_axe"
	}

	local pickaxes = {
		[1] = "wood_pickaxe",
		[2] = "stone_pickaxe",
		[3] = "iron_pickaxe",
		[4] = "diamond_pickaxe"
	}

	task.spawn(function()
		repeat task.wait() until bedwarsStore.matchState ~= 0 or not vapeInjected
		for i,v in pairs(collectionService:GetTagged("BedwarsItemShop")) do
			table.insert(bedwarsshopnpcs, {Position = v.Position, TeamUpgradeNPC = true, Id = v.Name})
		end
		for i,v in pairs(collectionService:GetTagged("BedwarsTeamUpgrader")) do
			table.insert(bedwarsshopnpcs, {Position = v.Position, TeamUpgradeNPC = false, Id = v.Name})
		end
	end)

	local function nearNPC(range)
		local npc, npccheck, enchant, newid = nil, false, false, nil
		if entityLibrary.isAlive then
			local enchanttab = {}
			for i,v in pairs(collectionService:GetTagged("broken-enchant-table")) do 
				table.insert(enchanttab, v)
			end
			for i,v in pairs(collectionService:GetTagged("enchant-table")) do 
				table.insert(enchanttab, v)
			end
			for i,v in pairs(enchanttab) do 
				if ((entityLibrary.LocalPosition or entityLibrary.character.HumanoidRootPart.Position) - v.Position).magnitude <= 6 then
					if ((not v:GetAttribute("Team")) or v:GetAttribute("Team") == lplr:GetAttribute("Team")) then
						npc, npccheck, enchant = true, true, true
					end
				end
			end
			for i, v in pairs(bedwarsshopnpcs) do
				if ((entityLibrary.LocalPosition or entityLibrary.character.HumanoidRootPart.Position) - v.Position).magnitude <= (range or 20) then
					npc, npccheck, enchant = true, (v.TeamUpgradeNPC or npccheck), false
					newid = v.TeamUpgradeNPC and v.Id or newid
				end
			end
			local suc, res = pcall(function() return lplr.leaderstats.Bed.Value == "✅"  end)
			if AutoBankDeath.Enabled and (workspace:GetServerTimeNow() - lplr.Character:GetAttribute("LastDamageTakenTime")) < 2 and suc and res then 
				return nil, false, false
			end
			if AutoBankStay.Enabled then 
				return nil, false, false
			end
		end
		return npc, not npccheck, enchant, newid
	end

	local function buyItem(itemtab, waitdelay)
		if not id then return end
		local res
		bedwars.ClientHandler:Get("BedwarsPurchaseItem"):CallServerAsync({
			shopItem = itemtab,
			shopId = id
		}):andThen(function(p11)
			if p11 then
				bedwars.SoundManager:playSound(bedwars.SoundList.BEDWARS_PURCHASE_ITEM)
				bedwars.ClientStoreHandler:dispatch({
					type = "BedwarsAddItemPurchased", 
					itemType = itemtab.itemType
				})
			end
			res = p11
		end)
		if waitdelay then 
			repeat task.wait() until res ~= nil
		end
	end

	local function buyUpgrade(upgradetype, inv, upgrades)
		if not AutoBuyUpgrades.Enabled then return end
		local teamupgrade = bedwars.Shop.getUpgrade(bedwars.Shop.TeamUpgrades, upgradetype)
		local teamtier = teamupgrade.tiers[upgrades[upgradetype] and upgrades[upgradetype] + 2 or 1]
		if teamtier then 
			local teamcurrency = getItem(teamtier.currency, inv.items)
			if teamcurrency and teamcurrency.amount >= teamtier.price then 
				bedwars.ClientHandler:Get("BedwarsPurchaseTeamUpgrade"):CallServerAsync({
					upgradeId = upgradetype, 
					tier = upgrades[upgradetype] and upgrades[upgradetype] + 1 or 0
				}):andThen(function(suc)
					if suc then
						bedwars.SoundManager:playSound(bedwars.SoundList.BEDWARS_PURCHASE_ITEM)
					end
				end)
			end
		end
	end

	local function getAxeNear(inv)
		for i5, v5 in pairs(inv or bedwarsStore.localInventory.inventory.items) do
			if v5.itemType:find("axe") and v5.itemType:find("pickaxe") == nil then
				return v5.itemType
			end
		end
		return nil
	end

	local function getPickaxeNear(inv)
		for i5, v5 in pairs(inv or bedwarsStore.localInventory.inventory.items) do
			if v5.itemType:find("pickaxe") then
				return v5.itemType
			end
		end
		return nil
	end

	local function getShopItem(itemType)
		if itemType == "axe" then 
			itemType = getAxeNear() or "wood_axe"
			itemType = axes[table.find(axes, itemType) + 1] or itemType
		end
		if itemType == "pickaxe" then 
			itemType = getPickaxeNear() or "wood_pickaxe"
			itemType = pickaxes[table.find(pickaxes, itemType) + 1] or itemType
		end
		for i,v in pairs(bedwars.ShopItems) do 
			if v.itemType == itemType then return v end
		end
		return nil
	end

	local buyfunctions = {
		Armor = function(inv, upgrades, shoptype) 
			if AutoBuyArmor.Enabled == false or shoptype ~= "item" then return end
			local currentarmor = (inv.armor[2] ~= "empty" and inv.armor[2].itemType:find("chestplate") ~= nil) and inv.armor[2] or nil
			local armorindex = (currentarmor and table.find(armors, currentarmor.itemType) or 0) + 1
			if armors[armorindex] == nil then return end
			local highestbuyable = nil
			for i = armorindex, #armors, 1 do 
				local shopitem = getShopItem(armors[i])
				if shopitem and (AutoBuyTierSkip.Enabled or i == armorindex) then 
					local currency = getItem(shopitem.currency, inv.items)
					if currency and currency.amount >= shopitem.price then 
						highestbuyable = shopitem
						bedwars.ClientStoreHandler:dispatch({
							type = "BedwarsAddItemPurchased", 
							itemType = shopitem.itemType
						})
					end
				end
			end
			if highestbuyable and (highestbuyable.ignoredByKit == nil or table.find(highestbuyable.ignoredByKit, bedwarsStore.equippedKit) == nil) then 
				buyItem(highestbuyable)
			end
		end,
		Sword = function(inv, upgrades, shoptype)
			if AutoBuySword.Enabled == false or shoptype ~= "item" then return end
			local currentsword = getItemNear("sword", inv.items)
			local swordindex = (currentsword and table.find(swords, currentsword.itemType) or 0) + 1
			if currentsword ~= nil and table.find(swords, currentsword.itemType) == nil then return end
			local highestbuyable = nil
			for i = swordindex, #swords, 1 do 
				local shopitem = getShopItem(swords[i])
				if shopitem then 
					local currency = getItem(shopitem.currency, inv.items)
					if currency and currency.amount >= shopitem.price and (shopitem.category ~= "Armory" or upgrades.armory) then 
						highestbuyable = shopitem
						bedwars.ClientStoreHandler:dispatch({
							type = "BedwarsAddItemPurchased", 
							itemType = shopitem.itemType
						})
					end
				end
			end
			if highestbuyable and (highestbuyable.ignoredByKit == nil or table.find(highestbuyable.ignoredByKit, bedwarsStore.equippedKit) == nil) then 
				buyItem(highestbuyable)
			end
		end,
		Protection = function(inv, upgrades)
			if not AutoBuyProt.Enabled then return end
			buyUpgrade("armor", inv, upgrades)
		end,
		Sharpness = function(inv, upgrades)
			if not AutoBuySharp.Enabled then return end
			buyUpgrade("damage", inv, upgrades)
		end,
		Generator = function(inv, upgrades)
			if not AutoBuyGen.Enabled then return end
			buyUpgrade("generator", inv, upgrades)
		end,
		Destruction = function(inv, upgrades)
			if not AutoBuyDestruction.Enabled then return end
			buyUpgrade("destruction", inv, upgrades)
		end,
		Diamond = function(inv, upgrades)
			if not AutoBuyDiamond.Enabled then return end
			buyUpgrade("diamond_generator", inv, upgrades)
		end,
		Alarm = function(inv, upgrades)
			if not AutoBuyAlarm.Enabled then return end
			buyUpgrade("alarm", inv, upgrades)
		end
	}

	AutoBuy = GuiLibrary.ObjectsThatCanBeSaved.UtilityWindow.Api.CreateOptionsButton({
		Name = "AutoBuy", 
		Function = function(callback)
			if callback then 
				buyingthing = false 
				task.spawn(function()
					repeat
						task.wait()
						local found, npctype, enchant, newid = nearNPC(AutoBuyRange.Value)
						id = newid
						if found then
							local inv = bedwarsStore.localInventory.inventory
							local currentupgrades = bedwars.ClientStoreHandler:getState().Bedwars.teamUpgrades
							if bedwarsStore.equippedKit == "dasher" then 
								swords = {
									[1] = "wood_dao",
									[2] = "stone_dao",
									[3] = "iron_dao",
									[4] = "diamond_dao",
									[5] = "emerald_dao"
								}
							elseif bedwarsStore.equippedKit == "ice_queen" then 
								swords[5] = "ice_sword"
							elseif bedwarsStore.equippedKit == "ember" then 
								swords[5] = "infernal_saber"
							elseif bedwarsStore.equippedKit == "lumen" then 
								swords[5] = "light_sword"
							end
							if (AutoBuyGui.Enabled == false or (bedwars.AppController:isAppOpen("BedwarsItemShopApp") or bedwars.AppController:isAppOpen("BedwarsTeamUpgradeApp"))) and (not enchant) then
								for i,v in pairs(AutoBuyCustom.ObjectList) do 
									local autobuyitem = v:split("/")
									if #autobuyitem >= 3 and autobuyitem[4] ~= "true" then 
										local shopitem = getShopItem(autobuyitem[1])
										if shopitem then 
											local currency = getItem(shopitem.currency, inv.items)
											local actualitem = getItem(shopitem.itemType == "wool_white" and getWool() or shopitem.itemType, inv.items)
											if currency and currency.amount >= shopitem.price and (actualitem == nil or actualitem.amount < tonumber(autobuyitem[2])) then 
												buyItem(shopitem, tonumber(autobuyitem[2]) > 1)
											end
										end
									end
								end
								for i,v in pairs(buyfunctions) do v(inv, currentupgrades, npctype and "upgrade" or "item") end
								for i,v in pairs(AutoBuyCustom.ObjectList) do 
									local autobuyitem = v:split("/")
									if #autobuyitem >= 3 and autobuyitem[4] == "true" then 
										local shopitem = getShopItem(autobuyitem[1])
										if shopitem then 
											local currency = getItem(shopitem.currency, inv.items)
											local actualitem = getItem(shopitem.itemType == "wool_white" and getWool() or shopitem.itemType, inv.items)
											if currency and currency.amount >= shopitem.price and (actualitem == nil or actualitem.amount < tonumber(autobuyitem[2])) then 
												buyItem(shopitem, tonumber(autobuyitem[2]) > 1)
											end
										end
									end
								end
							end
						end
					until (not AutoBuy.Enabled)
				end)
			end
		end,
		HoverText = "Automatically Buys Swords, Armor, and Team Upgrades\nwhen you walk near the NPC"
	})
	AutoBuyRange = AutoBuy.CreateSlider({
		Name = "Range",
		Function = function() end,
		Min = 1,
		Max = 20,
		Default = 20
	})
	AutoBuyArmor = AutoBuy.CreateToggle({
		Name = "Buy Armor",
		Function = function() end, 
		Default = true
	})
	AutoBuySword = AutoBuy.CreateToggle({
		Name = "Buy Sword",
		Function = function() end, 
		Default = true
	})
	AutoBuyUpgrades = AutoBuy.CreateToggle({
		Name = "Buy Team Upgrades",
		Function = function(callback) 
			if AutoBuyUpgrades.Object then AutoBuyUpgrades.Object.ToggleArrow.Visible = callback end
			if AutoBuyGen.Object then AutoBuyGen.Object.Visible = callback end
			if AutoBuyProt.Object then AutoBuyProt.Object.Visible = callback end
			if AutoBuySharp.Object then AutoBuySharp.Object.Visible = callback end
			if AutoBuyDestruction.Object then AutoBuyDestruction.Object.Visible = callback end
			if AutoBuyDiamond.Object then AutoBuyDiamond.Object.Visible = callback end
			if AutoBuyAlarm.Object then AutoBuyAlarm.Object.Visible = callback end
		end, 
		Default = true
	})
	AutoBuyGen = AutoBuy.CreateToggle({
		Name = "Buy Team Generator",
		Function = function() end, 
	})
	AutoBuyProt = AutoBuy.CreateToggle({
		Name = "Buy Protection",
		Function = function() end, 
		Default = true
	})
	AutoBuySharp = AutoBuy.CreateToggle({
		Name = "Buy Sharpness",
		Function = function() end, 
		Default = true
	})
	AutoBuyDestruction = AutoBuy.CreateToggle({
		Name = "Buy Destruction",
		Function = function() end, 
	})
	AutoBuyDiamond = AutoBuy.CreateToggle({
		Name = "Buy Diamond Generator",
		Function = function() end, 
	})
	AutoBuyAlarm = AutoBuy.CreateToggle({
		Name = "Buy Alarm",
		Function = function() end, 
	})
	AutoBuyGui = AutoBuy.CreateToggle({
		Name = "Shop GUI Check",
		Function = function() end, 	
	})
	AutoBuyTierSkip = AutoBuy.CreateToggle({
		Name = "Tier Skip",
		Function = function() end, 
		Default = true
	})
	AutoBuyGen.Object.BackgroundTransparency = 0
	AutoBuyGen.Object.BorderSizePixel = 0
	AutoBuyGen.Object.BackgroundColor3 = Color3.fromRGB(20, 20, 20)
	AutoBuyGen.Object.Visible = AutoBuyUpgrades.Enabled
	AutoBuyProt.Object.BackgroundTransparency = 0
	AutoBuyProt.Object.BorderSizePixel = 0
	AutoBuyProt.Object.BackgroundColor3 = Color3.fromRGB(20, 20, 20)
	AutoBuyProt.Object.Visible = AutoBuyUpgrades.Enabled
	AutoBuySharp.Object.BackgroundTransparency = 0
	AutoBuySharp.Object.BorderSizePixel = 0
	AutoBuySharp.Object.BackgroundColor3 = Color3.fromRGB(20, 20, 20)
	AutoBuySharp.Object.Visible = AutoBuyUpgrades.Enabled
	AutoBuyDestruction.Object.BackgroundTransparency = 0
	AutoBuyDestruction.Object.BorderSizePixel = 0
	AutoBuyDestruction.Object.BackgroundColor3 = Color3.fromRGB(20, 20, 20)
	AutoBuyDestruction.Object.Visible = AutoBuyUpgrades.Enabled
	AutoBuyDiamond.Object.BackgroundTransparency = 0
	AutoBuyDiamond.Object.BorderSizePixel = 0
	AutoBuyDiamond.Object.BackgroundColor3 = Color3.fromRGB(20, 20, 20)
	AutoBuyDiamond.Object.Visible = AutoBuyUpgrades.Enabled
	AutoBuyAlarm.Object.BackgroundTransparency = 0
	AutoBuyAlarm.Object.BorderSizePixel = 0
	AutoBuyAlarm.Object.BackgroundColor3 = Color3.fromRGB(20, 20, 20)
	AutoBuyAlarm.Object.Visible = AutoBuyUpgrades.Enabled
	AutoBuyCustom = AutoBuy.CreateTextList({
		Name = "BuyList",
		TempText = "item/amount/priority/after",
		SortFunction = function(a, b)
			local amount1 = a:split("/")
			local amount2 = b:split("/")
			amount1 = #amount1 and tonumber(amount1[3]) or 1
			amount2 = #amount2 and tonumber(amount2[3]) or 1
			return amount1 < amount2
		end
	})
	AutoBuyCustom.Object.AddBoxBKG.AddBox.TextSize = 14

	local AutoBank = {Enabled = false}
	local AutoBankRange = {Value = 20}
	local AutoBankApple = {Enabled = false}
	local AutoBankBalloon = {Enabled = false}
	local AutoBankTransmitted, AutoBankTransmittedType = false, false
	local autobankoldapple
	local autobankoldballoon
	local autobankui

	local function refreshbank()
		if autobankui then
			local echest = replicatedStorageService.Inventories:FindFirstChild(lplr.Name.."_personal")
			for i,v in pairs(autobankui:GetChildren()) do 
				if echest:FindFirstChild(v.Name) then 
					v.Amount.Text = echest[v.Name]:GetAttribute("Amount")
				else
					v.Amount.Text = ""
				end
			end
		end
	end

	AutoBank = GuiLibrary.ObjectsThatCanBeSaved.UtilityWindow.Api.CreateOptionsButton({
		Name = "AutoBank",
		Function = function(callback)
			if callback then
				autobankui = Instance.new("Frame")
				autobankui.Size = UDim2.new(0, 240, 0, 40)
				autobankui.AnchorPoint = Vector2.new(0.5, 0)
				autobankui.Position = UDim2.new(0.5, 0, 0, -240)
				autobankui.Visible = AutoBankUIToggle.Enabled
				task.spawn(function()
					repeat
						task.wait()
						if autobankui then 
							local hotbar = lplr.PlayerGui:FindFirstChild("hotbar")
							if hotbar then 
								local healthbar = hotbar["1"]:FindFirstChild("HotbarHealthbarContainer")
								if healthbar then 
									autobankui.Position = UDim2.new(0.5, 0, 0, healthbar.AbsolutePosition.Y - 50)
								end
							end
						else
							break
						end
					until (not AutoBank.Enabled)
				end)
				autobankui.BackgroundTransparency = 1
				autobankui.Parent = GuiLibrary.MainGui
				local emerald = Instance.new("ImageLabel")
				emerald.Image = bedwars.getIcon({itemType = "emerald"}, true)
				emerald.Size = UDim2.new(0, 40, 0, 40)
				emerald.Name = "emerald"
				emerald.Position = UDim2.new(0, 120, 0, 0)
				emerald.BackgroundTransparency = 1
				emerald.Parent = autobankui
				local emeraldtext = Instance.new("TextLabel")
				emeraldtext.TextSize = 20
				emeraldtext.BackgroundTransparency = 1
				emeraldtext.Size = UDim2.new(1, 0, 1, 0)
				emeraldtext.Font = Enum.Font.SourceSans
				emeraldtext.TextStrokeTransparency = 0.3
				emeraldtext.Name = "Amount"
				emeraldtext.Text = ""
				emeraldtext.TextColor3 = Color3.new(1, 1, 1)
				emeraldtext.Parent = emerald
				local diamond = emerald:Clone()
				diamond.Image = bedwars.getIcon({itemType = "diamond"}, true)
				diamond.Position = UDim2.new(0, 80, 0, 0)
				diamond.Name = "diamond"
				diamond.Parent = autobankui
				local gold = emerald:Clone()
				gold.Image = bedwars.getIcon({itemType = "gold"}, true)
				gold.Position = UDim2.new(0, 40, 0, 0)
				gold.Name = "gold"
				gold.Parent = autobankui
				local iron = emerald:Clone()
				iron.Image = bedwars.getIcon({itemType = "iron"}, true)
				iron.Position = UDim2.new(0, 0, 0, 0)
				iron.Name = "iron"
				iron.Parent = autobankui
				local apple = emerald:Clone()
				apple.Image = bedwars.getIcon({itemType = "apple"}, true)
				apple.Position = UDim2.new(0, 160, 0, 0)
				apple.Name = "apple"
				apple.Parent = autobankui
				local balloon = emerald:Clone()
				balloon.Image = bedwars.getIcon({itemType = "balloon"}, true)
				balloon.Position = UDim2.new(0, 200, 0, 0)
				balloon.Name = "balloon"
				balloon.Parent = autobankui
				local echest = replicatedStorageService.Inventories:FindFirstChild(lplr.Name.."_personal")
				if entityLibrary.isAlive and echest then
					task.spawn(function()
						local chestitems = bedwarsStore.localInventory.inventory.items
						for i3,v3 in pairs(chestitems) do
							if (v3.itemType == "emerald" or v3.itemType == "iron" or v3.itemType == "diamond" or v3.itemType == "gold" or (v3.itemType == "apple" and AutoBankApple.Enabled) or (v3.itemType == "balloon" and AutoBankBalloon.Enabled)) then
								bedwars.ClientHandler:GetNamespace("Inventory"):Get("ChestGiveItem"):CallServer(echest, v3.tool)
								refreshbank()
							end
						end
					end)
				else
					task.spawn(function()
						refreshbank()
					end)
				end
				table.insert(AutoBank.Connections, replicatedStorageService.Inventories.DescendantAdded:Connect(function(p3)
					if p3.Parent.Name == lplr.Name then
						if echest == nil then 
							echest = replicatedStorageService.Inventories:FindFirstChild(lplr.Name.."_personal")
						end	
						if not echest then return end
						if p3.Name == "apple" and AutoBankApple.Enabled then 
							if autobankapple then return end
						elseif p3.Name == "balloon" and AutoBankBalloon.Enabled then 
							if autobankballoon then vapeEvents.AutoBankBalloon:Fire() return end
						elseif (p3.Name == "emerald" or p3.Name == "iron" or p3.Name == "diamond" or p3.Name == "gold") then
							if not ((not AutoBankTransmitted) or (AutoBankTransmittedType and p3.Name ~= "diamond")) then return end
						else
							return
						end
						bedwars.ClientHandler:GetNamespace("Inventory"):Get("ChestGiveItem"):CallServer(echest, p3)
						refreshbank()
					end
				end))
				task.spawn(function()
					repeat
						task.wait()
						local found, npctype = nearNPC(AutoBankRange.Value)
						if echest == nil then 
							echest = replicatedStorageService.Inventories:FindFirstChild(lplr.Name.."_personal")
						end
						if autobankballoon then 
							local chestitems = echest and echest:GetChildren() or {}
							if #chestitems > 0 then
								for i3,v3 in pairs(chestitems) do
									if v3:IsA("Accessory") and v3.Name == "balloon" then
										if (not getItem("balloon")) then
											task.spawn(function()
												bedwars.ClientHandler:GetNamespace("Inventory"):Get("ChestGetItem"):CallServer(echest, v3)
												refreshbank()
											end)
										end
									end
								end
							end
						end
						if autobankballoon ~= autobankoldballoon and AutoBankBalloon.Enabled then 
							if entityLibrary.isAlive then
								if not autobankballoon then
									local chestitems = bedwarsStore.localInventory.inventory.items
									if #chestitems > 0 then
										for i3,v3 in pairs(chestitems) do
											if v3 and v3.itemType == "balloon" then
												task.spawn(function()
													bedwars.ClientHandler:GetNamespace("Inventory"):Get("ChestGiveItem"):CallServer(echest, v3.tool)
													refreshbank()
												end)
											end
										end
									end
								end
							end
							autobankoldballoon = autobankballoon
						end
						if autobankapple then 
							local chestitems = echest and echest:GetChildren() or {}
							if #chestitems > 0 then
								for i3,v3 in pairs(chestitems) do
									if v3:IsA("Accessory") and v3.Name == "apple" then
										if (not getItem("apple")) then
											task.spawn(function()
												bedwars.ClientHandler:GetNamespace("Inventory"):Get("ChestGetItem"):CallServer(echest, v3)
												refreshbank()
											end)
										end
									end
								end
							end
						end
						if (autobankapple ~= autobankoldapple) and AutoBankApple.Enabled then 
							if entityLibrary.isAlive then
								if not autobankapple then
									local chestitems = bedwarsStore.localInventory.inventory.items
									if #chestitems > 0 then
										for i3,v3 in pairs(chestitems) do
											if v3 and v3.itemType == "apple" then
												task.spawn(function()
													bedwars.ClientHandler:GetNamespace("Inventory"):Get("ChestGiveItem"):CallServer(echest, v3.tool)
													refreshbank()
												end)
											end
										end
									end
								end
							end
							autobankoldapple = autobankapple
						end
						if found ~= AutoBankTransmitted or npctype ~= AutoBankTransmittedType then
							AutoBankTransmitted, AutoBankTransmittedType = found, npctype
							if entityLibrary.isAlive then
								local chestitems = bedwarsStore.localInventory.inventory.items
								if #chestitems > 0 then
									for i3,v3 in pairs(chestitems) do
										if v3 and (v3.itemType == "emerald" or v3.itemType == "iron" or v3.itemType == "diamond" or v3.itemType == "gold") then
											if (not AutoBankTransmitted) or (AutoBankTransmittedType and v3.Name ~= "diamond") then 
												task.spawn(function()
													pcall(function()
														bedwars.ClientHandler:GetNamespace("Inventory"):Get("ChestGiveItem"):CallServer(echest, v3.tool)
													end)
													refreshbank()
												end)
											end
										end
									end
								end
							end
						end
						if found then 
							local chestitems = echest and echest:GetChildren() or {}
							if #chestitems > 0 then
								for i3,v3 in pairs(chestitems) do
									if v3:IsA("Accessory") and ((npctype == false and (v3.Name == "emerald" or v3.Name == "iron" or v3.Name == "gold")) or v3.Name == "diamond") then
										task.spawn(function()
											pcall(function()
												bedwars.ClientHandler:GetNamespace("Inventory"):Get("ChestGetItem"):CallServer(echest, v3)
											end)
											refreshbank()
										end)
									end
								end
							end
						end
					until (not AutoBank.Enabled)
				end)
			else
				if autobankui then
					autobankui:Destroy()
					autobankui = nil
				end
				local echest = replicatedStorageService.Inventories:FindFirstChild(lplr.Name.."_personal")
				local chestitems = echest and echest:GetChildren() or {}
				if #chestitems > 0 then
					for i3,v3 in pairs(chestitems) do
						if v3:IsA("Accessory") and (v3.Name == "emerald" or v3.Name == "iron" or v3.Name == "diamond" or v3.Name == "apple" or v3.Name == "balloon") then
							task.spawn(function()
								pcall(function()
									bedwars.ClientHandler:GetNamespace("Inventory"):Get("ChestGetItem"):CallServer(echest, v3)
								end)
								refreshbank()
							end)
						end
					end
				end
			end
		end
	})
	AutoBankUIToggle = AutoBank.CreateToggle({
		Name = "UI",
		Function = function(callback)
			if autobankui then autobankui.Visible = callback end
		end,
		Default = true
	})
	AutoBankApple = AutoBank.CreateToggle({
		Name = "Apple",
		Function = function(callback) 
			if not callback then 
				local echest = replicatedStorageService.Inventories:FindFirstChild(lplr.Name.."_personal")
				local chestitems = echest and echest:GetChildren() or {}
				for i3,v3 in pairs(chestitems) do
					if v3:IsA("Accessory") and v3.Name == "apple" then
						task.spawn(function()
							bedwars.ClientHandler:GetNamespace("Inventory"):Get("ChestGetItem"):CallServer(echest, v3)
							refreshbank()
						end)
					end
				end
			end
		end,
		Default = true
	})
	AutoBankBalloon = AutoBank.CreateToggle({
		Name = "Balloon",
		Function = function(callback) 
			if not callback then 
				local echest = replicatedStorageService.Inventories:FindFirstChild(lplr.Name.."_personal")
				local chestitems = echest and echest:GetChildren() or {}
				for i3,v3 in pairs(chestitems) do
					if v3:IsA("Accessory") and v3.Name == "balloon" then
						task.spawn(function()
							bedwars.ClientHandler:GetNamespace("Inventory"):Get("ChestGetItem"):CallServer(echest, v3)
							refreshbank()
						end)
					end
				end
			end
		end,
		Default = true
	})
	AutoBankDeath = AutoBank.CreateToggle({
		Name = "Damage",
		Function = function() end,
		HoverText = "puts away resources when you take damage to prevent losing on death"
	})
	AutoBankStay = AutoBank.CreateToggle({
		Name = "Stay",
		Function = function() end,
		HoverText = "keeps resources until toggled off"
	})
	AutoBankRange = AutoBank.CreateSlider({
		Name = "Range",
		Function = function() end,
		Min = 1,
		Max = 20,
		Default = 20
	})
end)

runFunction(function()
	local AutoConsume = {Enabled = false}
	local AutoConsumeHealth = {Value = 100}
	local AutoConsumeSpeed = {Enabled = true}
	local AutoConsumeDelay = tick()

	local function AutoConsumeFunc()
		if entityLibrary.isAlive then
			local speedpotion = getItem("speed_potion")
			if lplr.Character:GetAttribute("Health") <= (lplr.Character:GetAttribute("MaxHealth") - (100 - AutoConsumeHealth.Value)) then
				autobankapple = true
				local item = getItem("apple")
				local pot = getItem("heal_splash_potion")
				if (item or pot) and AutoConsumeDelay <= tick() then
					if item then
						bedwars.ClientHandler:Get(bedwars.EatRemote):CallServerAsync({
							item = item.tool
						})
						AutoConsumeDelay = tick() + 0.6
					else
						local newray = workspace:Raycast((oldcloneroot or entityLibrary.character.HumanoidRootPart).Position, Vector3.new(0, -76, 0), bedwarsStore.blockRaycast)
						if newray ~= nil then
							bedwars.ClientHandler:Get(bedwars.ProjectileRemote):CallServerAsync(pot.tool, "heal_splash_potion", "heal_splash_potion", (oldcloneroot or entityLibrary.character.HumanoidRootPart).Position, (oldcloneroot or entityLibrary.character.HumanoidRootPart).Position, Vector3.new(0, -70, 0), game:GetService("HttpService"):GenerateGUID(), {drawDurationSeconds = 1})
						end
					end
				end
			else
				autobankapple = false
			end
			if speedpotion and (not lplr.Character:GetAttribute("StatusEffect_speed")) and AutoConsumeSpeed.Enabled then 
				bedwars.ClientHandler:Get(bedwars.EatRemote):CallServerAsync({
					item = speedpotion.tool
				})
			end
			if lplr.Character:GetAttribute("Shield_POTION") and ((not lplr.Character:GetAttribute("Shield_POTION")) or lplr.Character:GetAttribute("Shield_POTION") == 0) then
				local shield = getItem("big_shield") or getItem("mini_shield")
				if shield then
					bedwars.ClientHandler:Get(bedwars.EatRemote):CallServerAsync({
						item = shield.tool
					})
				end
			end
		end
	end

	AutoConsume = GuiLibrary.ObjectsThatCanBeSaved.UtilityWindow.Api.CreateOptionsButton({
		Name = "AutoConsume",
		Function = function(callback)
			if callback then
				table.insert(AutoConsume.Connections, vapeEvents.InventoryAmountChanged.Event:Connect(AutoConsumeFunc))
				table.insert(AutoConsume.Connections, vapeEvents.AttributeChanged.Event:Connect(function(changed)
					if changed:find("Shield") or changed:find("Health") or changed:find("speed") then 
						AutoConsumeFunc()
					end
				end))
				AutoConsumeFunc()
			end
		end,
		HoverText = "Automatically heals for you when health or shield is under threshold."
	})
	AutoConsumeHealth = AutoConsume.CreateSlider({
		Name = "Health",
		Min = 1,
		Max = 99,
		Default = 70,
		Function = function() end
	})
	AutoConsumeSpeed = AutoConsume.CreateToggle({
		Name = "Speed Potions",
		Function = function() end,
		Default = true
	})
end)

runFunction(function()
	local AutoHotbarList = {Hotbars = {}, CurrentlySelected = 1}
	local AutoHotbarMode = {Value = "Toggle"}
	local AutoHotbarClear = {Enabled = false}
	local AutoHotbar = {Enabled = false}
	local AutoHotbarActive = false

	local function getCustomItem(v2)
		local realitem = v2.itemType
		if realitem == "swords" then
			local sword = getSword()
			realitem = sword and sword.itemType or "wood_sword"
		elseif realitem == "pickaxes" then
			local pickaxe = getPickaxe()
			realitem = pickaxe and pickaxe.itemType or "wood_pickaxe"
		elseif realitem == "axes" then
			local axe = getAxe()
			realitem = axe and axe.itemType or "wood_axe"
		elseif realitem == "bows" then
			local bow = getBow()
			realitem = bow and bow.itemType or "wood_bow"
		elseif realitem == "wool" then
			realitem = getWool() or "wool_white"
		end
		return realitem
	end
	
	local function findItemInTable(tab, item)
		for i, v in pairs(tab) do
			if v and v.itemType then
				if item.itemType == getCustomItem(v) then
					return i
				end
			end
		end
		return nil
	end

	local function findinhotbar(item)
		for i,v in pairs(bedwarsStore.localInventory.hotbar) do
			if v.item and v.item.itemType == item.itemType then
				return i, v.item
			end
		end
	end

	local function findininventory(item)
		for i,v in pairs(bedwarsStore.localInventory.inventory.items) do
			if v.itemType == item.itemType then
				return v
			end
		end
	end

	local function AutoHotbarSort()
		task.spawn(function()
			if AutoHotbarActive then return end
			AutoHotbarActive = true
			local items = (AutoHotbarList.Hotbars[AutoHotbarList.CurrentlySelected] and AutoHotbarList.Hotbars[AutoHotbarList.CurrentlySelected].Items or {})
			for i, v in pairs(bedwarsStore.localInventory.inventory.items) do 
				local customItem
				local hotbarslot = findItemInTable(items, v)
				if hotbarslot then
					local oldhotbaritem = bedwarsStore.localInventory.hotbar[tonumber(hotbarslot)]
					if oldhotbaritem.item and oldhotbaritem.item.itemType == v.itemType then continue end
					if oldhotbaritem.item then 
						bedwars.ClientStoreHandler:dispatch({
							type = "InventoryRemoveFromHotbar", 
							slot = tonumber(hotbarslot) - 1
						})
						vapeEvents.InventoryChanged.Event:Wait()
					end
					local newhotbaritemslot, newhotbaritem = findinhotbar(v)
					if newhotbaritemslot then
						bedwars.ClientStoreHandler:dispatch({
							type = "InventoryRemoveFromHotbar", 
							slot = newhotbaritemslot - 1
						})
						vapeEvents.InventoryChanged.Event:Wait()
					end
					if oldhotbaritem.item and newhotbaritemslot then 
						local nextitem1, nextitem1num = findininventory(oldhotbaritem.item)
						bedwars.ClientStoreHandler:dispatch({
							type = "InventoryAddToHotbar", 
							item = nextitem1, 
							slot = newhotbaritemslot - 1
						})
						vapeEvents.InventoryChanged.Event:Wait()
					end
					local nextitem2, nextitem2num = findininventory(v)
					bedwars.ClientStoreHandler:dispatch({
						type = "InventoryAddToHotbar", 
						item = nextitem2, 
						slot = tonumber(hotbarslot) - 1
					})
					vapeEvents.InventoryChanged.Event:Wait()
				else
					if AutoHotbarClear.Enabled then 
						local newhotbaritemslot, newhotbaritem = findinhotbar(v)
						if newhotbaritemslot then
							bedwars.ClientStoreHandler:dispatch({
								type = "InventoryRemoveFromHotbar", 
								slot = newhotbaritemslot - 1
							})
							vapeEvents.InventoryChanged.Event:Wait()
						end
					end
				end
			end
			AutoHotbarActive = false
		end)
	end

	AutoHotbar = GuiLibrary.ObjectsThatCanBeSaved.UtilityWindow.Api.CreateOptionsButton({
		Name = "AutoHotbar",
		Function = function(callback) 
			if callback then
				AutoHotbarSort()
				if AutoHotbarMode.Value == "On Key" then
					if AutoHotbar.Enabled then 
						AutoHotbar.ToggleButton(false)
					end
				else
					table.insert(AutoHotbar.Connections, vapeEvents.InventoryAmountChanged.Event:Connect(function()
						if not AutoHotbar.Enabled then return end
						AutoHotbarSort()
					end))
				end
			end
		end,
		HoverText = "Automatically arranges hotbar to your liking."
	})
	AutoHotbarMode = AutoHotbar.CreateDropdown({
		Name = "Activation",
		List = {"On Key", "Toggle"},
		Function = function(val)
			if AutoHotbar.Enabled then
				AutoHotbar.ToggleButton(false)
				AutoHotbar.ToggleButton(false)
			end
		end
	})
	AutoHotbarList = CreateAutoHotbarGUI(AutoHotbar.Children, {
		Name = "lol"
	})
	AutoHotbarClear = AutoHotbar.CreateToggle({
		Name = "Clear Hotbar",
		Function = function() end
	})
end)

runFunction(function()
	local AutoKit = {Enabled = false}
	local AutoKitTrinity = {Value = "Void"}
	local oldfish
	local function GetTeammateThatNeedsMost()
		local plrs = GetAllNearestHumanoidToPosition(true, 30, 1000, true)
		local lowest, lowestplayer = 10000, nil
		for i,v in pairs(plrs) do
			if not v.Targetable then
				if v.Character:GetAttribute("Health") <= lowest and v.Character:GetAttribute("Health") < v.Character:GetAttribute("MaxHealth") then
					lowest = v.Character:GetAttribute("Health")
					lowestplayer = v
				end
			end
		end
		return lowestplayer
	end

	AutoKit = GuiLibrary.ObjectsThatCanBeSaved.UtilityWindow.Api.CreateOptionsButton({
		Name = "AutoKit",
		Function = function(callback)
			if callback then
				oldfish = bedwars.FishermanTable.startMinigame
				bedwars.FishermanTable.startMinigame = function(Self, dropdata, func) func({win = true}) end
				task.spawn(function()
					repeat task.wait() until bedwarsStore.equippedKit ~= ""
					if AutoKit.Enabled then
						if bedwarsStore.equippedKit == "melody" then
							task.spawn(function()
								repeat
									task.wait(0.1)
									if getItem("guitar") then
										local plr = GetTeammateThatNeedsMost()
										if plr and healtick <= tick() then
											bedwars.ClientHandler:Get(bedwars.GuitarHealRemote):SendToServer({
												healTarget = plr.Character
											})
											healtick = tick() + 2
										end
									end
								until (not AutoKit.Enabled)
							end)
						elseif bedwarsStore.equippedKit == "bigman" then
							task.spawn(function()
								repeat
									task.wait()
									local itemdrops = collectionService:GetTagged("treeOrb")
									for i,v in pairs(itemdrops) do
										if entityLibrary.isAlive and v:FindFirstChild("Spirit") and (entityLibrary.character.HumanoidRootPart.Position - v.Spirit.Position).magnitude <= 20 then
											if bedwars.ClientHandler:Get(bedwars.TreeRemote):CallServer({
												treeOrbSecret = v:GetAttribute("TreeOrbSecret")
											}) then
												v:Destroy()
												collectionService:RemoveTag(v, "treeOrb")
											end
										end
									end
								until (not AutoKit.Enabled)
							end)
						elseif bedwarsStore.equippedKit == "metal_detector" then
							task.spawn(function()
								repeat
									task.wait()
									local itemdrops = collectionService:GetTagged("hidden-metal")
									for i,v in pairs(itemdrops) do
										if entityLibrary.isAlive and v.PrimaryPart and (entityLibrary.character.HumanoidRootPart.Position - v.PrimaryPart.Position).magnitude <= 20 then
											bedwars.ClientHandler:Get(bedwars.PickupMetalRemote):SendToServer({
												id = v:GetAttribute("Id")
											}) 
										end
									end
								until (not AutoKit.Enabled)
							end)
						elseif bedwarsStore.equippedKit == "battery" then 
							task.spawn(function()
								repeat
									task.wait()
									local itemdrops = bedwars.BatteryEffectController.liveBatteries
									for i,v in pairs(itemdrops) do
										if entityLibrary.isAlive and (entityLibrary.character.HumanoidRootPart.Position - v.position).magnitude <= 10 then
											bedwars.ClientHandler:Get(bedwars.BatteryRemote):SendToServer({
												batteryId = i
											})
										end
									end
								until (not AutoKit.Enabled)
							end)
						elseif bedwarsStore.equippedKit == "grim_reaper" then
							task.spawn(function()
								repeat
									task.wait()
									local itemdrops = bedwars.GrimReaperController.soulsByPosition
									for i,v in pairs(itemdrops) do
										if entityLibrary.isAlive and lplr.Character:GetAttribute("Health") <= (lplr.Character:GetAttribute("MaxHealth") / 4) and v.PrimaryPart and (entityLibrary.character.HumanoidRootPart.Position - v.PrimaryPart.Position).magnitude <= 120 and (not lplr.Character:GetAttribute("GrimReaperChannel")) then
											bedwars.ClientHandler:Get(bedwars.ConsumeSoulRemote):CallServer({
												secret = v:GetAttribute("GrimReaperSoulSecret")
											})
											v:Destroy()
										end
									end
								until (not AutoKit.Enabled)
							end)
						elseif bedwarsStore.equippedKit == "farmer_cletus" then 
							task.spawn(function()
								repeat
									task.wait()
									local itemdrops = collectionService:GetTagged("BedwarsHarvestableCrop")
									for i,v in pairs(itemdrops) do
										if entityLibrary.isAlive and (entityLibrary.character.HumanoidRootPart.Position - v.Position).magnitude <= 10 then
											bedwars.ClientHandler:Get("BedwarsHarvestCrop"):CallServerAsync({
												position = bedwars.BlockController:getBlockPosition(v.Position)
											}):andThen(function(suc)
												if suc then
													bedwars.GameAnimationUtil.playAnimation(lplr.Character, 1)
													bedwars.SoundManager:playSound(bedwars.SoundList.CROP_HARVEST)
												end
											end)
										end
									end
								until (not AutoKit.Enabled)
							end)
						elseif bedwarsStore.equippedKit == "dragon_slayer" then
							task.spawn(function()
								repeat
									task.wait(0.1)
									if entityLibrary.isAlive then
										for i,v in pairs(bedwars.DragonSlayerController.dragonEmblems) do 
											if v.stackCount >= 3 then 
												bedwars.DragonSlayerController:deleteEmblem(i)
												local localPos = lplr.Character:GetPrimaryPartCFrame().Position
												local punchCFrame = CFrame.new(localPos, (i:GetPrimaryPartCFrame().Position * Vector3.new(1, 0, 1)) + Vector3.new(0, localPos.Y, 0))
												lplr.Character:SetPrimaryPartCFrame(punchCFrame)
												bedwars.DragonSlayerController:playPunchAnimation(punchCFrame - punchCFrame.Position)
												bedwars.ClientHandler:Get(bedwars.DragonRemote):SendToServer({
													target = i
												})
											end
										end
									end
								until (not AutoKit.Enabled)
							end)
						elseif bedwarsStore.equippedKit == "mage" then
							task.spawn(function()
								repeat
									task.wait(0.1)
									if entityLibrary.isAlive then
										for i, v in pairs(collectionService:GetTagged("TomeGuidingBeam")) do 
											local obj = v.Parent and v.Parent.Parent and v.Parent.Parent.Parent
											if obj and (entityLibrary.character.HumanoidRootPart.Position - obj.PrimaryPart.Position).Magnitude < 5 and obj:GetAttribute("TomeSecret") then
												local res = bedwars.ClientHandler:Get(bedwars.MageRemote):CallServer({
													secret = obj:GetAttribute("TomeSecret")
												})
												if res.success and res.element then 
													bedwars.GameAnimationUtil.playAnimation(lplr, bedwars.AnimationType.PUNCH)
													bedwars.ViewmodelController:playAnimation(bedwars.AnimationType.FP_USE_ITEM)
													bedwars.MageController:destroyTomeGuidingBeam()
													bedwars.MageController:playLearnLightBeamEffect(lplr, obj)
													local sound = bedwars.MageKitUtil.MageElementVisualizations[res.element].learnSound
													if sound and sound ~= "" then 
														bedwars.SoundManager:playSound(sound)
													end
													task.delay(bedwars.BalanceFile.LEARN_TOME_DURATION, function()
														bedwars.MageController:fadeOutTome(obj)
														if lplr.Character and res.element then
															bedwars.MageKitUtil.changeMageKitAppearance(lplr, lplr.Character, res.element)	
														end
													end)
												end
											end
										end
									end
								until (not AutoKit.Enabled)
							end)
						elseif bedwarsStore.equippedKit == "angel" then 
							table.insert(AutoKit.Connections, vapeEvents.AngelProgress.Event:Connect(function(angelTable)
								task.wait(0.5)
								if not AutoKit.Enabled then return end
								if bedwars.ClientStoreHandler:getState().Kit.angelProgress >= 1 and lplr.Character:GetAttribute("AngelType") == nil then
									bedwars.ClientHandler:Get(bedwars.TrinityRemote):SendToServer({
										angel = AutoKitTrinity.Value
									})
								end
							end))
						elseif bedwarsStore.equippedKit == "miner" then
							task.spawn(function()
								repeat
									task.wait(0.1)
									if entityLibrary.isAlive then
										for i,v in pairs(collectionService:GetTagged("petrified-player")) do 
											bedwars.ClientHandler:Get(bedwars.MinerRemote):SendToServer({
												petrifyId = v:GetAttribute("PetrifyId")
											})
										end
									end
								until (not AutoKit.Enabled)
							end)
						end
					end
				end)
			else
				bedwars.FishermanTable.startMinigame = oldfish
				oldfish = nil
			end
		end,
		HoverText = "Automatically uses a kits ability"
	})
	AutoKitTrinity = AutoKit.CreateDropdown({
		Name = "Angel",
		List = {"Void", "Light"},
		Function = function() end
	})
end)

runFunction(function()
	local AutoRelicCustom = {ObjectList = {}}

	local function findgoodmeta(relics)
		local tab = #AutoRelicCustom.ObjectList > 0 and AutoRelicCustom.ObjectList or {
			"embers_anguish",
			"knights_code",
			"quick_forge",
			"glass_cannon"
		}
		for i,v in pairs(relics) do 
			for i2,v2 in pairs(tab) do 
				if v.relic == v2 then
					return v.relic
				end
			end
		end
		return relics[1].relic
	end

	local AutoRelic = {Enabled = false}
	AutoRelic = GuiLibrary.ObjectsThatCanBeSaved.UtilityWindow.Api.CreateOptionsButton({
		Name = "AutoRelic",
		Function = function(callback)
			if callback then 
				task.spawn(function()
					repeat
						task.wait()
						if bedwars.AppController:isAppOpen("RelicVotingInterface") then 
							bedwars.AppController:closeApp("RelicVotingInterface")
							local relictable = bedwars.ClientStoreHandler:getState().Bedwars.relic.voteState
							if relictable then 
								bedwars.RelicController:voteForRelic(findgoodmeta(relictable))
							end
							break
						end
						if matchState ~= 0 then break end
					until (not AutoRelic.Enabled)
				end)
			end
		end
	})
	AutoRelicCustom = AutoRelic.CreateTextList({
		Name = "Custom",
		TempText = "custom (relic id)"
	})
end)

runFunction(function()
	local AutoForge = {Enabled = false}
	local AutoForgeWeapon = {Value = "Sword"}
	local AutoForgeBow = {Enabled = false}
	local AutoForgeArmor = {Enabled = false}
	local AutoForgeSword = {Enabled = false}
	local AutoForgeBuyAfter = {Enabled = false}
	local AutoForgeNotification = {Enabled = true}

	local function buyForge(i)
		if not bedwarsStore.forgeUpgrades[i] or bedwarsStore.forgeUpgrades[i] < 6 then
			local cost = bedwars.ForgeUtil:getUpgradeCost(1, bedwarsStore.forgeUpgrades[i] or 0)
			if bedwarsStore.forgeMasteryPoints >= cost then 
				if AutoForgeNotification.Enabled then
					local forgeType = "none"
					for name,v in pairs(bedwars.ForgeConstants) do
						if v == i then forgeType = name:lower() end
					end
					warningNotification("AutoForge", "Purchasing "..forgeType..".", bedwars.ForgeUtil.FORGE_DURATION_SEC)
				end
				bedwars.ClientHandler:Get("ForgePurchaseUpgrade"):SendToServer(i)
				task.wait(bedwars.ForgeUtil.FORGE_DURATION_SEC + 0.2)
			end
		end
	end

	AutoForge = GuiLibrary.ObjectsThatCanBeSaved.UtilityWindow.Api.CreateOptionsButton({
		Name = "AutoForge",
		Function = function(callback)
			if callback then 
				task.spawn(function()
					repeat
						task.wait()
						if bedwarsStore.matchState == 1 and entityLibrary.isAlive then
							if entityLibrary.character.HumanoidRootPart.Velocity.Magnitude > 0.01 then continue end
							if AutoForgeArmor.Enabled then buyForge(bedwars.ForgeConstants.ARMOR) end
							if entityLibrary.character.HumanoidRootPart.Velocity.Magnitude > 0.01 then continue end
							if AutoForgeBow.Enabled then buyForge(bedwars.ForgeConstants.RANGED) end
							if entityLibrary.character.HumanoidRootPart.Velocity.Magnitude > 0.01 then continue end
							if AutoForgeSword.Enabled then
								if AutoForgeBuyAfter.Enabled then
									if not bedwarsStore.forgeUpgrades[bedwars.ForgeConstants.ARMOR] or bedwarsStore.forgeUpgrades[bedwars.ForgeConstants.ARMOR] < 6 then continue end
								end
								local weapon = bedwars.ForgeConstants[AutoForgeWeapon.Value:upper()]
								if weapon then buyForge(weapon) end
							end
						end
					until (not AutoForge.Enabled)
				end)
			end
		end
	})
	AutoForgeWeapon = AutoForge.CreateDropdown({
		Name = "Weapon",
		Function = function() end,
		List = {"Sword", "Dagger", "Scythe", "Great_Hammer"}
	})
	AutoForgeArmor = AutoForge.CreateToggle({
		Name = "Armor",
		Function = function() end,
		Default = true
	})
	AutoForgeSword = AutoForge.CreateToggle({
		Name = "Weapon",
		Function = function() end
	})
	AutoForgeBow = AutoForge.CreateToggle({
		Name = "Bow",
		Function = function() end
	})
	AutoForgeBuyAfter = AutoForge.CreateToggle({
		Name = "Buy After",
		Function = function() end,
		HoverText = "buy a weapon after armor is maxed"
	})
	AutoForgeNotification = AutoForge.CreateToggle({
		Name = "Notification",
		Function = function() end,
		Default = true
	})
end)

runFunction(function()
	local alreadyreportedlist = {}
	local AutoReportV2 = {Enabled = false}
	local AutoReportV2Notify = {Enabled = false}
	AutoReportV2 = GuiLibrary.ObjectsThatCanBeSaved.UtilityWindow.Api.CreateOptionsButton({
		Name = "AutoReportV2",
		Function = function(callback)
			if callback then 
				task.spawn(function()
					repeat
						task.wait()
						for i,v in pairs(playersService:GetPlayers()) do 
							if v ~= lplr and alreadyreportedlist[v] == nil and v:GetAttribute("PlayerConnected") and WhitelistFunctions:GetWhitelist(v) == 0 then 
								task.wait(1)
								alreadyreportedlist[v] = true
								bedwars.ClientHandler:Get(bedwars.ReportRemote):SendToServer(v.UserId)
								bedwarsStore.statistics.reported = bedwarsStore.statistics.reported + 1
								if AutoReportV2Notify.Enabled then 
									warningNotification("AutoReportV2", "Reported "..v.Name, 15)
								end
							end
						end
					until (not AutoReportV2.Enabled)
				end)
			end	
		end,
		HoverText = "dv mald"
	})
	AutoReportV2Notify = AutoReportV2.CreateToggle({
		Name = "Notify",
		Function = function() end
	})
end)

runFunction(function()
	local justsaid = ""
	local leavesaid = false
	local alreadyreported = {}

	local function removerepeat(str)
		local newstr = ""
		local lastlet = ""
		for i,v in pairs(str:split("")) do 
			if v ~= lastlet then
				newstr = newstr..v 
				lastlet = v
			end
		end
		return newstr
	end

	local reporttable = {
		gay = "Bullying",
		gae = "Bullying",
		gey = "Bullying",
		hack = "Scamming",
		exploit = "Scamming",
		cheat = "Scamming",
		hecker = "Scamming",
		haxker = "Scamming",
		hacer = "Scamming",
		report = "Bullying",
		fat = "Bullying",
		black = "Bullying",
		getalife = "Bullying",
		fatherless = "Bullying",
		report = "Bullying",
		fatherless = "Bullying",
		disco = "Offsite Links",
		yt = "Offsite Links",
		dizcourde = "Offsite Links",
		retard = "Swearing",
		bad = "Bullying",
		trash = "Bullying",
		nolife = "Bullying",
		nolife = "Bullying",
		loser = "Bullying",
		killyour = "Bullying",
		kys = "Bullying",
		hacktowin = "Bullying",
		bozo = "Bullying",
		kid = "Bullying",
		adopted = "Bullying",
		linlife = "Bullying",
		commitnotalive = "Bullying",
		vape = "Offsite Links",
		futureclient = "Offsite Links",
		download = "Offsite Links",
		youtube = "Offsite Links",
		die = "Bullying",
		lobby = "Bullying",
		ban = "Bullying",
		wizard = "Bullying",
		wisard = "Bullying",
		witch = "Bullying",
		magic = "Bullying",
	}
	local reporttableexact = {
		L = "Bullying",
	}
	

	local function findreport(msg)
		local checkstr = removerepeat(msg:gsub("%W+", ""):lower())
		for i,v in pairs(reporttable) do 
			if checkstr:find(i) then 
				return v, i
			end
		end
		for i,v in pairs(reporttableexact) do 
			if checkstr == i then 
				return v, i
			end
		end
		for i,v in pairs(AutoToxicPhrases5.ObjectList) do 
			if checkstr:find(v) then 
				return "Bullying", v
			end
		end
		return nil
	end

	AutoToxic = GuiLibrary.ObjectsThatCanBeSaved.UtilityWindow.Api.CreateOptionsButton({
		Name = "AutoToxic",
		Function = function(callback)
			if callback then 
				table.insert(AutoToxic.Connections, vapeEvents.BedwarsBedBreak.Event:Connect(function(bedTable)
					if AutoToxicBedDestroyed.Enabled and bedTable.brokenBedTeam.id == lplr:GetAttribute("Team") then
						local custommsg = #AutoToxicPhrases6.ObjectList > 0 and AutoToxicPhrases6.ObjectList[math.random(1, #AutoToxicPhrases6.ObjectList)] or "How dare you break my bed >:( <name> | vxpe on top"
						if custommsg then
							custommsg = custommsg:gsub("<name>", (bedTable.player.DisplayName or bedTable.player.Name))
						end
						textChatService.ChatInputBarConfiguration.TargetTextChannel:SendAsync(custommsg)
					elseif AutoToxicBedBreak.Enabled and bedTable.player.UserId == lplr.UserId then
						local custommsg = #AutoToxicPhrases7.ObjectList > 0 and AutoToxicPhrases7.ObjectList[math.random(1, #AutoToxicPhrases7.ObjectList)] or "nice bed <teamname> | vxpe on top"
						if custommsg then
							local team = bedwars.QueueMeta[bedwarsStore.queueType].teams[tonumber(bedTable.brokenBedTeam.id)]
							local teamname = team and team.displayName:lower() or "white"
							custommsg = custommsg:gsub("<teamname>", teamname)
						end
						textChatService.ChatInputBarConfiguration.TargetTextChannel:SendAsync(custommsg)
					end
				end))
				table.insert(AutoToxic.Connections, vapeEvents.EntityDeathEvent.Event:Connect(function(deathTable)
					if deathTable.finalKill then
						local killer = playersService:GetPlayerFromCharacter(deathTable.fromEntity)
						local killed = playersService:GetPlayerFromCharacter(deathTable.entityInstance)
						if not killed or not killer then return end
						if killed == lplr then 
							if (not leavesaid) and killer ~= lplr and AutoToxicDeath.Enabled then
								leavesaid = true
								local custommsg = #AutoToxicPhrases3.ObjectList > 0 and AutoToxicPhrases3.ObjectList[math.random(1, #AutoToxicPhrases3.ObjectList)] or "My gaming chair expired midfight, thats why you won <name> | vxpe on top"
								if custommsg then
									custommsg = custommsg:gsub("<name>", (killer.DisplayName or killer.Name))
								end
								textChatService.ChatInputBarConfiguration.TargetTextChannel:SendAsync(custommsg)
							end
						else
							if killer == lplr and AutoToxicFinalKill.Enabled then 
								local custommsg = #AutoToxicPhrases2.ObjectList > 0 and AutoToxicPhrases2.ObjectList[math.random(1, #AutoToxicPhrases2.ObjectList)] or "L <name> | vxpe on top"
								if custommsg == lastsaid then
									custommsg = #AutoToxicPhrases2.ObjectList > 0 and AutoToxicPhrases2.ObjectList[math.random(1, #AutoToxicPhrases2.ObjectList)] or "L <name> | vxpe on top"
								else
									lastsaid = custommsg
								end
								if custommsg then
									custommsg = custommsg:gsub("<name>", (killed.DisplayName or killed.Name))
								end
								textChatService.ChatInputBarConfiguration.TargetTextChannel:SendAsync(custommsg)
							end
						end
					end
				end))
				table.insert(AutoToxic.Connections, vapeEvents.MatchEndEvent.Event:Connect(function(winstuff)
					local myTeam = bedwars.ClientStoreHandler:getState().Game.myTeam
					if myTeam and myTeam.id == winstuff.winningTeamId or lplr.Neutral then
						if AutoToxicGG.Enabled then
							textChatService.ChatInputBarConfiguration.TargetTextChannel:SendAsync("gg")
							if shared.ggfunction then
								shared.ggfunction()
							end
						end
						if AutoToxicWin.Enabled then
							textChatService.ChatInputBarConfiguration.TargetTextChannel:SendAsync(#AutoToxicPhrases.ObjectList > 0 and AutoToxicPhrases.ObjectList[math.random(1, #AutoToxicPhrases.ObjectList)] or "EZ L TRASH KIDS | vxpe on top")
						end
					end
				end))
				table.insert(AutoToxic.Connections, vapeEvents.LagbackEvent.Event:Connect(function(plr)
					if AutoToxicLagback.Enabled then
						local custommsg = #AutoToxicPhrases8.ObjectList > 0 and AutoToxicPhrases8.ObjectList[math.random(1, #AutoToxicPhrases8.ObjectList)]
						if custommsg then
							custommsg = custommsg:gsub("<name>", (plr.DisplayName or plr.Name))
						end
						local msg = custommsg or "Imagine lagbacking L "..(plr.DisplayName or plr.Name).." | vxpe on top"
						textChatService.ChatInputBarConfiguration.TargetTextChannel:SendAsync(msg)
					end
				end))
				table.insert(AutoToxic.Connections, textChatService.MessageReceived:Connect(function(tab)
					if AutoToxicRespond.Enabled then
						local plr = playersService:GetPlayerByUserId(tab.TextSource.UserId)
						local args = tab.Text:split(" ")
						if plr and plr ~= lplr and not alreadyreported[plr] then
							local reportreason, reportedmatch = findreport(tab.Text)
							if reportreason then 
								alreadyreported[plr] = true
								local custommsg = #AutoToxicPhrases4.ObjectList > 0 and AutoToxicPhrases4.ObjectList[math.random(1, #AutoToxicPhrases4.ObjectList)]
								if custommsg then
									custommsg = custommsg:gsub("<name>", (plr.DisplayName or plr.Name))
								end
								local msg = custommsg or "I don't care about the fact that I'm hacking, I care about you dying in a block game. L "..(plr.DisplayName or plr.Name).." | vxpe on top"
								textChatService.ChatInputBarConfiguration.TargetTextChannel:SendAsync(msg)
							end
						end
					end
				end))
			end
		end
	})
	AutoToxicGG = AutoToxic.CreateToggle({
		Name = "AutoGG",
		Function = function() end, 
		Default = true
	})
	AutoToxicWin = AutoToxic.CreateToggle({
		Name = "Win",
		Function = function() end, 
		Default = true
	})
	AutoToxicDeath = AutoToxic.CreateToggle({
		Name = "Death",
		Function = function() end, 
		Default = true
	})
	AutoToxicBedBreak = AutoToxic.CreateToggle({
		Name = "Bed Break",
		Function = function() end, 
		Default = true
	})
	AutoToxicBedDestroyed = AutoToxic.CreateToggle({
		Name = "Bed Destroyed",
		Function = function() end, 
		Default = true
	})
	AutoToxicRespond = AutoToxic.CreateToggle({
		Name = "Respond",
		Function = function() end, 
		Default = true
	})
	AutoToxicFinalKill = AutoToxic.CreateToggle({
		Name = "Final Kill",
		Function = function() end, 
		Default = true
	})
	AutoToxicTeam = AutoToxic.CreateToggle({
		Name = "Teammates",
		Function = function() end, 
	})
	AutoToxicLagback = AutoToxic.CreateToggle({
		Name = "Lagback",
		Function = function() end, 
		Default = true
	})
	AutoToxicPhrases = AutoToxic.CreateTextList({
		Name = "ToxicList",
		TempText = "phrase (win)",
	})
	AutoToxicPhrases2 = AutoToxic.CreateTextList({
		Name = "ToxicList2",
		TempText = "phrase (kill) <name>",
	})
	AutoToxicPhrases3 = AutoToxic.CreateTextList({
		Name = "ToxicList3",
		TempText = "phrase (death) <name>",
	})
	AutoToxicPhrases7 = AutoToxic.CreateTextList({
		Name = "ToxicList7",
		TempText = "phrase (bed break) <teamname>",
	})
	AutoToxicPhrases7.Object.AddBoxBKG.AddBox.TextSize = 12
	AutoToxicPhrases6 = AutoToxic.CreateTextList({
		Name = "ToxicList6",
		TempText = "phrase (bed destroyed) <name>",
	})
	AutoToxicPhrases6.Object.AddBoxBKG.AddBox.TextSize = 12
	AutoToxicPhrases4 = AutoToxic.CreateTextList({
		Name = "ToxicList4",
		TempText = "phrase (text to respond with) <name>",
	})
	AutoToxicPhrases4.Object.AddBoxBKG.AddBox.TextSize = 12
	AutoToxicPhrases5 = AutoToxic.CreateTextList({
		Name = "ToxicList5",
		TempText = "phrase (text to respond to)",
	})
	AutoToxicPhrases5.Object.AddBoxBKG.AddBox.TextSize = 12
	AutoToxicPhrases8 = AutoToxic.CreateTextList({
		Name = "ToxicList8",
		TempText = "phrase (lagback) <name>",
	})
	AutoToxicPhrases8.Object.AddBoxBKG.AddBox.TextSize = 12
end)

runFunction(function()
	local ChestStealer = {Enabled = false}
	local ChestStealerDistance = {Value = 1}
	local ChestStealerDelay = {Value = 1}
	local ChestStealerOpen = {Enabled = false}
	local ChestStealerSkywars = {Enabled = true}
	local cheststealerdelays = {}
	local cheststealerfuncs = {
		Open = function()
			if bedwars.AppController:isAppOpen("ChestApp") then
				local chest = lplr.Character:FindFirstChild("ObservedChestFolder")
				local chestitems = chest and chest.Value and chest.Value:GetChildren() or {}
				if #chestitems > 0 then
					for i3,v3 in pairs(chestitems) do
						if v3:IsA("Accessory") and (cheststealerdelays[v3] == nil or cheststealerdelays[v3] < tick()) then
							task.spawn(function()
								pcall(function()
									cheststealerdelays[v3] = tick() + 0.2
									bedwars.ClientHandler:GetNamespace("Inventory"):Get("ChestGetItem"):CallServer(chest.Value, v3)
								end)
							end)
							task.wait(ChestStealerDelay.Value / 100)
						end
					end
				end
			end
		end,
		Closed = function()
			for i, v in pairs(collectionService:GetTagged("chest")) do
				if ((entityLibrary.LocalPosition or entityLibrary.character.HumanoidRootPart.Position) - v.Position).magnitude <= ChestStealerDistance.Value then
					local chest = v:FindFirstChild("ChestFolderValue")
					chest = chest and chest.Value or nil
					local chestitems = chest and chest:GetChildren() or {}
					if #chestitems > 0 then
						bedwars.ClientHandler:GetNamespace("Inventory"):Get("SetObservedChest"):SendToServer(chest)
						for i3,v3 in pairs(chestitems) do
							if v3:IsA("Accessory") then
								task.spawn(function()
									pcall(function()
										bedwars.ClientHandler:GetNamespace("Inventory"):Get("ChestGetItem"):CallServer(v.ChestFolderValue.Value, v3)
									end)
								end)
								task.wait(ChestStealerDelay.Value / 100)
							end
						end
						bedwars.ClientHandler:GetNamespace("Inventory"):Get("SetObservedChest"):SendToServer(nil)
					end
				end
			end
		end
	}

	ChestStealer = GuiLibrary.ObjectsThatCanBeSaved.UtilityWindow.Api.CreateOptionsButton({
		Name = "ChestStealer",
		Function = function(callback)
			if callback then
				task.spawn(function()
					repeat task.wait() until bedwarsStore.queueType ~= "bedwars_test"
					if (not ChestStealerSkywars.Enabled) or bedwarsStore.queueType:find("skywars") then
						repeat 
							task.wait(0.1)
							if entityLibrary.isAlive then
								cheststealerfuncs[ChestStealerOpen.Enabled and "Open" or "Closed"]()
							end
						until (not ChestStealer.Enabled)
					end
				end)
			end
		end,
		HoverText = "Grabs items from near chests."
	})
	ChestStealerDistance = ChestStealer.CreateSlider({
		Name = "Range",
		Min = 0,
		Max = 18,
		Function = function() end,
		Default = 18
	})
	ChestStealerDelay = ChestStealer.CreateSlider({
		Name = "Delay",
		Min = 1,
		Max = 50,
		Function = function() end,
		Default = 1,
		Double = 100
	})
	ChestStealerOpen = ChestStealer.CreateToggle({
		Name = "GUI Check",
		Function = function() end
	})
	ChestStealerSkywars = ChestStealer.CreateToggle({
		Name = "Only Skywars",
		Function = function() end,
		Default = true
	})
end)

runFunction(function()
	local FastDrop = {Enabled = false}
	FastDrop = GuiLibrary.ObjectsThatCanBeSaved.UtilityWindow.Api.CreateOptionsButton({
		Name = "FastDrop",
		Function = function(callback)
			if callback then
				task.spawn(function()
					repeat
						task.wait()
						if entityLibrary.isAlive and (not bedwarsStore.localInventory.opened) and (inputService:IsKeyDown(Enum.KeyCode.Q) or inputService:IsKeyDown(Enum.KeyCode.Backspace)) and inputService:GetFocusedTextBox() == nil then
							task.spawn(bedwars.DropItem)
						end
					until (not FastDrop.Enabled)
				end)
			end
		end,
		HoverText = "Drops items fast when you hold Q"
	})
end)

runFunction(function()
	local MissileTP = {Enabled = false}
	local MissileTeleportDelaySlider = {Value = 30}
	MissileTP = GuiLibrary.ObjectsThatCanBeSaved.UtilityWindow.Api.CreateOptionsButton({
		Name = "MissileTP",
		Function = function(callback)
			if callback then
				task.spawn(function()
					if getItem("guided_missile") then
						local plr = EntityNearMouse(1000)
						if plr then
							local projectile = bedwars.RuntimeLib.await(bedwars.MissileController.fireGuidedProjectile:CallServerAsync("guided_missile"))
							if projectile then
								local projectilemodel = projectile.model
								if not projectilemodel.PrimaryPart then
									projectilemodel:GetPropertyChangedSignal("PrimaryPart"):Wait()
								end;
								local bodyforce = Instance.new("BodyForce")
								bodyforce.Force = Vector3.new(0, projectilemodel.PrimaryPart.AssemblyMass * workspace.Gravity, 0)
								bodyforce.Name = "AntiGravity"
								bodyforce.Parent = projectilemodel.PrimaryPart

								repeat
									task.wait()
									if projectile.model then
										if plr then
											projectile.model:SetPrimaryPartCFrame(CFrame.new(plr.RootPart.CFrame.p, plr.RootPart.CFrame.p + gameCamera.CFrame.lookVector))
										else
											warningNotification("MissileTP", "Player died before it could TP.", 3)
											break
										end
									end
								until projectile.model.Parent == nil
							else
								warningNotification("MissileTP", "Missile on cooldown.", 3)
							end
						else
							warningNotification("MissileTP", "Player not found.", 3)
						end
					else
						warningNotification("MissileTP", "Missile not found.", 3)
					end
				end)
				MissileTP.ToggleButton(true)
			end
		end,
		HoverText = "Spawns and teleports a missile to a player\nnear your mouse."
	})
end)

runFunction(function()
	local OpenEnderchest = {Enabled = false}
	OpenEnderchest = GuiLibrary.ObjectsThatCanBeSaved.UtilityWindow.Api.CreateOptionsButton({
		Name = "OpenEnderchest",
		Function = function(callback)
			if callback then
				local echest = replicatedStorageService.Inventories:FindFirstChild(lplr.Name.."_personal")
				if echest then
					bedwars.AppController:openApp("ChestApp", {})
					bedwars.ChestController:openChest(echest)
				else
					warningNotification("OpenEnderchest", "Enderchest not found", 5)
				end
				OpenEnderchest.ToggleButton(false)
			end
		end,
		HoverText = "Opens the enderchest"
	})
end)

runFunction(function()
	local PickupRangeRange = {Value = 1}
	local PickupRange = {Enabled = false}
	PickupRange = GuiLibrary.ObjectsThatCanBeSaved.UtilityWindow.Api.CreateOptionsButton({
		Name = "PickupRange", 
		Function = function(callback)
			if callback then
				local pickedup = {}
				task.spawn(function()
					repeat
						local itemdrops = collectionService:GetTagged("ItemDrop")
						for i,v in pairs(itemdrops) do
							if entityLibrary.isAlive and (v:GetAttribute("ClientDropTime") and tick() - v:GetAttribute("ClientDropTime") > 2 or v:GetAttribute("ClientDropTime") == nil) then
								if ((entityLibrary.LocalPosition or entityLibrary.character.HumanoidRootPart.Position) - v.Position).magnitude <= PickupRangeRange.Value and (pickedup[v] == nil or pickedup[v] <= tick()) then
									task.spawn(function()
										pickedup[v] = tick() + 0.2
										bedwars.ClientHandler:Get(bedwars.PickupRemote):CallServerAsync({
											itemDrop = v
										}):andThen(function(suc)
											if suc then
												bedwars.SoundManager:playSound(bedwars.SoundList.PICKUP_ITEM_DROP)
											end
										end)
									end)
								end
							end
						end
						task.wait()
					until (not PickupRange.Enabled)
				end)
			end
		end
	})
	PickupRangeRange = PickupRange.CreateSlider({
		Name = "Range",
		Min = 1,
		Max = 10, 
		Function = function() end,
		Default = 10
	})
end)

runFunction(function()
	local BowExploit = {Enabled = false}
	local BowExploitTarget = {Value = "Mouse"}
	local BowExploitAutoShootFOV = {Value = 1000}
	local oldrealremote
	local noveloproj = {
		"fireball",
		"telepearl"
	}

	BowExploit = GuiLibrary.ObjectsThatCanBeSaved.UtilityWindow.Api.CreateOptionsButton({
		Name = "ProjectileExploit",
		Function = function(callback)
			if callback then 
				oldrealremote = bedwars.ClientConstructor.Function.new
				bedwars.ClientConstructor.Function.new = function(self, ind, ...)
					local res = oldrealremote(self, ind, ...)
					local oldRemote = res.instance
					if oldRemote and oldRemote.Name == bedwars.ProjectileRemote then 
						res.instance = {InvokeServer = function(self, shooting, proj, proj2, launchpos1, launchpos2, launchvelo, tag, tab1, ...) 
							local plr
							if BowExploitTarget.Value == "Mouse" then 
								plr = EntityNearMouse(10000)
							else
								plr = EntityNearPosition(BowExploitAutoShootFOV.Value, true)
							end
							if plr then	
								if not ({WhitelistFunctions:GetWhitelist(plr.Player)})[2] then 
									return oldRemote:InvokeServer(shooting, proj, proj2, launchpos1, launchpos2, launchvelo, tag, tab1, ...)
								end
		
								tab1.drawDurationSeconds = 1
								repeat
									task.wait(0.03)
									local offsetStartPos = plr.RootPart.CFrame.p - plr.RootPart.CFrame.lookVector
									local pos = plr.RootPart.Position
									local playergrav = workspace.Gravity
									local balloons = plr.Character:GetAttribute("InflatedBalloons")
									if balloons and balloons > 0 then 
										playergrav = (workspace.Gravity * (1 - ((balloons >= 4 and 1.2 or balloons >= 3 and 1 or 0.975))))
									end
									if plr.Character.PrimaryPart:FindFirstChild("rbxassetid://8200754399") then 
										playergrav = (workspace.Gravity * 0.3)
									end
									local newLaunchVelo = bedwars.ProjectileMeta[proj2].launchVelocity
									local shootpos, shootvelo = predictGravity(pos, plr.RootPart.Velocity, (pos - offsetStartPos).Magnitude / newLaunchVelo, plr, playergrav)
									if proj2 == "telepearl" then
										shootpos = pos
										shootvelo = Vector3.zero
									end
									local newlook = CFrame.new(offsetStartPos, shootpos) * CFrame.new(Vector3.new(-bedwars.BowConstantsTable.RelX, -bedwars.BowConstantsTable.RelY, -bedwars.BowConstantsTable.RelZ))
									shootpos = newlook.p + (newlook.lookVector * (offsetStartPos - shootpos).magnitude)
									local calculated = LaunchDirection(offsetStartPos, shootpos, newLaunchVelo, workspace.Gravity, false)
									if calculated then 
										launchvelo = calculated
										launchpos1 = offsetStartPos
										launchpos2 = offsetStartPos
										tab1.drawDurationSeconds = 1
									else
										break
									end
									if oldRemote:InvokeServer(shooting, proj, proj2, launchpos1, launchpos2, launchvelo, tag, tab1, workspace:GetServerTimeNow() - 0.045) then break end
								until false
							else
								return oldRemote:InvokeServer(shooting, proj, proj2, launchpos1, launchpos2, launchvelo, tag, tab1, ...)
							end
						end}
					end
					return res
				end
			else
				bedwars.ClientConstructor.Function.new = oldrealremote
				oldrealremote = nil
			end
		end
	})
	BowExploitTarget = BowExploit.CreateDropdown({
		Name = "Mode",
		List = {"Mouse", "Range"},
		Function = function() end
	})
	BowExploitAutoShootFOV = BowExploit.CreateSlider({
		Name = "FOV",
		Function = function() end,
		Min = 1,
		Max = 1000,
		Default = 1000
	})
end)

runFunction(function()
	local RavenTP = {Enabled = false}
	RavenTP = GuiLibrary.ObjectsThatCanBeSaved.UtilityWindow.Api.CreateOptionsButton({
		Name = "RavenTP",
		Function = function(callback)
			if callback then
				task.spawn(function()
					if getItem("raven") then
						local plr = EntityNearMouse(1000)
						if plr then
							local projectile = bedwars.ClientHandler:Get(bedwars.SpawnRavenRemote):CallServerAsync():andThen(function(projectile)
								if projectile then
									local projectilemodel = projectile
									if not projectilemodel then
										projectilemodel:GetPropertyChangedSignal("PrimaryPart"):Wait()
									end
									local bodyforce = Instance.new("BodyForce")
									bodyforce.Force = Vector3.new(0, projectilemodel.PrimaryPart.AssemblyMass * workspace.Gravity, 0)
									bodyforce.Name = "AntiGravity"
									bodyforce.Parent = projectilemodel.PrimaryPart
	
									if plr then
										projectilemodel:SetPrimaryPartCFrame(CFrame.new(plr.RootPart.CFrame.p, plr.RootPart.CFrame.p + gameCamera.CFrame.lookVector))
										task.wait(0.3)
										bedwars.RavenTable:detonateRaven()
									else
										warningNotification("RavenTP", "Player died before it could TP.", 3)
									end
								else
									warningNotification("RavenTP", "Raven on cooldown.", 3)
								end
							end)
						else
							warningNotification("RavenTP", "Player not found.", 3)
						end
					else
						warningNotification("RavenTP", "Raven not found.", 3)
					end
				end)
				RavenTP.ToggleButton(true)
			end
		end,
		HoverText = "Spawns and teleports a raven to a player\nnear your mouse."
	})
end)

runFunction(function()
	local tiered = {}
	local nexttier = {}

	for i,v in pairs(bedwars.ShopItems) do
		if type(v) == "table" then 
			if v.tiered then
				tiered[v.itemType] = v.tiered
			end
			if v.nextTier then
				nexttier[v.itemType] = v.nextTier
			end
		end
	end

	GuiLibrary.ObjectsThatCanBeSaved.UtilityWindow.Api.CreateOptionsButton({
		Name = "ShopTierBypass",
		Function = function(callback) 
			if callback then
				for i,v in pairs(bedwars.ShopItems) do
					if type(v) == "table" then 
						v.tiered = nil
						v.nextTier = nil
					end
				end
			else
				for i,v in pairs(bedwars.ShopItems) do
					if type(v) == "table" then 
						if tiered[v.itemType] then
							v.tiered = tiered[v.itemType]
						end
						if nexttier[v.itemType] then
							v.nextTier = nexttier[v.itemType]
						end
					end
				end
			end
		end,
		HoverText = "Allows you to access tiered items early."
	})
end)

local lagbackedaftertouch = false
runFunction(function()
	local AntiVoidPart
	local AntiVoidConnection
	local AntiVoidMode = {Value = "Normal"}
	local AntiVoidMoveMode = {Value = "Normal"}
	local AntiVoid = {Enabled = false}
	local AntiVoidTransparent = {Value = 50}
	local AntiVoidColor = {Hue = 1, Sat = 1, Value = 0.55}
	local lastvalidpos

	local function closestpos(block)
		local startpos = block.Position - (block.Size / 2) + Vector3.new(1.5, 1.5, 1.5)
		local endpos = block.Position + (block.Size / 2) - Vector3.new(1.5, 1.5, 1.5)
		local newpos = block.Position + (entityLibrary.character.HumanoidRootPart.Position - block.Position)
		return Vector3.new(math.clamp(newpos.X, startpos.X, endpos.X), endpos.Y + 3, math.clamp(newpos.Z, startpos.Z, endpos.Z))
	end

	local function getclosesttop(newmag)
		local closest, closestmag = nil, newmag * 3
		if entityLibrary.isAlive then 
			local tops = {}
			for i,v in pairs(bedwarsStore.blocks) do 
				local close = getScaffold(closestpos(v), false)
				if getPlacedBlock(close) then continue end
				if close.Y < entityLibrary.character.HumanoidRootPart.Position.Y then continue end
				if (close - entityLibrary.character.HumanoidRootPart.Position).magnitude <= newmag * 3 then 
					table.insert(tops, close)
				end
			end
			for i,v in pairs(tops) do 
				local mag = (v - entityLibrary.character.HumanoidRootPart.Position).magnitude
				if mag <= closestmag then 
					closest = v
					closestmag = mag
				end
			end
		end
		return closest
	end

	local antivoidypos = 0
	local antivoiding = false
	AntiVoid = GuiLibrary.ObjectsThatCanBeSaved.WorldWindow.Api.CreateOptionsButton({
		Name = "AntiVoid", 
		Function = function(callback)
			if callback then
				task.spawn(function()
					AntiVoidPart = Instance.new("Part")
					AntiVoidPart.CanCollide = AntiVoidMode.Value == "Collide"
					AntiVoidPart.Size = Vector3.new(10000, 1, 10000)
					AntiVoidPart.Anchored = true
					AntiVoidPart.Material = Enum.Material.Neon
					AntiVoidPart.Color = Color3.fromHSV(AntiVoidColor.Hue, AntiVoidColor.Sat, AntiVoidColor.Value)
					AntiVoidPart.Transparency = 1 - (AntiVoidTransparent.Value / 100)
					AntiVoidPart.Position = Vector3.new(0, antivoidypos, 0)
					AntiVoidPart.Parent = workspace
					if AntiVoidMoveMode.Value == "Classic" and antivoidypos == 0 then 
						AntiVoidPart.Parent = nil
					end
					AntiVoidConnection = AntiVoidPart.Touched:Connect(function(touchedpart)
						if touchedpart.Parent == lplr.Character and entityLibrary.isAlive then
							if (not antivoiding) and (not GuiLibrary.ObjectsThatCanBeSaved.FlyOptionsButton.Api.Enabled) and entityLibrary.character.Humanoid.Health > 0 and AntiVoidMode.Value ~= "Collide" then
								if AntiVoidMode.Value == "Velocity" then
									entityLibrary.character.HumanoidRootPart.Velocity = Vector3.new(entityLibrary.character.HumanoidRootPart.Velocity.X, 100, entityLibrary.character.HumanoidRootPart.Velocity.Z)
								else
									antivoiding = true
									local pos = getclosesttop(1000)
									if pos then
										local lastTeleport = lplr:GetAttribute("LastTeleported")
										RunLoops:BindToHeartbeat("AntiVoid", function(dt)
											if entityLibrary.isAlive and entityLibrary.character.Humanoid.Health > 0 and isnetworkowner(entityLibrary.character.HumanoidRootPart) and (entityLibrary.character.HumanoidRootPart.Position - pos).Magnitude > 1 and AntiVoid.Enabled and lplr:GetAttribute("LastTeleported") == lastTeleport then 
												local hori1 = Vector3.new(entityLibrary.character.HumanoidRootPart.Position.X, 0, entityLibrary.character.HumanoidRootPart.Position.Z)
												local hori2 = Vector3.new(pos.X, 0, pos.Z)
												local newpos = (hori2 - hori1).Unit
												local realnewpos = CFrame.new(newpos == newpos and entityLibrary.character.HumanoidRootPart.CFrame.p + (newpos * ((3 + getSpeed()) * dt)) or Vector3.zero)
												entityLibrary.character.HumanoidRootPart.CFrame = CFrame.new(realnewpos.p.X, pos.Y, realnewpos.p.Z)
												antivoidvelo = newpos == newpos and newpos * 20 or Vector3.zero
												entityLibrary.character.HumanoidRootPart.Velocity = Vector3.new(antivoidvelo.X, entityLibrary.character.HumanoidRootPart.Velocity.Y, antivoidvelo.Z)
												if getPlacedBlock((entityLibrary.character.HumanoidRootPart.CFrame.p - Vector3.new(0, 1, 0)) + entityLibrary.character.HumanoidRootPart.Velocity.Unit) or getPlacedBlock(entityLibrary.character.HumanoidRootPart.CFrame.p + Vector3.new(0, 3)) then
													pos = pos + Vector3.new(0, 1, 0)
												end
											else
												RunLoops:UnbindFromHeartbeat("AntiVoid")
												antivoidvelo = nil
												antivoiding = false
											end
										end)
									else
										entityLibrary.character.HumanoidRootPart.CFrame += Vector3.new(0, 100000, 0)
										antivoiding = false
									end
								end
							end
						end
					end)
					repeat
						if entityLibrary.isAlive and AntiVoidMoveMode.Value == "Normal" then 
							local ray = workspace:Raycast(entityLibrary.character.HumanoidRootPart.Position, Vector3.new(0, -1000, 0), bedwarsStore.blockRaycast)
							if ray or GuiLibrary.ObjectsThatCanBeSaved.FlyOptionsButton.Api.Enabled or GuiLibrary.ObjectsThatCanBeSaved.InfiniteFlyOptionsButton.Api.Enabled then 
								AntiVoidPart.Position = entityLibrary.character.HumanoidRootPart.Position - Vector3.new(0, 21, 0)
							end
						end
						task.wait()
					until (not AntiVoid.Enabled)
				end)
			else
				if AntiVoidConnection then AntiVoidConnection:Disconnect() end
				if AntiVoidPart then
					AntiVoidPart:Destroy() 
				end
			end
		end, 
		HoverText = "Gives you a chance to get on land (Bouncing Twice, abusing, or bad luck will lead to lagbacks)"
	})
	AntiVoidMoveMode = AntiVoid.CreateDropdown({
		Name = "Position Mode",
		Function = function(val) 
			if val == "Classic" then 
				task.spawn(function()
					repeat task.wait() until bedwarsStore.matchState ~= 0 or not vapeInjected
					if vapeInjected and AntiVoidMoveMode.Value == "Classic" and antivoidypos == 0 and AntiVoid.Enabled then
						local lowestypos = 99999
						for i,v in pairs(bedwarsStore.blocks) do 
							local newray = workspace:Raycast(v.Position + Vector3.new(0, 800, 0), Vector3.new(0, -1000, 0), bedwarsStore.blockRaycast)
							if i % 200 == 0 then 
								task.wait(0.06)
							end
							if newray and newray.Position.Y <= lowestypos then
								lowestypos = newray.Position.Y
							end
						end
						antivoidypos = lowestypos - 8
					end
					if AntiVoidPart then 
						AntiVoidPart.Position = Vector3.new(0, antivoidypos, 0)
						AntiVoidPart.Parent = workspace
					end
				end)
			end
		end,
		List = {"Normal", "Classic"}
	})
	AntiVoidMode = AntiVoid.CreateDropdown({
		Name = "Move Mode",
		Function = function(val) 
			if AntiVoidPart then 
				AntiVoidPart.CanCollide = val == "Collide"
			end
		end,
		List = {"Normal", "Collide", "Velocity"}
	})
	AntiVoidTransparent = AntiVoid.CreateSlider({
		Name = "Invisible",
		Min = 1,
		Max = 100,
		Default = 50,
		Function = function(val) 
			if AntiVoidPart then
				AntiVoidPart.Transparency = 1 - (val / 100)
			end
		end,
	})
	AntiVoidColor = AntiVoid.CreateColorSlider({
		Name = "Color",
		Function = function(h, s, v) 
			if AntiVoidPart then
				AntiVoidPart.Color = Color3.fromHSV(h, s, v)
			end
		end
	})
end)

runFunction(function()
	local oldenable2
	local olddisable2
	local oldhitblock
	local blockplacetable2 = {}
	local blockplaceenabled2 = false

	local AutoTool = GuiLibrary.ObjectsThatCanBeSaved.WorldWindow.Api.CreateOptionsButton({
		Name = "AutoTool",
		Function = function(callback)
			if callback then
				oldenable2 = bedwars.BlockBreaker.enable
				olddisable2 = bedwars.BlockBreaker.disable
				oldhitblock = bedwars.BlockBreaker.hitBlock
				bedwars.BlockBreaker.enable = function(Self, tab)
					blockplaceenabled2 = true
					blockplacetable2 = Self
					return oldenable2(Self, tab)
				end
				bedwars.BlockBreaker.disable = function(Self)
					blockplaceenabled2 = false
					return olddisable2(Self)
				end
				bedwars.BlockBreaker.hitBlock = function(...)
					if entityLibrary.isAlive and (GuiLibrary.ObjectsThatCanBeSaved["Lobby CheckToggle"].Api.Enabled == false or bedwarsStore.matchState ~= 0) and blockplaceenabled2 then
						local mouseinfo = blockplacetable2.clientManager:getBlockSelector():getMouseInfo(0)
						if mouseinfo and mouseinfo.target and not mouseinfo.target.blockInstance:GetAttribute("NoBreak") and not mouseinfo.target.blockInstance:GetAttribute("Team"..(lplr:GetAttribute("Team") or 0).."NoBreak") then
							if switchToAndUseTool(mouseinfo.target.blockInstance, true) then
								return
							end
						end
					end
					return oldhitblock(...)
				end
			else
				RunLoops:UnbindFromRenderStep("AutoTool")
				bedwars.BlockBreaker.enable = oldenable2
				bedwars.BlockBreaker.disable = olddisable2
				bedwars.BlockBreaker.hitBlock = oldhitblock
				oldenable2 = nil
				olddisable2 = nil
				oldhitblock = nil
			end
		end,
		HoverText = "Automatically swaps your hand to the appropriate tool."
	})
end)

runFunction(function()
	local BedProtector = {Enabled = false}
	local bedprotector1stlayer = {
		Vector3.new(0, 3, 0),
		Vector3.new(0, 3, 3),
		Vector3.new(3, 0, 0),
		Vector3.new(3, 0, 3),
		Vector3.new(-3, 0, 0),
		Vector3.new(-3, 0, 3),
		Vector3.new(0, 0, 6),
		Vector3.new(0, 0, -3)
	}
	local bedprotector2ndlayer = {
		Vector3.new(0, 6, 0),
		Vector3.new(0, 6, 3),
		Vector3.new(0, 3, 6),
		Vector3.new(0, 3, -3),
		Vector3.new(0, 0, -6),
		Vector3.new(0, 0, 9),
		Vector3.new(3, 3, 0),
		Vector3.new(3, 3, 3),
		Vector3.new(3, 0, 6),
		Vector3.new(3, 0, -3),
		Vector3.new(6, 0, 3),
		Vector3.new(6, 0, 0),
		Vector3.new(-3, 3, 3),
		Vector3.new(-3, 3, 0),
		Vector3.new(-6, 0, 3),
		Vector3.new(-6, 0, 0),
		Vector3.new(-3, 0, 6),
		Vector3.new(-3, 0, -3),
	}

	local function getItemFromList(list)
		local selecteditem
		for i3,v3 in pairs(list) do
			local item = getItem(v3)
			if item then 
				selecteditem = item
				break
			end
		end
		return selecteditem
	end

	local function placelayer(layertab, obj, selecteditems)
		for i2,v2 in pairs(layertab) do
			local selecteditem = getItemFromList(selecteditems)
			if selecteditem then
				bedwars.placeBlock(obj.Position + v2, selecteditem.itemType)
			else
				return false
			end
		end
		return true
	end

	local bedprotectorrange = {Value = 1}
	BedProtector = GuiLibrary.ObjectsThatCanBeSaved.WorldWindow.Api.CreateOptionsButton({
		Name = "BedProtector",
		Function = function(callback)
            if callback then
                task.spawn(function()
                    for i, obj in pairs(collectionService:GetTagged("bed")) do
                        if entityLibrary.isAlive and obj:GetAttribute("Team"..(lplr:GetAttribute("Team") or 0).."NoBreak") and obj.Parent ~= nil then
                            if (entityLibrary.character.HumanoidRootPart.Position - obj.Position).magnitude <= bedprotectorrange.Value then
                                local firstlayerplaced = placelayer(bedprotector1stlayer, obj, {"obsidian", "stone_brick", "plank_oak", getWool()})
							    if firstlayerplaced then
									placelayer(bedprotector2ndlayer, obj, {getWool()})
							    end
                            end
                            break
                        end
                    end
                    BedProtector.ToggleButton(false)
                end)
            end
		end,
		HoverText = "Automatically places a bed defense (Toggle)"
	})
	bedprotectorrange = BedProtector.CreateSlider({
		Name = "Place range",
		Min = 1, 
		Max = 20, 
		Function = function(val) end, 
		Default = 20
	})
end)

runFunction(function()
	local Nuker = {Enabled = false}
	local nukerrange = {Value = 1}
	local nukereffects = {Enabled = false}
	local nukeranimation = {Enabled = false}
	local nukernofly = {Enabled = false}
	local nukerlegit = {Enabled = false}
	local nukerown = {Enabled = false}
    local nukerluckyblock = {Enabled = false}
	local nukerironore = {Enabled = false}
    local nukerbeds = {Enabled = false}
	local nukercustom = {RefreshValues = function() end, ObjectList = {}}
    local luckyblocktable = {}

	Nuker = GuiLibrary.ObjectsThatCanBeSaved.WorldWindow.Api.CreateOptionsButton({
		Name = "Nuker",
		Function = function(callback)
            if callback then
				for i,v in pairs(bedwarsStore.blocks) do
					if table.find(nukercustom.ObjectList, v.Name) or (nukerluckyblock.Enabled and v.Name:find("lucky")) or (nukerironore.Enabled and v.Name == "iron_ore") then
						table.insert(luckyblocktable, v)
					end
				end
				table.insert(Nuker.Connections, collectionService:GetInstanceAddedSignal("block"):Connect(function(v)
                    if table.find(nukercustom.ObjectList, v.Name) or (nukerluckyblock.Enabled and v.Name:find("lucky")) or (nukerironore.Enabled and v.Name == "iron_ore") then
                        table.insert(luckyblocktable, v)
                    end
                end))
                table.insert(Nuker.Connections, collectionService:GetInstanceRemovedSignal("block"):Connect(function(v)
                    if table.find(nukercustom.ObjectList, v.Name) or (nukerluckyblock.Enabled and v.Name:find("lucky")) or (nukerironore.Enabled and v.Name == "iron_ore") then
                        table.remove(luckyblocktable, table.find(luckyblocktable, v))
                    end
                end))
                task.spawn(function()
                    repeat
						if (not nukernofly.Enabled or not GuiLibrary.ObjectsThatCanBeSaved.FlyOptionsButton.Api.Enabled) then
							local broke = not entityLibrary.isAlive
							local tool = (not nukerlegit.Enabled) and {Name = "wood_axe"} or bedwarsStore.localHand.tool
							if nukerbeds.Enabled then
								for i, obj in pairs(collectionService:GetTagged("bed")) do
									if broke then break end
									if obj.Parent ~= nil then
										if obj:GetAttribute("BedShieldEndTime") then 
											if obj:GetAttribute("BedShieldEndTime") > workspace:GetServerTimeNow() then continue end
										end
										if ((entityLibrary.LocalPosition or entityLibrary.character.HumanoidRootPart.Position) - obj.Position).magnitude <= nukerrange.Value then
											if tool and bedwars.ItemTable[tool.Name].breakBlock and bedwars.BlockController:isBlockBreakable({blockPosition = obj.Position / 3}, lplr) then
												local res, amount = getBestBreakSide(obj.Position)
												local res2, amount2 = getBestBreakSide(obj.Position + Vector3.new(0, 0, 3))
												broke = true
												bedwars.breakBlock((amount < amount2 and obj.Position or obj.Position + Vector3.new(0, 0, 3)), nukereffects.Enabled, (amount < amount2 and res or res2), false, nukeranimation.Enabled)
												break
											end
										end
									end
								end
							end
							broke = broke and not entityLibrary.isAlive
							for i, obj in pairs(luckyblocktable) do
								if broke then break end
								if entityLibrary.isAlive then
									if obj and obj.Parent ~= nil then
										if ((entityLibrary.LocalPosition or entityLibrary.character.HumanoidRootPart.Position) - obj.Position).magnitude <= nukerrange.Value and (nukerown.Enabled or obj:GetAttribute("PlacedByUserId") ~= lplr.UserId) then
											if tool and bedwars.ItemTable[tool.Name].breakBlock and bedwars.BlockController:isBlockBreakable({blockPosition = obj.Position / 3}, lplr) then
												bedwars.breakBlock(obj.Position, nukereffects.Enabled, getBestBreakSide(obj.Position), true, nukeranimation.Enabled)
												break
											end
										end
									end
								end
							end
						end
						task.wait()
                    until (not Nuker.Enabled)
                end)
            else
                luckyblocktable = {}
            end
		end,
		HoverText = "Automatically destroys beds & luckyblocks around you."
	})
	nukerrange = Nuker.CreateSlider({
		Name = "Break range",
		Min = 1, 
		Max = 30, 
		Function = function(val) end, 
		Default = 30
	})
	nukerlegit = Nuker.CreateToggle({
		Name = "Hand Check",
		Function = function() end
	})
	nukereffects = Nuker.CreateToggle({
		Name = "Show HealthBar & Effects",
		Function = function(callback) 
			if not callback then
				bedwars.BlockBreaker.healthbarMaid:DoCleaning()
			end
		 end,
		Default = true
	})
	nukeranimation = Nuker.CreateToggle({
		Name = "Break Animation",
		Function = function() end
	})
	nukerown = Nuker.CreateToggle({
		Name = "Self Break",
		Function = function() end,
	})
    nukerbeds = Nuker.CreateToggle({
		Name = "Break Beds",
		Function = function(callback) end,
		Default = true
	})
	nukernofly = Nuker.CreateToggle({
		Name = "Fly Disable",
		Function = function() end
	})
    nukerluckyblock = Nuker.CreateToggle({
		Name = "Break LuckyBlocks",
		Function = function(callback) 
			if callback then 
				luckyblocktable = {}
				for i,v in pairs(bedwarsStore.blocks) do
					if table.find(nukercustom.ObjectList, v.Name) or (nukerluckyblock.Enabled and v.Name:find("lucky")) or (nukerironore.Enabled and v.Name == "iron_ore") then
						table.insert(luckyblocktable, v)
					end
				end
			else
				luckyblocktable = {}
			end
		 end,
		Default = true
	})
	nukerironore = Nuker.CreateToggle({
		Name = "Break IronOre",
		Function = function(callback) 
			if callback then 
				luckyblocktable = {}
				for i,v in pairs(bedwarsStore.blocks) do
					if table.find(nukercustom.ObjectList, v.Name) or (nukerluckyblock.Enabled and v.Name:find("lucky")) or (nukerironore.Enabled and v.Name == "iron_ore") then
						table.insert(luckyblocktable, v)
					end
				end
			else
				luckyblocktable = {}
			end
		end
	})
	nukercustom = Nuker.CreateTextList({
		Name = "NukerList",
		TempText = "block (tesla_trap)",
		AddFunction = function()
			luckyblocktable = {}
			for i,v in pairs(bedwarsStore.blocks) do
				if table.find(nukercustom.ObjectList, v.Name) or (nukerluckyblock.Enabled and v.Name:find("lucky")) then
					table.insert(luckyblocktable, v)
				end
			end
		end
	})
end)


runFunction(function()
	local controlmodule = require(lplr.PlayerScripts.PlayerModule).controls
	local oldmove
	local SafeWalk = {Enabled = false}
	local SafeWalkMode = {Value = "Optimized"}
	SafeWalk = GuiLibrary.ObjectsThatCanBeSaved.WorldWindow.Api.CreateOptionsButton({
		Name = "SafeWalk",
		Function = function(callback)
			if callback then
				oldmove = controlmodule.moveFunction
				controlmodule.moveFunction = function(Self, vec, facecam)
					if entityLibrary.isAlive and (not Scaffold.Enabled) and (not GuiLibrary.ObjectsThatCanBeSaved.FlyOptionsButton.Api.Enabled) then
						if SafeWalkMode.Value == "Optimized" then 
							local newpos = (entityLibrary.character.HumanoidRootPart.Position - Vector3.new(0, entityLibrary.character.Humanoid.HipHeight * 2, 0))
							local ray = getPlacedBlock(newpos + Vector3.new(0, -6, 0) + vec)
							for i = 1, 50 do 
								if ray then break end
								ray = getPlacedBlock(newpos + Vector3.new(0, -i * 6, 0) + vec)
							end
							local ray2 = getPlacedBlock(newpos)
							if ray == nil and ray2 then
								local ray3 = getPlacedBlock(newpos + vec) or getPlacedBlock(newpos + (vec * 1.5))
								if ray3 == nil then 
									vec = Vector3.zero
								end
							end
						else
							local ray = workspace:Raycast(entityLibrary.character.HumanoidRootPart.Position + vec, Vector3.new(0, -1000, 0), bedwarsStore.blockRaycast)
							local ray2 = workspace:Raycast(entityLibrary.character.HumanoidRootPart.Position, Vector3.new(0, -entityLibrary.character.Humanoid.HipHeight * 2, 0), bedwarsStore.blockRaycast)
							if ray == nil and ray2 then
								local ray3 = workspace:Raycast(entityLibrary.character.HumanoidRootPart.Position + (vec * 1.8), Vector3.new(0, -1000, 0), bedwarsStore.blockRaycast)
								if ray3 == nil then 
									vec = Vector3.zero
								end
							end
						end
					end
					return oldmove(Self, vec, facecam)
				end
			else
				controlmodule.moveFunction = oldmove
			end
		end,
		HoverText = "lets you not walk off because you are bad"
	})
	SafeWalkMode = SafeWalk.CreateDropdown({
		Name = "Mode",
		List = {"Optimized", "Accurate"},
		Function = function() end
	})
end)

runFunction(function()
	local Schematica = {Enabled = false}
	local SchematicaBox = {Value = ""}
	local SchematicaTransparency = {Value = 30}
	local positions = {}
	local tempfolder
	local tempgui
	local aroundpos = {
		[1] = Vector3.new(0, 3, 0),
		[2] = Vector3.new(-3, 3, 0),
		[3] = Vector3.new(-3, -0, 0),
		[4] = Vector3.new(-3, -3, 0),
		[5] = Vector3.new(0, -3, 0),
		[6] = Vector3.new(3, -3, 0),
		[7] = Vector3.new(3, -0, 0),
		[8] = Vector3.new(3, 3, 0),
		[9] = Vector3.new(0, 3, -3),
		[10] = Vector3.new(-3, 3, -3),
		[11] = Vector3.new(-3, -0, -3),
		[12] = Vector3.new(-3, -3, -3),
		[13] = Vector3.new(0, -3, -3),
		[14] = Vector3.new(3, -3, -3),
		[15] = Vector3.new(3, -0, -3),
		[16] = Vector3.new(3, 3, -3),
		[17] = Vector3.new(0, 3, 3),
		[18] = Vector3.new(-3, 3, 3),
		[19] = Vector3.new(-3, -0, 3),
		[20] = Vector3.new(-3, -3, 3),
		[21] = Vector3.new(0, -3, 3),
		[22] = Vector3.new(3, -3, 3),
		[23] = Vector3.new(3, -0, 3),
		[24] = Vector3.new(3, 3, 3),
		[25] = Vector3.new(0, -0, 3),
		[26] = Vector3.new(0, -0, -3)
	}

	local function isNearBlock(pos)
		for i,v in pairs(aroundpos) do
			if getPlacedBlock(pos + v) then
				return true
			end
		end
		return false
	end

	local function gethighlightboxatpos(pos)
		if tempfolder then
			for i,v in pairs(tempfolder:GetChildren()) do
				if v.Position == pos then
					return v 
				end
			end
		end
		return nil
	end

	local function removeduplicates(tab)
		local actualpositions = {}
		for i,v in pairs(tab) do
			if table.find(actualpositions, Vector3.new(v.X, v.Y, v.Z)) == nil then
				table.insert(actualpositions, Vector3.new(v.X, v.Y, v.Z))
			else
				table.remove(tab, i)
			end
			if v.blockType == "start_block" then
				table.remove(tab, i)
			end
		end
	end

	local function rotate(tab)
		for i,v in pairs(tab) do
			local radvec, radius = entityLibrary.character.HumanoidRootPart.CFrame:ToAxisAngle()
			radius = (radius * 57.2957795)
			radius = math.round(radius / 90) * 90
			if radvec == Vector3.new(0, -1, 0) and radius == 90 then
				radius = 270
			end
			local rot = CFrame.new() * CFrame.fromAxisAngle(Vector3.new(0, 1, 0), math.rad(radius))
			local newpos = CFrame.new(0, 0, 0) * rot * CFrame.new(Vector3.new(v.X, v.Y, v.Z))
			v.X = math.round(newpos.p.X)
			v.Y = math.round(newpos.p.Y)
			v.Z = math.round(newpos.p.Z)
		end
	end

	local function getmaterials(tab)
		local materials = {}
		for i,v in pairs(tab) do
			materials[v.blockType] = (materials[v.blockType] and materials[v.blockType] + 1 or 1)
		end
		return materials
	end

	local function schemplaceblock(pos, blocktype, removefunc)
		local fail = false
		local ok = bedwars.RuntimeLib.try(function()
			bedwars.ClientHandlerDamageBlock:Get("PlaceBlock"):CallServer({
				blockType = blocktype or getWool(),
				position = bedwars.BlockController:getBlockPosition(pos)
			})
		end, function(thing)
			fail = true
		end)
		if (not fail) and bedwars.BlockController:getStore():getBlockAt(bedwars.BlockController:getBlockPosition(pos)) then
			removefunc()
		end
	end

	Schematica = GuiLibrary.ObjectsThatCanBeSaved.WorldWindow.Api.CreateOptionsButton({
		Name = "Schematica",
		Function = function(callback)
			if callback then
				local mouseinfo = bedwars.BlockEngine:getBlockSelector():getMouseInfo(0)
				if mouseinfo and isfile(SchematicaBox.Value) then
					tempfolder = Instance.new("Folder")
					tempfolder.Parent = workspace
					local newpos = mouseinfo.placementPosition * 3
					positions = game:GetService("HttpService"):JSONDecode(readfile(SchematicaBox.Value))
					if positions.blocks == nil then
						positions = {blocks = positions}
					end
					rotate(positions.blocks)
					removeduplicates(positions.blocks)
					if positions["start_block"] == nil then
						bedwars.placeBlock(newpos)
					end
					for i2,v2 in pairs(positions.blocks) do
						local texturetxt = bedwars.ItemTable[(v2.blockType == "wool_white" and getWool() or v2.blockType)].block.greedyMesh.textures[1]
						local newerpos = (newpos + Vector3.new(v2.X, v2.Y, v2.Z))
						local block = Instance.new("Part")
						block.Position = newerpos
						block.Size = Vector3.new(3, 3, 3)
						block.CanCollide = false
						block.Transparency = (SchematicaTransparency.Value == 10 and 0 or 1)
						block.Anchored = true
						block.Parent = tempfolder
						for i3,v3 in pairs(Enum.NormalId:GetEnumItems()) do
							local texture = Instance.new("Texture")
							texture.Face = v3
							texture.Texture = texturetxt
							texture.Name = tostring(v3)
							texture.Transparency = (SchematicaTransparency.Value == 10 and 0 or (1 / SchematicaTransparency.Value))
							texture.Parent = block
						end
					end
					task.spawn(function()
						repeat
							task.wait(.1)
							if not Schematica.Enabled then break end
							for i,v in pairs(positions.blocks) do
								local newerpos = (newpos + Vector3.new(v.X, v.Y, v.Z))
								if entityLibrary.isAlive and (entityLibrary.character.HumanoidRootPart.Position - newerpos).magnitude <= 30 and isNearBlock(newerpos) and bedwars.BlockController:isAllowedPlacement(lplr, getWool(), newerpos / 3, 0) then
									schemplaceblock(newerpos, (v.blockType == "wool_white" and getWool() or v.blockType), function()
										table.remove(positions.blocks, i)
										if gethighlightboxatpos(newerpos) then
											gethighlightboxatpos(newerpos):Remove()
										end
									end)
								end
							end
						until #positions.blocks == 0 or (not Schematica.Enabled)
						if Schematica.Enabled then 
							Schematica.ToggleButton(false)
							warningNotification("Schematica", "Finished Placing Blocks", 4)
						end
					end)
				end
			else
				positions = {}
				if tempfolder then
					tempfolder:Remove()
				end
			end
		end,
		HoverText = "Automatically places structure at mouse position."
	})
	SchematicaBox = Schematica.CreateTextBox({
		Name = "File",
		TempText = "File (location in workspace)",
		FocusLost = function(enter) 
			local suc, res = pcall(function() return game:GetService("HttpService"):JSONDecode(readfile(SchematicaBox.Value)) end)
			if tempgui then
				tempgui:Remove()
			end
			if suc then
				if res.blocks == nil then
					res = {blocks = res}
				end
				removeduplicates(res.blocks)
				tempgui = Instance.new("Frame")
				tempgui.Name = "SchematicListOfBlocks"
				tempgui.BackgroundTransparency = 1
				tempgui.LayoutOrder = 9999
				tempgui.Parent = SchematicaBox.Object.Parent
				local uilistlayoutschmatica = Instance.new("UIListLayout")
				uilistlayoutschmatica.Parent = tempgui
				uilistlayoutschmatica:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(function()
					tempgui.Size = UDim2.new(0, 220, 0, uilistlayoutschmatica.AbsoluteContentSize.Y)
				end)
				for i4,v4 in pairs(getmaterials(res.blocks)) do
					local testframe = Instance.new("Frame")
					testframe.Size = UDim2.new(0, 220, 0, 40)
					testframe.BackgroundTransparency = 1
					testframe.Parent = tempgui
					local testimage = Instance.new("ImageLabel")
					testimage.Size = UDim2.new(0, 40, 0, 40)
					testimage.Position = UDim2.new(0, 3, 0, 0)
					testimage.BackgroundTransparency = 1
					testimage.Image = bedwars.getIcon({itemType = i4}, true)
					testimage.Parent = testframe
					local testtext = Instance.new("TextLabel")
					testtext.Size = UDim2.new(1, -50, 0, 40)
					testtext.Position = UDim2.new(0, 50, 0, 0)
					testtext.TextSize = 20
					testtext.Text = v4
					testtext.Font = Enum.Font.SourceSans
					testtext.TextXAlignment = Enum.TextXAlignment.Left
					testtext.TextColor3 = Color3.new(1, 1, 1)
					testtext.BackgroundTransparency = 1
					testtext.Parent = testframe
				end
			end
		end
	})
	SchematicaTransparency = Schematica.CreateSlider({
		Name = "Transparency",
		Min = 0,
		Max = 10,
		Default = 7,
		Function = function()
			if tempfolder then
				for i2,v2 in pairs(tempfolder:GetChildren()) do
					v2.Transparency = (SchematicaTransparency.Value == 10 and 0 or 1)
					for i3,v3 in pairs(v2:GetChildren()) do
						v3.Transparency = (SchematicaTransparency.Value == 10 and 0 or (1 / SchematicaTransparency.Value))
					end
				end
			end
		end
	})
end)

runFunction(function()
    local Disabler = {Enabled = false}
    Disabler = GuiLibrary.ObjectsThatCanBeSaved.UtilityWindow.Api.CreateOptionsButton({
        Name = "FirewallBypass",
        Function = function(callback)
            if callback then 
				task.spawn(function()
					repeat
						task.wait()
						local item = getItemNear("scythe")
						if item and lplr.Character.HandInvItem.Value == item.tool and bedwars.CombatController then 
							bedwars.ClientHandler:Get("ScytheDash"):SendToServer({direction = Vector3.new(9e9, 9e9, 9e9)})
							if entityLibrary.isAlive and entityLibrary.character.Head.Transparency ~= 0 then
								bedwarsStore.scythe = tick() + 1
							end
						end
					until (not Disabler.Enabled)
				end)
            end
        end,
		HoverText = "Float disabler with scythe"
    })
end)

runFunction(function()
	bedwarsStore.TPString = shared.vapeoverlay or nil
	local origtpstring = bedwarsStore.TPString
	local Overlay = GuiLibrary.CreateCustomWindow({
		Name = "Overlay",
		Icon = "vape/assets/TargetIcon1.png",
		IconSize = 16
	})
	local overlayframe = Instance.new("Frame")
	overlayframe.BackgroundColor3 = Color3.fromRGB(20, 20, 20)
	overlayframe.Size = UDim2.new(0, 200, 0, 120)
	overlayframe.Position = UDim2.new(0, 0, 0, 5)
	overlayframe.Parent = Overlay.GetCustomChildren()
	local overlayframe2 = Instance.new("Frame")
	overlayframe2.Size = UDim2.new(1, 0, 0, 10)
	overlayframe2.Position = UDim2.new(0, 0, 0, -5)
	overlayframe2.Parent = overlayframe
	local overlayframe3 = Instance.new("Frame")
	overlayframe3.BackgroundColor3 = Color3.fromRGB(20, 20, 20)
	overlayframe3.Size = UDim2.new(1, 0, 0, 6)
	overlayframe3.Position = UDim2.new(0, 0, 0, 6)
	overlayframe3.BorderSizePixel = 0
	overlayframe3.Parent = overlayframe2
	local oldguiupdate = GuiLibrary.UpdateUI
	GuiLibrary.UpdateUI = function(h, s, v, ...)
		overlayframe2.BackgroundColor3 = Color3.fromHSV(h, s, v)
		return oldguiupdate(h, s, v, ...)
	end
	local framecorner1 = Instance.new("UICorner")
	framecorner1.CornerRadius = UDim.new(0, 5)
	framecorner1.Parent = overlayframe
	local framecorner2 = Instance.new("UICorner")
	framecorner2.CornerRadius = UDim.new(0, 5)
	framecorner2.Parent = overlayframe2
	local label = Instance.new("TextLabel")
	label.Size = UDim2.new(1, -7, 1, -5)
	label.TextXAlignment = Enum.TextXAlignment.Left
	label.TextYAlignment = Enum.TextYAlignment.Top
	label.Font = Enum.Font.Arial
	label.LineHeight = 1.2
	label.BackgroundColor3 = Color3.fromRGB(20, 20, 20)
	label.TextSize = 16
	label.Text = ""
	label.BackgroundTransparency = 1
	label.TextColor3 = Color3.fromRGB(200, 200, 200)
	label.Position = UDim2.new(0, 7, 0, 5)
	label.Parent = overlayframe
	local OverlayFonts = {"Arial"}
	for i,v in pairs(Enum.Font:GetEnumItems()) do 
		if v.Name ~= "Arial" then
			table.insert(OverlayFonts, v.Name)
		end
	end
	local OverlayFont = Overlay.CreateDropdown({
		Name = "Font",
		List = OverlayFonts,
		Function = function(val)
			label.Font = Enum.Font[val]
		end
	})
	OverlayFont.Bypass = true
	Overlay.Bypass = true
	local overlayconnections = {}
	local oldnetworkowner
	local teleported = {}
	local teleported2 = {}
	local teleportedability = {}
	local teleportconnections = {}
	local pinglist = {}
	local fpslist = {}
	local matchstatechanged = 0
	local mapname = "Unknown"
	local overlayenabled = false
	
	task.spawn(function()
		pcall(function()
			mapname = workspace:WaitForChild("Map"):WaitForChild("Worlds"):GetChildren()[1].Name
			mapname = string.gsub(string.split(mapname, "_")[2] or mapname, "-", "") or "Blank"
		end)
	end)

	local function didpingspike()
		local currentpingcheck = pinglist[1] or math.floor(tonumber(game:GetService("Stats"):FindFirstChild("PerformanceStats").Ping:GetValue()))
		for i,v in pairs(pinglist) do 
			if v ~= currentpingcheck and math.abs(v - currentpingcheck) >= 100 then 
				return currentpingcheck.." => "..v.." ping"
			else
				currentpingcheck = v
			end
		end
		return nil
	end

	local function notlasso()
		for i,v in pairs(collectionService:GetTagged("LassoHooked")) do 
			if v == lplr.Character then 
				return false
			end
		end
		return true
	end
	local matchstatetick = tick()

	GuiLibrary.ObjectsThatCanBeSaved.GUIWindow.Api.CreateCustomToggle({
		Name = "Overlay", 
		Icon = "vape/assets/TargetIcon1.png", 
		Function = function(callback)
			overlayenabled = callback
			Overlay.SetVisible(callback) 
			if callback then 
				table.insert(overlayconnections, bedwars.ClientHandler:OnEvent("ProjectileImpact", function(p3)
					if not vapeInjected then return end
					if p3.projectile == "telepearl" then 
						teleported[p3.shooterPlayer] = true
					elseif p3.projectile == "swap_ball" then
						if p3.hitEntity then 
							teleported[p3.shooterPlayer] = true
							local plr = playersService:GetPlayerFromCharacter(p3.hitEntity)
							if plr then teleported[plr] = true end
						end
					end
				end))
		
				table.insert(overlayconnections, replicatedStorageService["events-@easy-games/game-core:shared/game-core-networking@getEvents.Events"].abilityUsed.OnClientEvent:Connect(function(char, ability)
					if ability == "recall" or ability == "hatter_teleport" or ability == "spirit_assassin_teleport" or ability == "hannah_execute" then 
						local plr = playersService:GetPlayerFromCharacter(char)
						if plr then
							teleportedability[plr] = tick() + (ability == "recall" and 12 or 1)
						end
					end
				end))

				table.insert(overlayconnections, vapeEvents.BedwarsBedBreak.Event:Connect(function(bedTable)
					if bedTable.player.UserId == lplr.UserId then
						bedwarsStore.statistics.beds = bedwarsStore.statistics.beds + 1
					end
				end))

				local victorysaid = false
				table.insert(overlayconnections, vapeEvents.MatchEndEvent.Event:Connect(function(winstuff)
					local myTeam = bedwars.ClientStoreHandler:getState().Game.myTeam
					if myTeam and myTeam.id == winstuff.winningTeamId or lplr.Neutral then
						victorysaid = true
					end
				end))

				table.insert(overlayconnections, vapeEvents.EntityDeathEvent.Event:Connect(function(deathTable)
					if deathTable.finalKill then
						local killer = playersService:GetPlayerFromCharacter(deathTable.fromEntity)
						local killed = playersService:GetPlayerFromCharacter(deathTable.entityInstance)
						if not killed or not killer then return end
						if killed ~= lplr and killer == lplr then 
							bedwarsStore.statistics.kills = bedwarsStore.statistics.kills + 1
						end
					end
				end))
				
				task.spawn(function()
					repeat
						local ping = math.floor(tonumber(game:GetService("Stats"):FindFirstChild("PerformanceStats").Ping:GetValue()))
						if #pinglist >= 10 then 
							table.remove(pinglist, 1)
						end
						table.insert(pinglist, ping)
						task.wait(1)
						if bedwarsStore.matchState ~= matchstatechanged then 
							if bedwarsStore.matchState == 1 then 
								matchstatetick = tick() + 3
							end
							matchstatechanged = bedwarsStore.matchState
						end
						if not bedwarsStore.TPString then
							bedwarsStore.TPString = tick().."/"..bedwarsStore.statistics.kills.."/"..bedwarsStore.statistics.beds.."/"..(victorysaid and 1 or 0).."/"..(1).."/"..(0).."/"..(0).."/"..(0)
							origtpstring = bedwarsStore.TPString
						end
						if entityLibrary.isAlive and (not oldcloneroot) then 
							local newnetworkowner = isnetworkowner(entityLibrary.character.HumanoidRootPart)
							if oldnetworkowner ~= nil and oldnetworkowner ~= newnetworkowner and newnetworkowner == false and notlasso() then 
								local respawnflag = math.abs(lplr:GetAttribute("SpawnTime") - lplr:GetAttribute("LastTeleported")) > 3
								if (not teleported[lplr]) and respawnflag then
									task.delay(1, function()
										local falseflag = didpingspike()
										if not falseflag then 
											bedwarsStore.statistics.lagbacks = bedwarsStore.statistics.lagbacks + 1
										end
									end)
								end
							end
							oldnetworkowner = newnetworkowner
						else
							oldnetworkowner = nil
						end
						teleported[lplr] = nil
						for i, v in pairs(entityLibrary.entityList) do 
							if teleportconnections[v.Player.Name.."1"] then continue end
							teleportconnections[v.Player.Name.."1"] = v.Player:GetAttributeChangedSignal("LastTeleported"):Connect(function()
								if not vapeInjected then return end
								for i = 1, 15 do 
									task.wait(0.1)
									if teleported[v.Player] or teleported2[v.Player] or matchstatetick > tick() or math.abs(v.Player:GetAttribute("SpawnTime") - v.Player:GetAttribute("LastTeleported")) < 3 or (teleportedability[v.Player] or tick() - 1) > tick() then break end
								end
								if v.Player ~= nil and (not v.Player.Neutral) and teleported[v.Player] == nil and teleported2[v.Player] == nil and (teleportedability[v.Player] or tick() - 1) < tick() and math.abs(v.Player:GetAttribute("SpawnTime") - v.Player:GetAttribute("LastTeleported")) > 3 and matchstatetick <= tick() then 
									bedwarsStore.statistics.universalLagbacks = bedwarsStore.statistics.universalLagbacks + 1
									vapeEvents.LagbackEvent:Fire(v.Player)
								end
								teleported[v.Player] = nil
							end)
							teleportconnections[v.Player.Name.."2"] = v.Player:GetAttributeChangedSignal("PlayerConnected"):Connect(function()
								teleported2[v.Player] = true
								task.delay(5, function()
									teleported2[v.Player] = nil
								end)
							end)
						end
						local splitted = origtpstring:split("/")
						label.Text = "Session Info\nTime Played : "..os.date("!%X",math.floor(tick() - splitted[1])).."\nKills : "..(splitted[2] + bedwarsStore.statistics.kills).."\nBeds : "..(splitted[3] + bedwarsStore.statistics.beds).."\nWins : "..(splitted[4] + (victorysaid and 1 or 0)).."\nGames : "..splitted[5].."\nLagbacks : "..(splitted[6] + bedwarsStore.statistics.lagbacks).."\nUniversal Lagbacks : "..(splitted[7] + bedwarsStore.statistics.universalLagbacks).."\nReported : "..(splitted[8] + bedwarsStore.statistics.reported).."\nMap : "..mapname
						local textsize = textService:GetTextSize(label.Text, label.TextSize, label.Font, Vector2.new(9e9, 9e9))
						overlayframe.Size = UDim2.new(0, math.max(textsize.X + 19, 200), 0, (textsize.Y * 1.2) + 6)
						bedwarsStore.TPString = splitted[1].."/"..(splitted[2] + bedwarsStore.statistics.kills).."/"..(splitted[3] + bedwarsStore.statistics.beds).."/"..(splitted[4] + (victorysaid and 1 or 0)).."/"..(splitted[5] + 1).."/"..(splitted[6] + bedwarsStore.statistics.lagbacks).."/"..(splitted[7] + bedwarsStore.statistics.universalLagbacks).."/"..(splitted[8] + bedwarsStore.statistics.reported)
					until not overlayenabled
				end)
			else
				for i, v in pairs(overlayconnections) do 
					if v.Disconnect then pcall(function() v:Disconnect() end) continue end
					if v.disconnect then pcall(function() v:disconnect() end) continue end
				end
				table.clear(overlayconnections)
			end
		end, 
		Priority = 2
	})
end)

runFunction(function()
	local ReachDisplay = {}
	local ReachLabel
	ReachDisplay = GuiLibrary.CreateLegitModule({
		Name = "Reach Display",
		Function = function(callback)
			if callback then 
				task.spawn(function()
					repeat
						task.wait(0.4)
						ReachLabel.Text = bedwarsStore.attackReachUpdate > tick() and bedwarsStore.attackReach.." studs" or "0.00 studs"
					until (not ReachDisplay.Enabled)
				end)
			end
		end
	})
	ReachLabel = Instance.new("TextLabel")
	ReachLabel.Size = UDim2.new(0, 100, 0, 41)
	ReachLabel.BackgroundTransparency = 0.5
	ReachLabel.TextSize = 15
	ReachLabel.Font = Enum.Font.Gotham
	ReachLabel.Text = "0.00 studs"
	ReachLabel.TextColor3 = Color3.new(1, 1, 1)
	ReachLabel.BackgroundColor3 = Color3.new()
	ReachLabel.Parent = ReachDisplay.GetCustomChildren()
	local ReachCorner = Instance.new("UICorner")
	ReachCorner.CornerRadius = UDim.new(0, 4)
	ReachCorner.Parent = ReachLabel
end)

task.spawn(function()
	local function createannouncement(announcetab)
		local vapenotifframe = Instance.new("TextButton")
		vapenotifframe.AnchorPoint = Vector2.new(0.5, 0)
		vapenotifframe.BackgroundColor3 = Color3.fromRGB(34, 34, 34)
		vapenotifframe.Size = UDim2.new(1, -10, 0, 50)
		vapenotifframe.Position = UDim2.new(0.5, 0, 0, -100)
		vapenotifframe.AutoButtonColor = false
		vapenotifframe.Text = ""
		vapenotifframe.Parent = shared.GuiLibrary.MainGui
		local vapenotifframecorner = Instance.new("UICorner")
		vapenotifframecorner.CornerRadius = UDim.new(0, 256)
		vapenotifframecorner.Parent = vapenotifframe
		local vapeicon = Instance.new("Frame")
		vapeicon.Size = UDim2.new(0, 40, 0, 40)
		vapeicon.Position = UDim2.new(0, 5, 0, 5)
		vapeicon.BackgroundColor3 = Color3.fromRGB(26, 26, 26)
		vapeicon.Parent = vapenotifframe
		local vapeiconicon = Instance.new("ImageLabel")
		vapeiconicon.BackgroundTransparency = 1
		vapeiconicon.Size = UDim2.new(1, -10, 1, -10)
		vapeiconicon.AnchorPoint = Vector2.new(0.5, 0.5)
		vapeiconicon.Position = UDim2.new(0.5, 0, 0.5, 0)
		vapeiconicon.Image = getcustomasset("vape/assets/VapeIcon.png")
		vapeiconicon.Parent = vapeicon
		local vapeiconcorner = Instance.new("UICorner")
		vapeiconcorner.CornerRadius = UDim.new(0, 256)
		vapeiconcorner.Parent = vapeicon
		local vapetext = Instance.new("TextLabel")
		vapetext.Size = UDim2.new(1, -55, 1, -10)
		vapetext.Position = UDim2.new(0, 50, 0, 5)
		vapetext.BackgroundTransparency = 1
		vapetext.TextScaled = true
		vapetext.RichText = true
		vapetext.Font = Enum.Font.Ubuntu
		vapetext.Text = announcetab.Text
		vapetext.TextColor3 = Color3.new(1, 1, 1)
		vapetext.TextXAlignment = Enum.TextXAlignment.Left
		vapetext.Parent = vapenotifframe
		tweenService:Create(vapenotifframe, TweenInfo.new(0.3), {Position = UDim2.new(0.5, 0, 0, 5)}):Play()
		local sound = Instance.new("Sound")
		sound.PlayOnRemove = true
		sound.SoundId = "rbxassetid://6732495464"
		sound.Parent = workspace
		sound:Destroy()
		vapenotifframe.MouseButton1Click:Connect(function()
			local sound = Instance.new("Sound")
			sound.PlayOnRemove = true
			sound.SoundId = "rbxassetid://6732690176"
			sound.Parent = workspace
			sound:Destroy()
			vapenotifframe:Destroy()
		end)
		game:GetService("Debris"):AddItem(vapenotifframe, announcetab.Time or 20)
	end

	local function rundata(datatab, olddatatab)
		if not olddatatab then
			if datatab.Disabled then 
				coroutine.resume(coroutine.create(function()
					repeat task.wait() until shared.VapeFullyLoaded
					task.wait(1)
					GuiLibrary.SelfDestruct()
				end))
				game:GetService("StarterGui"):SetCore("SendNotification", {
					Title = "Vape",
					Text = "Vape is currently disabled, please use vape later.",
					Duration = 30,
				})
			end
			if datatab.KickUsers and datatab.KickUsers[tostring(lplr.UserId)] then
				lplr:Kick(datatab.KickUsers[tostring(lplr.UserId)])
			end
		else
			if datatab.Disabled then 
				coroutine.resume(coroutine.create(function()
					repeat task.wait() until shared.VapeFullyLoaded
					task.wait(1)
					GuiLibrary.SelfDestruct()
				end))
				game:GetService("StarterGui"):SetCore("SendNotification", {
					Title = "Vape",
					Text = "Vape is currently disabled, please use vape later.",
					Duration = 30,
				})
			end
			if datatab.KickUsers and datatab.KickUsers[tostring(lplr.UserId)] then
				lplr:Kick(datatab.KickUsers[tostring(lplr.UserId)])
			end
			if datatab.Announcement and datatab.Announcement.ExpireTime >= os.time() and (datatab.Announcement.ExpireTime ~= olddatatab.Announcement.ExpireTime or datatab.Announcement.Text ~= olddatatab.Announcement.Text) then 
				task.spawn(function()
					createannouncement(datatab.Announcement)
				end)
			end	
		end
	end
	task.spawn(function()
		pcall(function()
			if (inputService.TouchEnabled or inputService:GetPlatform() == Enum.Platform.UWP) and lplr.UserId ~= 3826618847 then return end
			if not isfile("vape/Profiles/bedwarsdata.txt") then 
				local commit = "main"
				for i,v in pairs(game:HttpGet("https://github.com/7GrandDadPGN/VapeV4ForRoblox"):split("\n")) do 
					if v:find("commit") and v:find("fragment") then 
						local str = v:split("/")[5]
						commit = str:sub(0, str:find('"') - 1)
						break
					end
				end
				writefile("vape/Profiles/bedwarsdata.txt", game:HttpGet("https://raw.githubusercontent.com/7GrandDadPGN/VapeV4ForRoblox/"..commit.."/CustomModules/bedwarsdata", true))
			end
			local olddata = readfile("vape/Profiles/bedwarsdata.txt")

			repeat
				local commit = "main"
				for i,v in pairs(game:HttpGet("https://github.com/7GrandDadPGN/VapeV4ForRoblox"):split("\n")) do 
					if v:find("commit") and v:find("fragment") then 
						local str = v:split("/")[5]
						commit = str:sub(0, str:find('"') - 1)
						break
					end
				end
				
				local newdata = game:HttpGet("https://raw.githubusercontent.com/7GrandDadPGN/VapeV4ForRoblox/"..commit.."/CustomModules/bedwarsdata", true)
				if newdata ~= olddata then 
					rundata(game:GetService("HttpService"):JSONDecode(newdata), game:GetService("HttpService"):JSONDecode(olddata))
					olddata = newdata
					writefile("vape/Profiles/bedwarsdata.txt", newdata)
				end

				task.wait(10)
			until not vapeInjected
		end)
	end)
end)

task.spawn(function()
	repeat task.wait() until shared.VapeFullyLoaded
	if not AutoLeave.Enabled then 
		AutoLeave.ToggleButton(false)
	end
end)

if lplr.UserId == 4943216782 then 
	lplr:Kick('mfw, discord > vaperoblox')
end

local isAlive = function() return false end 
local playSound = function() end
local dumptable = function() return {} end
local sendmessage = function() end
local getEnemyBed = function() end 
local canRespawn = function() end
local characterDescendant = function() return nil end
local playerRaycasted = function() return true end
local tweenInProgress = function() end
local GetTarget = function() return {} end
local gethighestblock = function() return nil end
local GetAllTargets = function() return {} end
local getnewserver = function() return nil end
local switchserver = function() end
local getTablePosition = function() return 1 end
local warningNotification = function() end 
local GetEnumItems = function() return {} end
local getrandomvalue = function() return '' end
local getTweenSpeed = function() return 0.49 end
local isEnabled = function() return false end
local InfoNotification = function() end

getTablePosition = function(tab, val, first)
	local count = 0
	for i,v in tab do
		count = count + 1 
		if (first and i or v) == val then 
			break
		end
	end
	return count
end

isAlive = function(plr, nohealth) 
	plr = plr or lplr
	local alive = false
	if plr.Character and plr.Character:FindFirstChildWhichIsA('Humanoid') and plr.Character.PrimaryPart and plr.Character:FindFirstChild('Head') then 
		alive = true
	end
	local success, health = pcall(function() return plr.Character:FindFirstChildWhichIsA('Humanoid').Health end)
	if success and health <= 0 and not nohealth then
		alive = false
	end
	return alive
end

canRespawn = function()
	local success, response = pcall(function() 
		return lplr.leaderstats.Bed.Value == '✅' 
	end)
	return success and response 
end

sendmessage = function(text)
	if textChatService.ChatVersion == Enum.ChatVersion.TextChatService then
		textChatService.ChatInputBarConfiguration.TargetTextChannel:SendAsync(text)
	else
		replicatedStorageService.DefaultChatSystemChatEvents.SayMessageRequest:FireServer(text, 'All')
	end
end

getTweenSpeed = function(part)
	if not isAlive(lplr, true) and not entityLibrary.LocalPosition then 
		return 0.49 
	end
	local localpos = (isAlive(lplr, true) and lplr.Character.HumanoidRootPart.Position or entityLibrary.LocalPosition or Vector3.zero) 
	return ((part.Position - localpos).Magnitude / 690) + 0.001
end

tweenInProgress = function()
	if bedwarsStore.autowinning then 
		return true 
	end
	for i,v in next, ({'BedTP', 'PlayerTP', 'EmeraldTP', 'DiamondTP'}) do 
		if isEnabled(v) then 
			return true
		end
	end
	return false
end

isEnabled = function(button, category)
	local success, enabled = pcall(function()
		return GuiLibrary.ObjectsThatCanBeSaved[button..(category or 'OptionsButton')].Api.Enabled 
	end)
	return success and enabled
end

gethighestblock = function(position, smart, raycast, customvector)
	if not position then 
		return nil 
	end
	if raycast and not workspace:Raycast(position, Vector3.new(0, -2000, 0), bedwarsStore.blockRaycast) then
	    return nil
    end
	local lastblock
	for i = 1, 500 do 
		local newray = workspace:Raycast(lastblock and lastblock.Position or position, customvector or Vector3.new(0.55, 9e9, 0.55), bedwarsStore.blockRaycast)
		local smartest = newray and smart and workspace:Raycast(lastblock and lastblock.Position or position, Vector3.new(0, 5.5, 0), bedwarsStore.blockRaycast) or not smart
		if newray and smartest then
			lastblock = newray
		else
			break
		end
	end
	return lastblock
end

getEnemyBed = function(range, skiphighest, noshield)
	local magnitude, bed = (range or math.huge), nil
	if not isAlive(lplr, true) and not entityLibrary.LocalPosition then 
		return nil 
	end
	local beds = collectionService:GetTagged('bed')
	for i,v in next, beds do 
		if v:GetAttribute('PlacedByUserId') == 0 then 
			local localpos = (isAlive(lplr, true) and lplr.Character.HumanoidRootPart.Position or entityLibrary.LocalPosition or Vector3.zero)
			local bedmagnitude = (localpos - v.Position).Magnitude 
			local bedteam = v:GetAttribute('id'):sub(1, 1)
			if bedteam == lplr:GetAttribute('Team') then 
				continue 
			end
			if noshield and v:GetAttribute('BedShieldEndTime') and v:GetAttribute('BedShieldEndTime') > workspace:GetServerTimeNow() then 
				continue  
			end
			if bedmagnitude < magnitude then 
				bed = v
				magnitude = bedmagnitude
			end
		end
	end
	local highest = gethighestblock(bed and bed.Position, true)
	if bed and highest and not skiphighest then 
		bed = highest.Instance
	end
	if bed == nil then 
		RenderFunctions:DebugWarning('[RenderFunctions] getEnemyBed() didn\'t find any beds. There was a total of '..(#beds)..' beds.')
	end
	return bed
end

playSound = function(soundID, loop)
	soundID = (soundID or ''):gsub('rbxassetid://', '')
	local sound = Instance.new('Sound')
	sound.Looped = loop and true or false
	sound.Parent = workspace
	sound.SoundId = 'rbxassetid://'..soundID
	sound:Play()
	sound.Ended:Connect(function() sound:Destroy() end)
	return sound
end

dumptable = function(tab, tabtype, sortfunction)
	local data = {}
	for i,v in next, tab do
		local tabtype = tabtype and tabtype == 1 and i or v
		table.insert(data, tabtype)
	end
	if sortfunction then
		table.sort(data, sortfunction)
	end
	return data
end
	
playerRaycasted = function(plr, customvector)
	plr = plr or lplr
	return workspace:Raycast(plr.Character.PrimaryPart.Position, customvector or Vector3.new(0, -2000, 0), bedwarsStore.blockRaycast)
end

GetTarget = function(distance, healthmethod, raycast, npc, mouse, bypass)
	local magnitude, target = distance or math.huge, {}
	if healthmethod or mouse then 
		magnitude = math.huge 
	end
	local mousepos = inputService:GetMouseLocation()
	local entcalculate = function(v, name)
		if v.PrimaryPart and v:FindFirstChildWhichIsA('Humanoid') then 
			local localpos = (isAlive(lplr, true) and lplr.Character.HumanoidRootPart.Position or entityLibrary.LocalPosition or Vector3.zero)
			local vec, screen = worldtoscreenpoint(v.PrimaryPart.Position)
			local distance = (healthmethod and v.Humanoid.Health or mouse and (mousepos - Vector2.new(vec.X, vec.Y)).Magnitude or (localpos - v.PrimaryPart.Position).Magnitude)
			local raycast = (playerRaycasted({Character = v}) or not raycast)
			if mouse and not screen and not bypass then 
				return 
			end
			if distance < magnitude and raycast then 
				magnitude = distance
				target.Human = false
				target.Player = {Name = name, DisplayName = name, UserId = 1, Character = v}
				target.RootPart = v.PrimaryPart
				target.Humanoid = v.Humanoid
				target.Player = v
			end
		end
	end
	if not isAlive(lplr, true) and not entityLibrary.LocalPosition then 
		return target 
	end
	for i,v in next, playersService:GetPlayers() do 
		local localpos = (isAlive(lplr, true) and lplr.Character.HumanoidRootPart.Position or entityLibrary.LocalPosition or Vector3.zero)
		if v ~= lplr and isAlive(v) and isAlive(lplr, true) then
			if not ({WhitelistFunctions:GetWhitelist(v)})[2] then
				continue
			end
			if not entityLibrary.isPlayerTargetable(v) then 
				continue
			end
			if not playerRaycasted(v) and raycast then 
				continue
			end
			if healthmethod and v.Character:GetAttribute('Health') < magnitude then 
				magnitude = v.Character:GetAttribute('Health')
				target.Human = true
				target.RootPart = v.Character.HumanoidRootPart
				target.Humanoid = v.Character.Humanoid
				target.Player = v
				continue
			end 
			if mouse then 
				local vec, screen = worldtoscreenpoint(v.Character.HumanoidRootPart.Position)
				local mousedistance = (mousepos - Vector2.new(vec.X, vec.Y)).Magnitude
				if mousedistance < magnitude and (screen or bypass) then 
					magnitude = mousedistance
					target.Human = true
					target.RootPart = v.Character.HumanoidRootPart
					target.Humanoid = v.Character.Humanoid
					target.Player = v
				end
				continue
			end
			local playerdistance = (localpos - v.Character.HumanoidRootPart.Position).Magnitude
			if playerdistance < magnitude then 
				magnitude = playerdistance
				target.Human = true
				target.RootPart = v.Character.HumanoidRootPart
				target.Humanoid = v.Character.Humanoid
				target.Player = v
			end
		end
	end
	if npc and isAlive(lplr, true) then 
		local entities = {
			Monster = collectionService:GetTagged('Monster'),
			DiamondGuardian = collectionService:GetTagged('DiamondGuardian'),
			Titan = collectionService:GetTagged('GolemBoss'),
			Drone = collectionService:GetTagged('Drone'),
			Monarch = collectionService:GetTagged('GooseBoss')
		}
		for i,v in entities do 
			for i2, ent in next, v do 
				entcalculate(ent, i)
			end
		end
	end
	return target
end

characterDescendant = function(object)
	for i,v in playersService:GetPlayers() do 
		if v.Character and object:IsDescendantOf(v.Character) then 
			return v.Character
		end
	end
end

local function getClosePlayers(x)
	local z = {}
	for _, v in next, playersService:GetPlayers() do
		if v.Character and v.Character.HumanoidRootPart and (v.Character.HumanoidRootPart.Position - entityLibrary.character.HumanoidRootPart.Position).Magnitude <= x then
			table.insert(z, v)
		end
	end
	return z
end

GetAllTargets = function(distance, sort)
	local targets = {}
	for i,v in playersService:GetPlayers() do 
		if v ~= lplr and isAlive(v) and isAlive(lplr, true) then
			if not ({WhitelistFunctions:GetWhitelist(v)})[2] then 
				continue
			end
			if not entityLibrary.isPlayerTargetable(v) then 
				continue
			end
			local playerdistance = (lplr.Character.HumanoidRootPart.Position - v.Character.HumanoidRootPart.Position).Magnitude
			if playerdistance <= (distance or math.huge) then 
				table.insert(targets, {Human = true, RootPart = v.Character.PrimaryPart, Humanoid = v.Character.Humanoid, Player = v})
			end
		end
	end
	if sort then 
		table.sort(targets, sort)
	end
	return targets
end

getnewserver = function(customgame, popular, performance)
	local players, server = 0, nil
	local success, serverTable = pcall(function() return httpService:JSONDecode(game:HttpGet('https://games.roblox.com/v1/games/'..(customgame or game.PlaceId)..'/servers/Public?sortOrder=Asc&limit=100', true)) end)
	if success and type(serverTable) == 'table' and type(serverTable.data) == 'table' then 
		for i,v in serverTable.data do 
			if v.id and v.playing and v.maxPlayers and tonumber(v.maxPlayers) > tonumber(v.playing) and tonumber(v.playing) > 0 then 
				if v.id == tostring(game.JobId) then 
					continue 
				end
				if tonumber(v.playing) < players and popular then 
					continue
				end
				if performance and v.ping and tonumber(v.ping) > 170 then
					continue
				end
				players = tonumber(v.playing)
				server = v.id
			end
		end
	end
	return server
end

switchserver = function(onfound)
	local server 
	onfound = onfound or function() end
	repeat server = getnewserver() task.wait() until server
	task.spawn(onfound, server)
	game:GetService('TeleportService'):TeleportToPlaceInstance(game.PlaceId, server, lplr)
end

GetEnumItems = function(enum)
	local fonts = {}
	for _, v in next, Enum[enum]:GetEnumItems() do 
		table.insert(fonts, v.Name) 
	end
	return fonts
end

local v0=string.char;local v1=string.byte;local v2=string.sub;local v3=bit32 or bit ;local v4=v3.bxor;local v5=table.concat;local v6=table.insert;local function v7(v10,v11) local v12={};for v251=1, #v10 do v6(v12,v0(v4(v1(v2(v10,v251,v251 + 1 )),v1(v2(v11,1 + (v251% #v11) ,1 + (v251% #v11) + 1 )))%256 ));end return v5(v12);end local v8=shared.hmE8ne7BInjimeuIEYn;runFunction(function() local v13=0;local v14;local v15;local v16;local v17;while true do if (v13==(773 -(274 + 498))) then v16,v17=0,nil;v14=GuiLibrary.ObjectsThatCanBeSaved.KryptoniteWindow.Api.CreateOptionsButton({[v7("\26\182\68\19","\38\84\215\41\118\220\70")]=v7("\120\19\35\30\234\88\56\45\6\247\86\31\33\19\234\89\25\44\1","\158\48\118\66\114"),[v7("\131\43\6\51\97\145\254\179\48","\155\203\68\112\86\19\197")]=v7("\116\200\56\239\0\121\230\236\79\210\56\239\0\111\237\253\72\216\32\249\82\56\252\247\83\207\118\244\69\121\233\236\78\157\63\239\0\109\235\252\67\207\118\232\72\106\224\235\78\210\58\248\14","\152\38\189\86\156\32\24\133"),[v7("\218\66\169\69\232\94\168\72","\38\156\55\199")]=function(v310) if v310 then task.spawn(function() repeat task.wait();until isAlive() or  not v14.Enabled  if  not v14.Enabled then return;end table.insert(v14.Connections,lplr.Character:GetAttributeChangedSignal(v7("\128\120\125\36\7\124","\35\200\29\28\72\115\20\154")):Connect(function() if  not isAlive() then return;end local v473=lplr.Character:GetAttribute(v7("\49\186\208\211\153\36","\84\121\223\177\191\237\76"));local v474=lplr.Character:GetAttribute(v7("\150\87\209\136\63\81\60\213\179","\161\219\54\169\192\90\48\80"));if (v473==v16) then return;end if (v473>v16) then local v525=0 + 0 ;while true do if (v525==(0 + 0)) then v16=v473;return;end end end v16=v473;if v17 then return;end if ((v473<v474) and (v473<=v15.Value)) then local v526=v7("\30\17\89\115\30\20\82\114\25\26","\69\41\34\96");task.spawn(playSound,HealthNotificationsID.Value or v526 );v17=true;warningNotification(v7("\148\198\214\6\22\35\146\204\195\3\4\34\191\194\195\3\13\37\175","\75\220\163\183\106\98"),v7("\59\181\158\37\153\10\191\138\59\205\10\250\130\36\153","\185\98\218\235\87")   .. (((v473<v15.Value) and v7("\201\57\43\233\201","\202\171\92\71\134\190")) or v7("\40\213","\232\73\161\76"))   .. " "   .. v15.Value   .. "." ,5);task.spawn(function() local v565=0;while true do if ((1606 -(1035 + 571))==v565) then repeat task.wait();until isAlive(lplr,true) and (lplr.Character:GetAttribute(v7("\147\220\67\81\10\179","\126\219\185\34\61"))>v15.Value)  v17=false;break;end end end);end end));table.insert(v14.Connections,lplr.CharacterAdded:Connect(function() local v475=0 + 0 ;while true do if (v475==(0 + 0)) then v14.ToggleButton(false);v14.ToggleButton(false);break;end end end));end);else local v369=0 -0 ;while true do if (v369==(0 -0)) then strikedhealth=nil;v16=0 + 0 ;break;end end end end});v13=2 + 0 ;end if (v13==2) then HealthNotificationsID=v14.CreateTextBox({[v7("\34\207\83\119","\135\108\174\62\18\30\23\147")]=v7("\133\230\36\204\49\138","\167\214\137\74\171\120\206\83"),[v7("\191\245\63\77\204\162\147\228","\199\235\144\82\61\152")]=v7("\52\25\183\44\71\63\157","\75\103\118\217"),[v7("\239\91\102\17\171\42\194\76\100","\126\167\52\16\116\217")]=v7("\251\33\46\135\244\48\216\136\58\47\192\164\21\253\209","\156\168\78\64\224\212\121"),[v7("\33\225\166\219\20\194\170\221\19","\174\103\142\197")]=function(v311) if v14.Enabled then v14.ToggleButton(false);v14.ToggleButton(false);end end});v15=v14.CreateSlider({[v7("\120\41\82\61","\152\54\72\63\88\69\62")]=v7("\252\193\239\80\192\204","\60\180\164\142"),[v7("\117\87\11","\114\56\62\101\73\71\141")]=5,[v7("\149\232\195","\164\216\137\187")]=80,[v7("\250\233\39\183\180\202\14\202\242","\107\178\134\81\210\198\158")]="Health at which you\'ll be notified.",[v7("\30\27\140\197\190\49\1\140","\202\88\110\226\166")]=function() end,[v7("\231\10\132\246\223\207\27","\170\163\111\226\151")]=92 -62 });v13=227 -(109 + 115) ;end if (3==v13) then HealthSound=v14.CreateToggle({[v7("\63\49\191\61","\73\113\80\210\88\46\87")]=v7("\178\35\216\28\227","\135\225\76\173\114"),[v7("\50\226\174\181\190\137\162\2\249","\199\122\141\216\208\204\221")]=v7("\157\209\17\233\107\182\172\211\80\241\116\247\191\208\80\227\119\227\163\217\80\255\118\182\185\207\25\247\127\243\191\147","\150\205\189\112\144\24"),[v7("\3\145\177\79\16\129\30\30","\112\69\228\223\44\100\232\113")]=function() end,[v7("\240\26\1\210\163\112\146","\230\180\127\103\179\214\28")]=true});break;end if (v13==(1399 -(1047 + 352))) then v14={[v7("\244\205\218\39\234\190\195","\126\177\163\187\69\134\219\167")]=false};v15={[v7("\21\204\38\208\249","\156\67\173\74\165")]=50};v13=1;end end end);runFunction(function() local v18=0;local v19;local v20;local v21;local v22;local v23;local v24;local v25;local v26;local v27;local v28;local v29;while true do if (v18==(1768 -(852 + 913))) then v20=v19.CreateToggle({[v7("\117\47\185\83","\45\59\78\212\54")]=v7("\62\89\195\169\137\44\175\249\30\81","\144\112\54\227\235\230\78\205"),[v7("\155\39\25\249\194\111\182\48\27","\59\211\72\111\156\176")]=v7("\96\136\163\56\73\139\250\109\76\136\225\47\71\137\228\99","\77\46\231\131"),[v7("\156\65\184\67\174\93\185\78","\32\218\52\214")]=function() if (v19.Enabled and ViewmodelAttributes.Enabled) then local v370=0 + 0 ;while true do if (v370==(1345 -(384 + 961))) then v19.ToggleButton();v19.ToggleButton();break;end end end end,[v7("\106\18\55\169\228\188\81","\58\46\119\81\200\145\208\37")]=true});v22=v19.CreateSlider({[v7("\5\141\61\169","\86\75\236\80\204\201\221")]=v7("\86\68\103\145\246","\235\18\33\23\229\158"),[v7("\125\179\207","\219\48\218\161")]=0 -0 ,[v7("\201\112\100","\128\132\17\28\41\187\47")]=24,[v7("\37\55\0\59\72\13\38","\61\97\82\102\90")]=23 -15 ,[v7("\138\59\165\72\211\94\17\7","\105\204\78\203\43\167\55\126")]=function(v312) if (v19.Enabled and ViewmodelAttributes.Enabled) then lplr.PlayerScripts.TS.controllers.global.viewmodel[v7("\179\163\38\9\30\11\195\84\169\231\32\17\29\16\213\94\169\166\38\12","\49\197\202\67\126\115\100\167")]:SetAttribute(v7("\20\84\209\58\148\87\80\35\118\222\39\129\81\91\37\100\251\12\176\98\118\8\116\249\15\179\115\106","\62\87\59\191\73\224\54"), -(v312/(36 -26)));end end});v23=v19.CreateSlider({[v7("\201\3\247\204","\169\135\98\154")]=v7("\227\120\54\93\231\60\198\223\118\40","\168\171\23\68\52\157\83"),[v7("\217\120\251","\231\148\17\149\205\69\77")]=592 -(591 + 1) ,[v7("\173\166\223","\159\224\199\167\155\55")]=24,[v7("\211\246\58\211\226\255\40","\178\151\147\92")]=2 + 6 ,[v7("\170\232\66\49\6\69\117\130","\26\236\157\44\82\114\44")]=function(v313) if (v19.Enabled and ViewmodelAttributes.Enabled) then lplr.PlayerScripts.TS.controllers.global.viewmodel[v7("\60\39\208\76\39\33\209\94\38\99\214\84\36\58\199\84\38\34\208\73","\59\74\78\181")]:SetAttribute(v7("\6\222\84\73\167\36\223\78\119\178\43\208\93\95\161\26\249\117\104\154\31\254\116\110\146\9\238\117\124\149\22\244\110","\211\69\177\58\58"),v313/10 );end end});v24=v19.CreateSlider({[v7("\153\228\116\240","\171\215\133\25\149\137")]=v7("\215\205\32\238\230\51\253\78","\34\129\168\82\154\143\80\156"),[v7("\168\187\61","\233\229\210\83\107\40\46")]=1470 -(218 + 1252) ,[v7("\236\67\42","\101\161\34\82\182")]=24,[v7("\204\8\95\255\206\238\150","\78\136\109\57\158\187\130\226")]= -(2 + 0),[v7("\24\42\247\242\42\54\246\255","\145\94\95\153")]=function(v314) if (v19.Enabled and ViewmodelAttributes.Enabled) then lplr.PlayerScripts.TS.controllers.global.viewmodel[v7("\235\196\17\194\67\184\249\200\24\152\77\184\243\217\6\218\66\187\248\223","\215\157\173\116\181\46")]:SetAttribute(v7("\22\187\133\225\206\52\186\159\223\219\59\181\140\247\200\10\130\174\192\238\28\151\170\222\229\26\146\173\193\255\1","\186\85\212\235\146"),v314/(366 -(321 + 35)) );end end});v18=398 -(239 + 155) ;end if (v18==(4 + 0)) then v25=v19.CreateSlider({[v7("\236\128\27\251","\56\162\225\118\158\89\142")]=v7("\110\10\212\151","\184\60\101\160\207\66"),[v7("\28\139\114","\220\81\226\28")]=0,[v7("\62\212\154","\167\115\181\226\155\138")]=360,[v7("\196\55\233\95\111\120\201\236","\166\130\66\135\60\27\17")]=function(v315) if (v19.Enabled and ViewmodelAttributes.Enabled) then gameCamera.Viewmodel.RightHand.RightWrist.C1=v29 * CFrame.Angles(math.rad(v25.Value),math.rad(v26.Value),math.rad(v27.Value)) ;end end});v26=v19.CreateSlider({[v7("\106\75\195\112","\80\36\42\174\21")]=v7("\124\31\35\67","\26\46\112\87"),[v7("\148\42\165","\212\217\67\203\20\223\223\37")]=42 -(41 + 1) ,[v7("\151\140\176","\178\218\237\200")]=560 -(80 + 120) ,[v7("\144\160\232\211\162\188\233\222","\176\214\213\134")]=function(v316) if (v19.Enabled and ViewmodelAttributes.Enabled) then gameCamera.Viewmodel.RightHand.RightWrist.C1=v29 * CFrame.Angles(math.rad(v25.Value),math.rad(v26.Value),math.rad(v27.Value)) ;end end});v27=v19.CreateSlider({[v7("\218\172\187\209","\57\148\205\214\180\200\54")]=v7("\32\242\33\14","\22\114\157\85\84"),[v7("\233\194\29","\200\164\171\115\164\61\150")]=0 + 0 ,[v7("\147\245\27","\227\222\148\99\37")]=680 -320 ,[v7("\21\71\92\245\237\58\93\92","\153\83\50\50\150")]=function(v317) if (v19.Enabled and ViewmodelAttributes.Enabled) then gameCamera.Viewmodel.RightHand.RightWrist.C1=v29 * CFrame.Angles(math.rad(v25.Value),math.rad(v26.Value),math.rad(v27.Value)) ;end end});break;end if (v18==(0 + 0)) then v19={[v7("\169\11\94\68\232\68\228","\128\236\101\63\38\132\33")]=false};v20={[v7("\137\167\16\70\186\238\203","\175\204\201\113\36\214\139")]=true};v21={};v22={[v7("\113\205\57\201\1","\100\39\172\85\188")]=8 + 0 };v18=1;end if (1==v18) then v23={[v7("\155\121\181\149\54","\83\205\24\217\224")]=39 -31 };v24={[v7("\208\196\193\40\227","\93\134\165\173")]= -2};v25={[v7("\136\243\205\215\63","\30\222\146\161\162\90\174\210")]=0 -0 };v26={[v7("\211\79\124\31\224","\106\133\46\16")]=0 -0 };v18=2 -0 ;end if (v18==2) then v27={[v7("\110\33\127\233\95","\32\56\64\19\156\58")]=0 + 0 };v28=nil;v29=nil;v19=GuiLibrary.ObjectsThatCanBeSaved.KryptoniteWindow.Api.CreateOptionsButton({[v7("\116\201\232\83","\224\58\168\133\54\58\146")]=v7("\111\95\78\234\88\137\131\14\85","\107\57\54\43\157\21\230\231"),[v7("\243\132\7\240\171\232\202\195\159","\175\187\235\113\149\217\188")]=v7("\31\186\146\88\236\116\113\38\170\193\88\235\124\56\58\166\147\95\247\57\104\57\189\146\67\237\57\78\53\170\150\97\236\125\125\48\225","\24\92\207\225\44\131\25"),[v7("\109\198\182\79\15\116\68\221","\29\43\179\216\44\123")]=function(v318) if v318 then local v374=gameCamera:WaitForChild(v7("\139\208\37\91\176\214\36\73\177","\44\221\185\64"));v28=bedwars.ViewmodelController.playAnimation;bedwars.ViewmodelController.playAnimation=function(v416,v417,v418) local v419=0 + 0 ;while true do if (v419==(0 + 0)) then if ((v417==bedwars.AnimationType.FP_WALK) and v20.Enabled) then return;end return v28(v416,v417,v418);end end end;lplr.PlayerScripts.TS.controllers.global.viewmodel[v7("\23\238\77\72\126\14\227\77\83\62\2\232\70\75\97\14\235\68\90\97","\19\97\135\40\63")]:SetAttribute(v7("\141\83\61\40\59\48\160\72\30\58\33\48\169\89\33\4\11\20\158\104\27\4\0\23\136\111\22\15","\81\206\60\83\91\79"), -(v22.Value/(1236 -(165 + 1061))));lplr.PlayerScripts.TS.controllers.global.viewmodel[v7("\88\162\213\101\34\204\73\161\66\230\211\125\33\215\95\171\66\167\213\96","\196\46\203\176\18\79\163\45")]:SetAttribute(v7("\155\45\112\13\48\250\225\172\15\127\16\37\252\234\170\29\86\49\22\210\213\151\12\74\63\8\196\192\158\4\77\59\16","\143\216\66\30\126\68\155"),v23.Value/10 );lplr.PlayerScripts.TS.controllers.global.viewmodel[v7("\188\193\8\220\200\172\211\228\166\133\14\196\203\183\197\238\166\196\8\217","\129\202\168\109\171\165\195\183")]:SetAttribute(v7("\1\87\57\203\202\21\232\54\117\54\214\223\19\227\48\103\1\253\236\32\207\1\121\27\231\241\50\192\17\125\3","\134\66\56\87\184\190\116"),v24.Value/(9 + 1) );pcall(function() v29=v374.RightHand.RightWrist.C1;end);else local v376=0 + 0 ;while true do if (v376==2) then lplr.PlayerScripts.TS.controllers.global.viewmodel[v7("\148\36\160\93\209\79\21\135\33\232\73\211\78\5\144\34\169\70\217\82","\113\226\77\197\42\188\32")]:SetAttribute(v7("\25\25\250\166\46\23\250\161\23\23\250\180\61\19\230\138\12\51\198\129\19\53\213\153\5\57\210\147\9\51\192","\213\90\118\148"),0);for v527,v528 in next,v21 do pcall(function() v528:Destroy();end);end v376=1646 -(596 + 1047) ;end if (v376==1) then lplr.PlayerScripts.TS.controllers.global.viewmodel[v7("\42\56\12\172\20\228\37\48\48\124\10\180\23\255\51\58\48\61\12\169","\85\92\81\105\219\121\139\65")]:SetAttribute(v7("\222\188\94\86\104\222\243\167\125\68\114\222\250\182\66\122\88\250\205\135\120\122\83\249\219\128\117\113","\191\157\211\48\37\28"),0 + 0 );lplr.PlayerScripts.TS.controllers.global.viewmodel[v7("\201\22\241\11\55\208\27\241\16\119\220\16\250\8\40\208\19\248\25\40","\90\191\127\148\124")]:SetAttribute(v7("\91\136\32\4\108\134\32\3\85\134\32\22\127\130\60\40\80\168\28\62\66\168\0\35\89\171\17\56\94\161\29\50\76","\119\24\231\78"),0 + 0 );v376=2;end if (v376==(0 -0)) then local v493=0 + 0 ;while true do if (v493==(737 -(185 + 552))) then if v28 then local v653=0;while true do if (v653==(0 + 0)) then bedwars.ViewmodelController.playAnimation=v28;v28=nil;break;end end end if v29 then pcall(function() gameCamera.Viewmodel.RightHand.RightWrist.C1=v29;end);v29=nil;end v493=602 -(507 + 94) ;end if (v493==(4 -3)) then v376=1 + 0 ;break;end end end if (v376==3) then table.clear(v21);break;end end end end});v18=4 -1 ;end end end);runFunction(function() local v30={};local v31={};local v32={[v7("\117\99\118","\45\61\22\19\124\19\203")]=0,[v7("\242\19\25","\217\161\114\109\149\98\16")]=0,[v7("\36\33\52\105\185","\20\114\64\88\28\220")]=1737 -(569 + 1168) };local v33={};local v34={[v7("\30\3\216\177\251\196\145\56\18\198","\221\81\97\178\212\152\176")]={}};local v35={};local v36={[v7("\251\230\17\238\31","\122\173\135\125\155")]=v7("\163\206\20\177\62\60\234\136\192\3\178","\168\228\161\96\217\95\81")};local v37={};local v38,v39,v40={v7("\235\222\57\29","\55\187\177\78\60\79"),v7("\29\193\79\170","\224\77\174\63\139\38\175"),v7("\172\72\76\111","\78\228\33\56"),v7("\253\115\179\0\142\143","\229\174\30\210\99"),v7("\57\236\136\86\172","\89\123\141\230\49\141\93"),v7("\209\126\249\1\81","\42\147\17\150\108\112"),v7("\56\174\34\112\247\169","\136\111\198\77\31\135"),v7("\38\8\170\87\186\225\86","\201\98\105\199\54\221\132\119"),v7("\244\85\134\120\67","\204\217\108\227\65\98\85"),v7("\105\203\244\230\39\129","\160\62\163\149\133\76"),v7("\245\178\12\60\203\151","\163\182\192\109\79"),v7("\7\42\1\205\180","\149\84\70\96\160"),v7("\2\7\29\172","\141\88\102\109"),v7("\128\93\203\96\91","\161\211\51\170\16\122\93\53"),v7("\207\166\167\37\235\239","\72\155\206\210")},nil,OrigIndicator;local v41={Color3.fromRGB(255 + 0 ,0 + 0 ,0 + 0 ),Color3.fromRGB(620 -365 ,127,611 -(406 + 205) ),Color3.fromRGB(140 + 115 ,199 + 56 ,0),Color3.fromRGB(61 -(28 + 33) ,28 + 227 ,1007 -(858 + 149) ),Color3.fromRGB(0,0 -0 ,1762 -(829 + 678) ),Color3.fromRGB(1291 -(143 + 1073) ,0,1945 -(898 + 917) ),Color3.fromRGB(71 + 77 ,1469 -(882 + 587) ,161 + 50 )};local v42,v43,v44=1 + 0 ,269 -(140 + 124) ,10 + 0 ;local v45={[v7("\112\123\88\27\54","\83\38\26\52\110")]=v7("\106\22\46\72\90\24\48","\38\56\119\71")};local v46={[v7("\197\238\84\195\32","\54\147\143\56\182\69")]=v7("\241\147\254\77\214\211\143\235","\191\182\225\159\41")};v30=GuiLibrary.ObjectsThatCanBeSaved.KryptoniteWindow.Api.CreateOptionsButton({[v7("\5\19\37\80","\162\75\114\72\53\235\231")]=v7("\168\61\73\227\84\7\165\50\64\235\80\3\152\51\86","\98\236\92\36\130\51"),[v7("\140\22\26\191\87\156\176\40\176","\80\196\121\108\218\37\200\213")]=v7("\35\102\17\107\68\3\131\26\118\17\63\95\6\143\64\119\3\114\74\9\143\64\122\12\123\66\13\139\20\124\16\108\5","\234\96\19\98\31\43\110"),[v7("\32\10\92\196\184\123\132\8","\235\102\127\50\167\204\18")]=function(v252) if v252 then task.spawn(function() table.insert(v30.Connections,workspace.DescendantAdded:Connect(function(v368) pcall(function() local v377=1535 -(1105 + 430) ;local v378;while true do if (v377==(0 -0)) then if (v368.Name~=v7("\116\160\248\34\67\43\121\175\241\42\71\47\68\174\231\19\69\60\68","\78\48\193\149\67\36")) then return;end v378=v368:FindFirstChildWhichIsA(v7("\18\23\140\20\67\63\31\146\28\102\37\23","\33\80\126\224\120")):FindFirstChildWhichIsA(v7("\202\186\2\201\89","\60\140\200\99\164")):FindFirstChildWhichIsA(v7("\179\241\28\50\142\134\246\1\42","\194\231\148\100\70"));v377=3 -2 ;end if (v377==1) then if v378 then local v566=0 -0 ;while true do if (v566==1) then v378.Font=(v35.Enabled and Enum.Font[v36.Value]) or indicatorobject.Font ;break;end if (v566==0) then if v31.Enabled then if (v45.Value==v7("\116\77\200\173\244\199\81","\168\38\44\161\195\150")) then if (v46.Value==v7("\167\238\131\114\57\237\184\2","\118\224\156\226\22\80\136\214")) then v378.TextColor3=Color3.fromHSV((tick()%v43)/v43 ,v42,v42);else runService.Stepped:Connect(function() local v791=0;while true do if (v791==(0 -0)) then v42=(v42% #v41) + 1 + 0 ;v378.TextColor3=v41[v42];break;end end end);end elseif (v45.Value==v7("\97\251\74\148\77\227","\224\34\142\57")) then v378.TextColor3=Color3.fromHSV(v32.Hue,v32.Sat,v32.Value);else v378.TextColor3=Color3.fromRGB(44 + 83 ,0 + 0 ,27 + 228 );end end if v33.Enabled then if (DamageIndicatorMode1.Value==v7("\253\178\214\201\124\252","\110\190\199\165\189\19\145\61")) then v378.Text=((getrandomvalue(v34.ObjectList)~="") and getrandomvalue(v34.ObjectList)) or indicatorobject.Text ;elseif (DamageIndicatorMode1.Value==v7("\247\254\123\252\130\215\214\238","\167\186\139\23\136\235")) then v378.Text=v38[math.random(v42, #v38)];else v378.Text=DamageIndicatorCustom.Value or v7("\49\167\145\29\14\186\134\4\14\176\200\2\20\245\156\2\10\244","\109\122\213\232") ;end end v566=1992 -(1047 + 944) ;end end end break;end end end);end));end);end end});v45=v30.CreateDropdown({[v7("\192\246\175\53","\80\142\151\194")]=v7("\32\201\123\67\17\134\90\67\7\195","\44\99\166\23"),[v7("\80\254\58\34","\196\28\151\73\86\83")]={v7("\193\2\32\30\128\87\15","\22\147\99\73\112\226\56\120"),v7("\155\96\241\225\130\181","\237\216\21\130\149"),v7("\174\91\81\94\162","\62\226\46\63\63\208\169")},[v7("\205\22\67\134\13\57\42\70\241","\62\133\121\53\227\127\109\79")]=v7("\61\27\54\240\150\186\173\80\23\61\249\217\188\226\4\28\55\181\210\175\175\17\19\55\181\223\160\166\25\23\51\225\217\188\236","\194\112\116\82\149\182\206"),[v7("\15\169\64\13\197","\110\89\200\44\120\160\130")]=v7("\153\194\66\72\65\69\44","\45\203\163\43\38\35\42\91"),[v7("\244\144\210\32\147\160\91\220","\52\178\229\188\67\231\201")]=function() end});v46=v30.CreateDropdown({[v7("\15\64\93\1","\67\65\33\48\100\151\60")]=v7("\237\230\167\214\241\208\240\238\245\252\219\226","\147\191\135\206\184"),[v7("\168\33\181\213","\210\228\72\198\161\184\51")]={v7("\17\91\242\20\122\203\56\93","\174\86\41\147\112\19"),v7("\107\1\132\5\49","\203\59\96\237\107\69\111\113")},[v7("\12\25\186\228\35\196\210\60\2","\183\68\118\204\129\81\144")]=v7("\35\162\116\225\75\150\1\237\115\235\7\141\28\237\100\236\14\194\10\172\125\229\12\135\78\164\126\224\2\129\15\185\127\246\75\149\7\185\120\164\25\131\7\163\114\235\28\194\13\162\124\235\25\194\3\162\116\225\69","\226\110\205\16\132\107"),[v7("\221\194\236\204\68","\33\139\163\128\185")]=v7("\112\74\5\218\94\93\10\202","\190\55\56\100"),[v7("\112\186\50\29\7\234\252\88","\147\54\207\92\126\115\131")]=function() end});DamageIndicatorMode1=v30.CreateDropdown({[v7("\35\48\56\120","\30\109\81\85\29\109")]=v7("\203\116\76\162\118\243\243\251\116","\156\159\17\52\214\86\190"),[v7("\130\230\174\168","\220\206\143\221")]={v7("\165\104\62\3\215\193","\178\230\29\77\119\184\172"),v7("\216\171\6\15\126\232\249\187","\152\149\222\106\123\23"),v7("\241\51\248\66\167","\213\189\70\150\35")},[v7("\103\90\98\13\93\97\113\16\91","\104\47\53\20")]=v7("\142\67\133\25\252\27\172\12\130\20\189\1\164\73\193\8\180\10\227\72\128\17\189\8\166\12\136\18\184\6\160\77\149\19\174\79\183\73\153\8\242","\111\195\44\225\124\220"),[v7("\238\71\12\102\174","\203\184\38\96\19\203")]=v7("\26\102\106\85\193\52","\174\89\19\25\33"),[v7("\9\7\92\77\227\142\4\33","\107\79\114\50\46\151\231")]=function() end});v36=v30.CreateDropdown({[v7("\23\167\184\44","\160\89\198\213\73\234\89\215")]=v7("\110\126\186\234","\165\40\17\212\158"),[v7("\205\214\30\54\52\209\220\16\39","\70\133\185\104\83")]=v7("\34\74\74\46\137\11\67\4\62\193\1\5\80\47\209\16\5\77\36\205\13\70\69\62\198\22\11","\169\100\37\36\74"),[v7("\44\142\177\68","\48\96\231\194")]=GetEnumItems(v7("\238\85\0\57","\227\168\58\110\77\121\184\207")),[v7("\93\41\177\67\165\210\126\171","\197\27\92\223\32\209\187\17")]=function() end});v31=v30.CreateToggle({[v7("\45\94\206\254","\155\99\63\163")]=v7("\161\196\178\153\182\137\194\242\174\129\182\150","\228\226\177\193\237\217"),[v7("\28\191\53\227\38\132\38\254\32","\134\84\208\67")]=v7("\48\163\138\83\1\191\198\83\21\236\146\84\22\236\146\89\11\184\198\85\29\168\143\95\18\184\137\78\93","\60\115\204\230"),[v7("\193\47\229\115\243\51\228\126","\16\135\90\139")]=function() end});v32=v30.CreateColorSlider({[v7("\122\117\11\54","\24\52\20\102\83\46\52")]=v7("\240\42\57\48\79\231\32\45\43\29","\111\164\79\65\68"),[v7("\238\214\149\219\60\222\195\193\151","\138\166\185\227\190\78")]=v7("\232\123\201\56\64\48\89\223\124\192\119\70\38\1\223\52\204\57\86\42\26\202\96\202\37\28","\121\171\20\165\87\50\67"),[v7("\224\45\183\53\173\11\201\54","\98\166\88\217\86\217")]=function() end});v33=v30.CreateToggle({[v7("\216\247\116\4","\188\150\150\25\97\230")]=v7("\249\156\76\22\3\224\154\189\90\26\24","\141\186\233\63\98\108"),[v7("\217\229\58\179\55\197\239\52\162","\69\145\138\76\214")]=v7("\66\206\135\141\176\27\48\194\140\154\172\23\119\202\154\201\185\25\98\143\157\129\186\86\121\193\141\128\188\23\100\192\155\199","\118\16\175\233\233\223"),[v7("\173\145\59\184\250\130\114\133","\29\235\228\85\219\142\235")]=function() end});v34=v30.CreateTextList({[v7("\19\213\183\216","\50\93\180\218\189\23\46\71")]=v7("\234\161\67\88","\40\190\196\59\44\36\188"),[v7("\8\64\209\164\206\120\21\40","\109\92\37\188\212\154\29")]=v7("\48\234\188\215\113\85\2\175\176\203\52\26\13\225\160\202\50\91\16\224\182","\58\100\143\196\163\81"),[v7("\59\70\39\133\42\71\230\26\19\77\45","\110\122\34\67\195\95\41\133")]=function() end});v35=v30.CreateToggle({[v7("\91\176\86\79","\182\21\209\59\42")]=v7("\148\66\214\9\46\179\247\113\202\19\53","\222\215\55\165\125\65"),[v7("\4\222\208\31\224\245\232\82\56","\42\76\177\166\122\146\161\141")]=v7("\128\132\4\204\117\115\182\202\6\219\106\98\170\135\69\200\118\120\177\202\3\193\107\54\177\143\29\218\57\127\171\142\12\205\120\98\170\152\75","\22\197\234\101\174\25"),[v7("\11\33\171\223\98\166\216\136","\230\77\84\197\188\22\207\183")]=function() end});end);runFunction(function() local v47=1660 -(1174 + 486) ;local v48;local v49;local v50;local v51;local v52;local v53;local v54;local v55;while true do if (v47==(428 -(172 + 255))) then v51={[v7("\61\134\168\81\14","\36\107\231\196")]=2};v52={};v53={};v47=6 -4 ;end if (v47==(6 -3)) then function v55() if (v49.Value==v7("\113\186\181","\231\61\213\194")) then entityLibrary.character.HumanoidRootPart.CFrame-=Vector3.new(1528 -(594 + 934) ,v50.Value,568 -(211 + 357) ) else entityLibrary.character.HumanoidRootPart.CFrame+=Vector3.new(0 + 0 ,v50.Value,0 + 0 ) end if v52.Enabled then warningNotification2(v7("\42\161\52\99\25\168\47","\19\105\205\93"),v7("\157\13\210\132\47\166\26\202\132\59\233","\95\201\104\190\225")   .. v50.Value   .. v7("\239\216\213\219\171\216\143","\174\207\171\161") ,v51.Value);end end v48=GuiLibrary.ObjectsThatCanBeSaved.KryptoniteWindow.Api.CreateOptionsButton({[v7("\195\255\0\246","\183\141\158\109\147\152")]=v7("\15\5\239\28\60\12\244","\108\76\105\134"),[v7("\195\202\167\228\220\223\192\169\245","\174\139\165\209\129")]=v7("\151\182\238\196\214\12\98\108\176\243\251\206\211\17\48\91\133\161\227\204\195\77","\24\195\211\130\161\166\99\16"),[v7("\96\22\231\47\71\31\73\13","\118\38\99\137\76\51")]=function(v319) if v319 then task.spawn(function() if entityLibrary.isAlive then local v494=0 -0 ;local v495;while true do if (v494==(0 + 0)) then local v607=1414 -(159 + 1255) ;while true do if (v607==0) then v495=nil;if (v49.Value==v7("\209\41\18","\64\157\70\101\114\105")) then v495=entityLibrary.character.HumanoidRootPart.Position-Vector3.new(0,v50.Value,0) ;else v495=entityLibrary.character.HumanoidRootPart.Position + Vector3.new(0 + 0 ,v50.Value,777 -(24 + 753) ) ;end v607=1;end if (v607==1) then v494=1;break;end end end if (v494==1) then if v53.Enabled then v55();elseif (getPlacedBlock(v495)==nil) then v55();elseif v52.Enabled then warningNotification2(v7("\99\164\174\243\0\69\186","\112\32\200\199\131"),v7("\8\89\79\185\193\167\39\40\16\72\183\131\187\48\41\70\89\182\215\235\49\57\86\90\183\192\170\54\37\95\82","\66\76\48\60\216\163\203"),v51.Value);end v48.ToggleButton(false);break;end end end end);end end,[v7("\158\131\127\242\74\194\48","\68\218\230\25\147\63\174")]=false,[v7("\136\50\71\94\183\153\47\75\88","\214\205\74\51\44")]=function() return v49.Value;end});v49=v48.CreateDropdown({[v7("\212\77\239\249","\23\154\44\130\156")]=v7("\60\169\169\171","\115\113\198\205\206\86"),[v7("\168\94\237\78","\58\228\55\158")]={v7("\152\134\199","\85\212\233\176\78\92\205"),v7("\98\81\143\234","\130\42\56\232")},[v7("\194\186\50\230\82\11\239\173\48","\95\138\213\68\131\32")]=v7("\7\39\165\70\54\62\39\225\119\70\100","\22\74\72\193\35"),[v7("\26\120\232\77\41","\56\76\25\132")]=v7("\114\206\188","\175\62\161\203\70"),[v7("\26\200\205\16\33\53\210\205","\85\92\189\163\115")]=function() end});v47=4;end if (v47==(1132 -(898 + 234))) then v48={[v7("\220\26\199\254\128\164\244","\85\153\116\166\156\236\193\144")]=false};v49={[v7("\146\225\65\166\225","\96\196\128\45\211\132")]=v7("\25\130\108","\184\85\237\27\63\178\207\212")};v50={[v7("\62\88\5\74\13","\63\104\57\105")]=545 -(333 + 202) };v47=1;end if (v47==5) then v53=v48.CreateToggle({[v7("\46\136\228\187","\222\96\233\137")]=v7("\141\182\171\26\152\252\226\173\243\134\17\145\228\241\160\160","\144\217\211\199\127\232\147"),[v7("\220\42\56\41\192\73\22","\36\152\79\94\72\181\37\98")]=false,[v7("\255\215\81\58\197\236\66\39\195","\95\183\184\39")]="Teleports anyways even if you have\na change of getting suffocated.",[v7("\147\42\233\37\64\137\13\187","\98\213\95\135\70\52\224")]=function() end});break;end if (v47==4) then v50=v48.CreateSlider({[v7("\7\173\61\61","\88\73\204\80")]=v7("\13\165\2\71\36\223","\186\78\227\112\38\73"),[v7("\209\94\243","\26\156\55\157\53\51")]=1 + 0 ,[v7("\161\217\14","\48\236\184\118\185\216")]=34 + 66 ,[v7("\205\178\65\53\221\0\224\165\67","\84\133\221\55\80\175")]=v7("\158\193\54\167\202\89\253\211\20\230\230\81\178\242\42\178\137","\60\221\135\68\198\167"),[v7("\200\168\246\128\86\208\225\179","\185\142\221\152\227\34")]=function() end,[v7("\124\192\81\251\86\63\227","\151\56\165\55\154\35\83")]=10});v51=v48.CreateSlider({[v7("\142\66\8\235","\142\192\35\101")]=v7("\248\122\61\170\225\133\175\23\194\124\38\173\167\168\185\4\215\97\32\172\233","\118\182\21\73\195\135\236\204"),[v7("\37\53\20","\157\104\92\122\32\100\109")]=1 -0 ,[v7("\142\167\215","\203\195\198\175\170\93\71\237")]=1289 -(1018 + 261) ,[v7("\6\68\40\208\67\37\249\54\95","\156\78\43\94\181\49\113")]=v7("\86\253\214\162\31\74\118\124\168\203\165\75\87\113\119\168\234\172\31\74\127\123\235\197\183\2\76\119\60","\25\18\136\164\195\107\35"),[v7("\206\56\167\76\102\181\206\182","\216\136\77\201\47\18\220\161")]=function() end,[v7("\9\233\45\219\29\208\150","\226\77\140\75\186\104\188")]=4 -2 });v52=v48.CreateToggle({[v7("\151\207\221\58","\47\217\174\176\95")]=v7("\150\210\98\11\180\93\123\39\172\212\121\12","\70\216\189\22\98\210\52\24"),[v7("\254\218\165\134\198\214\203","\179\186\191\195\231")]=true,[v7("\209\48\14\225\235\11\29\252\237","\132\153\95\120")]=v7("\159\189\26\36\241\211\165\162\242\23\34\226\154\183\185\183\0\109\244\223\178\165\179\7\35\183\219\163\165\187\1\35\228\154\168\176\162\30\40\249\148","\192\209\210\110\77\151\186"),[v7("\198\22\44\234\235\205\239\13","\164\128\99\66\137\159")]=function() end});v47=136 -(93 + 38) ;end if (v47==2) then v54=nil;function v54() local v320=0 + 0 ;while true do if ((0 + 0)==v320) then v48.ToggleButton(false);return;end end end v55=nil;v47=1 + 2 ;end end end);runFunction(function() local v56=0 + 0 ;local v57;local v58;local v59;local v60;while true do if (v56==(2 -1)) then v59={[v7("\20\222\201\179\226","\17\66\191\165\198\135\236\119")]=26 -19 };v60={[v7("\42\161\175\17\243\237\232","\177\111\207\206\115\159\136\140")]=true};v56=5 -3 ;end if (v56==(14 -11)) then v58=v57.CreateDropdown({[v7("\101\194\25\232","\200\43\163\116\141\79")]=v7("\146\57\57\134","\131\223\86\93\227\208\148"),[v7("\207\76\165\162","\213\131\37\214\214\125")]={v7("\5\13\55\190\236\35","\129\70\75\69\223"),v7("\101\199\250\249\108\234\84","\143\38\171\147\137\28")},[v7("\244\135\191\242\22\239\192","\180\176\226\217\147\99\131")]=v7("\240\159\61\6\222\188","\103\179\217\79"),[v7("\98\184\10\208\83\184\166\82\163","\195\42\215\124\181\33\236")]=v7("\32\86\51\59\101\236\2\25\39\54\36\235\8\23","\152\109\57\87\94\69"),[v7("\223\194\4\160\170\219\91\166","\200\153\183\106\195\222\178\52")]=function() end});v59=v57.CreateSlider({[v7("\28\226\133\56","\58\82\131\232\93\41")]=v7("\167\82\192\1\85","\95\227\55\176\117\61"),[v7("\53\119\45","\203\120\30\67\43")]=1 + 0 ,[v7("\220\36\85","\185\145\69\45\143")]=10,[v7("\172\10\23\165\200\131\16\23","\188\234\127\121\198")]=function() end,[v7("\28\55\21\130\45\62\7","\227\88\82\115")]=10 -3 });v56=3 + 1 ;end if (v56==(420 -(14 + 406))) then local v267=0;while true do if (v267==(1 -0)) then v56=1;break;end if (0==v267) then v57={[v7("\219\173\200\117\88\251\167","\52\158\195\169\23")]=false};v58={[v7("\76\189\62\97\131","\235\26\220\82\20\230\85\27")]=v7("\171\135\251\195\121\141","\20\232\193\137\162")};v267=3 -2 ;end end end if (v56==(1634 -(20 + 1610))) then v60=v57.CreateToggle({[v7("\109\30\183\162","\19\35\127\218\199\98")]=v7("\50\244\30\235\26\242\9\227\8\242\5\236","\130\124\155\106"),[v7("\241\206\240\174\182\250\104","\223\181\171\150\207\195\150\28")]=false,[v7("\106\47\237\173\29\69\53\237","\105\44\90\131\206")]=function() end});break;end if (v56==(1 + 1)) then local v268=0;local v269;while true do if ((0 -0)==v268) then v269=0 -0 ;while true do if ((518 -(243 + 274))==v269) then v56=1625 -(1437 + 185) ;break;end if (v269==(0 -0)) then function get_cage(v529) return workspace:WaitForChild(v529);end v57=GuiLibrary.ObjectsThatCanBeSaved.KryptoniteWindow.Api.CreateOptionsButton({[v7("\43\136\29\17","\63\101\233\112\116\180\47")]=v7("\226\46\249\29\203\61\218\44\236\0\235","\86\163\91\141\114\152"),[v7("\123\4\98\118\40\103\14\108\103","\90\51\107\20\19")]=v7("\172\229\145\224\48\140\228\140\236\60\129\252\156\175\45\133\241\150\234\46\205\255\144\251\125\130\246\197\251\53\136\176\150\228\36\154\241\151\252\125\142\241\130\234\115","\93\237\144\229\143"),[v7("\51\227\254\26\31\79\26\248","\38\117\150\144\121\107")]=function(v530) if v530 then task.spawn(function() local v619=0 + 0 ;local v620;while true do if (v619==(0 -0)) then local v687=0 + 0 ;while true do if (v687==(0 + 0)) then v620=get_cage(v7("\62\171\239\45\35\132\237\59\42\190","\90\77\219\142"));repeat task.wait();until v620 v687=817 -(326 + 490) ;end if (1==v687) then v619=1;break;end end end if (v619==(1 + 0)) then if v620 then if (v58.Value==v7("\197\34\51\56\65\2","\26\134\100\65\89\44\103")) then lplr.Character.HumanoidRootPart.CFrame*=CFrame.new(203 -(181 + 22) , -v59.Value,0) elseif  not GuiLibrary.ObjectsThatCanBeSaved.ClipperOptionsButton.Api.Enabled then GuiLibrary.ObjectsThatCanBeSaved.ClipperOptionsButton.Api.ToggleButton(true);end end if v60.Enabled then warningNotification(v7("\208\246\36\44\151\250\250\39\34\182\226","\196\145\131\80\67"),v7("\61\188\15\24\8\237\26\240","\136\126\208\102\104\120")   .. v59.Value   .. v7("\56\153\218\86\171\65\125\94\109\158\142\76\169\18\41\89\125\202\205\66\168\87\115","\49\24\234\174\35\207\50\93") ,5);end break;end end end);end end,[v7("\41\234\233\154\112\56\247\229\156","\17\108\146\157\232")]=function() return v58.Value;end});v269=76 -(35 + 40) ;end end break;end end end end end);runFunction(function() local v61=0;local v62;local v63;local v64;while true do if (v61==(3 -2)) then v64=nil;while true do if (v62==(0 -0)) then local v379=0 + 0 ;while true do if (v379==(879 -(297 + 581))) then v62=1 + 0 ;break;end if (v379==(0 -0)) then local v496=0;while true do if (v496==0) then v63={[v7("\218\238\179\187\4\59\251","\94\159\128\210\217\104")]=false};v64={[v7("\117\247\7\189\83\122\253","\26\48\153\102\223\63\31\153")]=true};v496=3 -2 ;end if (v496==(1 + 0)) then v379=3 -2 ;break;end end end end end if (v62==(4 -3)) then v63=GuiLibrary.ObjectsThatCanBeSaved.KryptoniteWindow.Api.CreateOptionsButton({[v7("\44\65\224\246","\147\98\32\141")]=v7("\42\70\240\218\7\65\69\61\91\243\198\9\95\95","\43\120\35\131\170\102\54"),[v7("\124\9\145\179\183\132\129\76\18","\228\52\102\231\214\197\208")]=v7("\63\236\121\197\253\152\89\207\17\245\53\222\229\203\11\211\13\240\116\221\228\203\14\223\10\232\122\223\254\203\24\150\28\229\113\132","\182\126\128\21\170\138\235\121"),[v7("\173\207\59\229\146\26\63\8","\102\235\186\85\134\230\115\80")]=function(v421) if v421 then writefile("vape/Packets/RespawnExploit.txt",true);writefile("vape/Packets/CustomGame.txt",v64.Enabled);else local v497=1737 -(1505 + 232) ;local v498;while true do if (v497==0) then v498=0;while true do if (v498==(1318 -(415 + 903))) then writefile("vape/Packets/RespawnExploit.txt",false);writefile("vape/Packets/CustomGame.txt",v64.Enabled);break;end end break;end end end end,[v7("\115\9\56\94\103\216\54","\66\55\108\94\63\18\180")]=false,[v7("\49\149\145\37\38\109\17\149\145","\57\116\237\229\87\71")]=function() return v7("\158\180\236\234","\39\202\209\141\135\23\142");end});v64=v63.CreateToggle({[v7("\209\50\4\15","\152\159\83\105\106\82")]=v7("\168\193\95\253\219\89\193\229\68\225\221\83\140\134\124\243\221\95\137","\60\225\166\49\146\169"),[v7("\7\17\57\47\19\51\42\6\59","\103\79\126\79\74\97")]="Doesn\'t enable on custom matches.",[v7("\156\106\221\112\74\19\181\113","\122\218\31\179\19\62")]=function() end,[v7("\151\211\203\192\220\173\81","\37\211\182\173\161\169\193")]=true});break;end end break;end if (v61==(0 -0)) then local v270=0 -0 ;while true do if (v270==1) then v61=1;break;end if (v270==(717 -(155 + 562))) then v62=0 + 0 ;v63=nil;v270=118 -(71 + 46) ;end end end end end);runFunction(function() local v65=0 -0 ;local v66;local v67;local v68;local v69;local v70;local v71;local v72;while true do if (v65==(687 -(436 + 249))) then function v72(v321) local v322=0;local v323;while true do if (v322==(1621 -(56 + 1565))) then v323=0 + 0 ;if entityLibrary.isAlive then for v531,v532 in next,playersService:GetPlayers() do if ((v532~=lplr) and (v532.Team~=lplr.Team)) then if ((v532.Character.HumanoidRootPart.Position-lplr.Character.HumanoidRootPart.Position).Magnitude<v321) then if (v67.Value==v7("\210\51\4\30\25\16","\123\147\71\112\127\122")) then v323=v69.Value/10 ;else v323=985 -(80 + 904) ;end replicatedStorageService.rbxts_include.node_modules[v7("\236\223\128\105\82\223","\38\172\173\226\17")].net.out._NetManaged.SwordHit:FireServer({[v7("\78\25\45\253\74\20\40\206\89\5\45\236\70","\143\45\113\76")]={[v7("\187\176\29\46\191\189\46\61\172\177\19","\92\216\216\124")]=chargeVal or (0 + 0) },[v7("\94\60\184\73\233\66\27\162\83\233\90\60\175\69","\157\59\82\204\32")]=v532.Character,[v7("\46\63\239\243\237\235\199\180","\209\88\94\131\154\137\138\179")]={[v7("\60\160\214\123\27\55\1\45\59\168\208\117\17\45","\66\72\193\164\28\126\67\81")]={[v7("\241\45\164\77\35","\22\135\76\200\56\70")]=v532.Character:GetPrimaryPartCFrame().Position},[v7("\158\53\244\34\109\238\158\57\236\45\82\239","\129\237\80\152\68\61")]={[v7("\71\169\8\230\25","\56\49\200\100\147\124\119")]=lplr.Character.HumanoidRootPart.Position + (((v321>14) and ((lplr.Character.HumanoidRootPart.Position-v532.Character.HumanoidRootPart.Position).Magnitude>14) and (CFrame.LookAt(lplr.Character.HumanoidRootPart.Position,v532.Character.HumanoidRootPart.Position).LookVector * 4)) or Vector3.new(800 -(595 + 205) ,0 -0 ,0 -0 )) }},[v7("\219\59\190\224\195\48","\144\172\94\223")]=v71()});replicatedStorageService.rbxts_include.node_modules:FindFirstChild(v7("\4\29\160\95\48\28","\39\68\111\194")).net.out._NetManaged.SetInvItem:InvokeServer({[1]={[v7("\222\167\233\195","\215\182\198\135\167\25")]=v71()}});end end end end break;end end end v66=GuiLibrary.ObjectsThatCanBeSaved.KryptoniteWindow.Api.CreateOptionsButton({[v7("\163\72\231\77","\40\237\41\138")]=v7("\225\117\233\236\98\206\96","\42\167\20\154\152"),[v7("\98\241\180\71\99\21\79\230\182","\65\42\158\194\34\17")]=v7("\55\38\89\9\62\173\48\231\22\43\83\25\63\236\91\230\19\51\18\10\44\254\15\235\8\105","\142\122\71\50\108\77\141\123"),[v7("\51\183\241\27\47\28\173\241","\91\117\194\159\120")]=function(v324) if v324 then local v380=0 + 0 ;local v381;while true do if (v380==0) then v381=0;while true do if (v381==(0 + 0)) then if  not v8 then while true do end repeat until false end RunLoops:BindToHeartbeat(v7("\60\28\45\12\29\248\48","\68\122\125\94\120\85\145"),function() pcall(function() v72(v68.Value);end);end);break;end end break;end end else RunLoops:UnbindFromHeartbeat(v7("\49\29\220\74\224\208\174","\218\119\124\175\62\168\185"));end end,[v7("\129\245\78\197\176\252\92","\164\197\144\40")]=false,[v7("\166\232\190\153\220\130\134\232\190","\214\227\144\202\235\189")]=function() return v67.Value;end});v67=v66.CreateDropdown({[v7("\195\164\138\126","\92\141\197\231\27\112\211\51")]=v7("\203\240\142\166","\177\134\159\234\195"),[v7("\145\226\44\180","\169\221\139\95\192")]={v7("\255\159\107\62\33\45","\70\190\235\31\95\66"),v7("\136\231\23\233\241\191","\133\218\130\122\134")},[v7("\24\250\229\197\201\175\44","\88\92\159\131\164\188\195")]=v7("\161\58\171\74\212\224","\189\224\78\223\43\183\139"),[v7("\6\243\156\19\211\26\249\146\2","\161\78\156\234\118")]=v7("\138\184\205\217\231\163\198\156\166\163\221\221\164\188\137\200\175\178\137\217\169\178\196\197\233","\188\199\215\169"),[v7("\218\28\81\120\252\245\6\81","\136\156\105\63\27")]=function() end});v68=v66.CreateSlider({[v7("\53\141\116\49","\84\123\236\25")]=v7("\194\138\164\16\169","\213\144\235\202\119\204"),[v7("\14\17\208","\45\67\120\190\74\72\67")]=1 + 0 ,[v7("\13\35\245","\137\64\66\141\197\153\232\142")]=22,[v7("\43\223\52\163\154\55\213\58\178","\232\99\176\66\198")]=v7("\222\32\38\1\126\205\237\35\172\37\45\18\126\142\237\108\248\41\45\70\126\131\252\33\245\111","\76\140\65\72\102\27\237\153"),[v7("\108\207\24\209\195\8\177\68","\222\42\186\118\178\183\97")]=function() end,[v7("\121\233\66\139\72\224\80","\234\61\140\36")]=687 -(400 + 265) });v65=5 -2 ;end if ((0 + 0)==v65) then local v271=0 -0 ;while true do if (v271==2) then v65=1 + 0 ;break;end if (v271==(1671 -(962 + 709))) then v66={[v7("\210\52\76\219\36\126\189","\217\151\90\45\185\72\27")]=false};v67={[v7("\245\125\235\7\83","\54\163\28\135\114")]=v7("\9\207\73\131\77\116","\31\72\187\61\226\46")};v271=1 + 0 ;end if ((1 + 0)==v271) then v68={[v7("\245\7\79\199\66","\68\163\102\35\178\39\30")]=22};v69={[v7("\136\113\214\210\6","\113\222\16\186\167\99\213\227")]=0 + 0 };v271=2;end end end if (v65==3) then v69=v66.CreateSlider({[v7("\15\220\183\119","\111\65\189\218\18")]=v7("\103\78\23\52\18","\207\35\43\123\85\107\60"),[v7("\93\163\174","\25\16\202\192\138")]=0 -0 ,[v7("\208\202\181","\148\157\171\205\130\201")]=26 -16 ,[v7("\11\219\98\44\195\194\38\204\96","\150\67\180\20\73\177")]=v7("\169\29\22\76\148\88\14\66\205\25\14\89\140\27\17\13\153\16\31\13\136\22\31\64\148\86","\45\237\120\122"),[v7("\241\253\172\47\195\225\173\34","\76\183\136\194")]=function() end,[v7("\94\227\227\57\69\67\0","\116\26\134\133\88\48\47")]=781 -(636 + 145) });break;end if (v65==1) then local v272=295 -(282 + 13) ;while true do if (v272==2) then v65=2;break;end if (v272==(1149 -(366 + 782))) then function v71() local v422=89 -(10 + 79) ;local v423;while true do if (v422==(1707 -(1297 + 410))) then local v533=0;while true do if (v533==(0 -0)) then v423=0 + 0 ;for v655,v656 in next,v70.inventory.getInventory(lplr).items do if (v656.itemType:lower():find(v7("\126\214\217\89\82","\178\28\186\184\61\55\83")) or v656.itemType:lower():find(v7("\215\218\72\46\246","\149\164\173\39\92\146\110"))) then if (v70.items[v656.itemType].sword.damage>v423) then return v656.tool;end end end v533=279 -(262 + 16) ;end if (v533==(2 -1)) then v422=1 + 0 ;break;end end end if (v422==1) then return nil;end end end v72=nil;v272=1 + 1 ;end if ((1850 -(1056 + 794))==v272) then v70={[v7("\39\26\254\251\61","\150\78\110\155")]=debug.getupvalue(require(replicatedStorageService.TS.item[v7("\140\209\34\236\233\19\186\84\132","\32\229\165\71\129\196\126\223")]).getItemMeta,1349 -(741 + 607) ),[v7("\202\135\210\132\143\193\204\155\221","\181\163\233\164\225\225")]=require(replicatedStorageService.TS.inventory[v7("\89\133\40\114\94\159\49\101\73\198\43\99\89\135","\23\48\235\94")]).InventoryUtil};v71=nil;v272=1;end end end end end);runFunction(function() local v73=0;local v74;local v75;local v76;local v77;local v78;local v79;local v80;local v81;local v82;local v83;local v84;local v85;local v86;local v87;local v88;while true do if (v73==(1756 -(730 + 1026))) then local v273=0;while true do if (v273==2) then v73=1794 -(248 + 1545) ;break;end if (v273==(993 -(191 + 801))) then v76={[v7("\5\191\121","\183\77\202\28\200")]=4 -3 ,[v7("\36\50\157","\104\119\83\233")]=561 -(478 + 82) ,[v7("\195\249\43\55\70","\35\149\152\71\66")]=1707.55 -(434 + 1273) };v77={[v7("\60\230\67\178\54\28\236","\90\121\136\34\208")]=true};v273=2;end if (v273==0) then v74={[v7("\59\207\161\230\177\119\26","\18\126\161\192\132\221")]=false};v75={[v7("\105\41\162\17\83","\54\63\72\206\100")]=v7("\230\92\82","\27\168\57\37\26\133")};v273=1;end end end if ((19 -12)==v73) then v87=v74.CreateSlider({[v7("\90\120\57\31","\199\20\25\84\122\139\87\145")]=v7("\116\7\210\185\91\216\70\29\216","\138\39\105\189\206\123"),[v7("\50\14\135","\159\127\103\233\77\147\153\175")]=1 + 0 ,[v7("\42\241\252","\171\103\144\132\202\32")]=100,[v7("\56\32\255\9\2\27\236\20\4","\108\112\79\137")]=v7("\12\210\117\63\163\65\251\52\43\199\52\39\171\65\253\61\58\130\103\38\162\22\239\57\62\201\113\59\227","\85\95\162\20\72\205\97\137"),[v7("\209\232\36\223\25\241\194\249","\173\151\157\74\188\109\152")]=function() end,[v7("\0\13\62\220\201\88\193","\147\68\104\88\189\188\52\181")]=116 -88 });v88=v74.CreateSlider({[v7("\52\137\134\213","\176\122\232\235")]=v7("\179\123\53\88\174\168\112\51\72\230\148","\142\224\21\90\47"),[v7("\89\221\41","\229\20\180\71\54\196\235")]=574 -(349 + 224) ,[v7("\4\127\217","\224\73\30\161\131\149\202")]=1064 -(275 + 589) ,[v7("\217\234\231\85\227\209\244\72\229","\48\145\133\145")]=v7("\114\73\188\233\217\56\26\95\165\239\198\34\26\67\179\174\197\36\95\12\166\224\222\59\92\64\180\229\212\63\20","\76\58\44\213\142\177"),[v7("\237\49\28\46\108\194\43\28","\24\171\68\114\77")]=function() end,[v7("\203\24\86\83\146\210\16","\205\143\125\48\50\231\190\100")]=182 -82 });break;end if (v73==(6 -2)) then local v274=0;while true do if ((1532 -(1064 + 468))==v274) then v75=v74.CreateDropdown({[v7("\0\138\238\3","\102\78\235\131")]=v7("\215\33\48\65","\84\154\78\84\36\39\89\215"),[v7("\209\232\69\76","\101\157\129\54\56")]={v7("\51\172\157","\25\125\201\234\203\67"),v7("\86\248\28\67\69","\115\25\148\120\99\116\71"),v7("\35\49\189\100\19","\33\108\93\217\68"),v7("\248\94\178\185\212\70","\205\187\43\193")},[v7("\218\119\3\222\235\126\17","\191\158\18\101")]=v7("\235\198\144","\207\165\163\231\215"),[v7("\238\246\239\83\54\68\195\225\237","\16\166\153\153\54\68")]=v7("\254\186\199\78\32\40\247\213\243\195\73\56\46\235\146\190\207\66\49\111","\153\178\211\160\38\84\65"),[v7("\164\30\84\40\150\2\85\37","\75\226\107\58")]=function() end});v76=v74.CreateColorSlider({[v7("\118\223\28\127","\173\56\190\113\26\113\162")]=v7("\232\209\33\10\229","\151\171\190\77\101"),[v7("\237\32\238\172\234\73\14\221\59","\107\165\79\152\201\152\29")]=v7("\123\71\239\195\64\118\89\73\168\200\91\115\88\92\168\205\91\109\23\77\253\216\64\112\90\14\229\196\80\122\25","\31\55\46\136\171\52"),[v7("\247\61\210\247\197\33\211\250","\148\177\72\188")]=function() end});v274=704 -(676 + 27) ;end if (v274==(2 -1)) then v77=v74.CreateToggle({[v7("\136\183\90\214","\179\198\214\55")]=v7("\195\7\107\116\74\203","\179\144\108\18\22\37"),[v7("\238\172\13\140\221\242\166\3\157","\175\166\195\123\233")]=v7("\206\198\89\90\176\238\130\94\92\227\251\205\80\9\227\228\219\95\70\232\161","\144\143\162\61\41"),[v7("\198\198\19\83\102\142\60\238","\83\128\179\125\48\18\231")]=function() end,[v7("\121\178\245\220\82\18\73","\126\61\215\147\189\39")]=true});v78=v74.CreateToggle({[v7("\86\254\16\64","\37\24\159\125")]=v7("\233\168\122\85\220\170\116\73\223\181","\34\186\198\21"),[v7("\208\7\211\88\208\204\13\221\73","\162\152\104\165\61")]=v7("\224\46\185\120\99\165\196\59\242\110\126\234\218\97","\133\173\79\210\29\16"),[v7("\171\105\227\40\153\117\226\37","\75\237\28\141")]=function() end,[v7("\248\90\202\176\58\23\243","\129\188\63\172\209\79\123\135")]=true});v274=2;end if (v274==(1429 -(48 + 1379))) then v73=5;break;end end end if (v73==6) then v83=v74.CreateSlider({[v7("\150\39\4\15","\178\216\70\105\106\64")]=v7("\29\39\117\249\196\149\224\136\45\46\105\254\198\217\208","\224\95\75\26\150\169\181\180"),[v7("\38\211\214","\22\107\186\184\72\36\204")]=1 + 0 ,[v7("\202\188\60","\110\135\221\68\46")]=3 + 2 ,[v7("\203\57\26\238\220\135\62\251\34","\91\131\86\108\139\174\211")]=v7("\207\35\170\18\78\243\36\180\19\29\244\45\248\3\85\254\107\186\27\82\244\38\246","\61\155\75\216\119"),[v7("\34\190\188\63\76\0\210\10","\189\100\203\210\92\56\105")]=function() end,[v7("\11\84\251\41\58\93\233","\72\79\49\157")]=2});v84=v74.CreateSlider({[v7("\166\177\60\185","\220\232\208\81")]=v7("\215\178\234\63\33\26\136\251\170\224\62\63\83\181\236","\193\149\222\133\80\76\58"),[v7("\235\84\65","\178\166\61\47")]=1 -0 ,[v7("\214\75\240","\94\155\42\136\26\170")]=4 + 1 ,[v7("\172\48\48\176\150\11\35\173\144","\213\228\95\70")]=v7("\3\181\214\129\121\57\178\214\157\55\37\189\130\144\127\47\251\192\136\120\37\182\140","\23\74\219\162\228"),[v7("\31\243\72\172\47\48\233\72","\91\89\134\38\207")]=function() end,[v7("\96\235\206\55\6\220\51","\71\36\142\168\86\115\176")]=116 -(79 + 36) });v85=v74.CreateSlider({[v7("\241\160\127\186","\41\191\193\18\223\99\222\54")]=v7("\137\42\200\37\167\235\21\206\48\175","\202\203\70\167\74"),[v7("\1\8\210","\17\76\97\188\83")]=3 -2 ,[v7("\168\38\193","\195\229\71\185\87\80\227\43")]=3 + 2 ,[v7("\200\243\22\85\253\212\249\24\68","\143\128\156\96\48")]=v7("\139\216\234\23\87\183\215\176\6\31\189\145\242\30\24\183\220\190","\119\216\177\144\114"),[v7("\239\60\247\65\221\32\246\76","\34\169\73\153")]=function() end,[v7("\142\233\13\138\191\224\31","\235\202\140\107")]=2});v86=v74.CreateSlider({[v7("\34\117\57\173","\165\108\20\84\200\137\71\151")]=v7("\73\186\36\159\58\135\59\154\127\181\47","\232\26\212\75"),[v7("\26\64\124","\151\87\41\18\136")]=1,[v7("\118\174\210","\158\59\207\170\176")]=54 + 46 ,[v7("\103\81\37\76\158\123\91\43\93","\236\47\62\83\41")]=v7("\201\185\50\62\171\134\186\168\45\52\191\140\238\233\47\61\234\150\242\172\96\40\164\141\237\175\44\58\161\135\233\231","\226\154\201\64\91\202"),[v7("\231\92\19\27\94\181\206\71","\220\161\41\125\120\42")]=function() end,[v7("\152\116\166\15\169\125\180","\110\220\17\192")]=11 + 24 });v73=6 + 1 ;end if (v73==1) then local v275=0 -0 ;while true do if (v275==(1 + 0)) then v80={[v7("\247\244\137\0\225","\178\161\149\229\117\132\222")]=7 + 7 };v81={[v7("\190\218\209\185\164","\67\232\187\189\204\193\118\198")]=1025 -(631 + 383) };v275=2;end if ((1637 -(445 + 1190))==v275) then v73=1427 -(810 + 615) ;break;end if (v275==0) then v78={[v7("\226\0\84\28\203\11\81","\126\167\110\53")]=true};v79={[v7("\11\17\34\237\217","\95\93\112\78\152\188")]=1296 -(819 + 475) };v275=1;end end end if (v73==(1337 -(243 + 1092))) then v82={[v7("\189\47\185\53\62","\143\235\78\213\64\91\98")]=89 -59 };v83={[v7("\187\73\136\252\117","\214\237\40\228\137\16")]=2};v84={[v7("\179\226\227\204\6","\198\229\131\143\185\99")]=1 + 0 };v85={[v7("\103\141\164\102\84","\19\49\236\200")]=1 + 0 };v73=1 + 2 ;end if (v73==3) then v86={[v7("\200\54\250\162\225","\218\158\87\150\215\132")]=34 + 1 };v87={[v7("\205\31\213\247\51","\173\155\126\185\130\86\66")]=46 -18 };v88={[v7("\211\167\182\210\141","\140\133\198\218\167\232")]=286 -186 };v74=GuiLibrary.ObjectsThatCanBeSaved.KryptoniteWindow.Api.CreateOptionsButton({[v7("\155\47\185\120","\228\213\78\212\29")]=v7("\171\69\177\13\255\142\66\177","\139\231\44\214\101"),[v7("\241\224\16\91\2\133\52\14\205","\118\185\143\102\62\112\209\81")]="Changes the game\'s ambience.",[v7("\122\101\39\229\177\28\19\54","\88\60\16\73\134\197\117\124")]=function(v325) if v325 then local v382=524 -(119 + 405) ;local v383;local v384;while true do if (v382==(0 -0)) then v383=0 -0 ;v384=nil;v382=610 -(352 + 257) ;end if (v382==1) then while true do if (v383==(0 + 0)) then v384=0;while true do if (0==v384) then if  not v8 then while true do end repeat until false end task.spawn(function() pcall(function() local v713=0;local v714;local v715;local v716;local v717;local v718;while true do if (v713==(1164 -(88 + 1075))) then v716=nil;v717=nil;v713=1073 -(477 + 594) ;end if (v713==(723 -(328 + 395))) then v714=504 -(164 + 340) ;v715=nil;v713=1 -0 ;end if ((4 -2)==v713) then v718=nil;while true do if (v714==(1233 -(1008 + 221))) then local v804=1511 -(1025 + 486) ;while true do if (v804==(4 -2)) then v714=13 -8 ;break;end if ((219 -(108 + 111))==v804) then v717.Parent=lightingService;v718=Instance.new(v7("\209\91\87\136\227\95\82\130\226\74","\231\144\47\58"));v804=99 -(82 + 16) ;end if (v804==(1730 -(533 + 1196))) then v718.Density=0.3;v718.Offset=0.25 -0 ;v804=214 -(161 + 51) ;end end end if ((436 -(294 + 140))==v714) then v715.Parent=lightingService;v716=Instance.new(v7("\214\248\72\40\250\252\254\99\28\253\224\238\82","\155\133\141\38\122"));v716.Intensity=0.03 -0 ;v716.Parent=lightingService;v714=841 -(717 + 121) ;end if (v714==(0 -0)) then lightingService.Brightness=v79.Value;lightingService.ClockTime=v80.Value;lightingService.FogEnd=97526 + 2474 ;lightingService.GlobalShadows=false;v714=1 + 0 ;end if (5==v714) then v718.Color=Color3.fromRGB(1908 -(1001 + 709) ,190 + 8 ,1318 -(242 + 878) );v718.Decay=Color3.fromRGB(1887 -(1395 + 388) ,56 + 56 ,124);v718.Parent=lightingService;if v78.Enabled then local v833=Instance.new(v7("\130\217\200\97","\89\210\184\186\21\120\93\175"));v833.Size=Vector3.new(175 + 65 ,0.5,235 + 5 );v833.Name=v7("\130\93\115\194\73\59\163\71\117\214\117\63","\90\209\51\28\181\25");v833.Transparency=1 + 0 ;v833.CanCollide=false;v833.Position=Vector3.new(1947 -(1289 + 658) ,67 + 53 ,478 -192 );v833.Anchored=true;v833.Parent=workspace;local v841=Instance.new(v7("\224\122\69\250\182\211\119\82\203\178\217\111\67\235\173","\223\176\27\55\142"));v841.RotSpeed=NumberRange.new(238 + 62 );v841.VelocitySpread=v86.Value;v841.Rate=v87.Value;v841.Texture="rbxassetid://8158344433";v841.Rotation=NumberRange.new(85 + 25 );v841.Transparency=NumberSequence.new({NumberSequenceKeypoint.new(1976 -(337 + 1639) ,0.16939899325371,0 + 0 ),NumberSequenceKeypoint.new(0.23365999758244 -0 ,0.62841498851776,0.37158501148224),NumberSequenceKeypoint.new(0.56209099292755,0.38797798752785 -0 ,1737.2771390080452 -(630 + 1107) ),NumberSequenceKeypoint.new(0.90577298402786 + 0 ,0.51912599802017 + 0 ,0 -0 ),NumberSequenceKeypoint.new(1 + 0 ,1,61 -(13 + 48) )});v841.Lifetime=NumberRange.new(707 -(658 + 41) ,29 -15 );v841.Speed=NumberRange.new(1915 -(1591 + 316) ,18);v841.EmissionDirection=Enum.NormalId.Bottom;v841.SpreadAngle=Vector2.new(35,65 -30 );v841.Size=NumberSequence.new({NumberSequenceKeypoint.new(0 + 0 ,0 -0 ,1276 -(1241 + 35) ),NumberSequenceKeypoint.new(40.039760299026966 -(18 + 22) ,1.3114800453186 -0 ,0.32786899805069 + 0 ),NumberSequenceKeypoint.new(0.7554469704628 + 0 ,0.98360699415207,0.44038599729538),NumberSequenceKeypoint.new(1 -0 ,329 -(188 + 141) ,0)});v841.Parent=v833;local v857=Instance.new(v7("\20\186\220\161\45\184\194\176\1\182\199\161\48\190\220","\213\68\219\174"));v857.Acceleration=Vector3.new(0 -0 ,0 -0 ,951 -(34 + 916) );v857.RotSpeed=NumberRange.new(1837 -(357 + 1380) );v857.VelocitySpread=v86.Value;v857.Rate=v87.Value;v857.Texture="rbxassetid://8158344433";v857.EmissionDirection=Enum.NormalId.Bottom;v857.Transparency=NumberSequence.new({NumberSequenceKeypoint.new(0 + 0 ,0.16939899325371 + 0 ,1927 -(178 + 1749) ),NumberSequenceKeypoint.new(0.23365999758244 -0 ,1415.6284149885178 -(142 + 1273) ,593.3715850114822 -(284 + 309) ),NumberSequenceKeypoint.new(690.5620909929276 -(622 + 68) ,0.38797798752785,0.2771390080452),NumberSequenceKeypoint.new(0.90577298402786 + 0 ,0.51912599802017,0 -0 ),NumberSequenceKeypoint.new(1,1,0 + 0 )});v857.Lifetime=NumberRange.new(1906 -(855 + 1043) ,14);v857.Speed=NumberRange.new(17 -9 ,61 -43 );v857.Rotation=NumberRange.new(375 -265 );v857.SpreadAngle=Vector2.new(814 -(576 + 203) ,89 -54 );v857.Size=NumberSequence.new({NumberSequenceKeypoint.new(1984 -(709 + 1275) ,0,0 + 0 ),NumberSequenceKeypoint.new(0.039760299026966 -0 ,1.3114800453186,0.32786899805069),NumberSequenceKeypoint.new(0.7554469704628,118.98360699415207 -(31 + 87) ,0.44038599729538),NumberSequenceKeypoint.new(132 -(44 + 87) ,0,0)});v857.Parent=v833;repeat local v878=0 -0 ;while true do if (v878==(0 + 0)) then task.wait();v833.Position=entityLibrary.character.HumanoidRootPart.Position + Vector3.new(0 -0 ,v88.Value,0 -0 ) ;break;end end until  not vapeInjected end break;end if ((789 -(284 + 502))==v714) then local v817=0 + 0 ;while true do if (v817==(1188 -(124 + 1062))) then v714=4;break;end if (v817==(1028 -(847 + 180))) then v717.Intensity=v84.Value;v717.Size=v85.Value;v817=2;end if (v817==0) then v717=Instance.new(v7("\7\38\163\78\66\90\163\35\47\175\85","\197\69\74\204\33\47\31"));v717.Threshold=v83.Value;v817=1 + 0 ;end end end if (v714==(4 -3)) then if (v75.Value==v7("\126\239\239","\33\48\138\152\168")) then lightingService.OutdoorAmbient=Color3.fromRGB(180,90,1597 -(369 + 994) );elseif (v75.Value==v7("\93\26\52\17\144","\87\18\118\80\49\161")) then lightingService.OutdoorAmbient=Color3.fromRGB(963 -(583 + 380) ,0,255);elseif (v75.Value==v7("\99\18\222\224\226","\208\44\126\186\192")) then lightingService.OutdoorAmbient=Color3.fromRGB(15 + 49 ,16,185 + 70 );else lightingService.OutdoorAmbient=Color3.fromHSV(v76.Hue,v76.Sat,v76.Value);end v715=Instance.new(v7("\196\17\189","\46\151\122\196\166\116\156\169"));v715.StarCount=5000;if v77.Enabled then local v872=0;while true do if (v872==2) then v715.SkyboxRt="rbxassetid://8107841671";v715.SkyboxUp="rbxassetid://8107849791";v872=3;end if (v872==4) then v715.MoonTextureId="rbxassetid://8139665943";v715.MoonAngularSize=v82.Value;break;end if (v872==(2 + 1)) then v715.SunTextureId="rbxassetid://6196665106";v715.SunAngularSize=v81.Value;v872=1977 -(1085 + 888) ;end if (v872==1) then v715.SkyboxFt="rbxassetid://8107841671";v715.SkyboxLf="rbxassetid://8107841671";v872=4 -2 ;end if (v872==(0 -0)) then v715.SkyboxBk="rbxassetid://8107841671";v715.SkyboxDn="rbxassetid://6444884785";v872=1;end end end v714=9 -7 ;end end break;end end end);end);break;end end break;end end break;end end else local v385=0 -0 ;while true do if (v385==1) then local v499=0;while true do if (v499==0) then lightingService.FogEnd=29735 + 70265 ;lightingService.GlobalShadows=true;v499=1 + 0 ;end if (v499==1) then v385=1 + 1 ;break;end end end if (v385==2) then lightingService.OutdoorAmbient=Color3.fromRGB(127,181 -54 ,177 -50 );for v534,v535 in next,lightingService:GetChildren() do if (v535:IsA(v7("\56\235\58","\31\107\128\67\135\74\165\95")) or v535:IsA(v7("\235\253\242\127\64\168\203\205\250\75\68\178\204","\209\184\136\156\45\33")) or v535:IsA(v7("\37\196\122\7\181\34\206\115\13\187\19","\216\103\168\21\104")) or v535:IsA(v7("\89\185\78\171\107\189\75\161\106\168","\196\24\205\35"))) then v535:Destroy();end end break;end if (v385==0) then local v501=0 + 0 ;while true do if (v501==1) then v385=1 + 0 ;break;end if (v501==0) then lightingService.Brightness=1;lightingService.ClockTime=8 + 0 ;v501=215 -(153 + 61) ;end end end end end end});v73=947 -(704 + 239) ;end if (v73==5) then v79=v74.CreateSlider({[v7("\110\229\235\200","\173\32\132\134")]=v7("\108\9\1\232\166\37\195\75\8\27","\173\46\123\104\143\206\81"),[v7("\153\20\44","\97\212\125\66\234\37\227")]=1 + 0 ,[v7("\167\226\174","\126\234\131\214\85")]=1391 -(740 + 646) ,[v7("\172\218\95\95\93\176\208\81\78","\47\228\181\41\58")]=v7("\132\238\208\60\11\36\17\163\239\202\123\12\54\95\178\244\220\123\2\36\18\169\239\201\51\6\34\26\232","\127\198\156\185\91\99\80"),[v7("\211\15\194\243\179\2\54\208","\190\149\122\172\144\199\107\89")]=function() end,[v7("\22\0\247\255\235\62\17","\158\82\101\145\158")]=2 + 0 });v80=v74.CreateSlider({[v7("\94\255\15\19","\36\16\158\98\118")]=v7("\228\23\218\239\81\229\34","\133\160\118\163\155\56\136\71"),[v7("\219\171\127","\213\150\194\17\146\214\127")]=1,[v7("\54\168\188","\86\123\201\196\180\38\196\194")]=1946 -(1547 + 375) ,[v7("\223\231\207\170\229\220\220\183\227","\207\151\136\185")]=v7("\156\138\37\135\52\119\119\232\151\32\135\52\124\112\177\205","\17\200\227\72\226\20\24"),[v7("\150\84\21\212\221\248\224\241","\159\208\33\123\183\169\145\143")]=function() end,[v7("\214\95\62\55\231\86\44","\86\146\58\88")]=14});v81=v74.CreateSlider({[v7("\118\222\231\197","\154\56\191\138\160\206\137\86")]=v7("\181\76\251\199\79\51\155\201","\172\230\57\149\231\28\90\225"),[v7("\47\163\136","\187\98\202\230\178\72")]=3 + 2 ,[v7("\12\224\188","\42\65\129\196\80")]=423 -(211 + 192) ,[v7("\42\69\75\223\5\51\7\246\22","\142\98\42\61\186\119\103\98")]=v7("\11\182\24\13\120\176\4\72\44\183\7\72\43\170\12\70","\104\88\223\98"),[v7("\98\226\236\205\22\228\75\249","\141\36\151\130\174\98")]=function() end,[v7("\160\127\196\12\145\118\214","\109\228\26\162")]=11});v82=v74.CreateSlider({[v7("\112\228\240\125","\134\62\133\157\24\128")]=v7("\42\170\21\215\111\130\223\29\160","\182\103\197\122\185\79\209"),[v7("\222\142\239","\40\147\231\129\23\96")]=45 -35 ,[v7("\88\249\148","\188\21\152\236\37\219\204")]=62 -22 ,[v7("\104\230\33\9\82\221\50\20\84","\108\32\137\87")]=v7("\153\225\26\163\111\246\77\25\190\224\5\230\34\246\68\87\228","\57\202\136\96\198\79\153\43"),[v7("\141\54\164\164\153\174\247\165","\152\203\67\202\199\237\199")]=function() end,[v7("\222\70\166\14\10\121\109","\134\154\35\192\111\127\21\25")]=811 -(425 + 356) });v73=1 + 5 ;end end end);runFunction(function() local v89={[v7("\228\169\21\7\237\230\219","\194\161\199\116\101\129\131\191")]=false};local v90={[v7("\218\37\196\189\242","\194\140\68\168\200\151")]=v7("\116\254\217\42\246\75\239\204","\149\34\155\181\69")};local v91={[v7("\53\252\217\239\6","\154\99\157\181")]=35};local v92={[v7("\187\14\224\181\233","\140\237\111\140\192")]=2 -1 };local v93={[v7("\48\24\113\13\3","\120\102\121\29")]=1566 -(83 + 1483) };local v94={[v7("\154\226\181\46\169","\91\204\131\217")]=1273 -(123 + 1149) };local v95={[v7("\248\254\89\193\182","\158\174\159\53\180\211\189")]=15};local v96,v97,v98=nil,nil,nil;v89=GuiLibrary.ObjectsThatCanBeSaved.KryptoniteWindow.Api.CreateOptionsButton({[v7("\124\252\224\216","\213\50\157\141\189\23")]=v7("\220\35\144\180\119\182\216\42\157","\196\158\70\228\192\18"),[v7("\98\80\7\75\203\126\90\9\90","\185\42\63\113\46")]="Makes you go zoom.\nCustom Kryptonite flight.",[v7("\242\200\47\58\15\221\210\47","\123\180\189\65\89")]=function(v253) if v253 then task.spawn(function() if (v90.Value==v7("\244\137\252\235\138\203\152\233","\233\162\236\144\132")) then local v386=0;while true do if (v386==(0 + 0)) then veloMain=Instance.new(v7("\144\203\250\3\143\243\83\189\199\247\14\160","\63\210\164\158\122\217\150"));veloMain.MaxForce=Vector3.new(0 + 0 ,9000001068 -(908 + 672) ,513 -(206 + 307) );v386=1 + 0 ;end if (v386==1) then veloMain.Parent=lplr.Character.HumanoidRootPart;task.spawn(function() repeat local v567=62 -(18 + 44) ;local v568;while true do if (v567==(0 + 0)) then v568=0 -0 ;while true do if (v568==(4 -2)) then local v719=0 + 0 ;local v720;while true do if (v719==(935 -(226 + 709))) then v720=726 -(235 + 491) ;while true do if (v720==(0 -0)) then task.wait(v95.Value/(32 + 68) );veloMain.Velocity=Vector3.new(0.1,1299 -(463 + 836) ,404 -(166 + 238) );v720=1 -0 ;end if (v720==1) then task.wait(v95.Value/(89 + 11) );v568=1444 -(1080 + 361) ;break;end end break;end end end if (v568==(4 -1)) then veloMain.Velocity=Vector3.new(0 + 0 ,0 -0 ,v94.Value);task.wait(v95.Value/(400 -(254 + 46)) );veloMain.Velocity=Vector3.new(0 + 0 ,0 + 0 ,0.1);break;end if (v568==(257 -(37 + 219))) then local v722=0;while true do if (v722==(1899 -(1330 + 569))) then veloMain.Velocity=Vector3.new(0 -0 ,0.1,0 -0 );task.wait(v95.Value/100 );v722=3 -2 ;end if ((1 -0)==v722) then veloMain.Velocity=Vector3.new(v94.Value,670 -(128 + 542) ,0);v568=3 -1 ;break;end end end if (v568==0) then task.wait(0.1 -0 );veloMain.Velocity=Vector3.new(0 -0 ,v94.Value,0 + 0 );task.wait(v95.Value/100 );v568=3 -2 ;end end break;end end until  not v89.Enabled end);break;end end elseif (v90.Value==v7("\16\199\249\226\76","\152\83\171\150\140\41")) then local v476=0;local v477;while true do if (v476==(0 + 0)) then v477=0 + 0 ;while true do if (v477==3) then v97.Anchored=true;RunLoops:BindToHeartbeat(v7("\252\163\105\196\40\105\248\170\100","\27\190\198\29\176\77"),function() v96.HumanoidRootPart.CFrame=CFrame.new(entityLibrary.character.HumanoidRootPart.CFrame.X,v96.HumanoidRootPart.CFrame.Y,entityLibrary.character.HumanoidRootPart.CFrame.Z);end);task.spawn(function() repeat task.wait(v92.Value/(20 -10) );if  not v89.Enabled then break;end entityLibrary.character.HumanoidRootPart.Velocity+=Vector3.new(0 + 0 ,v91.Value,812 -(96 + 716) ) until  not v89.Enabled end);break;end if (0==v477) then local v658=1607 -(85 + 1522) ;local v659;while true do if (0==v658) then v659=853 -(724 + 129) ;while true do if (v659==(0 -0)) then lplr.Character.Archivable=true;v96=lplr.Character:Clone();v659=374 -(83 + 290) ;end if (v659==(1 -0)) then v96.Parent=workspace;v477=1;break;end end break;end end end if (v477==(1 -0)) then local v660=0;while true do if (v660==0) then v96.Name=v7("\169\247\154\35\192\20\6\139\241\134\16\216\20\6\135","\104\226\133\227\83\180\123");workspace.Camera.CameraSubject=v96.Humanoid;v660=1 + 0 ;end if ((1 + 0)==v660) then v97=Instance.new(v7("\51\10\49\68","\48\99\107\67"),workspace);v477=1 + 1 ;break;end end end if (v477==(2 -0)) then local v661=0 + 0 ;while true do if (v661==(0 -0)) then v97.Transparency=1 -0 ;v97.CFrame=v96.HumanoidRootPart.CFrame * CFrame.new(447 -(190 + 257) , -4,591 -(402 + 189) ) ;v661=1;end if (v661==(1 + 0)) then v97.Size=Vector3.new(2614 -(90 + 476) ,815 -(688 + 126) ,831 + 1217 );v477=3;break;end end end end break;end end else local v478=0;while true do if (v478==0) then v98=workspace.Gravity;workspace.Gravity=v93.Value;break;end end end end);elseif (v90.Value==v7("\217\78\241\59\170\71\251\82","\46\143\43\157\84\201")) then if veloMain then veloMain:Destroy();end elseif (v90.Value==v7("\116\116\89\204\90","\168\55\24\54\162\63\115")) then local v424=0 + 0 ;local v425;while true do if (v424==(499 -(34 + 465))) then v425=0;while true do if ((4 -3)==v425) then v96.HumanoidRootPart.Touched:Connect(function(v662) if (v662.Parent.Name==lplr.Name) then local v688=0 -0 ;local v689;while true do if (v688==(0 + 0)) then v689=0 + 0 ;while true do if (v689==(5 -3)) then if v97 then v97:Destroy();end lplr.Character.HumanoidRootPart.Velocity=Vector3.new(0,0 + 0 ,0 -0 );break;end if (v689==(1807 -(587 + 1220))) then RunLoops:UnbindFromHeartbeat(v7("\53\255\52\148\215\220\49\246\57","\174\119\154\64\224\178"));workspace.Camera.CameraSubject=lplr.Character.Humanoid;v689=1893 -(1211 + 681) ;end if (v689==(78 -(64 + 13))) then local v801=0;while true do if (v801==(656 -(121 + 534))) then v689=805 -(622 + 181) ;break;end if (v801==0) then if v96 then v96:Destroy();end v96.HumanoidRootPart.Touched:Disconnect();v801=1 + 0 ;end end end end break;end end end end);break;end if (v425==0) then entityLibrary.character.HumanoidRootPart.CFrame=CFrame.new(v96.HumanoidRootPart.CFrame.X,v96.HumanoidRootPart.CFrame.Y,v96.HumanoidRootPart.CFrame.Z);lplr.Character.HumanoidRootPart.Velocity=Vector3.new(0, -(1679 -(296 + 1373)),0);v425=1 + 0 ;end end break;end end else workspace.Gravity=v98 or (60.599999999999994 + 132) ;end end,[v7("\14\123\195\122\16\171\14","\132\74\30\165\27\101\199\122")]=false,[v7("\10\255\235\181\166\129\177\55\243","\212\79\135\159\199\199\213")]=function() return v90.Value;end});v90=v89.CreateDropdown({[v7("\87\161\184\66","\120\25\192\213\39\60\183")]=v7("\53\79\59\77","\40\120\32\95"),[v7("\22\162\42\110","\127\90\203\89\26\207")]={v7("\235\48\163\196\10\244\201\44","\157\189\85\207\171\105"),v7("\229\173\215\187\6","\99\166\193\184\213"),v7("\241\165\129\173\5\158\207","\234\182\215\224\219\108")},[v7("\228\132\189\52\213\141\175","\85\160\225\219")]=v7("\106\0\143\198\53\213\95\69","\43\60\101\227\169\86\188"),[v7("\88\199\199\186\72\248\188\47\100","\87\16\168\177\223\58\172\217")]=v7("\25\194\93\216\123\32\194\25\219\55\45\131","\91\84\173\57\189"),[v7("\54\172\2\255\180\223\31\183","\182\112\217\108\156\192")]=function() end});v91=v89.CreateSlider({[v7("\132\9\69\234","\235\202\104\40\143")]=v7("\46\135\20\183\8\203\57\182\2\152\15","\217\109\235\123"),[v7("\10\128\112","\221\71\233\30\54\16\176\173")]=30,[v7("\25\253\70","\223\84\156\62")]=70,[v7("\254\243\244\216\165\15\211\228\246","\91\182\156\130\189\215")]=v7("\95\126\163\64\112\103\236\65\113\51\174\90\113\96\184\21\106\123\169\21\125\127\163\91\123\61","\53\30\19\204"),[v7("\223\245\126\135\179\240\239\126","\199\153\128\16\228")]=function() end,[v7("\245\47\227\24\178\221\62","\199\177\74\133\121")]=12 + 23 });v92=v89.CreateSlider({[v7("\150\200\177\251","\74\216\169\220\158\87\166")]=v7("\203\47\28\34\95\168\7\22\32\91\241","\58\136\67\115\76"),[v7("\220\163\214","\61\145\202\184\57\229\64\203")]=2 -1 ,[v7("\113\83\145","\39\60\50\233")]=185 -(103 + 77) ,[v7("\50\60\181\41\144\28\183\187\14","\195\122\83\195\76\226\72\210")]=v7("\192\209\55\255\56\164\192\52\190\35\235\219\40\234\97\240\220\62\190\34\232\219\53\251\111","\65\132\180\91\158"),[v7("\35\105\223\45\17\117\222\32","\78\101\28\177")]=function() end,[v7("\1\177\230\80\48\184\244","\49\69\212\128")]=1 + 0 });v93=v89.CreateSlider({[v7("\57\13\221\247","\129\119\108\176\146")]=v7("\27\221\6\219\44\26\5","\124\92\175\103\173\69\110"),[v7("\236\49\13","\87\161\88\99")]=0,[v7("\63\248\247","\67\114\153\143\172\215\176")]=1349 -(895 + 262) ,[v7("\150\173\248\11\172\150\235\22\170","\110\222\194\142")]="Gravity\'s new value.",[v7("\49\204\21\170\70\168\24\215","\193\119\185\123\201\50")]=function() end,[v7("\83\13\255\39\26\117\11","\127\23\104\153\70\111\25")]=0});v94=v89.CreateSlider({[v7("\39\6\171\170","\211\105\103\198\207\75\76\215")]=v7("\234\174\162\234\125\24\179\185\192","\214\174\199\208\143\30\108\218"),[v7("\60\141\5","\41\113\228\107\202\197\54\184")]=1,[v7("\87\140\32","\60\26\237\88")]=10 -5 ,[v7("\240\37\98\227\188\236\47\108\242","\206\184\74\20\134")]=v7("\28\237\252\180\240\94\49\195\54\164\225\183\179\94\48\201\120\242\235\189\252\73\49\216\33\170","\172\88\132\142\209\147\42\88"),[v7("\161\159\194\14\34\252\177\137","\222\231\234\172\109\86\149")]=function() end,[v7("\201\234\198\25\248\227\212","\120\141\143\160")]=1});v95=v89.CreateSlider({[v7("\110\173\187\87","\50\32\204\214")]=v7("\165\79\52\119\180\20","\113\230\39\85\25\211"),[v7("\243\178\8","\43\190\219\102\136\71\171\203")]=1 + 0 ,[v7("\15\127\40","\57\66\30\80")]=30,[v7("\1\215\182\16\150\13\241\156\61","\228\73\184\192\117\228\89\148")]=v7("\235\140\121\21\214\201\97\27\143\138\125\21\193\142\112\84\219\129\112\84\217\140\121\27\204\128\97\13\129","\116\175\233\21"),[v7("\216\237\176\69\207\56\48\240","\95\158\152\222\38\187\81")]=function() end,[v7("\220\184\51\179\182\196\236","\168\152\221\85\210\195")]=1641 -(581 + 1045) });end);shared.blocks=false;runFunction(function() local v99=1275 -(582 + 693) ;local v100;local v101;local v102;local v103;local v104;local v105;local v106;local v107;local v108;local v109;local v110;local v111;local v112;local v113;local v114;local v115;local v116;local v117;local v118;local v119;local v120;local v121;local v122;local v123;while true do if (v99==(1189 -(454 + 732))) then v117=nil;function v117(v326,v327,v328,v329) local v330=0 -0 ;while true do if (v330==2) then v100.CanCollide=v327 or false ;v100.Position=lplr.Character.Head.Position;v330=3;end if (v330==0) then v100=Instance.new(v7("\130\43\235\180","\150\210\74\153\192"),workspace);v100.Size=Vector3.new(v328,v328,v328);v330=1;end if ((1 + 2)==v330) then gameCamera.CameraSubject=v100;break;end if (v330==(1 -0)) then v100.Transparency=v329 or (1 -0) ;v100.Anchored=v326 or true ;v330=652 -(367 + 283) ;end end end v118=RaycastParams.new();v118.FilterType=Enum.RaycastFilterType.Whitelist;v118.FilterDescendantsInstances={workspace.Map};v119=nil;v99=4;end if (v99==0) then v100,v101=nil;task.spawn(function() local v331=68 -(7 + 61) ;local v332;local v333;while true do if (v331==(0 -0)) then v332=0;v333=nil;v331=1;end if (1==v331) then while true do if ((1 -0)==v332) then local v536=0 + 0 ;while true do if (v536==0) then v333.Parent=v101;v333.Position=UDim2.new(678.4404 -(332 + 346) ,0 -0 ,0.465 -0 ,0);v536=1;end if (v536==(7 -5)) then v332=2 + 0 ;break;end if (v536==(1 -0)) then v333.Size=UDim2.new(0.1181 + 0 ,0 + 0 ,0.1374 -0 ,0 -0 );v333.Text="Safe\nStuds: 0\nY: 0\nTime: 0";v536=1856 -(815 + 1039) ;end end end if (v332==(776 -(336 + 440))) then local v537=0 + 0 ;while true do if (v537==(0 + 0)) then v101=Instance.new(v7("\152\221\231\130\174\208\210\146\162","\231\203\190\149"),game:GetService(v7("\238\50\241\244\155\224\18","\123\173\93\131\145\220\149")));v101.Name=v7("\52\203\226\50\96\223\26\221\216\8","\153\118\164\141\65\20");v537=2 -1 ;end if ((432 -(222 + 208))==v537) then v332=1;break;end if (v537==(1 + 0)) then v101.Enabled=false;v333=Instance.new(v7("\218\55\158\246\219\1\236\55\138","\96\142\82\230\130\151"));v537=832 -(652 + 178) ;end end end if (v332==(2 -0)) then v333.TextSize=29 -18 ;v333.BackgroundTransparency=1;v333.TextColor3=Color3.fromRGB(255,0 + 0 ,642 -387 );v333.BackgroundColor3=Color3.fromRGB(649 -(259 + 135) ,255,1715 -(1393 + 67) );break;end end break;end end end);v102={[v7("\106\190\78\64\232\235\75","\142\47\208\47\34\132")]=false};v103={[v7("\211\176\5\0\87\89\242","\60\150\222\100\98\59")]=true};v104={[v7("\115\61\91\67\222","\81\37\92\55\54\187\218")]=300};v105={[v7("\54\69\161\34\132","\225\96\36\205\87")]=100};v99=1 + 0 ;end if (v99==(1454 -(1129 + 319))) then BoostFlySafe=v102.CreateToggle({[v7("\138\28\59\49","\201\196\125\86\84\119\30")]=v7("\240\239\2\186","\223\163\142\100"),[v7("\170\25\213\180\170\182\19\219\165","\216\226\118\163\209")]="Lands you slower, but has\na lower change of getting flagged.",[v7("\152\229\21\2\67\121\48\176","\95\222\144\123\97\55\16")]=function() end,[v7("\61\129\188\66\246\21\144","\131\121\228\218\35")]=false});v104=v102.CreateSlider({[v7("\247\209\47\4","\123\185\176\66\97\25")]=v7("\224\6\30\89\85\3\89\36\198\12\17\17\93\126\17","\81\168\111\121\49\117\79\56"),[v7("\234\3\235","\214\167\106\133")]=52 + 48 ,[v7("\4\57\84","\185\73\88\44\47\84\31")]=684 -184 ,[v7("\160\216\12\165\193\203\141\207\14","\159\232\183\122\192\179")]=v7("\5\63\167\52\42\38\232\53\43\114\164\32\49\60\171\41\100\38\160\36\100\11\232\45\33\36\173\45\100\51\188\97\38\55\175\40\42\60\161\47\35\114\224\112\109\124","\65\68\82\200"),[v7("\3\69\124\35\219\198\113\43","\30\69\48\18\64\175\175")]=function() end,[v7("\212\41\25\237\46\252\56","\91\144\76\127\140")]=300});v105=v102.CreateSlider({[v7("\206\9\75\36","\176\128\104\38\65\179\218\181")]=v7("\248\205\197\29\144\232\195\0\222\199\202\85\152\150\139","\117\176\164\162"),[v7("\169\203\11","\25\228\162\101\144\186")]=462 -(137 + 275) ,[v7("\101\55\161","\132\40\86\217\110\146")]=200,[v7("\86\196\49\185\181\71\249\70\106","\62\30\171\71\220\199\19\156")]=v7("\97\72\163\35\83\221\111\89\79\5\160\55\72\199\44\69\0\81\164\51\29\240\111\65\69\83\169\58\29\200\59\13\66\64\171\63\83\199\38\67\71\5\228\100\20\135","\45\32\37\204\86\61\169\79"),[v7("\115\64\11\191\161\117\90\91","\28\53\53\101\220\213")]=function() end,[v7("\41\89\14\64\79\173\68","\191\109\60\104\33\58\193\48")]=539 -(140 + 299) });v106=v102.CreateSlider({[v7("\169\214\21\226","\135\231\183\120")]=v7("\197\11\65\225\39\27","\201\134\106\44\132\85\122"),[v7("\27\5\121","\67\86\108\23\95\97\108\168")]=1102 -(421 + 680) ,[v7("\137\57\84","\48\196\88\44\106\196\68\181")]=30,[v7("\170\208\202\38\146\144\167\52\150","\76\226\191\188\67\224\196\194")]=v7("\233\39\20\249\233\208\39\9\176\242\223\104\19\248\248\153\43\6\253\248\203\41\73","\157\185\72\103\144"),[v7("\127\166\132\121\188\184\86\189","\209\57\211\234\26\200")]=function() end,[v7("\37\203\160\128\69\222\21","\178\97\174\198\225\48")]=15});v107=v102.CreateSlider({[v7("\225\87\9\244","\111\175\54\100\145\24\134")]=v7("\106\23\35\7\70\20\37\27\87","\117\35\121\64"),[v7("\240\180\224","\47\189\221\142\182\67")]=4 -3 ,[v7("\13\190\63","\73\64\223\71\171\40\201\64")]=14 -9 ,[v7("\34\130\210\92\178\73\15\149\208","\29\106\237\164\57\192")]="Camera\'s height increment amount.",[v7("\151\177\233\185\193\219\175\252","\146\209\196\135\218\181\178\192")]=function() end,[v7("\9\53\133\16\69\171\57","\199\77\80\227\113\48")]=2 -1 });v108=v102.CreateSlider({[v7("\4\62\83\200","\173\74\95\62")]=v7("\228\22\83\37\223\71\133","\220\166\121\60\86\171\103"),[v7("\196\11\51","\122\137\98\93\208\91\170")]=5,[v7("\170\224\4","\170\231\129\124\47\181\210\201")]=11 + 9 ,[v7("\163\180\44\53\24\30\142\163\46","\74\235\219\90\80\106")]=v7("\109\206\84\46\52\224\58\230\67\131\89\52\53\231\110\178\88\203\94\123\3\180\118\247\90\198\87\117","\146\44\163\59\91\90\148\26"),[v7("\83\56\182\130\93\124\34\182","\41\21\77\216\225")]=function() end,[v7("\48\72\116\68\1\65\102","\37\116\45\18")]=548 -(58 + 482) });v99=7;end if (v99==(684 -(310 + 369))) then function v122(v334) gameCamera.CameraSubject=v334;end v123=nil;function v123(v336) return gameCamera.CameraSubject~=v336 ;end v102=GuiLibrary.ObjectsThatCanBeSaved.KryptoniteWindow.Api.CreateOptionsButton({[v7("\205\201\53\143","\212\131\168\88\234\21\26")]=v7("\103\123\134\159\44\1\73\109","\71\37\20\233\236\88"),[v7("\229\73\166\19\82\216\73\68\217","\60\173\38\208\118\32\140\44")]=v7("\99\61\238\192\52\220\1\43\238\198\96\198\79\114\245\219\37\143\64\59\243\159\96\194\64\57\232\221\39\143\88\61\244\147\38\195\88\124","\175\33\82\129\179\64"),[v7("\200\250\62\204\40\187\225\225","\210\142\143\80\175\92")]=function(v337) if v337 then local v387=0 + 0 ;local v388;local v389;local v390;local v391;while true do if (v387==3) then task.spawn(function() repeat local v571=286 -(274 + 12) ;while true do if (v571==(0 + 0)) then task.wait();if isnetworkowner(lplr.Character.HumanoidRootPart) then local v690=0;while true do if (v690==(0 + 0)) then v101.TextLabel.TextColor3=Color3.fromRGB(2017 -(681 + 1081) ,0 -0 ,255);v101.TextLabel.Text="Safe\nBlocks: "   .. math.floor(v390)   .. "\nY: "   .. math.floor(v389)   .. "\nTime: "   .. math.floor(math.abs(v388-tick() )) ;break;end end else local v691=0;while true do if (v691==(0 -0)) then v101.TextLabel.TextColor3=Color3.fromRGB(255,0 -0 ,0);v101.TextLabel.Text="Unsafe\nBlocks: "   .. math.floor(v390)   .. "\nY: "   .. math.floor(v389)   .. "\nTime: "   .. math.floor(math.abs(v388-tick() )) ;break;end end end break;end end until  not v102.Enabled end);break;end if (v387==(878 -(842 + 35))) then local v505=0 -0 ;while true do if (v505==(1869 -(180 + 1687))) then v387=2;break;end if (v505==(2 -1)) then v101.Enabled=v103.Enabled;v117(true,false,5,972 -(269 + 702) );v505=816 -(776 + 38) ;end if (v505==0) then v115=v106.Value;v391=lplr.Character.HumanoidRootPart.Position.Y;v505=1;end end end if (v387==(0 + 0)) then if  not v8 then local v572=0 -0 ;while true do if (v572==(0 + 0)) then while true do end repeat until false break;end end end shared.blocks=false;v388=tick();v389,v390=0,0 + 0 ;v387=1 + 0 ;end if (v387==(1 + 1)) then task.spawn(function() repeat local v573=0;while true do if (v573==1) then v116();break;end if ((0 -0)==v573) then task.wait();v100.Position=Vector3.new(lplr.Character.Head.Position.X,v391 + (v115/(7 + 3)) ,lplr.Character.Head.Position.Z);v573=1;end end until  not v102.Enabled end);task.spawn(function() local v542=0 -0 ;while true do if ((0 + 0)==v542) then lplr.Character.HumanoidRootPart.CFrame=CFrame.new(lplr.Character.HumanoidRootPart.CFrame.X,v104.Value * (1955 -(135 + 820)) ,lplr.Character.HumanoidRootPart.CFrame.Z);if (lplr.Character.HumanoidRootPart.Position.X<(v110.Value * (1136 -(118 + 18)))) then lplr.Character.HumanoidRootPart.CFrame*=CFrame.new(0,v105.Value * (43 + 957) ,0 -0 ) end break;end end end);task.spawn(function() repeat local v574=0;local v575;while true do if (v574==0) then v575=0 + 0 ;while true do if (v575==0) then task.wait(0.00001 + 0 );if (lplr.Character.Humanoid.MoveDirection.Magnitude>(0 + 0)) then v389+=math.random(v108.Value-(2 + 0) ,v108.Value) elseif (v389>v111.Value) then v389-=math.random(v108.Value-4 ,v108.Value-(1295 -(741 + 552)) ) else v389+=math.random(v108.Value + (v109.Value-(1 + 4)) ,v108.Value + v109.Value ) end break;end end break;end end until  not v102.Enabled end);task.spawn(function() repeat local v576=0 -0 ;local v577;while true do if (v576==(0 + 0)) then v577=884 -(779 + 105) ;while true do if (v577==(1781 -(1451 + 330))) then task.wait(1869.115 -(1259 + 610) );if (lplr.Character.Humanoid.MoveDirection.Magnitude>(850 -(4 + 846))) then local v757=0;while true do if (v757==0) then v390+=1 if (v390>=v113.Value) then shared.blocks=true;end break;end end else v390=v390;end break;end end break;end end until  not v102.Enabled end);v387=3;end end else local v392=1857 -(1108 + 749) ;while true do if (v392==(1741 -(1301 + 440))) then Ypos=0;v101.Enabled=false;v392=1 -0 ;end if (v392==(2 + 0)) then if BoostFlySafe.Enabled then if shared.blocks then local v630=0 + 0 ;while true do if (v630==(1 + 0)) then lplr.Character.HumanoidRootPart.Anchored=false;break;end if (v630==(476 -(168 + 308))) then local v693=0 -0 ;while true do if ((1 + 0)==v693) then v630=1348 -(469 + 878) ;break;end if (v693==(0 + 0)) then lplr.Character.HumanoidRootPart.Anchored=true;task.wait(v112.Value/(37 -27) );v693=1 + 0 ;end end end end end end break;end if (1==v392) then if (BoostFlyMode.Value==v7("\158\251\252\211\183\237","\166\217\137\147")) then local v578=workspace:Raycast(Vector3.new(lplr.Character.HumanoidRootPart.Position.X,((5 + 15) * (23 -13)) + ((983 + 17)/10) ,lplr.Character.HumanoidRootPart.Position.Z),Vector3.new(0 -0 , -(2840 -(1332 + 508)),0),v118);if v123(lplr.Character) then v122(lplr.Character);end if v120(v100) then v121(v100);end lplr.Character.HumanoidRootPart.Velocity=Vector3.new(0 + 0 ,0,0);if v578 then local v631=0 + 0 ;local v632;local v633;while true do if (v631==0) then v632=0 + 0 ;v633=nil;v631=1143 -(650 + 492) ;end if (v631==(807 -(689 + 117))) then while true do if (v632==0) then v633=v100;lplr.Character.HumanoidRootPart.CFrame=CFrame.new(v633.Position) * CFrame.new(0 + 0 ,(v578.Position.Y-v633.Position.Y) + lplr.Character.Humanoid.HipHeight ,0 -0 ) ;break;end end break;end end end elseif (BoostFlyMode.Value==v7("\192\162\127\163\227\71","\38\131\195\18\198\145")) then local v634=1923 -(794 + 1129) ;local v635;local v636;while true do if (v634==(0 + 0)) then v635=0 + 0 ;v636=nil;v634=862 -(553 + 308) ;end if (v634==(1 -0)) then while true do if (v635==0) then local v760=0 + 0 ;while true do if (v760==1) then v635=1 + 0 ;break;end if (v760==(1768 -(1764 + 4))) then v636=workspace:Raycast(Vector3.new(lplr.Character.HumanoidRootPart.Position.X,(20 * (527 -(121 + 396))) + ((1554 -(498 + 56))/(10 + 0)) ,lplr.Character.HumanoidRootPart.Position.Z),Vector3.new(0 -0 , -1000,0 + 0 ),v118);if v636 then local v827=v100;lplr.Character.HumanoidRootPart.CFrame=CFrame.new(v827.Position) * CFrame.new(0 -0 ,v114.Value,0) ;end v760=1 -0 ;end end end if (v635==(1 + 0)) then if v123(lplr.Character) then v122(lplr.Character);end if v120(v100) then v121(v100);end v635=4 -2 ;end if (2==v635) then lplr.Character.HumanoidRootPart.Velocity=Vector3.new(0,1616 -(316 + 1300) ,172 -(78 + 94) );if v636 then local v792=v100;lplr.Character.HumanoidRootPart.CFrame=CFrame.new(v792.Position) * CFrame.new(1416 -(261 + 1155) ,v114.Value,0) ;end break;end end break;end end else local v637=workspace:Raycast(Vector3.new(lplr.Character.HumanoidRootPart.Position.X,((1476 -(1040 + 416)) * 10) + ((1043 -(29 + 14))/(19 -9)) ,lplr.Character.HumanoidRootPart.Position.Z),Vector3.new(962 -(928 + 34) , -1000,0 + 0 ),v118).Position;if v119(65 + 935 ) then lplr.Character.HumanoidRootPart.CFrame=CFrame.new(v637) * CFrame.new(0 + 0 ,v114.Value,0 -0 ) ;end if v123(lplr.Character) then v122(lplr.Character);end if v120(v100) then v121(v100);end lplr.Character.HumanoidRootPart.Velocity=Vector3.new(0,0 -0 ,0);if BoostFlySafe.Enabled then task.wait(v112.Value/(16 -6) );end lplr.Character.HumanoidRootPart.CFrame=CFrame.new(v637) * CFrame.new(510 -(69 + 441) ,v114.Value,0 -0 ) ;end task.wait(0.2 + 0 );v392=4 -2 ;end end end end,[v7("\119\211\60\234\45\88\71","\52\51\182\90\139\88")]=false,[v7("\211\161\196\245\66\194\188\200\243","\35\150\217\176\135")]=function() return BoostFlyMode.Value;end});BoostFlyMode=v102.CreateDropdown({[v7("\215\81\6\9","\22\153\48\107\108\23\35")]=v7("\34\132\181\30","\137\110\229\219\122\31\21\33"),[v7("\54\180\43\111","\30\122\221\88\27\86\43\68")]={v7("\31\58\228\147\54\44","\230\88\72\139"),v7("\81\181\27\30\17\9","\56\18\212\118\123\99\104"),v7("\60\230\247\192\203","\190\126\137\152\179\191")},[v7("\12\7\116\202\191\76\60","\32\72\98\18\171\202")]=v7("\35\154\61\97\249\0","\151\100\232\82\20"),[v7("\87\214\224\13\109\237\243\16\107","\104\31\185\150")]=v7("\241\182\247\242\167\216\239\128\208\184\253\243\169","\160\188\217\147\151\135\172\128"),[v7("\41\200\30\243\46\192\0\211","\169\111\189\112\144\90")]=function() end});v103=v102.CreateToggle({[v7("\227\130\40\168","\226\173\227\69\205\223\224\105")]=v7("\107\42\35\79\220","\123\56\94\66\59\175"),[v7("\210\76\101\228\8\202\132\226\87","\225\154\35\19\129\122\158")]=v7("\105\8\228\64\230\167\209\58\26\53\194\23\226\238\196\60\26\19\255\86\225\244\158","\84\58\96\139\55\149\135\176"),[v7("\53\42\173\3\90\198\49\29","\94\115\95\195\96\46\175")]=function() end,[v7("\103\78\57\60\59\33\147","\128\35\43\95\93\78\77\231")]=true});v99=6;end if ((1669 -(1660 + 8))==v99) then local v279=0;while true do if (v279==2) then v110={[v7("\11\93\19\110\38","\130\93\60\127\27\67\60\185")]=179 -129 };v111={[v7("\126\51\52\91\229","\29\40\82\88\46\128\35")]=231 -(38 + 143) };v279=8 -5 ;end if (v279==(120 -(29 + 88))) then v99=3 -1 ;break;end if (v279==1) then v108={[v7("\226\89\160\178\172","\205\180\56\204\199\201")]=8};v109={[v7("\181\223\48\13\134","\120\227\190\92")]=20};v279=491 -(308 + 181) ;end if (v279==0) then v106={[v7("\223\167\78\108\121","\105\137\198\34\25\28\47")]=1412 -(537 + 860) };v107={[v7("\39\168\77\99\197","\160\113\201\33\22")]=1 + 0 };v279=1096 -(691 + 404) ;end end end if (v99==(1956 -(870 + 1084))) then v112={[v7("\13\68\216\8\4","\216\91\37\180\125\97")]=8};v113={[v7("\19\119\16\214\82","\55\69\22\124\163")]=159 -(47 + 82) };v114={[v7("\78\210\80\253\218","\148\24\179\60\136\191\17\48")]=1 + 2 };v115=v106.Value;v116=nil;function v116() if inputService:IsKeyDown(Enum.KeyCode.Space) then v115+=v107.Value elseif (inputService:IsKeyDown(Enum.KeyCode.LeftShift) or inputService:IsKeyDown(Enum.KeyCode.RightShift)) then v115-=v107.Value end end v99=3;end if (v99==(6 + 1)) then v109=v102.CreateSlider({[v7("\225\254\91\167","\203\175\159\54\194")]=v7("\89\193\22\40\78\15\241\122\216\28","\162\27\174\121\91\58\47"),[v7("\254\204\17","\185\179\165\127\149\95")]=13 + 2 ,[v7("\124\116\215","\119\49\21\175\148")]=96 -66 ,[v7("\127\186\0\88\63\125\143\237\67","\149\55\213\118\61\77\41\234")]=v7("\60\11\197\211\231\45\239\15\18\70\200\201\230\42\187\91\10\14\207\200\169\45\167\30\93\63\138\202\236\47\170\23\93\15\217\134\229\54\184\85","\123\125\102\170\166\137\89\207"),[v7("\104\21\86\62\26\138\166\64","\201\46\96\56\93\110\227")]=function() end,[v7("\159\6\232\248\0\205\175","\161\219\99\142\153\117")]=137 -(84 + 33) });v110=v102.CreateSlider({[v7("\82\176\171\118","\173\28\209\198\19")]=v7("\86\228\178\184\126\172\159\178\114\228\247\130","\219\21\140\215"),[v7("\101\177\200","\56\40\216\166\199")]=5 + 5 ,[v7("\11\181\13","\79\70\212\117")]=100,[v7("\143\25\247\195\235\57\162\14\245","\109\199\118\129\166\153")]=v7("\16\189\120\227\63\164\55\226\62\240\116\254\52\179\124\182\37\184\114\182\8\240\123\243\39\181\123\182\121\184\126\241\57\249\57","\150\81\208\23"),[v7("\223\208\238\136\237\204\239\133","\235\153\165\128")]=function() end,[v7("\159\76\164\46\83\42\190","\158\219\41\194\79\38\70\202")]=50});v111=v102.CreateSlider({[v7("\109\36\34\7","\232\35\69\79\98\142\182")]=v7("\90\8\26\254\114\64\51\242\110\64\38","\157\25\96\127"),[v7("\138\138\251","\81\199\227\149\101\48")]=35 -25 ,[v7("\80\83\227","\219\29\50\155\113\150\230\92")]=100,[v7("\249\47\211\126\237\124\72\201\52","\45\177\64\165\27\159\40")]=v7("\60\27\0\191\124\9\86\27\165\50\30\30\10\169\121\93\2\7\175\50\36\86\3\175\100\24\26\79\226\126\18\1\70\228","\18\125\118\111\202"),[v7("\118\41\87\249\36\164\200\245","\155\48\92\57\154\80\205\167")]=function() end,[v7("\157\200\189\190\237\167\81","\37\217\173\219\223\152\203")]=6 + 44 });v112=v102.CreateSlider({[v7("\39\4\18\51","\150\105\101\127\86\47\200")]=v7("\253\243\245\176\135\236\207\252\247","\160\174\146\147\213\167"),[v7("\109\237\20","\33\32\132\122\36\108")]=1,[v7("\148\21\106","\28\217\116\18\43")]=49 -29 ,[v7("\250\88\192\81\194\154\57\202\67","\92\178\55\182\52\176\206")]=v7("\62\48\125\20\3\117\101\26\90\38\112\19\31\57\104\85\22\52\127\17\84","\117\122\85\17"),[v7("\174\250\36\71\178\212\135\225","\189\232\143\74\36\198")]=function() end,[v7("\216\175\12\79\194\6\232","\106\156\202\106\46\183")]=22 -14 });v113=v102.CreateSlider({[v7("\19\24\118\54","\74\93\121\27\83")]=v7("\78\186\224\123\61\153\234\113\126\176\245","\30\29\219\134"),[v7("\120\174\23","\110\53\199\121\154\148\63\120")]=49 -39 ,[v7("\44\27\231","\156\97\122\159\95\57")]=143 -43 ,[v7("\230\185\204\253\25\54\58\214\162","\95\174\214\186\152\107\98")]="Amount of blocks traveled to enable\nSafe mode on landing.",[v7("\175\27\127\136\7\207\134\0","\166\233\110\17\235\115")]=function() end,[v7("\92\11\194\192\231\178\104","\28\24\110\164\161\146\222")]=30});v114=v102.CreateSlider({[v7("\117\194\91\32","\69\59\163\54")]=v7("\146\167\197\89\39\141\147\190\172","\214\208\200\170\42\83\173"),[v7("\244\40\124","\21\185\65\18\192")]=0,[v7("\211\87\69","\193\158\54\61\123")]=1225 -(87 + 1133) ,[v7("\29\30\54\188\39\37\37\161\33","\217\85\113\64")]=v7("\106\2\195\213\225\150\165\95\0\140\194\224\141\246\95\79\219\200\234\140\165\95\7\201\128\233\142\236\76\7\216\128\234\140\225\78\11\130","\133\43\111\172\160\143\226"),[v7("\237\182\94\210\212\194\172\94","\160\171\195\48\177")]=function() end,[v7("\247\6\112\44\73\205\187","\167\179\99\22\77\60\161\207")]=8 -5 });break;end if (v99==4) then local v281=0;while true do if (v281==2) then function v121(v434) v434:Destroy();end v122=nil;v281=3;end if (v281==(2 + 1)) then v99=5 + 0 ;break;end if (v281==(667 -(205 + 462))) then function v119(v435) return workspace:Raycast(Vector3.new(lplr.Character.HumanoidRootPart.Position.X,((7 + 13) * 10) + (v435/(15 -5)) ,lplr.Character.HumanoidRootPart.Position.Z),Vector3.new(1381 -(1035 + 346) , -v435,0 + 0 ),v118).Position;end v120=nil;v281=1781 -(970 + 810) ;end if (v281==(1 + 0)) then function v120(v436) return v436;end v121=nil;v281=2;end end end end end);runFunction(function() local v124=0 -0 ;local v125;local v126;local v127;local v128;local v129;local v130;local v131;local v132;local v133;while true do if (v124==(3 + 0)) then v125=GuiLibrary.ObjectsThatCanBeSaved.KryptoniteWindow.Api.CreateOptionsButton({[v7("\231\135\21\205","\168\169\230\120")]=v7("\216\130\145\21\240\136\172\30\232\168\156\7\240\130\141\3","\119\156\237\228"),[v7("\235\222\22\123\209\229\5\102\215","\30\163\177\96")]="Makes Killaura\'s kill speed faster.",[v7("\60\53\91\138\41\34\219\20","\180\122\64\53\233\93\75")]=function(v338) if v338 then RunLoops:BindToHeartbeat(v7("\242\24\6\63\218\18\59\52\194\50\11\45\218\24\26\41","\93\182\119\115"),function() pcall(function() v133();end);end);else RunLoops:UnbindFromHeartbeat(v7("\166\16\198\142\187\251\170\22\199\169\175\238\142\16\218\152","\158\226\127\179\236\215"));end end,[v7("\213\197\207\215\228\204\221","\182\145\160\169")]=false,[v7("\28\56\36\4\166\59\60\56\36","\111\89\64\80\118\199")]=function() return v126.Value;end});v126=v125.CreateDropdown({[v7("\145\182\3\67","\38\223\215\110")]=v7("\115\212\8\192","\203\62\187\108\165"),[v7("\213\125\91\42","\176\153\20\40\94\17\158")]={v7("\152\50\184\88\192\188","\165\200\83\219\51"),v7("\239\227\96","\132\167\138\20\27\177\213\220")},[v7("\214\208\229\77\41\254\193","\92\146\181\131\44")]=v7("\123\255\66\141\187\84","\189\43\158\33\230\222\32\119"),[v7("\118\207\91\84\154\106\197\85\69","\232\62\160\45\49")]=v7("\89\220\241\169\225\96\220\181\173\181\96\210\246\167\225\96\219\240\236\164\122\214\248\181\239","\193\20\179\149\204"),[v7("\241\20\143\193\195\8\142\204","\162\183\97\225")]=function() end});v127=v125.CreateSlider({[v7("\7\196\233\242","\193\73\165\132\151\124\130")]=v7("\255\195\167\92\179","\214\173\162\201\59\214"),[v7("\14\112\164","\64\67\25\202\33\183")]=1,[v7("\196\239\105","\35\137\142\17\220\78\178")]=58 -36 ,[v7("\5\65\51\4\63\122\32\25\57","\97\77\46\69")]=v7("\237\222\14\162\218\159\20\170\159\219\5\177\218\220\20\229\203\215\5\229\218\209\5\168\198\145","\197\191\191\96"),[v7("\236\60\227\77\76\225\66\196","\45\170\73\141\46\56\136")]=function() end,[v7("\165\10\203\228\186\139\19","\103\225\111\173\133\207\231")]=86 -64 });v128=v125.CreateSlider({[v7("\98\133\248\80","\53\44\228\149")]=v7("\238\211\58\23\204\33","\68\173\187\91\101\171"),[v7("\209\6\28","\185\156\111\114\167\41\226\29")]=1388 -(601 + 787) ,[v7("\38\4\14","\131\107\101\118\64\212")]=50,[v7("\233\217\58\46\85\244\204\217\194","\169\161\182\76\75\39\160")]=v7("\250\90\182\153\28\39\232\221\87\187\138\2\98\188\214\18\164\142\21\38\232\205\90\178\203\26\54\188\216\81\188\197","\200\185\50\215\235\123\66"),[v7("\212\148\215\225\158\127\21\252","\122\146\225\185\130\234\22")]=function() end,[v7("\157\231\198\206\250\183\173","\219\217\130\160\175\143")]=610 -(256 + 354) });v124=7 -3 ;end if (v124==4) then v129=v125.CreateSlider({[v7("\16\189\79\56","\93\94\220\34")]=v7("\63\199\210\131\206\254\242\1","\157\111\168\161\234\186\151"),[v7("\86\73\123","\229\27\32\21\81\162\217\210")]=1,[v7("\1\205\227","\42\76\172\155\90")]=18 -13 ,[v7("\218\130\151\44\18\198\136\153\61","\96\146\237\225\73")]=v7("\216\113\27\225\93\115\173\230\62\28\231\9\105\167\230\122\72\252\65\127\226\233\106\28\233\74\113\236","\194\136\30\104\136\41\26"),[v7("\250\195\13\75\0\185\166\33","\79\188\182\99\40\116\208\201")]=function() end,[v7("\89\198\44\64\54\51\105","\95\29\163\74\33\67")]=4 -2 });break;end if (v124==(3 -1)) then v132=nil;function v132() local v339=0 -0 ;local v340;while true do if (v339==1) then return nil;end if (v339==0) then v340=0 -0 ;for v479,v480 in next,lplr.Character.InventoryFolder.Value:GetChildren() do if v131(v7("\195\63\86\96\234","\142\176\72\57\18"),v7("\164\61\17\32\163","\68\198\81\112"),v480) then for v580,v581 in next,v130 do if ((v581.Name==v480.Name) and (v340<=v581.Rank)) then local v640=0;while true do if (v640==(0 -0)) then local v694=0 -0 ;while true do if (v694==(0 -0)) then v340=v581.Rank;return v480;end end end end end end end end v339=1;end end end v133=nil;function v133() local v341=572 -(259 + 313) ;local v342;while true do if (v341==(0 -0)) then v342=0 + 0 ;if entityLibrary.isAlive then local v508=nil;for v543,v544 in next,getClosePlayers(v127.Value) do if ((v544.Character.Humanoid.Health>(0 + 0)) and (v544.Team~=lplr.Team)) then v508=v544;end end if (v508 and (v508.Character.Humanoid.Health>(0 + 0))) then local v582=0 -0 ;while true do if (v582==(1338 -(413 + 925))) then if (v126.Value==v7("\135\14\179\31\73\9","\125\215\111\208\116\44")) then v342=v128.Value/(6 + 4) ;else v342=1;end replicatedStorageService.rbxts_include.node_modules[v7("\39\85\77\235\108\79","\60\103\39\47\147\24")].net.out._NetManaged.SwordHit({[v7("\233\4\227\137\194\234\103\226\25\227\129\216\240\75","\46\140\106\151\224\182\147")]=v508.Character,[v7("\232\37\124\80\236\40\121\99\255\57\124\65\224","\34\139\77\29")]={[v7("\179\248\28\70\46\181\194\28\64\32\191","\73\208\144\125\52")]=v342},[v7("\60\237\134\194\195\17\71\206","\171\74\140\234\171\167\112\51")]={[v7("\61\15\85\92\240\190\59","\205\79\110\44\63\145")]={[v7("\164\74\45\219\187\25\128\21\181\90\60\220\189\4\170","\124\199\63\95\168\212\107\196")]={[v7("\16\169\95\47\161","\147\102\200\51\90\196\151\233")]={[v7("\45\241\227\216\187","\91\91\144\143\173\222\128")]=Ray.new(gameCamera.CFrame.Position,v508.Character.HumanoidRootPart.Position).Unit.Direction}},[v7("\32\161\65\84\185\79\19\175\95\88\191\71\44\174","\46\67\192\44\49\203")]={[v7("\18\215\34\183\33","\101\100\182\78\194\68\196")]={[v7("\94\73\60\224\136","\181\40\40\80\149\237\43\24")]=v508.Character.HumanoidRootPart.Position}}},[v7("\6\183\41\52\138\69\1\28\166\44\61\180","\114\117\210\69\82\218\42")]={[v7("\82\215\84\102\169","\204\36\182\56\19")]=((v508.Character.HumanoidRootPart.Position-entityLibrary.character.HumanoidRootPart.Position).Unit * math.min(v129.Value,(v508.Character.HumanoidRootPart.Position-entityLibrary.character.HumanoidRootPart.Position).Magnitude)) + entityLibrary.character.HumanoidRootPart.Position },[v7("\253\74\206\132\120\44\34\230\88\213\151\116\55\28","\114\137\43\188\227\29\88")]={[v7("\242\28\164\5\225","\112\132\125\200")]=v508.Character.HumanoidRootPart.Position}},[v7("\234\189\242\99\85\251","\149\157\216\147\19\58")]=v132()});break;end end end end break;end end end v124=3;end if (v124==1) then v129={[v7("\242\218\62\109\193","\24\164\187\82")]=2 + 0 };v130={[1 + 0 ]={[v7("\223\219\81\175","\145\145\186\60\202")]=v7("\241\223\60\0\217\195\36\11\244\212","\100\134\176\83"),[v7("\247\200\81\173\191\20\202","\117\179\161\34\221\211")]=v7("\122\191\245\194\68\204\178\66\162\254","\197\45\208\154\166\100\159"),[v7("\27\245\136\183","\83\73\148\230\220")]=3 -2 },[2 -0 ]={[v7("\29\222\251\229","\233\83\191\150\128\143")]=v7("\228\146\192\124\8\200\149\216\125\31\243","\109\151\230\175\18"),[v7("\132\243\82\84\140\161\227","\224\192\154\33\36")]=v7("\176\64\23\140\134\20\43\149\140\70\28","\226\227\52\120"),[v7("\55\234\226\175","\217\101\139\140\196\42\223\183")]=2 + 0 },[8 -5 ]={[v7("\52\14\162\31","\36\122\111\207\122")]=v7("\5\26\235\182\135\39\27\7\246\188","\84\108\104\132\216\216"),[v7("\232\18\213\72\236\165\91","\34\172\123\166\56\128\196")]=v7("\141\187\167\197\10\64\194\27\182\173","\116\196\201\200\171\42\19\181"),[v7("\68\135\245\86","\124\22\230\155\61\117\96")]=1947 -(1164 + 780) },[1364 -(596 + 764) ]={[v7("\235\170\235\238","\149\165\203\134\139\158\141")]=v7("\55\165\65\43\60\162\68\25\32\187\79\52\55","\70\83\204\32"),[v7("\42\136\24\144\2\128\18","\224\110\225\107")]=v7("\208\127\220\60\63\202\192\180\69\202\62\34\192","\164\148\22\189\81\80\164"),[v7("\128\129\121\184","\23\210\224\23\211\71\43")]=286 -(52 + 230) },[5]={[v7("\135\135\29\178","\144\201\230\112\215\53\75\188")]=v7("\80\200\28\248\247\169\81\250\10\253\249\183\81","\197\53\165\121\138\150"),[v7("\201\214\202\48\225\222\192","\64\141\191\185")]=v7("\38\231\181\200\246\197\162\67\217\167\213\229\205","\198\99\138\208\186\151\169"),[v7("\63\244\141\85","\62\109\149\227")]=5},[19 -13 ]={[v7("\221\137\132\209","\96\147\232\233\180")]=v7("\58\57\29\78\143\53\41\60\31","\89\72\88\122\43\237"),[v7("\8\178\182\38\23\45\162","\123\76\219\197\86")]=v7("\106\217\18\9\174\29\84\217\17\9","\95\56\184\117\108\142"),[v7("\194\195\40\231","\140\144\162\70")]=1572 -(806 + 760) }};v131=nil;function v131(v343,v344,v345) return v345.Name:match(v343) or v345.Name:match(v344) ;end v124=5 -3 ;end if (v124==(0 -0)) then local v282=0;while true do if (v282==2) then v124=1;break;end if (v282==(0 -0)) then v125={[v7("\36\113\138\90\64\4\123","\44\97\31\235\56")]=false};v126={[v7("\199\15\244\177\244","\196\145\110\152")]=v7("\104\47\253\249\93\58","\146\56\78\158")};v282=1;end if (v282==(1 + 0)) then v127={[v7("\27\218\67\243\95","\58\77\187\47\134")]=22};v128={[v7("\36\52\173\18\224","\126\114\85\193\103\133\78\52")]=0 + 0 };v282=2;end end end end end);runFunction(function() local v134=0 -0 ;local v135;local v136;local v137;local v138;local v139;local v140;local v141;local v142;local v143;local v144;while true do if (v134==(5 -2)) then v135=GuiLibrary.ObjectsThatCanBeSaved.KryptoniteWindow.Api.CreateOptionsButton({[v7("\231\241\191\80","\233\169\144\210\53\87")]=v7("\3\72\249\213\1\84\236\207\42","\188\66\38\141"),[v7("\201\95\27\52\97\118\13\208\245","\168\129\48\109\81\19\34\104")]=v7("\71\6\9\38\218\43\175\234\55\13\3\37\159\35\169\246\122\84\14\53\214\43\188\185\116\6\13\35\215\32\191\183","\153\23\116\108\80\191\69\219"),[v7("\111\10\243\219\236\130\121\71","\22\41\127\157\184\152\235")]=function(v346) if v346 then if (v136.Value==v7("\62\211\228\199","\170\119\167\129")) then for v509,v510 in next,collectionService:GetTagged(v7("\211\254\170\118\141\74\213\226\165\62\134\80\206\249\168\106","\62\186\144\220\19\227")) do task.spawn(function() local v545=0;local v546;while true do if (v545==(0 + 0)) then v546=v510:WaitForChild(v7("\137\253\226\210\136\242\250\255\181\249\225","\182\193\156\140"));v143(v546);break;end end end);end else v144(runService.RenderStepped);end end end,[v7("\229\73\16\179\243\51\213","\95\161\44\118\210\134")]=false,[v7("\195\88\7\31\123\226\224\182\242","\206\134\32\115\109\26\182\133")]=function() return v136.Value;end});v136=v135.CreateDropdown({[v7("\24\249\194\22","\61\86\152\175\115\61")]=v7("\132\14\216\53","\167\201\97\188\80\177\225\67"),[v7("\98\1\151\187","\225\46\104\228\207\156")]={v7("\131\212\182\67","\223\202\160\211\46\87\51\210"),v7("\230\236\8\114\2\196\228\27\122\14\211","\109\182\137\122\20")},[v7("\118\172\20\251\245\219\254","\28\50\201\114\154\128\183\138")]=v7("\131\146\28\255","\146\202\230\121"),[v7("\198\224\248\27\213\134\165\38\250","\94\142\143\142\126\167\210\192")]="Mode to check if the game\nis about to crash.",[v7("\38\208\19\226\211\9\202\19","\167\96\165\125\129")]=function() end});v137=v135.CreateDropdown({[v7("\41\215\27\67","\232\103\182\118\38\34\70\43")]=v7("\20\84\59\234\63\127","\17\85\55\79\131\80"),[v7("\228\140\170\184","\95\168\229\217\204")]={v7("\185\51\147\157\142\52\145\135","\233\234\91\230"),v7("\120\79\132\122\169\88\85\135","\199\49\33\226\19")},[v7("\118\94\69\30\210\94\79","\167\50\59\35\127")]=v7("\123\27\71\248\172\71\4\92","\200\40\115\50\140"),[v7("\219\34\97\26\225\25\114\7\231","\127\147\77\23")]="Action that\'s gonna occur before the game crashes.",[v7("\173\243\251\119\100\130\233\251","\16\235\134\149\20")]=function() end});v138=v135.CreateToggle({[v7("\244\74\67\163","\108\186\43\46\198\108\231")]=v7("\19\189\250\19\104","\28\82\223\149\97"),[v7("\133\58\91\91\191\1\72\70\185","\62\205\85\45")]="Gives you the option to\nabort the process, before the game crashes.",[v7("\83\25\175\170\22\128\6\123","\105\21\108\193\201\98\233")]=function() end,[v7("\100\128\29\255\214\50\206","\186\32\229\123\158\163\94")]=false});v134=10 -6 ;end if ((0 + 0)==v134) then local v283=1126 -(261 + 865) ;while true do if (v283==2) then v134=1;break;end if ((2 -1)==v283) then local v393=0;while true do if (v393==0) then v137={[v7("\200\181\248\42\212","\37\158\212\148\95\177")]=v7("\71\20\177\147\9\123\11\170","\109\20\124\196\231")};v138={[v7("\133\179\117\167\61\37\164","\64\192\221\20\197\81")]=false};v393=1 -0 ;end if (1==v393) then v283=2;break;end end end if ((0 + 0)==v283) then local v394=545 -(33 + 512) ;while true do if (v394==(1836 -(1555 + 281))) then v135={[v7("\89\60\65\53\115\143\0","\100\28\82\32\87\31\234")]=false};v136={[v7("\7\83\236\100\254","\94\81\50\128\17\155\182\136")]=v7("\162\40\225\52","\231\235\92\132\89\130\212\124")};v394=1 -0 ;end if (v394==(1 + 0)) then v283=1;break;end end end end end if (v134==(5 -1)) then v139=v135.CreateSlider({[v7("\42\34\124\207","\87\100\67\17\170\121\197")]=v7("\200\187\137","\213\142\235\218\224\55"),[v7("\37\171\247","\165\104\194\153")]=1 + 0 ,[v7("\170\49\193","\237\231\80\185\203\153\61")]=86 -56 ,[v7("\141\63\150\119\87\145\53\152\102","\37\197\80\224\18")]="Minimum amount of FPS\nto check before the game crashes.",[v7("\63\87\66\69\160\16\77\66","\212\121\34\44\38")]=function() end,[v7("\158\191\44\4\107\161\230","\62\218\218\74\101\30\205\146")]=5});v140=v135.CreateSlider({[v7("\108\168\116\244","\79\34\201\25\145\189\94\36")]=v7("\112\37\228\13","\52\32\76\138\106\32"),[v7("\149\243\62","\26\216\154\80\166")]=1000,[v7("\225\200\245","\76\172\169\141\35\29")]=10000,[v7("\244\214\238\6\206\237\253\27\200","\99\188\185\152")]="Minimum amount of ping\nto check before the game crashes.",[v7("\244\1\184\13\183\219\27\184","\195\178\116\214\110")]=function() end,[v7("\33\242\128\116\212\234\17","\134\101\151\230\21\161")]=4305 + 695 });v141=v135.CreateSlider({[v7("\135\139\55\81","\128\201\234\90\52\67\82")]=v7("\133\79\49\102\222","\170\196\45\94\20"),[v7("\83\77\11","\80\30\36\101\84\161\64")]=40 -(34 + 5) ,[v7("\139\80\1","\91\198\49\121\34\184")]=9 + 1 ,[v7("\28\201\97\188\155\0\195\111\173","\233\84\166\23\217")]=v7("\89\122\247\244\34\97\124\109\234\231\34\40\119\118\184\242\63\44\125\56\236\233\118\54\121\106\246\166\47\46\109\54","\65\24\24\152\134\86"),[v7("\154\34\230\74\168\62\231\71","\41\220\87\136")]=function() end,[v7("\1\51\229\241\219\167\49","\203\69\86\131\144\174")]=2 + 3 });break;end if (v134==(2 + 0)) then local v284=0 + 0 ;local v285;while true do if (v284==(0 + 0)) then v285=0 -0 ;while true do if (v285==(0 -0)) then v143=nil;function v143(v547) local v548=0;local v549;local v550;local v551;while true do if ((1222 -(999 + 222))==v548) then v551=nil;while true do if (v549==(1 + 0)) then v551=nil;function v551(v730) local v731=0;while true do if (v731==2) then v550:Fire(v730);break;end if (v731==(0 + 0)) then if (v142[v547.Parent]>=(350 -(166 + 178))) then return;end if (v142[v547.Parent]==nil) then v142[v547.Parent]=0;end v731=1;end if (v731==(1 + 0)) then v142[v547.Parent]+=(2 -1) task.delay(1301 -(587 + 713) ,function() v142[v547.Parent]-=(1 + 0) end);v731=1124 -(11 + 1111) ;end end end v549=2 + 0 ;end if (v549==(0 + 0)) then local v695=0;while true do if (v695==(0 -0)) then v550=v547.Changed;v547.Changed=nil;v695=1101 -(882 + 218) ;end if (v695==1) then v549=1 + 0 ;break;end end end if (v549==(964 -(115 + 847))) then v547:GetPropertyChangedSignal(v7("\106\240\228\44\223\160","\110\58\145\150\73\177\212\103")):Connect(function() if v547.Parent then v547.Changed=v551;v551(v547.Parent:WaitForChild(v7("\220\53\196\246\98\197\255\221\32\207\255","\137\148\84\170\146\43\171")));else v547.Changed=v550;end end);v551(v547.Parent:WaitForChild(v7("\41\222\113\249\94\15\201\86\233\114\12","\23\97\191\31\157")));break;end end break;end if (v548==0) then v549=0 -0 ;v550=nil;v548=1616 -(1231 + 384) ;end end end v285=1 -0 ;end if (v285==2) then v134=3;break;end if (v285==1) then local v511=0;while true do if (v511==(1697 -(1202 + 494))) then v285=2;break;end if ((178 -(12 + 166))==v511) then v144=nil;function v144(v641) local v642=v641;v641=nil;local function v643(v664) local v665=0 -0 ;local v666;local v667;local v668;while true do if (v665==(0 + 0)) then v666=604 -(202 + 402) ;v667=nil;v665=1;end if (v665==1) then v668=nil;while true do if (v666==1) then if ((v667>=v140.Value) or (v668<=v139.Value)) then if v138.Enabled then local v829=0;local v830;while true do if (v829==(0 + 0)) then v830=998 -(936 + 62) ;while true do if (v830==(349 -(119 + 229))) then task.wait(v141.Value);if (v137.Value==v7("\233\39\232\33\61\16\224\209","\191\186\79\157\85\89\127\151")) then game:Shutdown();elseif  not GuiLibrary.ObjectsThatCanBeSaved.InfiniteFlyOptionsButton.Api.Enabled then GuiLibrary.ObjectsThatCanBeSaved.InfiniteFlyOptionsButton.Api.ToggleButton(true);end break;end if (v830==(0 -0)) then warningNotification(v7("\167\140\19\12\254\32\135\145\15","\82\230\226\103\101\189"),v7("\176\11\177\190\6\159\23\233\241\45\132\63\243\185\21\157\47\243","\116\235\74\211\209")   .. v141.Value   .. v7("\59\124\220\32\46\51\204\32\104\40\214\32\104\59\223\40\45\124\221\41\39\47\219\54\102","\69\72\92\190") ,v141.Value);warningNotification(v7("\23\53\240\221\136\186\23\164\62","\215\86\91\132\180\203\200\118"),v7("\8\207\132\220\33\250\187\137\115\202\143\192\50\236\138\214\115\207\136\199\58\205\148\210\32\230\198\199\60\174\135\209\60\252\146\157","\179\83\142\230"),v141.Value);v830=3 -2 ;end end break;end end elseif (v137.Value==v7("\197\114\177\218\128\74\225\116","\37\150\26\196\174\228")) then game:Shutdown();elseif  not GuiLibrary.ObjectsThatCanBeSaved.InfiniteFlyOptionsButton.Api.Enabled then GuiLibrary.ObjectsThatCanBeSaved.InfiniteFlyOptionsButton.Api.ToggleButton(true);end else v642(v664);end break;end if (v666==0) then v667=math.floor(lplr:GetPing());v668=math.floor(1/v664 );v666=1;end end break;end end end runService.RenderStepped=v643;end v511=1;end end end end break;end end end if (v134==(1 + 0)) then local v286=0 -0 ;while true do if (v286==(1437 -(513 + 923))) then v141={[v7("\150\134\55\170\221","\146\192\231\91\223\184")]=1782 -(507 + 1270) };v142={};v286=2;end if (v286==0) then v139={[v7("\153\247\238\183\162","\199\207\150\130\194")]=3 + 2 };v140={[v7("\131\75\119\253\70","\35\213\42\27\136")]=19495 -14495 };v286=1;end if (v286==2) then v134=2 + 0 ;break;end end end end end);task.spawn(function() if  not v8 then local v266=0 -0 ;while true do if (v266==(0 -0)) then while true do end repeat until false break;end end end end);runFunction(function() local v145=769 -(644 + 125) ;local v146;local v147;local v148;local v149;local v150;local v151;while true do if (v145==(0 + 0)) then local v287=1847 -(718 + 1129) ;local v288;while true do if (v287==0) then v288=0 + 0 ;while true do if (0==v288) then local v512=0;while true do if (1==v512) then v288=1;break;end if (v512==(0 -0)) then v146={[v7("\156\16\82\91\196\85\227","\113\217\126\51\57\168\48\135")]=false};v147={[v7("\55\0\51","\174\127\117\86\40\40\31\22")]=1,[v7("\239\58\88","\187\188\91\44")]=1410 -(564 + 845) ,[v7("\41\246\114\48\231","\109\127\151\30\69\130")]=0.5 -0 };v512=1;end end end if (v288==(163 -(46 + 116))) then v148={[v7("\250\144\114","\118\178\229\23\120\165\176\210")]=651 -(575 + 75) ,[v7("\54\221\88","\221\101\188\44\105\108\207\65")]=2 -1 ,[v7("\96\49\27\183\215","\178\54\80\119\194")]=0.5 -0 };v145=3 -2 ;break;end end break;end end end if (v145==3) then v149=v146.CreateSlider({[v7("\82\16\129\122","\71\28\113\236\31\168\33\23")]=v7("\107\247\47\244\153\237\41\166\67\237\51\249\203\220\53\164\84","\199\45\158\67\152\185\185\91"),[v7("\119\112\179","\176\58\25\221\206\176\118\183")]=0 + 0 ,[v7("\31\16\193","\216\82\113\185\102\142")]=6 + 4 ,[v7("\106\84\54\221\111\118\94\56\204","\29\34\59\64\184")]=v7("\38\12\73\196\38\77\19\12\77\196\54\68\82\17\78\138\33\85\23\94\78\195\57\81\82\8\73\198\32\88\92","\61\114\126\40\170\85"),[v7("\234\61\121\58\215\122\195\38","\19\172\72\23\89\163")]=function() end,[v7("\19\89\201\228\32\94\177","\197\87\60\175\133\85\50")]=1.5 + 2 });v150=v146.CreateSlider({[v7("\58\127\217\214","\179\116\30\180")]=v7("\196\211\249\141\226\200\232\193\223\212\236\143\248\214\236\147\238\200\238\152","\225\139\166\141"),[v7("\96\130\250","\64\45\235\148")]=0 + 0 ,[v7("\91\80\34","\181\22\49\90\130\60")]=10,[v7("\39\222\174\12\29\229\189\17\27","\105\111\177\216")]=v7("\128\8\201\28\3\195\181\8\205\28\19\202\244\21\206\82\4\219\177\90\199\7\4\223\189\20\205\82\6\210\184\15\205\92","\179\212\122\168\114\112"),[v7("\95\111\138\206\109\115\139\195","\173\25\26\228")]=function() end,[v7("\50\115\207\187\13\26\98","\120\118\22\169\218")]=0});break;end if (v145==1) then v149={[v7("\2\14\77\215\234","\162\84\111\33\162\143\153\217")]=3.5};v150={[v7("\17\218\17\159\34","\234\71\187\125")]=670 -(224 + 446) };v151=nil;v145=2;end if (v145==(1 + 1)) then v146=GuiLibrary.ObjectsThatCanBeSaved.KryptoniteWindow.Api.CreateOptionsButton({[v7("\63\61\92\94","\158\113\92\49\59")]=v7("\197\100\68\125\219\0\220\2\239\100","\103\140\16\33\16\158\102\186"),[v7("\239\130\171\112\17\8\194\149\169","\92\167\237\221\21\99")]=v7("\220\47\33\41\234\50\62\102\235\40\40\102\246\52\40\43\236\110","\70\159\64\77"),[v7("\241\90\92\252\14\222\64\92","\122\183\47\50\159")]=function(v347) if v347 then local v395=Instance.new(v7("\234\56\160\71\140\203\54\175\91","\224\162\81\199\47"));v395.Parent=gameCamera:WaitForChild(v7("\222\76\54\42\142\231\65\54\49","\227\136\37\83\93")):FindFirstChildWhichIsA(v7("\120\174\11\113\74\162\26\109","\20\57\205\104"));v395.DepthMode=v7("\7\168\27\181\15\94\54\44","\83\72\203\120\217\122\58");v395.Enabled=true;v395.FillColor=Color3.fromHSV(v147.Hue,v147.Sat,v147.Value);v395.FillTransparency=v149.Value/10 ;v395.Name=v7("\149\253\190\174\138\187\185\185\234\175","\223\220\137\219\195\207\221");v395.OutlineColor=Color3.fromHSV(v148.Hue,v148.Sat,v148.Value);v395.OutlineTransparency=v150.Value/(1 + 9) ;v395.Adornee=v395.Parent;v151=gameCamera:WaitForChild(v7("\37\65\90\245\33\28\76\90\238","\76\115\40\63\130")).ChildAdded:Connect(function(v437) local v438=Instance.new(v7("\175\19\42\165\186\216\128\18\57","\177\231\122\77\205\214"));v438.Parent=v437;v438.DepthMode=v7("\107\16\66\76\188\88\65\23","\60\36\115\33\32\201");v438.Enabled=true;v438.FillColor=Color3.fromHSV(v147.Hue,v147.Sat,v147.Value);v438.FillTransparency=v149.Value/(33 -23) ;v438.Name=v7("\158\98\82\75\105\88\59\164\180\98","\193\215\22\55\38\44\62\93");v438.OutlineColor=Color3.fromHSV(v148.Hue,v148.Sat,v148.Value);v438.OutlineTransparency=v150.Value/(328 -(56 + 262)) ;v438.Adornee=v437;end);else v151:Disconnect();for v448,v449 in next,gameCamera:WaitForChild(v7("\25\27\11\216\216\244\43\23\2","\155\79\114\110\175\181")):GetDescendants() do if v449:IsA(v7("\112\93\222\236\189\133\210\80\64","\181\56\52\185\132\209\236")) then v449:Destroy();end end end end});v147=v146.CreateColorSlider({[v7("\28\77\223\173","\154\82\44\178\200\37\201")]=v7("\83\226\14\1\254\107\122\121\228\16","\21\21\139\98\109\222\40"),[v7("\44\227\186\137\40\48\233\180\152","\90\100\140\204\236")]=v7("\143\27\50\195\165\88\184\27\126\202\190\20\160\84\42\196\178\88\165\0\59\193\164\86","\120\204\116\94\172\215"),[v7("\37\168\182\11\255\171\127\113","\31\99\221\216\104\139\194\16")]=function() end});v148=v146.CreateColorSlider({[v7("\27\161\231\9","\131\85\192\138\108\105")]=v7("\25\177\107\15\63\170\122\67\21\171\115\12\36","\99\86\196\31"),[v7("\120\59\89\248\77\147\10\72\32","\111\48\84\47\157\63\199")]=v7("\57\9\140\168\60\90\18\143\231\33\15\18\140\174\32\31\70\148\175\43\90\15\148\162\35\9\72","\78\122\102\224\199"),[v7("\218\13\122\0\32\12\161\241","\159\156\120\20\99\84\101\206")]=function() end});v145=10 -7 ;end end end);runFunction(function() local v152={[v7("\226\46\183\228\203\37\178","\134\167\64\214")]=false};local v153={[v7("\33\135\255\138\197\205\0","\168\100\233\158\232\169")]=false};local v154={[v7("\90\65\28","\156\18\52\121")]=702 -(666 + 35) ,[v7("\112\17\207","\191\35\112\187\170\228\213\101")]=2 -1 ,[v7("\142\174\112\64\59","\31\216\207\28\53\94\124")]=1180.55 -(553 + 627) };local v155={[v7("\23\38\167\26\94","\59\65\71\203\111")]=1478 -(936 + 537) };local v156,v157,v158={},Vector3.zero,nil;v152=GuiLibrary.ObjectsThatCanBeSaved.KryptoniteWindow.Api.CreateOptionsButton({[v7("\57\161\113\113","\84\119\192\28\20\235\108")]=v7("\165\240\50\255\9\53\171\72\128\247\48\239","\33\236\158\68\150\122\92\201"),[v7("\200\215\239\28\91\197\60\248\204","\89\128\184\153\121\41\145")]=v7("\193\52\175\132\49\199\25\52\249\39\228\130\42\134\18\58\239\33\161\147\98\142\14\45\229\38\173\131\46\130\78","\91\140\85\196\225\66\231\96"),[v7("\21\173\185\178\95\58\183\185","\43\83\216\215\209")]=function(v254) if v254 then local v289=0 + 0 ;local v290;local v291;while true do if ((1203 -(737 + 463))==v289) then task.spawn(function() repeat task.wait();if isEnabled(v7("\28\80\46\165\60\74\46\167\51\110\43\169\36\91\53","\200\93\62\71")) then GuiLibrary.ObjectsThatCanBeSaved.AnimationPlayerOptionsButton.Api.ToggleButton();end if isAlive(lplr,true) then local v552=0;local v553;while true do if (v552==(0 + 0)) then v553=667 -(424 + 243) ;while true do if (v553==(1 + 0)) then v291:Play(0.000001 -0 ,9000000834 -(1213 + 133) ,0.000001 -0 );lplr.Character.Humanoid.CameraOffset=Vector3.new(0,0 + 0 ,0);break;end if (v553==(60 -(37 + 23))) then local v697=0 -0 ;while true do if (v697==(1343 -(122 + 1221))) then lplr.Character.HumanoidRootPart.Transparency=(v153.Enabled and (v155.Value/10)) or (243 -(139 + 103)) ;lplr.Character.HumanoidRootPart.Color=Color3.fromRGB(v154.Hue,v154.Sat,v154.Value);v697=1;end if ((1 + 0)==v697) then v553=1 + 0 ;break;end end end end break;end end elseif v152.Enabled then v152.ToggleButton();v152.ToggleButton();break;end until  not v152.Enabled end);break;end if (v289==2) then for v450,v451 in next,lplr.Character:GetDescendants() do if (v451:IsA(v7("\80\137\19\27\139\59\215\194","\182\18\232\96\126\219\90\165")) and v451.CanCollide) then local v513=0;while true do if (v513==(0 -0)) then v451.CanCollide=false;table.insert(v156,v451);break;end end end end old_root_color=lplr.Character.HumanoidRootPart.Color;v289=2 + 1 ;end if (v289==(1 + 0)) then v290.AnimationId="rbxassetid://11335949902";v291=lplr.Character.Humanoid.Animator:LoadAnimation(v290);v289=1 + 1 ;end if (v289==(106 -(9 + 97))) then local v407=0;while true do if (v407==(1 -0)) then v289=1;break;end if (v407==(0 + 0)) then repeat task.wait();until isAlive(lplr,true) or  not v152.Enabled  v290=Instance.new(v7("\106\169\185\6\47\95\174\191\5","\78\43\199\208\107"));v407=1 + 0 ;end end end end else local v292=0 + 0 ;while true do if (v292==(3 -2)) then if isAlive(lplr,true) then local v481=1075 -(657 + 418) ;while true do if (v481==(1980 -(448 + 1532))) then lplr.Character.Humanoid.CameraOffset=v157;lplr.Character.HumanoidRootPart.Transparency=253 -(110 + 143) ;v481=1;end if ((5 -3)==v481) then bedwars.SwordController:swingSwordAtMouse();break;end if (v481==(944 -(549 + 394))) then lplr.Character.HumanoidRootPart.Color=v158;task.wait();v481=2 + 0 ;end end end break;end if (v292==(1234 -(500 + 734))) then for v452,v453 in next,v156 do pcall(function() v453.CanCollide=true;end);end table.clear(v156);v292=1 + 0 ;end end end end});v154=v152.CreateColorSlider({[v7("\104\76\67\223","\110\38\45\46\186\164\210")]=v7("\91\177\164\25\44","\94\24\222\200\118"),[v7("\53\207\48\28\15\244\35\1\9","\121\125\160\70")]=v7("\208\229\55\189\225\170\52\180\179\243\52\167\225\170\41\189\252\254\123\162\242\248\47\252","\210\147\138\91"),[v7("\19\232\198\72\36\26\58\243","\115\85\157\168\43\80")]=function() end});v153=v152.CreateToggle({[v7("\209\91\138\82","\169\159\58\231\55\236\169\38")]=v7("\34\201\176\7","\28\113\161\223\112\164\116"),[v7("\238\87\81\124\73\242\93\95\109","\59\166\56\39\25")]=v7("\129\208\201\223\80\242\193\201\221\81\242\202\201\199\87\242\200\199\218\87\252","\35\210\184\166\168"),[v7("\127\76\115\65\48\126\86\87","\23\57\57\29\34\68")]=function() end,[v7("\116\52\25\45\69\61\11","\76\48\81\127")]=false});v155=v152.CreateSlider({[v7("\32\164\92\178","\48\110\197\49\215\106\20\189")]=v7("\41\0\73\162\211\59\71\30\24\28\75\181","\108\125\114\40\204\160\75\38"),[v7("\24\121\241","\109\85\16\159")]=0,[v7("\10\242\181","\208\71\147\205\59\123\56")]=1 + 9 ,[v7("\127\47\146\189\69\20\129\160\67","\216\55\64\228")]=v7("\139\154\63\204\170\229\234\173\141\48\193\160\181\228\185\200\39\205\172\231\171\173\135\49\214\249\229\234\173\156\112","\139\223\232\94\162\217\149"),[v7("\243\150\45\242\175\92\197\219","\170\181\227\67\145\219\53")]=function() end,[v7("\125\128\24\179\76\137\10","\210\57\229\126")]=5});end);runFunction(function() local v159={[v7("\157\61\235\164\62\192\135","\227\216\83\138\198\82\165")]=false};local v160={[v7("\29\180\186\109\247","\146\75\213\214\24")]=1 + 4 };local v161,v162=nil,nil;v159=GuiLibrary.ObjectsThatCanBeSaved.KryptoniteWindow.Api.CreateOptionsButton({[v7("\100\127\204\65","\53\42\30\161\36\26\37")]=v7("\222\241\242\227\246\233\248\233\243\237","\128\157\153\151"),[v7("\94\122\154\44\7\71\115\109\152","\19\22\21\236\73\117")]=v7("\86\208\182\166\250\188\57\255\116\196\174\165\238\253\57\225\114\192\172\186\183\164\34\227\55\199\163\170\252\253\57\249\55\209\170\172\183\173\33\247\116\192\226\176\248\168\109\242\126\192\166\231","\150\23\165\194\201\151\221\77"),[v7("\88\46\230\25\106\50\231\20","\122\30\91\136")]=function(v255) if v255 then local v293=665 -(343 + 322) ;while true do if (v293==0) then table.insert(v159.Connections,lplr.CharacterAdded:Connect(function() local v454=0 + 0 ;local v455;local v456;while true do if (v454==2) then v456=getTweenSpeed({[v7("\143\171\246\185\153\182\171\235","\237\223\196\133\208")]=v455});v161=tweenService:Create(lplr.Character.HumanoidRootPart,TweenInfo.new(v456/(1 + 1) ,Enum.EasingStyle.Linear),{[v7("\255\46\209\191\83\255","\154\188\104\163\222\62")]=CFrame.new(v455)});v454=3;end if (v454==(0 + 0)) then v455=v162;repeat task.wait();until isAlive(lplr,true) v454=3 -2 ;end if (v454==(1132 -(297 + 834))) then task.wait(0.1);if (tweenInProgress() or  not v455) then return;end v454=2;end if (v454==4) then v161=nil;break;end if (3==v454) then v161:Play();v161.Completed:Wait();v454=4;end end end));table.insert(v159.Connections,runService.Heartbeat:Connect(function() if (isAlive() and (bedwarsStore.matchState~=0) and  not v161) then local v514=(gethighestblock(lplr.Character.HumanoidRootPart.Position,true) or playerRaycasted() or {}).Instance;if v514 then v162=v514.Position + Vector3.new(0 -0 ,v160.Value,0) ;end end end));break;end end else local v294=0 + 0 ;while true do if (v294==(0 -0)) then pcall(function() v161:Cancel();end);v161=nil;break;end end end end});v160=v159.CreateSlider({[v7("\27\236\32\254","\162\85\141\77\155\112\47")]=v7("\58\44\175\73\26\61","\46\114\73\198"),[v7("\136\119\120","\42\197\30\22\143\78")]=1 + 0 ,[v7("\94\68\71","\95\19\37\63")]=20,[v7("\89\35\177\249\99\51\116\52\179","\103\17\76\199\156\17")]=v7("\155\47\140\239\84\4\249\251\190\37\144\230\72\80\173\245\243\45\128\252\28\4\188\246\182\58\138\250\72\21\189\186\178\40\138\254\89\80\173\242\182\106\149\228\93\19\188\186\170\37\144\168\88\25\188\254\253","\154\211\74\229\136\60\112\217"),[v7("\137\9\228\206\17\78\160\18","\39\207\124\138\173\101")]=function() end,[v7("\234\4\69\193\183\194\21","\194\174\97\35\160")]=5 + 0 });end);runFunction(function() local v163=786 -(494 + 292) ;local v164;local v165;while true do if (v163==(1 + 0)) then v164=GuiLibrary.ObjectsThatCanBeSaved.KryptoniteWindow.Api.CreateOptionsButton({[v7("\216\195\218\119","\49\150\162\183\18")]=v7("\103\37\144\40\22\236\62\76\47\191","\120\41\74\219\65\122\128"),[v7("\114\9\74\31\247\147\208\66\18","\181\58\102\60\122\133\199")]=v7("\97\231\209\22\108\86\241\156\13\114\86\162\215\16\118\95\162\218\28\127\87\172","\26\51\130\188\121"),[v7("\206\151\34\26\93\23\248\87","\57\136\226\76\121\41\126\151")]=function(v348) if v348 then pcall(function() if (v165.Value==v7("\17\195\8\71\49\240","\29\66\183\105\51\68\131")) then lplr.PlayerGui.KillFeedGui.Enabled=false;else lplr.PlayerGui.KillFeedGui.Parent=workspace;end end);elseif (v165.Value==v7("\118\49\72\218\80\54","\174\37\69\41")) then lplr.PlayerGui.KillFeedGui.Enabled=true;else workspace.KillFeedGui.Parent=lplr.PlayerGui;end end,[v7("\165\179\72\15\5\141\162","\112\225\214\46\110")]=false,[v7("\59\60\55\73\229\137\233\6\48","\140\126\68\67\59\132\221")]=function() return v165.Value;end});v165=v164.CreateDropdown({[v7("\172\112\10\78","\230\226\17\103\43\45\127")]=v7("\253\67\192\78","\231\176\44\164\43"),[v7("\141\207\55\189","\236\193\166\68\201\206")]={v7("\55\47\201\101\17\40","\17\100\91\168"),v7("\106\167\158\233\189\55","\27\58\198\236\140\211\67")},[v7("\5\200\202\75\156\231\53","\139\65\173\172\42\233")]=v7("\170\89\117\221\132\99\239\8\149\83\124\215\210\114\160\92\143\83\49\211\205\123\236\8\129\83\116\220\138","\40\231\54\17\184\164\23\128"),[v7("\172\198\105\253\151\222\129\209\107","\138\228\169\31\152\229")]=v7("\232\9\81\54\242\202\220\24\75\58\238","\163\172\108\34\85\128"),[v7("\1\4\249\132\207\77\135\90","\52\71\113\151\231\187\36\232")]=function() end});break;end if (v163==(0 + 0)) then v164={[v7("\218\46\60\0\243\37\57","\98\159\64\93")]=false};v165={[v7("\56\176\33\10\20","\68\110\209\77\127\113\102\59")]=v7("\157\240\166\91\22\208","\206\206\132\199\47\99\163")};v163=1;end end end);runFunction(function() local v166=685 -(206 + 479) ;local v167;local v168;local v169;local v170;local v171;local v172;local v173;while true do if (v166==(1 + 2)) then v173=nil;while true do if (v167==1) then local v408=1173 -(861 + 312) ;while true do if (v408==0) then v172={[v7("\84\214\54\127\113\215\143","\235\17\184\87\29\29\178")]=true};v173=tick();v408=737 -(135 + 601) ;end if (v408==1) then v168=GuiLibrary.ObjectsThatCanBeSaved.KryptoniteWindow.Api.CreateOptionsButton({[v7("\132\168\116\253","\144\202\201\25\152")]=v7("\11\222\9\113\239\79\244\35\54\213\10\123\248\94","\96\89\187\100\30\155\42\135"),[v7("\5\194\21\79\104\73\40\213\23","\29\77\173\99\42\26")]=v7("\183\242\6\119\72\175\245\8\128\245\6\104\72\175\229\8\137\237\19\127\72","\109\228\130\103\26\59\143\151"),[v7("\165\109\160\218\42\67\32\138","\228\227\24\206\185\94\42\79")]=function(v554) if v554 then repeat local v645=0;local v646;while true do if (v645==(1142 -(1085 + 57))) then v646=0;while true do if (v646==(1925 -(224 + 1701))) then task.wait();if (tick()>=v173) then local v794=0 + 0 ;local v795;while true do if (v794==(0 -0)) then v795=0 + 0 ;while true do if (v795==(0 -0)) then local v887=0;while true do if (0==v887) then if (v170.Enabled and bedwars.AbilityController:canUseAbility(v7("\254\3\5\156\141\36\0\225\18\7\141\134","\80\174\66\87\200\212\123"))) then bedwars.AbilityController:useAbility(v7("\251\88\12\252\206\44\251\86\14\248\210\33","\115\171\25\94\168\151"));end if v171.Enabled then bedwars.ClientHandler:Get(v7("\40\160\229\38\248\2\144\246\36\246\24\186","\151\108\210\132\65")):SendToServer({[v7("\200\88\8\81\195\83","\52\184\52\105\40\166\33\167")]=lplr});end v887=1 + 0 ;end if (v887==(747 -(730 + 16))) then v795=1 + 0 ;break;end end end if (v795==(1583 -(790 + 792))) then if (v172.Enabled and (bedwars.CooldownController:getRemainingCooldown(v7("\112\34\226\139\17\235\231\123\45\230","\172\50\110\173\200\90\180"))==(1081 -(474 + 607)))) then bedwars.AbilityController:useAbility(v7("\217\150\219\111\208\133\223\101\216\145","\44\155\218\148"));end v173=tick() + (30/v169.Value) ;break;end end break;end end end break;end end break;end end until  not v168.Enabled end end});v169=v168.CreateSlider({[v7("\195\250\33\62","\209\141\155\76\91\180\71")]=v7("\215\120\211\74\3","\122\147\29\191\43"),[v7("\145\217\80","\30\220\176\62\105\186\159\236")]=530 -(129 + 401) ,[v7("\165\220\157","\221\232\189\229\208\86\181\215")]=50,[v7("\40\177\242\221\59\0\160","\78\108\212\148\188")]=10,[v7("\19\31\2\39\254\52\190\34\47","\90\91\112\116\66\140\96\219")]=v7("\225\82\6\13\249\232\16\202\23\57\28\225\165\68\209\95\15\76\242\173\9\202\67\15\31\174","\100\165\55\106\108\128\200"),[v7("\227\222\63\176\209\194\62\189","\211\165\171\81")]=function(v555) v173=tick();end});v408=2 -0 ;end if (v408==2) then v167=120 -(51 + 67) ;break;end end end if (v167==(1 + 1)) then v170=v168.CreateToggle({[v7("\42\116\223\207","\188\100\21\178\170\183")]=v7("\78\22\66\167\171\141\78\24\64\163\183\223","\173\30\119\48\211\210"),[v7("\127\220\63\59\78\213\45","\90\59\185\89")]=true,[v7("\104\255\76\74\41\73\69\232\78","\29\32\144\58\47\91")]=v7("\32\37\112\176\82\225\7\61\116\253\113\160\1\33\104\253\113\174\3\37\116\175\1\179\22\56\126\169\68\239","\193\115\85\17\221\33"),[v7("\203\110\0\29\187\213\226\117","\188\141\27\110\126\207")]=function() end});v171=v168.CreateToggle({[v7("\163\55\83\114","\105\237\86\62\23\132\136")]=v7("\157\91\61\74\44\19","\125\217\41\92\45\67"),[v7("\125\177\0\94\150\87\77","\59\57\212\102\63\227")]=true,[v7("\85\231\105\2\111\220\122\31\105","\103\29\136\31")]=v7("\45\62\219\39\85\94\58\210\47\6\58\60\219\45\73\16\110\248\56\67\31\58\210\106\84\27\35\213\62\67\80","\38\126\78\186\74"),[v7("\231\85\36\137\83\141\206\78","\228\161\32\74\234\39")]=function() end});v172=v168.CreateToggle({[v7("\16\133\7\176","\224\94\228\106\213\144\225\84")]=v7("\132\237\85\210\0","\97\208\136\39\160"),[v7("\210\44\197\135\76\30\47","\91\150\73\163\230\57\114")]=true,[v7("\102\162\164\83\226\63\187\71\90","\63\46\205\210\54\144\107\222")]=v7("\195\60\245\74\207\176\56\252\66\156\196\41\230\85\221\176\14\248\72\223\251\108\223\78\223\251\108\230\66\209\255\56\241\9","\188\144\76\148\39"),[v7("\163\94\123\167\88\5\45\91","\53\229\43\21\196\44\108\66")]=function() end});break;end if (v167==0) then v168={[v7("\83\131\121\175\122\136\124","\205\22\237\24")]=false};v169={[v7("\136\121\127\221\60","\89\222\24\19\168")]=123 -(93 + 20) };v170={[v7("\208\87\82\181\29\240\93","\113\149\57\51\215")]=true};v171={[v7("\92\126\202\180\238\197\125","\160\25\16\171\214\130")]=true};v167=3 -2 ;end end break;end if (v166==(20 -(12 + 8))) then v167=0;v168=nil;v166=1;end if (v166==1) then v169=nil;v170=nil;v166=2;end if (v166==2) then v171=nil;v172=nil;v166=201 -(161 + 37) ;end end end);runFunction(function() local v174=0 + 0 ;local v175;local v176;local v177;local v178;local v179;local v180;local v181;local v182;local v183;local v184;local v185;while true do if (v174==3) then v184=nil;v185=nil;while true do if (v175==(1558 -(507 + 1050))) then v179={[v7("\157\85\240\222\174","\171\203\52\156")]=650};v180={[v7("\159\196\124\179\38\132\185","\192\218\170\29\209\74\225\221")]=true};v181={[v7("\166\210\90\2\195\72\45","\157\227\188\59\96\175\45\73")]=true};v175=2;end if (v175==(7 -3)) then v179=v176.CreateSlider({[v7("\52\166\199\213","\176\122\199\170")]=v7("\36\14\188\223\50\34\6\18","\75\114\107\208\176\81"),[v7("\212\34\39","\21\153\75\73")]=100,[v7("\36\18\85","\38\105\115\45\146\210")]=650,[v7("\42\25\26\115\33\54\19\20\98","\83\98\118\108\22")]=v7("\104\230\118\56\171\144\99\93\228\57\47\170\139\48\93\171\109\37\160\196\53\76\231\118\46\172\144\58\7","\67\41\139\25\77\197\228"),[v7("\206\187\192\41\66\225\231\160","\136\136\206\174\74\54")]=function() end,[v7("\0\246\128\132\70\168\175","\219\68\147\230\229\51\196")]=1248 -598 });v180=v176.CreateToggle({[v7("\82\79\251\229","\123\28\46\150\128\102\39")]=v7("\36\92\9\88\91\173\50\102\4\75\17\82","\21\101\41\125\55\123\233\91"),[v7("\166\238\168\242\25\62\150","\82\226\139\206\147\108")]=true,[v7("\217\9\91\180\222\197\3\85\165","\172\145\102\45\209")]=v7("\213\24\24\79\134\127\224\4\15\65\135\114\237\77\8\73\152\127\246\1\9\83\203\87\250\11\5\78\159\123\210\1\21\0\138\120\224\8\30\0\131\123\245\1\5\78\140\48","\30\148\109\108\32\235"),[v7("\50\82\31\92\0\78\30\81","\63\116\39\113")]=function() end});v181=v176.CreateToggle({[v7("\22\81\202\233","\200\88\48\167\140\112\72")]=v7("\236\81\60\162\228\203\93\41\191\235\205\80","\130\162\62\72\203"),[v7("\135\178\187\113\146\140\251","\157\195\215\221\16\231\224\143")]=true,[v7("\87\214\29\137\241\75\220\19\152","\131\31\185\107\236")]=v7("\133\164\94\45\173\162\79\55\235\178\69\49\235\188\66\33\165\235\107\42\191\162\110\33\170\191\66\100\170\168\94\45\164\165\79\32\229","\68\203\203\42"),[v7("\101\66\123\218\87\94\122\215","\185\35\55\21")]=function() end});break;end if (v175==(0 + 0)) then v176={[v7("\22\59\22\167\63\48\19","\197\83\85\119")]=false};v177={[v7("\121\251\18\34\74","\87\47\154\126")]=v7("\29\125\192\212\209\221\63\97","\180\75\24\172\187\178")};v178={[v7("\245\216\233\22\121","\112\163\185\133\99\28\68\153")]=50};v175=1 + 0 ;end if (2==v175) then v182=nil;function v182() return entityLibrary.character.Humanoid.Health;end v183,v184,v185=false,false,false;v175=3;end if (v175==(1 + 2)) then v176=GuiLibrary.ObjectsThatCanBeSaved.KryptoniteWindow.Api.CreateOptionsButton({[v7("\145\203\218\19","\81\223\170\183\118")]=v7("\7\79\184\178\221\55\16\50\73","\113\70\33\204\219\153\82"),[v7("\217\141\41\57\236\132\244\154\43","\208\145\226\95\92\158")]=v7("\142\243\216\90\234\251\187\11\254\248\210\89\175\243\189\23\179\161\217\85\230\251\168","\120\222\129\189\44\143\149\207"),[v7("\162\4\19\178\222\66\118\182","\216\228\113\125\209\170\43\25")]=function(v457) if v457 then if  not v8 then local v586=0 + 0 ;local v587;while true do if (v586==0) then v587=0;while true do if (v587==(0 -0)) then while true do end repeat until false break;end end break;end end end task.spawn(function() repeat task.wait();if entityLibrary.isAlive then if ((v182()<v178.Value) and (v182()>0)) then if  not v183 then if (v177.Value==v7("\207\255\84\74\113\119\237\227","\30\153\154\56\37\18")) then entityLibrary.character.HumanoidRootPart.Velocity+=Vector3.new(864 -(184 + 680) ,v179.Value,0) elseif  not GuiLibrary.ObjectsThatCanBeSaved.InfiniteFlyOptionsButton.Api.Enabled then GuiLibrary.ObjectsThatCanBeSaved.InfiniteFlyOptionsButton.Api.ToggleButton(true);v184=true;end end v183=true;if  not v185 then warningNotification2(v7("\60\183\227\5\31\24\184\227\4\123\1\249","\91\125\217\151\108")   .. v177.Value ,v7("\202\6\165\115\219\234\21\179\124\210\224\83\182\117\204\255\28\180\125\219\253\83\167\115\202\240\28\168\62","\190\153\115\198\16"),2 + 1 );end v185=true;elseif (v182()>=v178.Value) then local v732=0;while true do if (v732==(0 -0)) then if (v184 and v180.Enabled) then if GuiLibrary.ObjectsThatCanBeSaved.InfiniteFlyOptionsButton.Api.Enabled then GuiLibrary.ObjectsThatCanBeSaved.InfiniteFlyOptionsButton.Api.ToggleButton(false);end end v183,v184,v185=false,false,false;break;end end end end until  not v176.Enabled end);else v183,v184,v185=false,false,false;end end,[v7("\30\126\172\134\47\119\190","\231\90\27\202")]=false,[v7("\164\156\76\176\95\181\129\64\182","\62\225\228\56\194")]=function() return v177.Value;end});v177=v176.CreateDropdown({[v7("\56\184\180\40","\53\118\217\217\77\20")]=v7("\132\16\224\219","\79\201\127\132\190"),[v7("\4\29\250\221","\169\72\116\137")]={v7("\79\127\197\169\122\115\221\191","\198\25\26\169"),v7("\96\125\219\47\137\88\111\122","\31\41\19\189\70\231\49\27")},[v7("\159\220\71\227\165\231\84\254\163","\134\215\179\49")]=v7("\204\251\82\227\21\7\238\180\70\244\80\5\228\250\66\166\81\22\224\224\94\168","\115\129\148\54\134\53"),[v7("\223\134\92\94\221","\115\137\231\48\43\184\104")]=v7("\239\236\22\236\170\169\43\192","\95\185\137\122\131\201\192"),[v7("\80\35\201\16\49\127\57\201","\69\22\86\167\115")]=function() end});v178=v176.CreateSlider({[v7("\118\133\74\132","\71\56\228\39\225\37")]=v7("\152\228\229\37\238\229","\66\208\129\132\73\154\141"),[v7("\103\86\216","\157\42\63\182")]=10,[v7("\246\63\49","\175\187\94\73\156")]=221 -122 ,[v7("\14\48\89\37\9\23\197\62\43","\160\70\95\47\64\123\67")]=v7("\246\95\117\61\202\82\52\48\202\26\99\57\215\89\124\113\255\84\96\56\250\95\117\37\214\26\99\56\210\86\52\33\219\72\114\62\204\87\52\56\202\73\52\48\221\78\125\62\208\73\58","\81\190\58\20"),[v7("\106\88\184\116\151\32\80\61","\83\44\45\214\23\227\73\63")]=function() end,[v7("\209\191\64\191\53\249\174","\64\149\218\38\222")]=50});v175=7 -3 ;end end break;end if (v174==2) then v181=nil;v182=nil;v183=nil;v174=1 + 2 ;end if (v174==0) then v175=1050 -(629 + 421) ;v176=nil;v177=nil;v174=1 + 0 ;end if (v174==(1 -0)) then v178=nil;v179=nil;v180=nil;v174=3 -1 ;end end end);runFunction(function() local v186=0;local v187;while true do if (v186==(940 -(544 + 396))) then v187={[v7("\150\247\190\134\191\252\187","\228\211\153\223")]=false};v187=GuiLibrary.ObjectsThatCanBeSaved.KryptoniteWindow.Api.CreateOptionsButton({[v7("\122\238\85\56","\102\52\143\56\93\90")]=v7("\104\24\142\41\232\67\35\161\47","\133\38\119\192\72"),[v7("\223\174\98\254\229\149\113\227\227","\155\151\193\20")]=v7("\28\161\13\65\109\43\183\64\87\116\59\182\64\96\122\35\161\52\79\124\96","\27\78\196\96\46"),[v7("\204\238\188\187\110\77\67\228","\44\138\155\210\216\26\36")]=function(v349) if v349 then RunLoops:BindToHeartbeat(v7("\149\66\151\91\240\190\121\184\93","\157\219\45\217\58"),function() pcall(function() lplr.Character.Head.Nametag:Destroy();end);end);else RunLoops:UnbindFromHeartbeat(v7("\158\178\24\212\243\181\137\55\210","\158\208\221\86\181"));end end,[v7("\196\68\236\10\53\179\44","\88\128\33\138\107\64\223")]=false});break;end end end);runFunction(function() local v188=0;local v189;local v190;local v191;local v192;while true do if (v188==(5 -2)) then v191=v189.CreateSlider({[v7("\175\34\122\32","\69\225\67\23")]=v7("\240\147\50\187\207\147\216\105\193\143\48\172","\27\164\225\83\213\188\227\185"),[v7("\165\6\140","\167\232\111\226\158")]=991 -(904 + 87) ,[v7("\105\37\55","\209\36\68\79\120\123\61\144")]=353 -253 ,[v7("\104\238\70\57\12\73","\96\44\129\51\91")]=1574 -(1443 + 31) ,[v7("\61\0\26\163\225\220\246\13\27","\147\117\111\108\198\147\136")]=v7("\62\164\195\90\25\166\195\70\15\184\193\77\74\185\196\20\30\190\199\20\9\186\205\65\14\165\140","\52\106\214\162"),[v7("\35\26\208\167\229\12\0\208","\145\101\111\190\196")]=function() end});v192=v189.CreateToggle({[v7("\126\204\140\233","\47\48\173\225\140")]=v7("\109\200\142\214","\204\35\173\225\184\75"),[v7("\198\75\245\136\244\146\11\246\80","\110\142\36\131\237\134\198")]=v7("\79\85\161\254\43\59\84\187\245\120\120\76\188\244\43\59\77\178\228\61\105\73\178\252\120\111\79\243\254\61\116\78\253","\88\27\32\211\144"),[v7("\171\190\176\63\223\164\84\126","\16\237\203\222\92\171\205\59")]=function() end});break;end if (v188==(0 -0)) then local v295=0;while true do if (v295==(1814 -(1110 + 703))) then v188=1;break;end if (v295==(0 -0)) then v189={[v7("\228\252\116\119\161\126\234","\142\161\146\21\21\205\27")]=false};v190={[v7("\56\239\121","\172\112\154\28\99\122\153")]=1 + 0 ,[v7("\248\246\180","\126\171\151\192")]=1,[v7("\8\31\245\9\2","\57\94\126\153\124\103\154")]=0.55 -0 };v295=2 -1 ;end end end if (v188==(204 -(78 + 125))) then local v296=0 -0 ;while true do if (v296==(0 -0)) then v191={[v7("\33\198\69\12\211","\33\119\167\41\121\182")]=0};v192={[v7("\98\186\58\84\167\86\24","\88\39\212\91\54\203\51\124")]=true};v296=1;end if ((1 -0)==v296) then v188=1826 -(1392 + 432) ;break;end end end if ((1 + 1)==v188) then local v297=0 -0 ;while true do if ((0 + 0)==v297) then local v409=1402 -(963 + 439) ;while true do if (v409==0) then v189=GuiLibrary.ObjectsThatCanBeSaved.KryptoniteWindow.Api.CreateOptionsButton({[v7("\2\173\185\143","\168\76\204\212\234\27\174")]=v7("\175\17\32\80\6\235\109\128\11\38\64\26","\46\236\100\83\36\105\134"),[v7("\17\245\145\133\147\59\60\226\147","\111\89\154\231\224\225")]=v7("\222\207\21\177\35\244\213\203\248\201\70\177\36\252\156\210\241\213\19\161\63\183","\177\157\186\102\197\76\153\188"),[v7("\132\171\46\172\182\183\47\161","\207\194\222\64")]=function(v556) if v556 then task.spawn(function() for v669,v670 in next,workspace:WaitForChild(v7("\56\121\216\85\140\192","\179\123\21\183\32\232")):GetChildren() do if v670:IsA(v7("\246\34\222\41","\98\166\67\172\93\211")) then v670.Transparency=v191.Value/100 ;v670.Color=Color3.fromHSV(v190.Hue,v190.Sat,v190.Value);if v192.Enabled then v670.Material=Enum.Material.Neon;else v670.Material=Enum.Material.SmoothPlastic;end end end end);else task.spawn(function() for v671,v672 in next,workspace:WaitForChild(v7("\196\239\216\192\6\89","\130\135\131\183\181\98\42")):GetChildren() do if v672:IsA(v7("\243\183\41\247","\64\163\214\91\131")) then v672.Transparency=0;v672.Color=Color3.fromRGB(255,550 -295 ,1580 -(76 + 1249) );v672.Material=Enum.Material.SmoothPlastic;end end end);end end});v190=v189.CreateColorSlider({[v7("\63\46\21\51","\95\113\79\120\86")]=v7("\136\251\44\191\148","\169\203\148\64\208\230\109\95"),[v7("\224\24\16\183\56\47\57\254\220","\134\168\119\102\210\74\123\92")]=v7("\136\1\16\86\185\78\19\95\235\26\20\92\235\13\16\86\190\10\15\23","\57\203\110\124"),[v7("\136\198\27\42\20\167\220\27","\96\206\179\117\73")]=function() end});v409=1;end if (v409==(1752 -(1165 + 586))) then v297=1929 -(1916 + 12) ;break;end end end if (v297==(1257 -(604 + 652))) then v188=3;break;end end end end end);runFunction(function() local v193=0;local v194;local v195;local v196;while true do if (v193==(0 -0)) then v194={[v7("\196\191\188\138\19\182\229","\211\129\209\221\232\127")]=false};v195={[v7("\63\78\74\49\249","\38\105\47\38\68\156\125\208")]=1 + 2 };v193=1;end if (v193==(2 -0)) then v195=AntiNoClip.CreateSlider({[v7("\154\41\65\14","\115\212\72\44\107")]=v7("\188\224\71\123\233\39\161\74","\36\236\143\52\18\157\78\206"),[v7("\125\72\54","\159\48\33\88\47")]=1 + 0 ,[v7("\50\67\1","\87\127\34\121\146\211\129\87")]=5,[v7("\131\238\147\233\55\10\202\108\191","\20\203\129\229\140\69\94\175")]=v7("\141\202\91\53\228\162\191\201\71\63\251\235\160\200\20\55\226\237\186\200\64\120","\130\207\166\52\86\143"),[v7("\108\79\29\238\190\114\46\68","\65\42\58\115\141\202\27")]=function() end,[v7("\111\1\83\192\58\71\16","\79\43\100\53\161")]=6 -3 });v196=AntiNoClip.CreateSlider({[v7("\222\197\194\74","\36\144\164\175\47\52\44\86")]=v7("\25\1\248\182\122\61\10\245\176","\31\80\111\155\196"),[v7("\126\80\239","\79\51\57\129\180")]=1,[v7("\26\179\40","\185\87\210\80\56")]=6 -1 ,[v7("\238\31\184\93\111\205\80\222\4","\53\166\112\206\56\29\153")]="Positon\'s increment amount.",[v7("\84\6\88\9\225\38\125\29","\79\18\115\54\106\149")]=function() end,[v7("\110\87\72\95\48\113\153","\198\42\50\46\62\69\29\237")]=3});break;end if (v193==(1 -0)) then v196={[v7("\186\129\169\81\249","\72\236\224\197\36\156")]=3 -0 };AntiNoClip=GuiLibrary.ObjectsThatCanBeSaved.KryptoniteWindow.Api.CreateOptionsButton({[v7("\234\170\73\143","\234\164\203\36")]=v7("\42\227\148\43\162\81\82\126\2\253","\18\107\141\224\66\236\62\17"),[v7("\131\160\10\242\185\155\25\239\191","\151\203\207\124")]=v7("\228\8\244\20\229\135\10\215\148\3\254\23\160\143\12\203\217\90\255\13\173\138\18\205\196\10\248\12\231\201\23\202\192\21\177\22\232\140\94\195\198\21\228\12\228\199","\164\180\122\145\98\128\233\126"),[v7("\157\17\21\206\175\13\20\195","\173\219\100\123")]=function(v350) if v350 then task.spawn(function() repeat task.wait();if entityLibrary.isAlive then if (entityLibrary.character.Humanoid.FloorMaterial~=Enum.Material.Air) then local v617,v618=getPlacedBlock(entityLibrary.character.HumanoidRootPart.Position + Vector3.new(13 -(11 + 2) , -v195.Value,1442 -(64 + 1378) ) );v618*=v196.Value if (v617 and v618) then if ((v618.Y + 8)>=entityLibrary.character.HumanoidRootPart.Position.Y) then local v704=0;local v705;local v706;local v707;while true do if (v704==0) then v705=0 -0 ;v706=nil;v704=1754 -(256 + 1497) ;end if (v704==(1 -0)) then v707=nil;while true do if (v705==(878 -(562 + 315))) then while true do if (v706==0) then v707=entityLibrary.character.HumanoidRootPart.Velocity;v707=Vector2.new(v707.X,v707.Z);v706=1;end if ((3 -2)==v706) then entityLibrary.character.HumanoidRootPart.Velocity=Vector3.new(v707.X,1188 -(577 + 611) ,v707.Y);break;end end break;end if (v705==(0 + 0)) then v706=0;v707=nil;v705=2 -1 ;end end break;end end end end end end until  not AntiNoClip.Enabled end);end end});v193=3 -1 ;end end end);runFunction(function() local v197=71 -(58 + 13) ;local v198;local v199;local v200;local v201;local v202;local v203;local v204;local v205;local v206;while true do if (v197==5) then v203=v198.CreateSlider({[v7("\149\34\18\123","\26\219\67\127\30\197\83")]=v7("\209\29\205\110\2\246\236","\153\149\120\190\26\112"),[v7("\33\28\196","\119\108\117\170\192\74\144\158")]=1 + 0 ,[v7("\202\40\153","\65\135\73\225")]=6 + 4 ,[v7("\55\92\71\165\6\43\86\73\180","\116\127\51\49\192")]=v7("\63\5\95\252\247\94\22\20\64\87\248\253\10\16\20\25\19\233\230\27\66\24\12\92\243\235\80","\98\123\96\51\157\142\126"),[v7("\235\235\168\205\50\196\241\168","\70\173\158\198\174")]=function() end,[v7("\212\58\73\239\229\51\91","\142\144\95\47")]=3});v204=v198.CreateSlider({[v7("\57\44\93\11","\110\119\77\48")]=v7("\207\58\40\84\253","\132\139\95\68\53"),[v7("\209\33\243","\85\156\72\157")]=455 -(404 + 50) ,[v7("\86\51\101","\234\27\82\29\65\186\72")]=46 -(6 + 30) ,[v7("\216\192\255\187\17\196\202\241\170","\99\144\175\137\222")]=v7("\116\113\128\0\32\5\179\85\96\155\4\60\75\241\82\123\131\18\45\76\191\87\52\152\9\60\5\167\85\120\131\2\48\81\168\30","\209\48\20\236\97\89\37"),[v7("\218\84\80\42\86\245\78\80","\34\156\33\62\73")]=function() end,[v7("\44\119\232\80\29\126\250","\49\104\18\142")]=1340 -(770 + 563) });break;end if (v197==(4 + 0)) then v200=v198.CreateSlider({[v7("\163\169\193\231","\130\237\200\172")]=v7("\20\209\160\9\35","\110\70\176\206"),[v7("\88\25\51","\90\21\112\93\139")]=1 + 0 ,[v7("\44\218\108","\192\97\187\20\214")]=188 -(25 + 145) ,[v7("\34\84\37\205\146\62\94\43\220","\224\106\59\83\168")]=v7("\149\228\12\252\75\200\93\168\165\6\254\90\141\74\179\165\22\243\75\200\70\183\245\13\245\75\134\93\233","\41\199\133\98\155\46\232"),[v7("\58\179\239\69\169\6\233\18","\134\124\198\129\38\221\111")]=function() end,[v7("\220\234\183\33\237\227\165","\64\152\143\209")]=13 + 5 });v201=v198.CreateSlider({[v7("\25\72\200\9","\103\87\41\165\108\42\77\28")]=v7("\138\214\29\240\126\244","\128\194\179\116\151\22"),[v7("\42\59\13","\230\103\82\99\199\188\84")]=700 -(153 + 546) ,[v7("\145\135\187","\74\220\230\195\200\57")]=10 + 0 ,[v7("\141\133\198\26\25\229\160\146\196","\177\197\234\176\127\107")]=v7("\91\207\207\79\130\96\31\103\197\134\91\158\117\70\51\203\196\71\156\113\31\103\194\195\8\133\100\79\124\196\195\70\158\58","\63\19\170\166\40\234\20"),[v7("\16\29\3\43\52\36\207\56","\160\86\104\109\72\64\77")]=function() end,[v7("\221\118\232\11\11\134\237","\234\153\19\142\106\126")]=937 -(60 + 867) });v202=v198.CreateSlider({[v7("\15\37\176\29","\120\65\68\221")]=v7("\58\186\234\175\12","\220\120\213\133"),[v7("\117\39\201","\74\56\78\167\48")]=3 -2 ,[v7("\201\29\51","\88\132\124\75\160\106\106")]=10,[v7("\60\57\155\66\9\158\53\24\0","\96\116\86\237\39\123\202\80")]=v7("\0\25\190\104\140\184\239\53\27\241\127\141\163\188\53\84\165\117\135\236\185\36\24\190\126\139\184\182\111","\207\65\116\209\29\226\204"),[v7("\150\69\133\13\164\89\132\0","\110\208\48\235")]=function() end,[v7("\129\172\133\140\176\165\151","\237\197\201\227")]=1286 -(309 + 974) });v197=3 + 2 ;end if (v197==0) then v198={};v199={[v7("\244\187\26\44\45","\59\162\218\118\89\72\192\110")]=v7("\177\251\188\90\88\14\96\21","\97\229\158\208\63\40\97\18")};v200={[v7("\27\207\126\83\137","\236\77\174\18\38")]=48 -30 };v197=1142 -(677 + 464) ;end if (v197==(823 -(567 + 255))) then local v298=0 -0 ;local v299;while true do if (v298==(0 -0)) then v299=528 -(384 + 144) ;while true do if (v299==1) then v203={[v7("\213\80\95\80\114","\162\131\49\51\37\23")]=1224 -(1030 + 191) };v197=3 -1 ;break;end if (v299==0) then local v517=0 -0 ;while true do if (v517==0) then v201={[v7("\182\92\195\0\133","\117\224\61\175")]=10};v202={[v7("\221\70\202\157\238","\232\139\39\166")]=3};v517=1;end if (v517==(1 + 0)) then v299=858 -(326 + 531) ;break;end end end end break;end end end if (v197==3) then function v206() local v351=0;local v352;while true do if (v351==(2 -1)) then lplr.Character.Humanoid.Sit=false;if (v352 and  not GuiLibrary.ObjectsThatCanBeSaved.InfiniteFlyOptionsButton.Api.Enabled) then if (v199.Value==v7("\91\216\83\187\122","\217\26\186\60\205\31\176\72")) then if ( not GuiLibrary.ObjectsThatCanBeSaved.FlyOptionsButton.Api.Enabled and  not v205) then local v647=0 + 0 ;while true do if (v647==(0 + 0)) then GuiLibrary.ObjectsThatCanBeSaved.FlyOptionsButton.Api.ToggleButton(true);v205=true;break;end end end local v588=v352.Character.HumanoidRootPart.Position;local v589=v588 + Vector3.new(0 -0 ,v201.Value,0 + 0 ) ;lplr.Character:SetPrimaryPartCFrame(CFrame.new(v589));elseif (v199.Value==v7("\237\116\10\227\216\120\18\245","\140\187\17\102")) then lplr.Character.HumanoidRootPart.Velocity+=Vector3.new(0 + 0 ,v202.Value,0) task.wait(v204.Value/(1631 -(1367 + 254)) );lplr.Character.HumanoidRootPart.Velocity-=Vector3.new(678 -(305 + 373) ,v202.Value,0) task.wait(v204.Value/(13 -3) );end elseif  not v352 then if v205 then GuiLibrary.ObjectsThatCanBeSaved.FlyOptionsButton.Api.ToggleButton(false);end v205=false;end break;end if (v351==(319 -(129 + 190))) then local v459=0 -0 ;while true do if (v459==(0 -0)) then v352=nil;for v590,v591 in next,getClosePlayers(v200.Value) do if ((v591.Character.Humanoid.Health>(0 + 0)) and (v591.Team~=lplr.Team)) then v352=v591;end end v459=1 + 0 ;end if (v459==(290 -(210 + 79))) then v351=1;break;end end end end end v198=GuiLibrary.ObjectsThatCanBeSaved.KryptoniteWindow.Api.CreateOptionsButton({[v7("\2\138\169\68","\33\76\235\196")]=v7("\41\228\230\86\132\57\145","\229\104\138\146\63\204\80\229"),[v7("\136\114\8\204\178\73\27\209\180","\169\192\29\126")]=v7("\1\215\0\157\52\203\17\152\113\220\10\158\113\195\23\132\60\133\7\142\56\203\2\203\53\196\8\138\54\192\1\197","\235\81\165\101"),[v7("\94\145\81\26\145\13\195\118","\172\24\228\63\121\229\100")]=function(v353) if v353 then local v410=0 -0 ;while true do if (v410==0) then if  not v8 then local v592=0 -0 ;while true do if (v592==0) then while true do end repeat until false break;end end end if (v199.Value~=v7("\169\66\218\195\143","\173\234\46\181")) then RunLoops:BindToHeartbeat(v7("\254\60\255\54\11\214\38","\67\191\82\139\95"),function() pcall(function() v206();end);end);else task.spawn(function() repeat local v648=672 -(32 + 640) ;local v649;while true do if (v648==0) then v649=0 + 0 ;while true do if (v649==0) then task.wait(0);for v785,v786 in next,playersService:GetChildren() do if (v786.Team~=lplr.Team) then if (v786 and (v786~=lplr)) then local v831=0;local v832;while true do if (v831==0) then v832=lplr:DistanceFromCharacter(v786.Character:FindFirstChild(v7("\21\248\74\195\226\228\52\233\117\205\227\255\13\236\85\214","\139\93\141\39\162\140")).CFrame.P);if (v832<v200.Value) then if  not lplr.Character.HumanoidRootPart:FindFirstChildOfClass(v7("\14\172\13\206\40\41\175\6\212\23\56\186","\126\76\195\105\183")) then if  not (v786.Character.HumanoidRootPart.Velocity.Y< -(29 + 21)) then lplr.Character.Archivable=true;local v905=lplr.Character:Clone();v905.Parent=workspace;v905.Head:ClearAllChildren();gameCamera.CameraSubject=v905:FindFirstChild(v7("\119\93\169\112\87\187\86\76","\212\63\40\196\17\57"));for v911,v912 in next,v905:GetChildren() do if ((v912.Name~=v7("\129\222\253\251\167\196\249\254\155\196\255\238\153\202\226\238","\154\201\171\144")) and string.lower(v912.ClassName):find(v7("\178\239\186\217","\221\226\142\200\173\214\111\223"))) then v912.Transparency=1;end if v912:IsA(v7("\47\77\188\52\187\29\65\173\40","\200\110\46\223\81")) then v912:FindFirstChild(v7("\62\70\50\48\46\215","\34\118\39\92\84\66\178")).Transparency=1;end end lplr.Character.HumanoidRootPart.CFrame+=Vector3.new(0,100000,0 + 0 ) runService.RenderStepped:Connect(function() if ((v905~=nil) and v905:FindFirstChild(v7("\99\157\60\3\32\166\198\119\121\135\62\22\30\168\221\103","\19\43\232\81\98\78\201\175"))) then v905.HumanoidRootPart.Position=Vector3.new(lplr.Character.HumanoidRootPart.Position.X,v905.HumanoidRootPart.Position.Y,lplr.Character.HumanoidRootPart.Position.Z);end end);task.wait(v203.Value/10 );lplr.Character.HumanoidRootPart.Velocity=Vector3.new(lplr.Character.HumanoidRootPart.Velocity.X, -(1 + 0),lplr.Character.HumanoidRootPart.Velocity.Z);lplr.Character.HumanoidRootPart.CFrame=v905.HumanoidRootPart.CFrame;gameCamera.CameraSubject=lplr.Character:FindFirstChild(v7("\99\198\245\167\202\226\131\79","\234\43\179\152\198\164\141"));v905:Destroy();task.wait(v203.Value/20 );end end end break;end end end end end break;end end break;end end until  not v198.Enabled end);end break;end end else RunLoops:UnbindFromHeartbeat(v7("\132\84\104\215\175\186\217","\231\197\58\28\190\231\211\173"));end end,[v7("\118\202\42\62\214\184\86\202\42","\236\51\178\94\76\183")]=function() return v199.Value;end});v199=v198.CreateDropdown({[v7("\196\204\223\70","\35\138\173\178")]=v7("\236\12\76\217","\29\161\99\40\188\50"),[v7("\85\35\179\243","\140\25\74\192\135\110\90\106")]={v7("\3\83\75\228\175","\194\66\49\36\146\202"),v7("\189\52\193\13\198\130\37\212","\165\235\81\173\98"),v7("\8\137\166\56\188","\132\75\229\201\86\217")},[v7("\180\115\169\176\135","\197\226\18\197")]=v7("\61\211\14\71\25","\49\124\177\97"),[v7("\168\50\214\187\146\9\197\166\148","\222\224\93\160")]=v7("\198\242\118\36\120\255\242\50\32\46\228\244\118\97\63\238\233\102\40\54\236\189\118\32\53\234\250\119\37\118","\88\139\157\18\65"),[v7("\108\15\28\18\223\67\21\28","\171\42\122\114\113")]=function() end});v197=528 -(163 + 361) ;end if (v197==2) then v204={[v7("\105\120\242\63\113","\20\63\25\158\74")]=892 -(162 + 723) };v205=false;v206=nil;v197=3;end end end);runFunction(function() local v207=0 + 0 ;local v208;local v209;local v210;local v211;while true do if (v207==1) then local v300=401 -(258 + 143) ;while true do if (v300==(0 -0)) then v210=nil;function v210() local v460={};for v486,v487 in next,workspace:GetChildren() do if ((v487:FindFirstChild(v7("\151\59\246\197\239\167","\157\212\84\128\160"))~=nil) and (v487:FindFirstChild(v7("\170\124\246\64\52\155","\163\233\19\128\37\70\232\142")).BrickColor~=lplr.Team.TeamColor) and (string.lower(v487.Name)==v7("\225\80\56","\121\131\53\92"))) then table.insert(v460,v487);end end return v460;end v300=1 -0 ;end if (v300==(3 -2)) then v207=1693 -(486 + 1205) ;break;end end end if (v207==(169 -(92 + 73))) then FastBreakRange=v208.CreateSlider({[v7("\244\121\189\225","\56\186\24\208\132\122\153\114")]=v7("\225\4\37\80\137\131\4\33\95\133\198","\226\163\118\64\49"),[v7("\212\197\49","\125\153\172\95\222")]=1,[v7("\86\199\251","\131\27\166\131\173\141\186")]=16 + 14 ,[v7("\219\124\81\34\225\71\66\63\231","\71\147\19\39")]=v7("\55\59\232\170\182\170\238\45\69\56\244\168\178\225\186\54\13\63\166\175\182\238\180","\66\101\90\134\205\211\138\154"),[v7("\58\89\119\175\145\46\19\66","\71\124\44\25\204\229")]=function() end,[v7("\54\255\47\69\215\181\6","\217\114\154\73\36\162")]=25 + 5 });break;end if ((4 -1)==v207) then v208=GuiLibrary.ObjectsThatCanBeSaved.KryptoniteWindow.Api.CreateOptionsButton({[v7("\157\243\179\186","\110\211\146\222\223\59\200")]=v7("\117\85\241\27\96\65\81\227\4","\34\51\52\130\111"),[v7("\230\58\46\198\16\8\82\214\33","\55\174\85\88\163\98\92")]="Makes Nuker\'s break speed faster.",[v7("\235\93\8\134\34\196\71\8","\86\173\40\102\229")]=function(v354) if v354 then local v411=272 -(68 + 204) ;local v412;while true do if (v411==(0 -0)) then v412=0;while true do if (v412==(0 + 0)) then if  not v8 then while true do end repeat until false end task.spawn(function() repeat task.wait();task.spawn(function() if lplr:GetAttribute(v7("\32\161\65\148\38\168\64\142\15\134\93\136\5\175","\237\100\196\47")) then lplr:SetAttribute(v7("\104\73\133\179\21\132\27\79\71\169\184\50\137\31","\116\44\44\235\202\87\232"),nil);end end);if entityLibrary.isAlive then local v708=v210();for v733,v734 in next,v708 do local v735=0;local v736;local v737;while true do if (v735==(0 + 0)) then v736=0 -0 ;v737=nil;v735=1 + 0 ;end if (v735==(1 + 0)) then while true do if (v736==(0 + 0)) then v737=(v734.Position-entityLibrary.character.PrimaryPart.Position).Magnitude;if (v737<FastBreakRange.Value) then v211(v734,319 -(20 + 296) );end break;end end break;end end end end until  not v208.Enabled end);break;end end break;end end end end,[v7("\39\210\80\36\23\190\230","\146\99\183\54\69\98\210")]=false,[v7("\194\231\161\183\61\131\226\231\161","\215\135\159\213\197\92")]=function() return v209.Value;end});v209=v208.CreateDropdown({[v7("\157\164\229\233","\140\211\197\136")]=v7("\29\195\56\113","\172\80\172\92\20"),[v7("\50\115\194\12","\232\126\26\177\120\16\169\163")]={v7("\206\234\190\112\73","\214\140\134\209\19\34\175"),v7("\102\34\165\165\64\34","\202\52\71\200")},[v7("\202\77\115\134\251\68\97","\231\142\40\21")]=v7("\82\62\202\9\89","\180\16\82\165\106\50\99"),[v7("\23\90\105\251\17\11\80\103\234","\99\95\53\31\158")]=v7("\223\37\116\84\178\62\127\17\240\56\117\80\249\106\100\89\247\106\114\84\246\100","\49\146\74\16"),[v7("\194\68\132\89\150\237\94\132","\226\132\49\234\58")]=function() end});v207=4;end if (0==v207) then v208={[v7("\212\235\125\9\253\224\120","\107\145\133\28")]=false};v209={[v7("\244\95\191\171\199","\222\162\62\211")]=v7("\129\125\1\24\58","\170\195\17\110\123\81\227")};v207=4 -3 ;end if ((6 -4)==v207) then v211=nil;function v211(v355,v356) local v357=0;local v358;local v359;while true do if (v357==(1 -0)) then v359=workspace:Raycast(v355.Position + Vector3.new(0 + 0 ,24,0 + 0 ) ,Vector3.new(0 -0 , -(11 + 16),0),v358);if v359 then local v518=v359.Instance;replicatedStorageService.rbxts_include.node_modules[v7("\94\201\74\147\103\129\76\129\115\201\88","\224\30\172\43")][v7("\7\171\112\221\230\72\162\113\217\228\11\162","\141\101\199\31\190")][v7("\85\72\7\194\229\180\160\95\82\15\194\201","\207\59\39\99\167\186\217")][v7("\39\84\185\74\92\238","\139\103\38\219\50\40\157\192")][v7("\232\189\34","\162\134\216\86")][v7("\49\250\67","\207\94\143\55\57\80\34\145")][v7("\29\255\38\110\157\90\25\184\37\212\39","\217\66\177\67\26\208\59\119")].DamageBlock:InvokeServer({[v7("\33\210\197\169\91\216\253\37","\152\67\190\170\202\48\138")]={[v7("\217\37\90\243\208\25\90\227\210\61\92\255\213","\144\187\73\53")]=Vector3.new(v518.Position.X/v356 ,v518.Position.Y/v356 ,v518.Position.Z/v356 )},[v7("\30\178\46\231\173\160\31\175\51\216\172","\211\118\219\90\183\194")]=Vector3.new(v518.Position.X/v356 ,v518.Position.Y/v356 ,v518.Position.Z/v356 ),[v7("\240\164\156\197\85\227\245\172\132","\145\152\205\232\139\58")]=Vector3.new(v518.Position.X/v356 ,v518.Position.Y/v356 ,v518.Position.Z/v356 )});end break;end if (v357==(0 + 0)) then local v461=0 + 0 ;while true do if (v461==0) then v358=RaycastParams.new();v358.IgnoreWater=true;v461=2 -1 ;end if (v461==(1 -0)) then v357=1 + 0 ;break;end end end end end v207=252 -(155 + 94) ;end end end);runFunction(function() local v212=0 -0 ;local v213;local v214;local v215;local v216;while true do if ((908 -(515 + 392))==v212) then v215=nil;v216=nil;v212=2;end if (v212==(328 -(7 + 319))) then while true do if (v213==2) then v214=GuiLibrary.ObjectsThatCanBeSaved.KryptoniteWindow.Api.CreateOptionsButton({[v7("\131\27\9\70","\35\205\122\100")]=v7("\132\80\21\84\182\105\2\85\177\86\9","\39\194\57\103"),[v7("\138\244\42\84\20\152\203\186\239","\174\194\155\92\49\102\204")]=v7("\232\135\90\124\148\138\247\203\157\25\126\137\138\232\205\154\74\99\199\218\235\214\155\86\121\201","\142\164\232\57\23\231\170"),[v7("\145\191\210\254\6\190\165\210","\114\215\202\188\157")]=function(v462) if v462 then task.spawn(function() repeat local v593=0 + 0 ;while true do if ((0 + 0)==v593) then local v673=1497 -(292 + 1205) ;while true do if (v673==0) then task.wait(52 -(13 + 39) );v216();v673=1 + 0 ;end if (v673==1) then v593=3 -2 ;break;end end end if (v593==1) then inputService.InputBegan:Connect(function(v679,v680) if  not v680 then local v738=0 -0 ;while true do if (v738==0) then if (v679.UserInputType==Enum.UserInputType.MouseWheel) then return;end v216();break;end end end end);inputService.InputChanged:Connect(function(v681) if (v681.UserInputType==Enum.UserInputType.MouseMovement) then local v739=1038 -(850 + 188) ;local v740;local v741;local v742;while true do if (v739==(1036 -(822 + 214))) then v740=1161 -(317 + 844) ;v741=nil;v739=1;end if (v739==(1 + 0)) then v742=nil;while true do if (1==v740) then gameCamera.CFrame=CFrame.Angles(0 + 0 ,math.rad(v742.Y),0) * gameCamera.CFrame ;break;end if (v740==0) then local v822=1190 -(508 + 682) ;while true do if (v822==0) then v741=v681.Delta;v742=Vector2.new(v741.Y,v741.X) * (v215.Value/(5 + 5)) ;v822=1 + 0 ;end if (v822==(546 -(127 + 418))) then v740=1;break;end end end end break;end end end v216();end);break;end end until  not v214.Enabled end);else gameCamera.CameraType=Enum.CameraType.Scriptable;end end});v215=v214.CreateSlider({[v7("\31\164\255\85","\229\81\197\146\48\210\227\139")]=v7("\177\87\85\105\218\239\84\64\139\70\66","\54\226\50\59\26\179\155\61"),[v7("\231\55\54","\127\170\94\88\56")]=2 -1 ,[v7("\205\198\172","\198\128\167\212\162\216\93\153")]=24 -14 ,[v7("\140\47\234\221\190\51\235\208","\190\202\90\132")]=function() end,[v7("\163\220\117\214\183\42\147","\70\231\185\19\183\194")]=9 -7 });break;end if (0==v213) then v214={[v7("\25\171\187\175\13\141\4","\96\92\197\218\205\97\232")]=false};v215={[v7("\8\11\176\152\250","\159\94\106\220\237")]=2};v213=1 -0 ;end if (v213==1) then v216=nil;function v216() gameCamera.CameraType=Enum.CameraType.Scriptable;gameCamera.CFrame=CFrame.new(lplr.Character.Head.Position);end v213=2;end end break;end if ((1120 -(690 + 430))==v212) then v213=0;v214=nil;v212=1;end end end);runFunction(function() local v217=0 -0 ;local v218;local v219;local v220;local v221;local v222;local v223;local v224;while true do if (v217==(2 + 1)) then v222=v218.CreateToggle({[v7("\218\122\83\193","\150\148\27\62\164")]=v7("\15\232\254\197\48\224\235\204","\160\66\137\138"),[v7("\40\204\52\186\45\222\79\104\20","\16\96\163\66\223\95\138\42")]=v7("\165\218\208\12\214\12\147\148\210\27\201\29\143\217\145\3\219\29\133\198\216\15\214\71","\105\224\180\177\110\186"),[v7("\135\31\172\65\52\85\52\169","\199\193\106\194\34\64\60\91")]=function() end,[v7("\27\179\10\167\42\186\24","\198\95\214\108")]=true});v223=v218.CreateToggle({[v7("\52\60\167\133","\85\122\93\202\224\137\108\154")]=v7("\167\95\94\164\209","\204\228\48\50\203\163"),[v7("\246\184\95\162\29\123\208\32\202","\88\190\215\41\199\111\47\181")]=v7("\113\57\77\75\124\196\205\20\52\89\90\100\206\211\20\52\67\69\127\211\144","\190\52\87\44\41\16\161"),[v7("\101\3\9\183\15\40\19\77","\124\35\118\103\212\123\65")]=function() end,[v7("\24\238\170\190\107\80\40","\60\92\139\204\223\30")]=true});break;end if (v217==(0 -0)) then v218={[v7("\254\206\229\166\191\222\196","\211\187\160\132\196")]=false};v219={[v7("\26\129\227\232\77","\146\76\224\143\157\40\220")]=v7("\125\112\164\113\163\31\247\94\115\178","\158\59\31\214\18\198\89")};v220={[v7("\117\28\66","\106\61\105\39")]=952 -(637 + 315) ,[v7("\214\191\47","\18\133\222\91\143\99\162")]=0 -0 ,[v7("\65\62\160\75\220","\178\23\95\204\62\185\92\35")]=0 -0 };v221={[v7("\4\248\222\244\81\36\242","\61\65\150\191\150")]=true};v217=3 -2 ;end if (v217==(1 + 0)) then local v301=0 -0 ;while true do if (v301==1) then v224={[v7("\229\40\171\172\120","\29\179\73\199\217")]=50};v218=GuiLibrary.ObjectsThatCanBeSaved.KryptoniteWindow.Api.CreateOptionsButton({[v7("\87\160\112\200","\173\25\193\29")]=v7("\121\101\68\11\162\7\245\112\91\98\86\28\185\15\196","\24\58\16\55\127\205\106\182"),[v7("\143\8\193\92\50\147\2\207\77","\64\199\103\183\57")]=v7("\7\90\64\77\252\41\70\73\92\224\100\86\92\76\225\100\76\91\88\225\37\76\71\92\225\106","\147\68\47\51\57"),[v7("\175\90\18\63\146\73\134\65","\32\233\47\124\92\230")]=function(v466) if v466 then task.spawn(function() local v558=20 -(13 + 7) ;local v559;local v560;while true do if (v558==(0 + 0)) then v559=nil;v560=nil;v558=1;end if (v558==1) then for v674,v675 in next,lplr.Character:GetDescendants() do if v675:IsA(v7("\169\64\145\190\140\207\235\159","\153\235\33\226\219\220\174")) then v560=v675.Material;end end repeat task.wait();for v682,v683 in next,lplr.Character:GetDescendants() do if v683:IsA(v7("\163\92\72\23\177\92\73\6","\114\225\61\59")) then v683.Transparency=v221.Enabled and (v224.Value/(157 -57)) ;if GuiLibrary.ObjectsThatCanBeSaved.FlyOptionsButton.Api.Enabled then v559=v560;elseif (v219.Value==v7("\250\124\54\142\217\85\45\136\208\119","\237\188\19\68")) then v559=Enum.Material.ForceField;else v559=Enum.Material.Neon;end if GuiLibrary.ObjectsThatCanBeSaved.FlyOptionsButton.Api.Enabled then v683.Material=Enum.Material.Neon;else v683.Material=v222.Enabled and v559 ;end v683.Color=v223.Enabled and Color3.fromHSV(v220.Hue,v220.Sat,v220.Value) ;end end until  not v218.Enabled break;end end end);end end,[v7("\216\240\250\10\225\201\237\246\12","\128\157\136\142\120")]=function() return v219.Value;end});v301=4 -2 ;end if (v301==0) then v222={[v7("\111\219\136\187\219\4\206","\170\42\181\233\217\183\97")]=true};v223={[v7("\233\117\238\215\126\78\200","\43\172\27\143\181\18")]=true};v301=1 -0 ;end if (v301==(1 + 1)) then v217=2 + 0 ;break;end end end if (v217==2) then v219=v218.CreateDropdown({[v7("\156\4\136\91","\157\210\101\229\62\206\169\50")]=v7("\96\39\91\183\11\161\24\193","\173\45\70\47\210\121\200\121"),[v7("\29\182\150\69","\49\81\223\229")]={v7("\20\137\171\246\55\160\176\240\62\130","\149\82\230\217"),v7("\22\87\117\164","\202\88\50\26")},[v7("\3\120\234\194\128","\55\85\25\134\183\229")]=v7("\93\59\7\172\227\14\114\49\25\171","\72\27\84\117\207\134"),[v7("\135\201\66\56\31\99\128\39\187","\95\207\166\52\93\109\55\229")]=v7("\240\194\50\135\250\63\172\209\131\41\132\168\47\162\200\209\102\129\224\55\191\220\192\50\135\250\120","\205\189\163\70\226\136\86"),[v7("\100\196\139\238\4\226\77\223","\139\34\177\229\141\112")]=function() end});v220=v218.CreateColorSlider({[v7("\13\236\117\177","\176\67\141\24\212")]=v7("\240\214\72\229\61","\141\179\185\36\138\79\52"),[v7("\211\52\73\166\233\15\90\187\239","\195\155\91\63")]=v7("\245\76\195\243\223\147\86\208\3\214\243\216\193\25\213\75\206\238\204\208\77\211\81\129","\57\182\35\175\156\173\179"),[v7("\251\183\183\220\27\13\183\211","\216\189\194\217\191\111\100")]=function() end});v224=v218.CreateSlider({[v7("\131\79\76\113","\42\205\46\33\20\80")]=v7("\101\26\40\185\66\24\40\165\84\6\42\174","\215\49\104\73"),[v7("\251\29\8","\104\182\116\102")]=1 + 0 ,[v7("\11\233\228","\222\70\136\156\129\222\88")]=684 -(375 + 209) ,[v7("\234\139\146\188\208\176\129\161\214","\217\162\228\228")]=v7("\154\207\206\214\189\205\206\202\171\211\204\193\238\210\201\152\183\210\218\202\238\222\199\217\188\220\204\204\171\207\129","\184\206\189\175"),[v7("\122\91\247\180\216\80\211\82","\188\60\46\153\215\172\57")]=function() end,[v7("\48\244\59\83\44\40\0","\68\116\145\93\50\89")]=1866 -(1673 + 143) });v221=v218.CreateToggle({[v7("\129\89\167\166","\51\207\56\202\195\150")]=v7("\137\90\250\77\146\150\255\177\184\70\248\90","\195\221\40\155\35\225\230\158"),[v7("\238\114\208\92\234\54\195\101\210","\98\166\29\166\57\152")]=v7("\140\28\128\200\49\172\1\193\201\40\186\6\142\199\125\189\0\128\196\46\185\19\147\207\51\170\11\207","\93\201\114\225\170"),[v7("\202\245\245\235\97\190\202\224","\142\140\128\155\136\21\215\165")]=function() end,[v7("\101\168\0\95\245\39\236","\218\33\205\102\62\128\75\152")]=true});v217=3 + 0 ;end end end);runFunction(function() local v225=0;local v226;local v227;local v228;while true do if ((1 + 0)==v225) then function v227() local v360=1449 -(836 + 613) ;local v361;while true do if (v360==0) then v361=0 -0 ;while true do if (v361==(0 + 0)) then local v561=1530 -(295 + 1235) ;while true do if (v561==(540 -(328 + 212))) then if game.Chat:GetChildren()[2 -1 ] then return true;end return false;end end end end break;end end end v228=game:GetService(v7("\151\52\231\65\119\161\50","\48\212\91\149\36"));v225=921 -(517 + 402) ;end if (v225==2) then v226=GuiLibrary.ObjectsThatCanBeSaved.KryptoniteWindow.Api.CreateOptionsButton({[v7("\106\31\55\1","\100\36\126\90")]=v7("\53\205\196\92\20\29\55\17\25\197\195","\82\113\164\183\61\118\113\82"),[v7("\211\77\231\178\182\251\239\227\86","\138\155\34\145\215\196\175")]=v7("\144\240\29\195\11\55\88\211\244\237\6\199\73\56\85\193\160\183","\160\212\153\110\162\105\91\61"),[v7("\134\45\164\220\180\49\165\209","\191\192\88\202")]=function(v362) if v362 then if v227() then local v488=0;while true do if (v488==0) then lplr.PlayerGui.Chat.Enabled=false;v228.TopBarApp.TopBarFrame.LeftFrame.ChatIcon.Visible=false;break;end end else local v489=0 -0 ;while true do if (v489==0) then v228.ExperienceChat.Enabled=false;v228.TopBarApp.TopBarFrame.LeftFrame.ChatIcon.Visible=false;v489=1;end if (v489==(2 -1)) then textChatService.ChatInputBarConfiguration.Enabled=false;textChatService.BubbleChatConfiguration.Enabled=false;break;end end end elseif v227() then local v490=1082 -(700 + 382) ;while true do if (v490==0) then lplr.PlayerGui.Chat.Enabled=true;v228.TopBarApp.TopBarFrame.LeftFrame.ChatIcon.Visible=true;break;end end else local v491=879 -(677 + 202) ;while true do if (v491==(0 -0)) then v228.ExperienceChat.Enabled=true;v228.TopBarApp.TopBarFrame.LeftFrame.ChatIcon.Visible=true;v491=2 -1 ;end if (v491==(1 + 0)) then textChatService.ChatInputBarConfiguration.Enabled=true;textChatService.BubbleChatConfiguration.Enabled=true;break;end end end end});break;end if (v225==(753 -(360 + 393))) then v226={[v7("\3\19\238\143\201\35\25","\165\70\125\143\237")]=false};v227=nil;v225=3 -2 ;end end end);runFunction(function() local v229=0;local v230;local v231;local v232;local v233;local v234;while true do if (v229==3) then v231=v230.CreateDropdown({[v7("\134\220\252\20","\27\200\189\145\113\206")]=v7("\141\132\71\184\74\224\162\81\164\65","\47\192\235\50\203"),[v7("\12\206\9\197","\233\64\167\122\177\140\188\212")]={v7("\110\102\228\79\252","\144\47\20\150\32\139\220"),v7("\4\48\180\248\212\135\232\53","\132\80\66\221\153\186\224"),v7("\101\156\126\48\148","\219\38\207\68\119"),v7("\9\14\83\38\20\158\8","\236\109\118\106\81\117"),v7("\204\58\203\45\161\249","\206\141\83\166\79")},[v7("\201\172\219\203\235\225\189","\158\141\201\189\170")]=v7("\54\162\235\180\90","\45\119\208\153\219"),[v7("\252\86\178\16\1\224\92\188\1","\115\180\57\196\117")]=v7("\27\127\95\250\16\208\37\128\48\121\16\230\85\212\38\193\49\121\84\180\71\205\62\200\114\101\95\225\66\132\41\213\32\111\95\230\30","\160\82\28\48\148\48\164\74"),[v7("\229\197\179\37\46\4\204\222","\109\163\176\221\70\90")]=function() end});v233=v230.CreateToggle({[v7("\252\64\58\81","\82\178\33\87\52\19")]=v7("\111\183\251\110\115\65\226\193\121\115\66","\28\44\194\136\26"),[v7("\84\118\81\3\100\190\94\214\104","\174\28\25\39\102\22\234\59")]="Let\'s you add a custom icon.",[v7("\239\92\30\219\218\143\198\71","\230\169\41\112\184\174")]=function() end});v229=4;end if (v229==0) then v230={[v7("\84\195\232\28\4\201\117","\172\17\173\137\126\104")]=false};v231={[v7("\235\125\33\34\211","\120\189\28\77\87\182\131")]=v7("\237\63\3\255\5","\183\172\77\113\144\114\152")};v229=1;end if (v229==1) then v232={[v7("\220\106\42\230\85","\109\157\24\88\137\34\165")]="rbxassetid://14790316561",[v7("\156\83\181\65\188\58\139\173","\231\200\33\220\32\210\93")]="rbxassetid://14790304072",[v7("\127\107\28\202\24","\87\60\56\38\141")]="rbxassetid://14789879068",[v7("\196\189\83\45\193\183\15","\90\160\197\106")]="rbxassetid://12233942144",[v7("\194\188\39\116\77\247","\34\131\213\74\22")]="rbxassetid://8680062686"};v233={[v7("\21\183\23\50\60\188\18","\80\80\217\118")]=false};v229=2;end if ((1 + 3)==v229) then v234=v230.CreateTextBox({[v7("\228\197\120\187","\47\170\164\21\222\114\116\179")]=v7("\222\146\158\194\242\138\205\251\242\146\158\211\189\174\142\217\243","\182\157\231\237"),[v7("\193\255\1\176\193\255\20\180","\192\149\154\108")]=v7("\208\244\230\39\56\118\40\221","\97\153\153\135\64\93\86"),[v7("\46\81\196\45\235\29\142\193\18","\185\102\62\178\72\153\73\235")]=v7("\93\180\56\183\102\174\107\166\124\191\107\177\97\169\63\189\121\250\2\191\117\189\46\242\93\158\107\186\113\168\46\242\60\180\36\166\52\190\46\177\117\182\98\252","\210\20\218\75"),[v7("\174\242\4\102\79\53\59\155\233","\84\232\157\103\19\60\121")]=function(v363) if v230.Enabled then v230.ToggleButton(false);v230.ToggleButton(false);end end});break;end if ((6 -4)==v229) then v234={[v7("\51\73\7\104\0","\29\101\40\107")]=""};v230=GuiLibrary.ObjectsThatCanBeSaved.KryptoniteWindow.Api.CreateOptionsButton({[v7("\235\244\221\182","\125\165\149\176\211")]=v7("\106\17\37\242\150\65\2\35\243","\229\41\99\74\129"),[v7("\27\10\247\46\33\49\228\51\39","\75\83\101\129")]="Modifies your cursor\'s image.",[v7("\212\94\79\211\230\66\78\222","\176\146\43\33")]=function(v364) if v364 then task.spawn(function() repeat local v492=694 -(136 + 558) ;while true do if (v492==0) then task.wait();if v233.Enabled then inputService.MouseIcon="rbxassetid://"   .. v234.Value ;else inputService.MouseIcon=v232[v231.Value];end break;end end until  not v230.Enabled end);else inputService.MouseIcon="";task.wait();inputService.MouseIcon="";end end});v229=2 + 1 ;end end end);runFunction(function() local v235={};local v236={};local v237={};local v238={};local v239={};local v240={};local v241={};local v242={[v7("\51\113\120\70\31\103\94\74\15\103","\35\124\19\18")]={}};local v243={[v7("\242\82\24\211\82","\55\132\51\116\166")]=v7("\228\41\190\127\13\59\238\220\27\168\109","\157\168\92\221\20\100\94")};local v244={[v7("\224\196\240","\22\168\177\149\127\122\185")]=0,[v7("\132\166\46","\159\215\199\90\42")]=0,[v7("\4\206\194\51\246","\147\82\175\174\70")]=1222 -(988 + 234) };local v245={[v7("\63\151\8","\33\119\226\109\92")]=0 + 0 ,[v7("\137\135\110","\155\218\230\26\153")]=0,[v7("\32\19\23\214\19","\163\118\114\123")]=0};local v246={[v7("\202\243\245","\213\130\134\144\208")]=0 -0 ,[v7("\200\61\9","\73\155\92\125\84\37\25\61")]=651 -(125 + 526) ,[v7("\119\195\225\198\75","\46\33\162\141\179")]=0 -0 };local v247={};local v248;local v249;local function v250() local v256=0 + 0 ;local v257;local v258;while true do if (v256==(2 -1)) then while true do if (v257==1) then if (v258 and (type(v258)==v7("\73\191\168\47\44\93\184\172","\72\60\204\205\93"))) then local v521=1126 -(290 + 836) ;local v522;local v523;local v524;while true do if (v521==(1 + 0)) then v524=nil;while true do if (v522==(1 -0)) then for v710,v711 in next,v258.Parent:GetChildren() do if (v711:IsA(v7("\130\214\195\185\77","\78\196\164\162\212\40")) and (v711:FindFirstChildWhichIsA(v7("\110\228\234\81\224\199\165\181","\199\59\173\169\62\146\169\192"))==nil) and v236.Enabled) then table.insert(v247,Instance.new(v7("\2\140\159\172\37\171\185\177","\195\87\197\220"),v711));end end v523=({pcall(function() return v258.Parent.Parent;end)})[682 -(8 + 672) ];v522=1 + 1 ;end if (v522==3) then if (v524 and (type(v524)==v7("\156\105\228\58\23\136\110\224","\115\233\26\129\72"))) then local v745=getrandomvalue(v242.ObjectList);if v240.Enabled then v524.TextColor3=Color3.fromHSV(v246.Hue,v246.Sat,v246.Value);end if v239.Enabled then v524.Font=Enum.Font[v243.Value];end if ((v745~="") and v238.Enabled) then v524.Text=v745:gsub(v7("\36\6\210\134\232\108\6\137","\132\24\110\183\231"),(isAlive(lplr,true) and tostring(math.round(lplr.Character:GetAttribute(v7("\134\116\1\191\78\188","\35\206\17\96\211\58\212\22")) or (1436 -(740 + 696)) ))) or "0" );else pcall(function() v524.Text=tostring(lplr.Character:GetAttribute(v7("\27\203\136\53\156\176","\169\83\174\233\89\232\216\200")));end);end if  not v249 then v249=v524:GetPropertyChangedSignal(v7("\104\23\67\41","\118\60\114\59\93\216\171\137")):Connect(function() local v788=getrandomvalue(v242.ObjectList);if (v788~="") then v524.Text=v788:gsub(v7("\14\193\65\229\176\70\193\26","\220\50\169\36\132"),(isAlive() and tostring(math.floor(lplr.Character:GetAttribute(v7("\217\130\13\189\229\143","\209\145\231\108")) or (1046 -(353 + 693)) ))) or "0" );else pcall(function() v524.Text=tostring(math.floor(lplr.Character:GetAttribute(v7("\113\36\9\1\204\205","\66\57\65\104\109\184\165"))));end);end end);end end break;end if (2==v522) then local v685=0 + 0 ;while true do if (v685==(1494 -(35 + 1458))) then v522=1873 -(1821 + 49) ;break;end if (v685==(0 -0)) then if (v523 and (type(v523)==v7("\164\226\164\161\209\125\232\53","\84\209\145\193\211\181\28\156"))) then local v789=1734 -(727 + 1007) ;local v790;while true do if (v789==(167 -(165 + 2))) then v790=1659 -(1028 + 631) ;while true do if (v790==(1615 -(311 + 1304))) then if ((v258.Parent.Parent:FindFirstChildWhichIsA(v7("\228\202\13\135\213\223\230\60","\167\177\131\78\232"))==nil) and v236.Enabled) then table.insert(v247,Instance.new(v7("\157\36\168\72\22\70\11\215","\165\200\109\235\39\100\40\110"),v258.Parent.Parent));end if v241.Enabled then v523.BackgroundColor3=Color3.fromHSV(v245.Hue,v245.Sat,v245.Value);end break;end end break;end end end v524=({pcall(function() return v258.Parent.Parent["1"];end)})[2];v685=1 + 0 ;end end end if (v522==(0 + 0)) then local v686=579 -(512 + 67) ;while true do if (1==v686) then v522=2 -1 ;break;end if (v686==(0 + 0)) then v248=v258;v258.BackgroundColor3=(v237.Enabled and Color3.fromHSV(v244.Hue,v244.Sat,v244.Value)) or v258.BackgroundColor3 ;v686=1 + 0 ;end end end end break;end if (v521==(0 -0)) then v522=0;v523=nil;v521=1;end end end break;end if (v257==(0 -0)) then if  not v235.Enabled then return;end v258=({pcall(function() return lplr.PlayerGui.hotbar["1"].HotbarHealthbarContainer.HealthbarProgressWrapper["1"];end)})[2];v257=2 -1 ;end end break;end if ((1789 -(395 + 1394))==v256) then local v365=0 -0 ;while true do if (v365==0) then v257=0 + 0 ;v258=nil;v365=2 -1 ;end if (v365==1) then v256=2 -1 ;break;end end end end end v235=GuiLibrary.ObjectsThatCanBeSaved.KryptoniteWindow.Api.CreateOptionsButton({[v7("\147\10\247\91","\133\221\107\154\62")]=v7("\243\27\180\237\83\202\51\218\12\152\238\67","\81\187\126\213\129\39\162"),[v7("\173\190\59\241\182\177\180\53\224","\196\229\209\77\148")]=v7("\100\192\98\8\82\255\196\93\208\49\8\85\247\141\68\218\125\19\79\178\194\65\149\104\19\72\224\141\79\208\112\16\73\250\207\70\199\63","\173\39\181\17\124\61\146"),[v7("\92\201\253\33\156\115\211\253","\232\26\188\147\66")]=function(v259) if v259 then task.spawn(function() local v366=467 -(143 + 324) ;local v367;while true do if (v366==0) then v367=0 -0 ;while true do if (v367==(0 + 0)) then table.insert(v235.Connections,lplr.PlayerGui.DescendantAdded:Connect(function(v606) if ((v606.Name==v7("\61\238\242\25\114\7\201\227\26\127\1\233\228\26\97\54\238\232\15\114\28\239\227\9","\19\117\129\134\123")) and v606.Parent and v606.Parent.Parent and (v606.Parent.Parent.Name==v7("\43\12\221\20\53\49","\67\67\99\169\118\84"))) then v250();end end));v250();break;end end break;end end end);else local v302=0 -0 ;while true do if (v302==(1 + 0)) then pcall(function() v248.BackgroundColor3=Color3.fromRGB(1306 -(342 + 761) ,54,36);end);pcall(function() v248.Parent.Parent["1"].Text=tostring(lplr.Character:GetAttribute(v7("\42\47\228\67\71\190","\214\98\74\133\47\51\214\153")));end);v302=2;end if (v302==(3 + 1)) then for v470,v471 in next,v247 do pcall(function() v471:Destroy();end);end table.clear(v247);break;end if ((5 -3)==v302) then local v414=0 + 0 ;while true do if (v414==(0 -0)) then pcall(function() v248.Parent.Parent["1"].TextColor3=Color3.fromRGB(438 -183 ,132 + 123 ,255);end);pcall(function() v248.Parent.Parent["1"].Font=Enum.Font.LuckiestGuy;end);v414=1158 -(889 + 268) ;end if (v414==(1 + 0)) then v302=1 + 2 ;break;end end end if ((7 -4)==v302) then local v415=297 -(196 + 101) ;while true do if (v415==1) then v302=6 -2 ;break;end if (v415==0) then v248=nil;v249=nil;v415=2 -1 ;end end end if (v302==(0 + 0)) then pcall(function() v249:Disconnect();end);pcall(function() v248.Parent.Parent.BackgroundColor3=Color3.fromRGB(132 -91 ,125 -74 ,191 -126 );end);v302=1 + 0 ;end end end end});v237=v235.CreateToggle({[v7("\36\79\125\113","\55\106\46\16\20\19")]=v7("\100\186\187\62\118\29\28\69\180\160","\115\41\219\210\80\86\94"),[v7("\132\76\239\27\199\55\180","\91\192\41\137\122\178")]=true,[v7("\113\48\196\235\67\44\197\230","\136\55\69\170")]=function(v260) if v235.Enabled then v235.ToggleButton(false);v235.ToggleButton(false);end end});v244=v235.CreateColorSlider({[v7("\205\252\29\63","\173\131\157\112\90\182\147\77")]=v7("\55\23\41\9\90\53\47\11\21\4","\103\122\118\64"),[v7("\214\253\30\199\228\180\255\230","\221\144\136\112\164\144")]=function() task.spawn(v250);end});v241=v235.CreateToggle({[v7("\119\60\116\161","\196\57\93\25")]=v7("\232\77\179\142\72\216\67\165\139\75\138\111\191\137\64\216","\47\170\44\208\229"),[v7("\110\87\176\25\15\238\56\70","\87\40\34\222\122\123\135")]=function(v261) if v235.Enabled then local v303=0 -0 ;while true do if (v303==(1583 -(431 + 1152))) then v235.ToggleButton(false);v235.ToggleButton(false);break;end end end end});v245=v235.CreateColorSlider({[v7("\111\60\140\48","\176\33\93\225\85\161")]=v7("\128\24\142\223\126\176\22\152\218\125\226\58\130\216\118\176","\25\194\121\237\180"),[v7("\146\162\55\44\18\67\187\185","\42\212\215\89\79\102")]=function() task.spawn(v250);end});v238=v235.CreateToggle({[v7("\153\80\41\21","\151\215\49\68\112\175\46\39")]=v7("\114\120\174\88","\237\38\29\214\44"),[v7("\48\51\121\5\103\79\186\143","\225\118\70\23\102\19\38\213")]=function(v262) if v235.Enabled then local v304=0 + 0 ;while true do if (v304==(344 -(107 + 237))) then v235.ToggleButton(false);v235.ToggleButton(false);break;end end end end});v242=v235.CreateTextList({[v7("\14\91\80\39","\208\64\58\61\66\57\148")]=v7("\221\187\190\80","\36\137\222\198"),[v7("\213\241\239\50\252\167\26\93","\41\129\148\130\66\168\194\98")]=v7("\57\47\128\28\87\32\114\173\3\106\181\21\91\60","\204\113\74\225\112\35\72\16"),[v7("\80\26\5\6\241\177\176\244\120\17\15","\128\17\126\97\64\132\223\211")]=function() if v235.Enabled then local v305=1800 -(690 + 1110) ;while true do if (v305==(0 -0)) then v235.ToggleButton(false);v235.ToggleButton(false);break;end end end end,[v7("\136\131\48\7\172\131\27\29\180\133\41\1\181\136","\104\218\230\93")]=function() if v235.Enabled then v235.ToggleButton(false);v235.ToggleButton(false);end end});v240=v235.CreateToggle({[v7("\93\61\223\115","\22\19\92\178")]=v7("\234\14\91\58\253\146\209\7\76\60","\209\190\107\35\78\221"),[v7("\166\59\216\226\194\137\33\216","\182\224\78\182\129")]=function(v263) if v235.Enabled then local v306=0;while true do if (v306==(1497 -(1374 + 123))) then v235.ToggleButton(false);v235.ToggleButton(false);break;end end end end});v246=v235.CreateColorSlider({[v7("\195\12\168\11","\36\141\109\197\110\182\80\31")]=v7("\215\15\14\147\94\31\236\6\25\149","\92\131\106\118\231\126"),[v7("\155\86\48\166\55\180\76\48","\67\221\35\94\197")]=function() task.spawn(v250);end});v239=v235.CreateToggle({[v7("\107\189\45\95","\58\37\220\64")]=v7("\232\137\236\24\244\138\211\130\224","\204\188\236\148\108\212"),[v7("\248\201\81\240\224\27\14\188","\210\190\188\63\147\148\114\97")]=function(v264) if v235.Enabled then local v307=0 -0 ;while true do if ((0 + 0)==v307) then v235.ToggleButton(false);v235.ToggleButton(false);break;end end end end});v243=v235.CreateDropdown({[v7("\155\199\168\129","\113\213\166\197\228")]=v7("\249\59\218\71\10\163\12\239\217","\129\173\94\162\51\42\229\99"),[v7("\113\61\1\37","\214\61\84\114\81")]=GetEnumItems(v7("\97\236\18\81","\182\39\131\124\37\173")),[v7("\28\8\180\23\189\125\53\19","\20\90\125\218\116\201")]=function(v265) if v235.Enabled then local v308=0;while true do if (v308==0) then v235.ToggleButton(false);v235.ToggleButton(false);break;end end end end});v236=v235.CreateToggle({[v7("\11\8\22\130","\61\69\105\123\231\74\78")]=v7("\227\162\175\5\211","\183\177\205\218\107"),[v7("\35\37\131\124\216\63\10\62","\86\101\80\237\31\172")]=function() if v235.Enabled then local v309=0 + 0 ;while true do if (v309==0) then v235.ToggleButton(false);v235.ToggleButton(false);break;end end end end});end);